// export const SERVER = 'http://ec2-18-216-169-21.us-east-2.compute.amazonaws.com:9002';
export const SERVER = 'http://localhost:8082';
// export const SERVER = 'https://ec2-18-222-206-235.us-east-2.compute.amazonaws.com:9083';
