import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {SERVER} from '../server';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {FactoryService} from '../shared/services';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  public userId: string;
  public pass: string;
  public userName: string;
  public password: string;
  public masterPass: string;
  public showReset = false;

  constructor(public router: Router, route: ActivatedRoute, private http: HttpClient, private fs: FactoryService) {
    this.showReset = false;
    this.showReset = route.snapshot.queryParams['showReset'];
    console.log('Reset enabled ' + this.showReset);
    const roles = localStorage.getItem('roles');
    if (roles != null && roles.indexOf('ADMIN', 0) > -1) {
      this.showReset = true;
    }
  }

  ngOnInit() {
  }

  onLoggedin() {
    // console.log('User Id  : ' + this.userId + ' p : ' + this.pass);
    const url = SERVER + '/posvcs/access/login';
    // console.log('Login script ' + this.loginForm);
    this.http.get<Array<String>>(url, {
      withCredentials: true,
      headers: new HttpHeaders().set('Content-Type', 'application/json')
        .set('Authorization', 'Basic ' + btoa(this.userId + ':' + this.pass)),
      observe: 'response'
    })
      .subscribe(resp => {
          console.log(resp);
          console.log(resp.headers.get('Set-Cookie'));
          console.log(resp.headers.get('X-QQ-Auth-roles'));
          localStorage.setItem('isLoggedin', 'true');
          localStorage.setItem('loggedUser', this.userId);
          localStorage.setItem('roles', resp.headers.get('X-QQ-Auth-roles'));
          this.router.navigate(['/layout/welcome']);
        },
        err => {
          console.log('Login error');
          localStorage.setItem('isLoggedin', 'false');
        }
      );
  }

  resetPassword() {
    console.log(' User : ' + this.userName + '  Password : ' + this.password);
    const headers = this.fs.getHttpHeaders();
    const url = SERVER + '/spasvcs/access/reset';
    const postData = '{"userName":"' + this.userName + '", "password":"' + this.password + '", "masterPass":"' + this.masterPass + '"}';
    this.http.post(url, postData, {
      withCredentials: true,
      headers: headers
    })
      .subscribe(resp => {
          console.log(resp);
        },
        err => {
          console.log('Login error');
        }
      );
  }
}
