import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {CustomerRoutingModule} from './customer-routing.module';
import {CustomerComponent} from './customer.component';
import {CustsearchComponent} from './custsearch/custsearch.component';
import {ReactiveFormsModule} from '@angular/forms';
import {MatDatepickerModule, MatFormFieldModule, MatNativeDateModule} from '@angular/material';

@NgModule({
  declarations: [
    CustomerComponent,
    CustsearchComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule, MatFormFieldModule, MatNativeDateModule, MatDatepickerModule,
    CustomerRoutingModule
  ]
})
export class CustomerModule {
}
