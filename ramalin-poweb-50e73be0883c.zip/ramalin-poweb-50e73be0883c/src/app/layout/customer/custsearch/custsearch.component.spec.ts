import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustsearchComponent } from './custsearch.component';

describe('CustsearchComponent', () => {
  let component: CustsearchComponent;
  let fixture: ComponentFixture<CustsearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustsearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustsearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
