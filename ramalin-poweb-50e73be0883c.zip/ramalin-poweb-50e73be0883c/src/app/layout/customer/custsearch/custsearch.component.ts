import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {Customer} from '../../../model/customer';
import {HttpClient} from '@angular/common/http';
import {ActivatedRoute, Router} from '@angular/router';
import {FactoryService} from '../../../shared/services';
import {SERVER} from '../../../server';

@Component({
  selector: 'app-custsearch',
  templateUrl: './custsearch.component.html',
  styleUrls: ['./custsearch.component.scss']
})
export class CustsearchComponent implements OnInit {
  errorMsg: string;
  searchForm: FormGroup;
  searchResult: Array<Customer> = [];

  constructor(private fb: FormBuilder, private http: HttpClient,
              route: ActivatedRoute, private router: Router, private fs: FactoryService) {
    this.createSearchCriteriaForm(this.fb);
  }

  ngOnInit() {
  }

  createSearchCriteriaForm(fb: FormBuilder) {
    this.searchForm = fb.group({
      'customerName': [null],
      'taxId': [null]
    });
  }

  submitForm(postData) {
    console.log(postData);
    this.errorMsg = null;
    let searchData = '';
    for (const field of Object.keys(postData)) {
      if (postData[field]) {
        searchData = searchData + field + '=' + postData[field] + '&';
      }
    }
    console.log('searchData: ' + searchData);
    this.getDataToService(searchData);
  }

  getDataToService(postData) {
    const url = SERVER + '/spasvcs/massage/form/search' + '?' + postData;
    const headers = this.fs.getHttpHeaders();
    this.http.get<Array<Customer>>(url, {
      withCredentials: true,
      headers: headers
    })
      .subscribe(data => {
        console.log(data);
        this.searchResult = <Array<Customer>> data;
      });
  }

  onViewClient(clientId) {
    console.log(clientId);
    this.router.navigate(['/massage', {customerId: clientId}]);
  }
}
