import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss']
})
export class CustomerComponent implements OnInit {
  showSearch: boolean;
  customerId: number;

  constructor() {
    this.showSearch = true;

   }

  ngOnInit() {
  }
  hideSearch(customerId: number){
    console.log('Event Triggered - Part Id ' + customerId);
    this.customerId = customerId;
    this.showSearch = false;
  }

}
