import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-po-line-item',
  templateUrl: './po-line-item.component.html',
  styleUrls: ['./po-line-item.component.css']
})
export class PoLineItemComponent implements OnInit {
  poLineItem = JSON.parse(localStorage.getItem('PO_LINE'));

  constructor() {
   console.log("poEach",this.poLineItem)
   }

  ngOnInit() {

  }

}
