import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {PurchorderComponent} from './purchorder.component';
import {PoEditComponent} from './po-edit/po-edit.component';

const routes: Routes = [
    {
        path: '',
        component: PurchorderComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class PurchorderRoutingModule {}
