import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PurchorderComponent } from './purchorder.component';

describe('PurchorderComponent', () => {
  let component: PurchorderComponent;
  let fixture: ComponentFixture<PurchorderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PurchorderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PurchorderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
