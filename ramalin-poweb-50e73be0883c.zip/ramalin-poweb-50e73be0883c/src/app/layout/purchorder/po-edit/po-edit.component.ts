import {Component, Input, OnInit} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {ActivatedRoute, Router} from '@angular/router';
import {FactoryService, PicklistService} from '../../../shared/services';
import {HttpClient} from '@angular/common/http';
import {SERVER} from '../../../server';
import {PurchOrder} from '../../../model/purchorder';

@Component({
  selector: 'app-po-edit',
  templateUrl: './po-edit.component.html',
  styleUrls: ['./po-edit.component.css']
})
export class PoEditComponent implements OnInit {
  @Input('poId') poIdEdited: number;
  title: String;
  errorMsg: String;
  dataSubmitted: boolean;
  poForm: FormGroup;

  PoLineItem: FormGroup;
  poLineItems = [];


  constructor(private fb: FormBuilder, private http: HttpClient,
              route: ActivatedRoute, private router: Router, private fs: FactoryService) {
  }

  ngOnInit() {
    // this.fetchPickListValues();
    this.createNewPo();
    if (this.poIdEdited > 0) {
      this.retrievePo();
    }
  }

  createPoForm(fb: FormBuilder) {
    this.poForm = fb.group({
      companyId: [null],
      id: [null],
      poNumber: [null],
      poDate: [null],
      department: [null],
      coRespPerson: [null],
      qqRespPerson: [null],
      vendorId: [null],
      dvryAddrId: [null],
      dvryTerms: [null],
      pymntTerms: [null],
      billToAddrId: [null],
      poLineItems: fb.array([ this.createPoLineItem(fb) ])
    });
  }

  createPoLineItem(fb: FormBuilder) {
    this.PoLineItem =  fb.group( {
      item: [null],
      material: [null],
      revision: [null],
      description: [null],
      quantity: [null],
      unit: [null],
      pricePerUnit: [null],
      createdDt: [null],
      modifiedDt: [null],
      createdBy: [null],
      modifiedBy: [null]
    });
  }


  displayExistingForm(fb: FormBuilder, retrieved: PurchOrder) {
    console.log("data",retrieved.poLineItems)
    this.poLineItems = retrieved.poLineItems
    this.poForm = fb.group({
      companyId: retrieved.companyId,
      id: retrieved.id,
      poNumber: retrieved.poNumber,
      poDate: retrieved.poDate,
      department: retrieved.department,
      coRespPerson: retrieved.coRespPerson,
      qqRespPerson: retrieved.qqRespPerson,
      vendorId: retrieved.vendorId,
      dvryAddrId: retrieved.dvryAddrId,
      dvryTerms: retrieved.dvryTerms,
      pymntTerms: retrieved.pymntTerms,
      billToAddrId: retrieved.billToAddrId,
      poLineItems: fb.array([ this.createPoLineItem(fb) ])
    });
  }
  fillPoLineItemDetail(poLineItem) {
    console.log("poline",poLineItem)
    this.PoLineItem = this.fb.group( {
      item: poLineItem.item,
      material: poLineItem.material,
      revision: poLineItem.revision,
      description: poLineItem.description,
      quantity: poLineItem.quantity,
      unit:poLineItem.unit,
      pricePerUnit: poLineItem.pricePerUnit,
      createdDt: [null],
      modifiedDt: [null],
      createdBy: [null],
      modifiedBy: [null]
    });
  }

  retrievePo() {
    this.title = 'Edit';
    this.retrievePoFromService();
  }

  createNewPo() {
    this.title = 'Create';
    this.createPoForm(this.fb);
  }

  retrievePoFromService() {
    const url = SERVER + '/posvcs/po/search/byId' + '?id=' + this.poIdEdited;
    const headers = this.fs.getHttpHeaders();
    this.http.get<PurchOrder>(url, {
      withCredentials: true,
      headers: headers
    })
      .subscribe(data => {
        console.log(data);
        this.displayExistingForm(this.fb, data);
      });
  }

  submitForm(postData) {
    const url = SERVER + '/posvcs/po/save';
    this.errorMsg = null;
    const headers = this.fs.getHttpHeaders();
    this.http.post(url, postData, {
      withCredentials: true,
      headers: headers
    })
      .subscribe(data => {
        console.log(data);
        this.dataSubmitted = true;
        this.poIdEdited = data['id'];
      });
  }
}
