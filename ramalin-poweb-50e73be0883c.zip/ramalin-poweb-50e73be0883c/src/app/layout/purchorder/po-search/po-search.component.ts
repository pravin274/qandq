import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {HttpClient} from '../../../../../node_modules/@angular/common/http';
import {ActivatedRoute, Router} from '@angular/router';
import {FactoryService} from '../../../shared/services';
import {SERVER} from '../../../server';
import {PurchOrder} from '../../../model/purchorder';

@Component({
  selector: 'app-po-search',
  templateUrl: './po-search.component.html',
  styleUrls: ['./po-search.component.css']
})
export class PoSearchComponent implements OnInit {
  errorMsg: string;
  searchForm: FormGroup;
  searchResult: Array<PurchOrder> = [];
  @Output() itemFound = new EventEmitter<number>();

  dateConfig : any = {
    dateInputFormat: 'DD-MM-YYYY' ,
    containerClass:'theme-blue'
  }

  constructor(private fb: FormBuilder, private http: HttpClient,
              route: ActivatedRoute, private router: Router, private fs: FactoryService) {
    this.createSearchCriteriaForm(this.fb);
  }

  ngOnInit() {
  }

  createSearchCriteriaForm(fb: FormBuilder) {
    this.searchForm = fb.group({
      'companyId': [null],
      'poNumber': [null],
      'poDate': [null],
      'department': [null],
      'vendorId': [null]
    });
  }

  submitForm(postData) {
    console.log(postData);
    this.errorMsg = null;
    let searchData = '';
    for (const field of Object.keys(postData)) {
      if (postData[field]) {
        searchData = searchData + field + '=' + postData[field] + '&';
      }
    }
    console.log('searchData: ' + searchData);
    this.getDataToService(searchData);
  }

  getDataToService(postData) {
    const url = SERVER + '/posvcs/po/form/search' + '?' + postData;
    const headers = this.fs.getHttpHeaders();
    this.http.get<Array<PurchOrder>>(url, {
      withCredentials: true,
      headers: headers
    })
      .subscribe(data => {
        console.log("--data--",data);
        this.searchResult = <Array<PurchOrder>> data;
      });
  }


  onViewPo(poId) {
    console.log(poId);
    this.itemFound.emit(poId);
  }

  onAddPo() {
    this.itemFound.emit(0);
  }
  onViewPOTest() {
      console.log("Test");


      // this.router.navigate(['/massage', {customerId: clientId}]);
    }
}
