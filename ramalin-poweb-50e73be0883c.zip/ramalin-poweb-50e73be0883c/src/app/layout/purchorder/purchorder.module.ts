import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {PurchorderComponent} from './purchorder.component';
import {ReactiveFormsModule} from '@angular/forms';
import {MatDatepickerModule, MatFormFieldModule, MatNativeDateModule} from '@angular/material';
import {PurchorderRoutingModule} from './purchorder-routing.module';
import {PoSearchComponent} from './po-search/po-search.component';
import { PoEditComponent } from './po-edit/po-edit.component';


@NgModule({
  declarations: [
    PurchorderComponent,
    PoSearchComponent,
    PoEditComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule, MatFormFieldModule, MatNativeDateModule, MatDatepickerModule,
    PurchorderRoutingModule
  ]
})
export class PurchOrderModule  { }
