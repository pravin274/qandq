import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchorder',
  templateUrl: './purchorder.component.html',
  styleUrls: ['./purchorder.component.css']
})
export class PurchorderComponent implements OnInit {
  showSearch: boolean;
  poId: number;

  constructor() {
    this.showSearch = true;
  }

  ngOnInit() {


  }
  onViewPO(){
  console.log("Test")
  }

  hideSearch(poId: number){
    console.log('Event Triggered - Po Id ' + poId);
    this.poId = poId;
    this.showSearch = false;
  }
}
