import {Component, Input, OnInit} from '@angular/core';
import {SERVER} from '../../../server';
import {Part} from '../../../model/part';
import {FormBuilder, FormGroup} from '@angular/forms';
import {HttpClient} from '../../../../../node_modules/@angular/common/http';
import {ActivatedRoute, Router} from '@angular/router';
import {FactoryService, PicklistService} from '../../../shared/services';

@Component({
  selector: 'app-part-edit',
  templateUrl: './part-edit.component.html',
  styleUrls: ['./part-edit.component.css']
})
export class PartEditComponent implements OnInit {
  @Input('partId') partIdEdited: number;
  title: String;
  errorMsg: String;
  dataSubmitted: boolean;
  partForm: FormGroup;
  // pickList values
  partCategoryValues = new Map<String, String>();
  partWeightUnitValues = new Map<String, String>();

  constructor(private fb: FormBuilder, private http: HttpClient,
              route: ActivatedRoute, private router: Router, private fs: FactoryService,
              private pick: PicklistService) {
  }

  ngOnInit() {
    this.fetchPickListValues();
    this.createNewPart();
    if (this.partIdEdited > 0) {
      this.retrievePart();
    }
  }

  createPartForm(fb: FormBuilder) {
    this.partForm = fb.group({
      'id': [null],
      'name': [null],
      'number': [null],
      'partRevNo': [null],
      'partRevDt': [null],
      'partRevOrder': [null],
      'drawingNo': [null],
      'drawingRevNo': [null],
      'drawingRevDt': [null],
      'qqsCode': [null],
      'qqsRevNo': [null],
      'qqsRevDt': [null],
      'projectName': [null],
      'category': [null],
      'materialSpec': [null],
      'castingWt': [null],
      'castingWtUnit': [null],
      'rfqVolume': [null],
      'mbq': [null],
      'uom': [null],
      'resourceInd': [null],
      'createdDt': [null],
      'modifiedDt': [null]
    });
  }

  displayExistingForm(fb: FormBuilder, retrieved: Part) {
    this.partForm = fb.group({
      'id': retrieved.id,
      'name': retrieved.name,
      'number': retrieved.number,
      'partRevNo': retrieved.partRevNo,
      'partRevDt': retrieved.partRevDt,
      'partRevOrder': retrieved.partRevOrder,
      'drawingNo': retrieved.drawingNo,
      'drawingRevNo': retrieved.drawingRevNo,
      'drawingRevDt': retrieved.drawingRevDt,
      'qqsCode': retrieved.qqsCode,
      'qqsRevNo': retrieved.qqsRevNo,
      'qqsRevDt': retrieved.qqsRevDt,
      'projectName': retrieved.projectName,
      'category': retrieved.category,
      'materialSpec': retrieved.materialSpec,
      'castingWt': retrieved.castingWt,
      'castingWtUnit': retrieved.castingWtUnit,
      'rfqVolume': retrieved.rfqVolume,
      'mbq': retrieved.mbq,
      'uom': retrieved.uom,
      'resourceInd': retrieved.resourceInd,
      'createdDt': retrieved.createdDt,
      'modifiedDt': retrieved.modifiedDt
    });
  }

  retrievePart() {
    this.title = 'Edit';
    this.retrievePartFromService();
  }

  createNewPart() {
    this.title = 'Create';
    this.createPartForm(this.fb);
  }

  retrievePartFromService() {
    const url = SERVER + '/posvcs/part/search/byId' + '?id=' + this.partIdEdited;
    const headers = this.fs.getHttpHeaders();
    this.http.get<Part>(url, {
      withCredentials: true,
      headers: headers
    })
      .subscribe(data => {
        console.log(data);
        this.displayExistingForm(this.fb, data);
      });
  }

  submitForm(postData) {
    const url = SERVER + '/posvcs/part/save';
    this.errorMsg = null;
    const headers = this.fs.getHttpHeaders();
    this.http.post(url, postData, {
      withCredentials: true,
      headers: headers
    })
      .subscribe(data => {
        console.log(data);
        this.dataSubmitted = true;
        this.partIdEdited = data['id'];
      });
  }

  fetchPickListValues() {
    this.pick.fetchPickListValues().subscribe(data => {
      const loc = <Map<String, Map<String, String>>>data;
      this.partCategoryValues = loc.get('PART_CATEGORY');
      this.partWeightUnitValues = loc.get('PART_WT_UNIT');
      console.log('PickList for category completed');
    });
  }
}
