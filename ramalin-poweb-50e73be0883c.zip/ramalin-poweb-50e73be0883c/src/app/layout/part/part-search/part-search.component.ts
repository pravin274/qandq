import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {Part} from '../../../model/part';
import {HttpClient} from '../../../../../node_modules/@angular/common/http';
import {ActivatedRoute, Router} from '@angular/router';
import {FactoryService} from '../../../shared/services';
import {SERVER} from '../../../server';

@Component({
  selector: 'app-part-search',
  templateUrl: './part-search.component.html',
  styleUrls: ['./part-search.component.css']
})
export class PartSearchComponent implements OnInit {
  errorMsg: string;
  searchForm: FormGroup;
  searchResult: Array<Part> = [];
  @Output() itemFound = new EventEmitter<number>();

  constructor(private fb: FormBuilder, private http: HttpClient,
              route: ActivatedRoute, private router: Router, private fs: FactoryService) {
    this.createSearchCriteriaForm(this.fb);
  }

  ngOnInit() {
  }

  createSearchCriteriaForm(fb: FormBuilder) {
    this.searchForm = fb.group({
      'name': [null],
      'number': [null],
      'drawingNo': [null],
      'qqsCode': [null],
      'projectName': [null],
      'createdDt': [null]
    });
  }

  submitForm(postData) {
    console.log(postData);
    this.errorMsg = null;
    let searchData = '';
    for (const field of Object.keys(postData)) {
      if (postData[field]) {
        searchData = searchData + field + '=' + postData[field] + '&';
      }
    }
    console.log('searchData: ' + searchData);
    this.getDataToService(searchData);
  }

  getDataToService(postData) {
    const url = SERVER + '/posvcs/part/form/search' + '?' + postData;
    const headers = this.fs.getHttpHeaders();
    this.http.get<Array<Part>>(url, {
      withCredentials: true,
      headers: headers
    })
      .subscribe(data => {
        console.log(data);
        this.searchResult = <Array<Part>> data;
      });
  }

  onViewPart(partId) {
    console.log(partId);
    this.itemFound.emit(partId);
    // this.router.navigate(['/massage', {customerId: clientId}]);
  }

  onAddPart() {
    this.itemFound.emit(0);
  }
}
