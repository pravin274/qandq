import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-part',
  templateUrl: './part.component.html',
  styleUrls: ['./part.component.css']
})
export class PartComponent implements OnInit {
  showSearch: boolean;
  partId: number;

  constructor() {
    this.showSearch = true;
  }

  ngOnInit() {
  }

  hideSearch(partId: number){
    console.log('Event Triggered - Part Id ' + partId);
    this.partId = partId;
    this.showSearch = false;
  }
}
