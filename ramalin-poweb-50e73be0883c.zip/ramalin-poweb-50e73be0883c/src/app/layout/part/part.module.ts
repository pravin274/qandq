import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {ReactiveFormsModule} from '@angular/forms';
import {MatDatepickerModule, MatFormFieldModule, MatNativeDateModule} from '@angular/material';
import {PartRoutingModule} from './part-routing.module';
import {PartComponent} from './part.component';
import { PartSearchComponent } from './part-search/part-search.component';
import { PartEditComponent } from './part-edit/part-edit.component';

@NgModule({
  declarations: [
    PartComponent,
    PartSearchComponent,
    PartEditComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule, MatFormFieldModule, MatNativeDateModule, MatDatepickerModule,
    PartRoutingModule
  ]
})
export class PartModule { }
