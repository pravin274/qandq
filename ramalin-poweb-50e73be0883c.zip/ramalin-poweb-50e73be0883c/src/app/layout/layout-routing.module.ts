import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {LayoutComponent} from './layout.component';

const routes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    children: [
      {path: '', redirectTo: 'welcome'},
      {path: 'customer', loadChildren: './customer/customer.module#CustomerModule'},
      {path: 'purchorder', loadChildren: './purchorder/purchorder.module#PurchOrderModule'},
      {path: 'welcome', loadChildren: './desk/starter-content/welcome-content.module#WelcomeContentModule'},
      {path: 'poadd', loadChildren: './purchorder/purchorder.module#PurchOrderModule'},
      {path: 'part', loadChildren: './part/part.module#PartModule'}
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LayoutRoutingModule {
}
