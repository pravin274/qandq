import {Injectable} from '@angular/core';
import {HttpHeaders} from '@angular/common/http';

@Injectable()
export class FactoryService {
    constructor() {
    }

    getHttpHeaders() {
        let headers = new HttpHeaders();
        headers = headers.append('Content-Type', 'application/json');
        return headers;
    }

    makeQueryString(postData): string {
        let queryString = '';
        for (const field of Object.keys(postData)) {
            if (postData[field]) {
                queryString = queryString + field + '=' + postData[field] + '&';
            }
        }
        return queryString;
    }

    formatDate(date: string): string {
    return new Date(date).toLocaleString('en-US',
        { year: 'numeric', month: 'numeric', day: 'numeric' });
    }
}
