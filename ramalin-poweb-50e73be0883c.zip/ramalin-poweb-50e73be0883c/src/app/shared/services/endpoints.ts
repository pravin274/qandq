// All service end points go here
export const PICK_LIST = '/posvcs/support/picklist';
