export class Codes {
  id: number;
  category: String;
  code: String;
  desc: String;
  activeDt: String;
  expireDt: String;
  notes: String;

  constructor(id: number, category: String, code: String, desc: String, activeDt: String, expireDt: String, notes: String) {
    this.id = id;
    this.category = category;
    this.code = code;
    this.desc = desc;
    this.activeDt = activeDt;
    this.expireDt = expireDt;
    this.notes = notes;
  }
}
