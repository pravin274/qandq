export class Part {
  id: number;
  name: string;
  number: string;
  partRevNo: string;
  partRevDt: string;
  partRevOrder: string;
  drawingNo: string;
  drawingRevNo: string;
  drawingRevDt: string;
  qqsCode: string;
  qqsRevNo: string;
  qqsRevDt: string;
  projectName: string;
  category: string;
  materialSpec: string;
  castingWt: number;
  castingWtUnit: string;
  rfqVolume: number;
  mbq: number;
  uom: string;
  resourceInd: string;
  createdDt: string;
  modifiedDt: string;

  constructor(id: number, name: string, number: string, partRevNo: string, partRevDt: string, partRevOrder: string, drawingNo: string, drawingRevNo: string, drawingRevDt: string, qqsCode: string, qqsRevNo: string, qqsRevDt: string, projectName: string, category: string, materialSpec: string, castingWt: number, castingWtUnit: string, rfqVolume: number, mbq: number, uom: string, resourceInd: string, createdDt: string, modifiedDt: string) {
    this.id = id;
    this.name = name;
    this.number = number;
    this.partRevNo = partRevNo;
    this.partRevDt = partRevDt;
    this.partRevOrder = partRevOrder;
    this.drawingNo = drawingNo;
    this.drawingRevNo = drawingRevNo;
    this.drawingRevDt = drawingRevDt;
    this.qqsCode = qqsCode;
    this.qqsRevNo = qqsRevNo;
    this.qqsRevDt = qqsRevDt;
    this.projectName = projectName;
    this.category = category;
    this.materialSpec = materialSpec;
    this.castingWt = castingWt;
    this.castingWtUnit = castingWtUnit;
    this.rfqVolume = rfqVolume;
    this.mbq = mbq;
    this.uom = uom;
    this.resourceInd = resourceInd;
    this.createdDt = createdDt;
    this.modifiedDt = modifiedDt;
  }
}
