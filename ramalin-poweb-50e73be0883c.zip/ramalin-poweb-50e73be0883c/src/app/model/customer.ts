export class Customer {
  id: number;
  parentId: number;
  name: string;
  type: string;
  desc: string;
  taxId: string;
  hierarchy: number;

  constructor(id: number, parentId: number, name: string, type: string, desc: string, taxId: string, hierarchy: number) {
    this.id = id;
    this.parentId = parentId;
    this.name = name;
    this.type = type;
    this.desc = desc;
    this.taxId = taxId;
    this.hierarchy = hierarchy;
  }
}
