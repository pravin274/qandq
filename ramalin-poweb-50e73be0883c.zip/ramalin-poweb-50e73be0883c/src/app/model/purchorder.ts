export class PurchOrder {
  id: number;
  companyId: number;
  poNumber: string;
  poDate: string;
  department: string;
  coRespPerson: number;
  qqRespPerson: number;
  vendorId: number;
  dvryAddrId: number;
  dvryTerms: string;
  pymntTerms: string;
  billToAddrId: number;
  createdDt: string;
  modifiedDt: string;
  createdBy: number;
  modifiedBy: number;
  poLineItems: PoLineItem[];

  constructor(id: number, companyId: number, poNumber: string, poDate: string, department: string, coRespPerson: number, qqRespPerson: number, vendorId: number, dvryAddrId: number, dvryTerms: string, pymntTerms: string, billToAddrId: number, createdDt: string, modifiedDt: string, createdBy: number, modifiedBy: number, poLineItems: PoLineItem[]) {
    this.id = id;
    this.companyId = companyId;
    this.poNumber = poNumber;
    this.poDate = poDate;
    this.department = department;
    this.coRespPerson = coRespPerson;
    this.qqRespPerson = qqRespPerson;
    this.vendorId = vendorId;
    this.dvryAddrId = dvryAddrId;
    this.dvryTerms = dvryTerms;
    this.pymntTerms = pymntTerms;
    this.billToAddrId = billToAddrId;
    this.createdDt = createdDt;
    this.modifiedDt = modifiedDt;
    this.createdBy = createdBy;
    this.modifiedBy = modifiedBy;
    this.poLineItems = poLineItems;
  }
}

export class PoLineItem {
  id: number;
  poId: number;
  item: string;
  material: string;
  revision: number;
  description: string;
  quantity: number;
  unit: string;
  pricePerUnit: number;
  createdDt: number;
  modifiedDt: number;
  createdBy: string;
  modifiedBy: string;


  constructor(item: string, material: string, revision: number, description: string, quantity: number, unit: string, pricePerUnit: number, createdDt: number, modifiedDt: number, createdBy: string, modifiedBy: string) {
    this.item = item;
    this.material = material;
    this.revision = revision;
    this.description = description;
    this.quantity = quantity;
    this.unit = unit;
    this.pricePerUnit = pricePerUnit;
    this.createdDt = createdDt;
    this.modifiedDt = modifiedDt;
    this.createdBy = createdBy;
    this.modifiedBy = modifiedBy;
  }
}
