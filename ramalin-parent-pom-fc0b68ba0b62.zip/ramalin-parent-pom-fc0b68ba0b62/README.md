# parent-pom
Contains all dependency management for sub modules.
mvn clean install - this will put the parent-pom in your local repository
Please see qqscommons for inheriting this parent pom sample
