-- 18-02-2019 by dhaarun

/*Alter `part` table schema changing casting weight decimal from(10,0) */
ALTER TABLE `qqordermgmnt`.`part` 
CHANGE COLUMN `castingWt` `castingWt` DECIMAL(10,3) NULL DEFAULT NULL ;

/*Add two new category value in codes Table (fastneres and bush) */
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `expireDt`, `notes`, `createdDt`, `modifiedDt`) VALUES ('25', 'PART_CATEGORY', 'FST', 'Fasteners', '2018-12-01 15:04:04', NULL, NULL, '2018-12-27 15:04:12', '2018-12-27 15:04:17');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`, `modifiedDt`) VALUES ('26', 'PART_CATEGORY', 'BUSH', 'Bush', '2018-12-01 15:04:04', '2018-12-27 15:04:12', '2018-12-27 15:04:17');
/*Add one new Stage value in codes Table (first approval state) */
DELETE FROM `qqordermgmnt`.`codes` WHERE (`id` = '7');

----------------------------------------------------------------------------------------------------------------------
-- 19-02-2019 by dhaarun
/*Add companyId in part table Table  for customer name*/
ALTER TABLE `qqordermgmnt`.`part` 
ADD COLUMN `companyId` INT(10) NULL DEFAULT NULL AFTER `modifiedDt`;

/*Alter `part` table schema changing uom chacter 3 to 4 */
ALTER TABLE `qqordermgmnt`.`part` 
CHANGE COLUMN `uom` `uom` CHAR(4) NULL DEFAULT NULL ;

/*Table structure for table `partstandard` */
DROP TABLE IF EXISTS `partstandard`;
CREATE TABLE `partstandard` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `partId` varchar(20) NOT NULL,
  `standardNumber` varchar(500) NOT NULL,
  `standardDescription` varchar(500) NOT NULL,
  `standardSpecificDescription` varchar(500) DEFAULT NULL,
  `revisionNumber` varchar(20) DEFAULT NULL,
  `standardLink` varchar(500) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL, 
  `createdBy` datetime DEFAULT NULL, 
 PRIMARY KEY (`id`)
);
ALTER TABLE `qqordermgmnt`.`partstandard` 
CHARACTER SET = latin1 , COLLATE = latin1_bin ;

/* added new codeassociation picklist */
INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('7', 'PART_RESOURCE', 'Y');
/* added new codes picklist */
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`, `modifiedDt`) VALUES ('27', 'PART_RESOURCE', 'RES', 'Resourcing', '2018-12-01 15:04:04', '2018-12-27 15:04:12', '2018-12-27 15:04:17');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`, `modifiedDt`) VALUES ('28', 'PART_RESOURCE', 'NPI', 'NPI', '2018-12-01 15:04:04', '2018-12-27 15:04:12', '2018-12-27 15:04:17');

---------------------------------------------------------------------------------
--20-02-2019 by dhaarun
INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('8', 'PART_UNIT_MEASUREMENT', 'Y');

/* added new codes picklist */
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`, `modifiedDt`) VALUES ('29', 'PART_UNIT_MEASUREMENT', 'MM', 'Milimeter', '2018-12-01 15:04:04', '2018-12-27 15:04:12', '2018-12-27 15:04:17');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`, `modifiedDt`) VALUES ('30', 'PART_UNIT_MEASUREMENT', 'MTR', 'Meter', '2018-12-01 15:04:04', '2018-12-27 15:04:12', '2018-12-27 15:04:17');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`, `modifiedDt`) VALUES ('31', 'PART_UNIT_MEASUREMENT', 'INCH', 'Inches', '2018-12-01 15:04:04', '2018-12-27 15:04:12', '2018-12-27 15:04:17');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`, `modifiedDt`) VALUES ('32', 'PART_UNIT_MEASUREMENT', 'UNIT', 'Unit', '2018-12-01 15:04:04', '2018-12-27 15:04:12', '2018-12-27 15:04:17');

/* alter PART_WT_UNIT codes meter to lbs */
UPDATE `qqordermgmnt`.`codes` SET `code` = 'LBS', `desc` = 'Lbs' WHERE (`id` = '16');


/*Table structure for table `standard` */
DROP TABLE IF EXISTS `standard`;
CREATE TABLE `qqordermgmnt`.`standard` (
  `id` INT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `standardNumber` VARCHAR(500) NOT NULL,
  `standardDescription` VARCHAR(500) NOT NULL,
  `revisionNumber` VARCHAR(20) NULL,
  `standardLink` VARCHAR(500) NULL,
  `createdDt` DATETIME NULL,
  `createdBy` INT(20) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1
COLLATE = latin1_bin;

/* alter table partstandard*/
DROP TABLE IF EXISTS `partstandard`;
CREATE TABLE `partstandard` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `partId` varchar(20) NOT NULL,
  `standardNumber` varchar(500) NOT NULL,
  `standardDescription` varchar(500) NOT NULL,
  `standardSpecificDescription` varchar(500) DEFAULT NULL,
  `revisionNumber` varchar(20) DEFAULT NULL,
  `standardLink` varchar(500) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL, 
  `createdBy`  INT(20) DEFAULT NULL, 
 PRIMARY KEY (`id`)
);


/*Table structure for table `partcustomerrequirement` */
DROP TABLE IF EXISTS `partcustomerrequirement`;
CREATE TABLE `qqordermgmnt`.`partcustomerrequirement` (
  `id` INT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `partId` INT(20) NOT NULL,
  `noteNumber` VARCHAR(500) NOT NULL,
  `customerRequirement` VARCHAR(500) NOT NULL,
  `createdDt` DATETIME NULL,
  `createdBy` INT(20) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1
COLLATE = latin1_bin;


/*Table structure for table `partrevisionamendment` */
DROP TABLE IF EXISTS `partrevisionamendment`;
CREATE TABLE `qqordermgmnt`.`partrevisionamendment` (
  `id` INT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `partId` INT(20) NOT NULL,
  `revisionNumber` VARCHAR(500) NOT NULL,
  `revisionDescription` VARCHAR(500) NOT NULL,
  `revisionDate` DATETIME DEFAULT NULL,
  `createdDt` DATETIME NULL,
  `createdBy` INT(20) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1
COLLATE = latin1_bin;


INSERT INTO `qqordermgmnt`.`standard` (`id`, `standardNumber`, `standardDescription`, `revisionNumber`, `standardLink`) VALUES ('1', 'Q00020', 'FCD USE ONLY - MATERIAL AND HEAT TREAT CERTIFICATION REQUIREMENTS FOR FLUID CONTROL TRACEABLE COMPONENTS', 'J', '');
INSERT INTO `qqordermgmnt`.`standard` (`id`, `standardNumber`, `standardDescription`, `revisionNumber`, `standardLink`) VALUES ('2', 'Q00021', 'FCD USE ONLY - IDENTIFICATION REQUIREMENTS FOR FLUID CONTROL MATERIALS AND COMPONENTS', 'L', '');
INSERT INTO `qqordermgmnt`.`standard` (`id`, `standardNumber`, `standardDescription`, `revisionNumber`, `standardLink`) VALUES ('3', 'Q00024', 'PRESSURE PUMPING USE ONLY - VISUAL INSPECTION, HANDLING, STORAGE AND SHIPPING REQUIREMENTS FOR FLUID CONTROL EQUIPMENT', 'I', '');
INSERT INTO `qqordermgmnt`.`standard` (`id`, `standardNumber`, `standardDescription`, `revisionNumber`, `standardLink`) VALUES ('4', 'Q00188', 'PRESSURE PUMPING USE ONLY - SKETCHES OF CRITICAL AREAS OF CAST PRODUCT SHAPES - FOR POROSITY ACCEPTANCE CRITERIA', 'N', '');
INSERT INTO `qqordermgmnt`.`standard` (`id`, `standardNumber`, `standardDescription`, `revisionNumber`, `standardLink`) VALUES ('5', 'Q00207', 'FCD USE ONLY - SPECIFICATION FOR WET MAGNETIC PARTICLE EXAMINATION OF MACHINED, CAST, AND FORGED PARTS - API 6A PSL 3 ACCEPTANCE CRITERIA', 'C', '');
INSERT INTO `qqordermgmnt`.`standard` (`id`, `standardNumber`, `standardDescription`, `revisionNumber`, `standardLink`) VALUES ('6', 'Q00303', 'CERTIFICATE OF COMPLIANCE', 'F', '');
INSERT INTO `qqordermgmnt`.`standard` (`id`, `standardNumber`, `standardDescription`, `revisionNumber`, `standardLink`) VALUES ('7', 'Q01205', 'MINIMUM REQUIREMENTS FOR HEAT TREATMENT EQUIPMENT QUALIFICATION', 'D', '');
INSERT INTO `qqordermgmnt`.`standard` (`id`, `standardNumber`, `standardDescription`, `revisionNumber`, `standardLink`) VALUES ('8', 'Q01206', 'GENERAL MATERIAL AND HEAT TREATMENT REQUIREMENTS FOR WELLHEAD, CHRISTMAS TREE, MANIFOLD AND RELATED EQUIPMENT', 'AA', '');
INSERT INTO `qqordermgmnt`.`standard` (`id`, `standardNumber`, `standardDescription`, `revisionNumber`, `standardLink`) VALUES ('9', 'Q01207', 'HEAT TREATMENT OF STEEL PARTS', 'U', '');
INSERT INTO `qqordermgmnt`.`standard` (`id`, `standardNumber`, `standardDescription`, `revisionNumber`, `standardLink`) VALUES ('10', 'Q01209', 'CUSTOM FORGING SPECIFICATION FOR CARBON, LOW ALLOY, MARTENSITIC AND PH STAINLESS STEELS FOR CRITICAL SERVICE', 'M', '');
INSERT INTO `qqordermgmnt`.`standard` (`id`, `standardNumber`, `standardDescription`, `revisionNumber`, `standardLink`) VALUES ('11', 'Q50153', 'FCD USE ONLY - DATA BOOK ELIGIBLE METALLIC COMPONENT', 'A', '');
INSERT INTO `qqordermgmnt`.`standard` (`id`, `standardNumber`, `standardDescription`, `revisionNumber`, `standardLink`) VALUES ('12', 'Q50186', 'FCD USE ONLY - SPECIAL PACKAGING REQUIREMENTS TO PREVENT CORROSION ON METALLIC EQUIPMENT', 'A', '');
INSERT INTO `qqordermgmnt`.`standard` (`id`, `standardNumber`, `standardDescription`, `revisionNumber`, `standardLink`) VALUES ('13', 'PS01060', 'ZINC PHOSPHATING', '021.00', '');
INSERT INTO `qqordermgmnt`.`standard` (`id`, `standardNumber`, `standardDescription`, `revisionNumber`, `standardLink`) VALUES ('14', 'PS01153', 'HEAT TREATMENT OF CASTINGS', '23', '');
INSERT INTO `qqordermgmnt`.`standard` (`id`, `standardNumber`, `standardDescription`, `revisionNumber`, `standardLink`) VALUES ('15', 'M10142 ', 'PRESSURE PUMPING USE ONLY - IRON CASTING - GRAY ASTM A48 CLASS 30', 'C', '');
INSERT INTO `qqordermgmnt`.`standard` (`id`, `standardNumber`, `standardDescription`, `revisionNumber`, `standardLink`) VALUES ('16', 'C85041', 'FCD USE ONLY - COATING SPECIFICATION FOR FMC PUMP RAW CASTINGS AND WELDMENTS', 'B', '');


---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--21-02-2019 by dhaarun

/*Alter the Table structure for table `part` (drop dowm character change) */
ALTER TABLE `qqordermgmnt`.`part` 
CHANGE COLUMN `category` `category` CHAR(5) NULL DEFAULT NULL ,
CHANGE COLUMN `castingWtUnit` `castingWtUnit` CHAR(5) NULL DEFAULT NULL ,
CHANGE COLUMN `uom` `uom` CHAR(5) NULL DEFAULT NULL ,
CHANGE COLUMN `resourceInd` `resourceInd` CHAR(5) NULL DEFAULT NULL ;

/*DROP TABLE PARTSTATUS. PART STATUS NOW STORED IN CHRONOLOGY TABLE*/
-- ***********************************************************
DROP TABLE `qqordermgmnt`.`partstatus`;
-- ***********************************************************


---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--07-03-2019 by dhaarun
/*Adding transport mode,Gstin, IE code and pre carriage in codes table*/
INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('9', 'TRANSPORT_MODE', 'Y');
INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('10', 'GSTIN_CODE', 'Y');
INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('11', 'IE_CODE', 'Y');
INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('12', 'PRE_CARRIAGE', 'Y');


INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`, `modifiedDt`) VALUES ('33', 'TRANSPORT_MODE', 'AIR', 'By - Air', '2018-12-01 15:04:04', '2018-12-27 15:04:12', '2018-12-27 15:04:17');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`, `modifiedDt`) VALUES ('34', 'TRANSPORT_MODE', 'SEA', 'By - Sea', '2018-12-01 15:04:04', '2018-12-27 15:04:12', '2018-12-27 15:04:17');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`, `modifiedDt`) VALUES ('35', 'GSTIN_CODE', 'GSTIN-CODE', '33AAAFQ68880G1Z7', '2018-12-01 15:04:04', '2018-12-27 15:04:12', '2018-12-27 15:04:17');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`, `modifiedDt`) VALUES ('36', 'IE_CODE', 'IE-CODE', 'AAAFQ6880G', '2018-12-01 15:04:04', '2018-12-27 15:04:12', '2018-12-27 15:04:17');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`, `modifiedDt`) VALUES ('37', 'PRE_CARRIAGE', 'ROAD', 'BY ROAD', '2018-12-01 15:04:04', '2018-12-27 15:04:12', '2018-12-27 15:04:17');

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--13-03-2019 by dhaarun
/*Drop the vessel , receipt , dlvry address from the invoice*/
ALTER TABLE `qqordermgmnt`.`invoice`
DROP COLUMN `vessel`,
DROP COLUMN `receiptAddr`,
DROP COLUMN `dlvryAddr`;

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--14-03-2019 by dhaarun
/*Added values in codeAssociations*/
INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('13', 'PLACE_RECEIPT', 'Y');
INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('14', 'DECLARATION', 'Y');



INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`, `modifiedDt`) VALUES ('38', 'PLACE_RECEIPT', 'CJB', 'COIMBATORE', '2018-12-01 15:04:04', '2018-12-27 15:04:12', '2018-12-27 15:04:17');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`) VALUES ('39', 'DECLARATION', 'DEC', 'We declare that this Invoice shows the Actual Price of the Goods described and that all Particulars are True and Correct.', '2018-12-01 15:04:04', '2018-12-27 15:04:12');



ALTER TABLE `qqordermgmnt`.`invoice`
ADD COLUMN `countryOfFinal` INT(20) NULL DEFAULT NULL AFTER `countryOrigin`;

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--15-03-2019 by dhaarun
LOCK TABLES `places` WRITE;
/*!40000 ALTER TABLE `places` DISABLE KEYS */;
INSERT INTO `places` VALUES (1,'IND','INDIA','CRY',NULL,NULL),
(2,'USA','USA','CRY',NULL,NULL),
(3,'GER','GERMANY','CRY',NULL,NULL),
(4,'MAA','CHENNAI','CTY',NULL,NULL),
(5,'CJB','COIMBATORE','CTY',NULL,NULL),
(6,'COK','COCHIN','CTY',NULL,NULL),
(7,'BLR','BENGALURU','CTY',NULL,NULL),
(8,'CJB','COIMBATORE','SUP',NULL,NULL),
(9,'DUB','DUBAI','SUP',NULL,NULL),
(10,'TCR','TUTICORIN','CTY',NULL,NULL),
(11,'PA','PA','CTY',NULL,NULL),
(12,'DFW','DALLAS','CTY',NULL,NULL);
/*!40000 ALTER TABLE `places` ENABLE KEYS */;
UNLOCK TABLES;


---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--18-03-2019 by dhaarun

SQL :

 ALTER TABLE `qqordermgmnt`.`invoice`
CHANGE COLUMN `finalDest` `finalDest` VARCHAR(200) NULL DEFAULT NULL ;

ALTER TABLE `qqordermgmnt`.`invoice`
CHANGE COLUMN `splInstruction` `splInstruction` VARCHAR(300) NULL DEFAULT NULL ;

-- Email table and data
DROP TABLE IF EXISTS `email`;

CREATE TABLE `email` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(20) DEFAULT NULL,
  `parentEntity` varchar(20) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `emailId` varchar(100) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;



LOCK TABLES `email` WRITE;
/*!40000 ALTER TABLE `email` DISABLE KEYS */;
INSERT INTO `email` VALUES (1,1,'H','C','gbaskar@technip.com','2018-12-04 22:02:23',NULL),(2,2,'H','C','kevin.schaaf@fmcti.com','2019-01-28 08:38:28',NULL),(3,3,'H','C','anthony.williams@technipfmc.com',NULL,NULL),(4,4,'H','C','holger.knief@technipfmc.com',NULL,NULL),(5,5,'H','C','ks@sakthigear.com',NULL,NULL),(6,6,'H','C','raja@sakthigear.com',NULL,NULL),(7,7,'H','C','ke@sakthigear.com',NULL,NULL),(8,8,'H','C','sales@futuretechengineers.com',NULL,NULL),(9,9,'H','C','admin@futuretechengineers.com',NULL,NULL),(10,10,'H','C','venkatr@reliancedia.com',NULL,NULL),(11,11,'H','C','aravindd@reliancedia.com',NULL,NULL),(12,13,'H','C','branchdevelopment@sakthigear.com',NULL,NULL);
/*!40000 ALTER TABLE `email` ENABLE KEYS */;
UNLOCK TABLES;


-- Dumping data for table `people`

-- people table and data

DROP TABLE IF EXISTS `people`;

CREATE TABLE `people` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `externalId` varchar(100) DEFAULT NULL,
  `parentType` varchar(5) DEFAULT NULL,
  `parentId` int(20) DEFAULT NULL,
  `category` varchar(5) DEFAULT NULL,
  `firstName` varchar(30) DEFAULT NULL,
  `lastName` varchar(30) DEFAULT NULL,
  `middleInitial` varchar(10) DEFAULT NULL,
  `otherInfo` varchar(300) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;


LOCK TABLES `people` WRITE;
/*!40000 ALTER TABLE `people` DISABLE KEYS */;
INSERT INTO `people` VALUES (1,'1','P',1,'B','Gandhi','Baskar','','','2019-02-11 19:07:20','2019-02-11 19:07:20'),(2,'1','P',1,'B','Kevin','Schaaf','','','2019-02-11 19:07:21','2019-02-11 19:07:21'),(3,'2','P',2,'B','Anthony','Williams','','','2019-02-11 19:07:21','2019-02-11 19:07:21'),(4,'3','P',3,'B','Holger','knief','','','2019-02-11 19:07:21','2019-02-11 19:07:21'),(5,'3','P',4,'B','Shanmugasundaram','','','','2019-02-11 19:07:21','2019-02-11 19:07:21'),(6,'3','P',4,'B','Raja','','','','2019-02-11 19:07:21','2019-02-11 19:07:21'),(7,'3','P',5,'B','Easwaran','','','','2019-02-11 19:07:22','2019-02-11 19:07:22'),(8,'3','P',6,'B','Peter','','','','2019-02-11 19:07:22','2019-02-11 19:07:22'),(9,'3','P',6,'B','Ravi','','','','2019-02-11 19:07:22','2019-02-11 19:07:22'),(10,'3','P',7,'B','Venkat Raman','','','','2019-02-11 19:07:22','2019-02-11 19:07:22'),(11,'3','P',7,'B','Aravindan','','','','2019-02-11 19:07:22','2019-02-11 19:07:22'),(12,'3','V',1,'R','GnanaSekar','','','','2019-02-11 19:07:23','2019-02-11 19:07:23'),(13,'3','P',5,'B','Ranjith',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `people` ENABLE KEYS */;
UNLOCK TABLES;


-- Dumping data for table `phone`


-- phone table and data

DROP TABLE IF EXISTS `phone`;

CREATE TABLE `phone` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(20) DEFAULT NULL,
  `parentEntity` varchar(20) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `phoneNo` varchar(50) DEFAULT NULL,
  `extension` varchar(50) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;



LOCK TABLES `phone` WRITE;
/*!40000 ALTER TABLE `phone` DISABLE KEYS */;
INSERT INTO `phone` VALUES (1,1,'H','C','+919944354704',NULL,'2018-12-12 22:02:01',NULL),(2,2,'H','C','+919944354704',NULL,'2019-01-28 08:38:50',NULL),(3,3,'H','C','+1254965825',NULL,'2019-01-28 08:38:50',NULL),(4,4,'H','C','04101-304 128',NULL,'2019-01-28 08:38:50',NULL),(5,5,'H','C','98943 16663',NULL,'2019-01-28 08:38:50',NULL),(6,6,'H','C','98943 16668',NULL,'2019-01-28 08:38:50',NULL),(7,7,'H','C','98942 16662',NULL,'2019-01-28 08:38:50',NULL),(8,8,'H','C','98437 81220',NULL,'2019-01-28 08:38:50',NULL),(9,9,'H','C','98430 74446',NULL,'2019-01-28 08:38:50',NULL),(10,10,'H','C','94440 67523',NULL,'2019-01-28 08:38:50',NULL),(11,11,'H','C','98418 83849',NULL,NULL,NULL),(12,13,'H','C','80565 51228',NULL,NULL,NULL);
/*!40000 ALTER TABLE `phone` ENABLE KEYS */;
UNLOCK TABLES;

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--19-03-2019 by dhaarun
--  Added the currency and country for picklist
INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('15', 'CURRENCY', 'Y');
INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('16', 'COUNTRY', 'Y');



INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`, `modifiedDt`) VALUES ('40', 'CURRENCY', 'USD', 'USD', '2018-12-01 15:04:04', '2018-12-27 15:04:12', '2018-12-27 15:04:17');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`, `modifiedDt`) VALUES ('41', 'CURRENCY', 'INR', 'INR', '2018-12-01 15:04:04', '2018-12-27 15:04:12', '2018-12-27 15:04:17');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`, `modifiedDt`) VALUES ('42', 'CURRENCY', 'EUR', 'EUR', '2018-12-01 15:04:04', '2018-12-27 15:04:12', '2018-12-27 15:04:17');


INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`, `modifiedDt`) VALUES ('43', 'COUNTRY', 'IND', 'India', '2018-12-01 15:04:04', '2018-12-27 15:04:12', '2018-12-27 15:04:17');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`, `modifiedDt`) VALUES ('44', 'COUNTRY', 'USA', 'USA', '2018-12-01 15:04:04', '2018-12-27 15:04:12', '2018-12-27 15:04:17');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`, `modifiedDt`) VALUES ('45', 'COUNTRY', 'GER', 'EUR', '2018-12-01 15:04:04', '2018-12-27 15:04:12', '2018-12-27 15:04:17');


---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--20-03-2019 by dhaarun
/*Alter `part` table schema changing casting weight decimal from(10,0) */
ALTER TABLE `qqordermgmnt`.`part`
CHANGE COLUMN `castingWt` `castingWt` DECIMAL(10,3) NULL DEFAULT NULL ;



---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--29-03-2019 by dhaarun
/*Alter `standard` table value */
UPDATE `qqordermgmnt`.`standard` SET `revisionNumber` = '22' WHERE (`id` = '13');
UPDATE `qqordermgmnt`.`standard` SET `revisionNumber` = '24' WHERE (`id` = '14');

UPDATE `qqordermgmnt`.`standard` SET `standardDescription` = 'STEEL AND IRON CASTING (AS CAST AND MACHINED) SURFACE EVALUATION AND REPAIR CRITERIA' WHERE (`id` = '20');

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--31-03-2019 by Rama

USE `qqordermgmnt`;

/*Table structure for table `pkgdetail` */

DROP TABLE IF EXISTS `pkgdetail`;

CREATE TABLE `pkgdetail` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `shipId` varchar(100) DEFAULT NULL,
  `pkgType` int(20) DEFAULT NULL,
  `totalQty` int(10) DEFAULT NULL,
  `netWeight` decimal(15,3) DEFAULT NULL,
  `grossWeight` decimal(15,3) DEFAULT NULL,
  `weightUnit` int(20) DEFAULT NULL,
  `height` decimal(10,3) DEFAULT NULL,
  `length` decimal(10,3) DEFAULT NULL,
  `width` decimal(10,3) DEFAULT NULL,
  `dimensionUnit` int(20) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `createdBy` int(20) DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  `modifiedBy` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `pkginvoicexref` */

DROP TABLE IF EXISTS `pkginvoicexref`;

CREATE TABLE `pkginvoicexref` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `pkgId` int(20) DEFAULT NULL,
  `invoiceId` int(20) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- 02-04-2019 -- by dhaarun
INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('17', 'PAYMENT_DECLARATION', 'Y');



INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`) VALUES ('46', 'PAYMENT_DECLARATION', 'IGST', 'Supply Meant for Export On payment of IGST ( IGST PAID ) ', '2019-04-02 15:04:04');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`) VALUES ('47', 'PAYMENT_DECLARATION', 'LUT', 'Supply Meant for Export On LUT AD330818000760A', '2019-04-02 15:04:04');


/*Alter Table structure for table `Invoice Table` */

ALTER TABLE `qqordermgmnt`.`invoice`
ADD COLUMN `paymentDeclaration` VARCHAR(45) NULL DEFAULT NULL AFTER `declaration`,
ADD COLUMN `bankId` INT(10) NULL DEFAULT NULL AFTER `paymentDeclaration`;

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--03-04-22019 -- by dhaarun

CREATE TABLE `qqordermgmnt`.`bank` (
  `id` INT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `bankName` VARCHAR(500) NULL DEFAULT NULL,
  `accountNumber` VARCHAR(50) NULL DEFAULT NULL,
  `ifscCode` VARCHAR(50) NULL DEFAULT NULL,
  `swiftcode` VARCHAR(45) NULL DEFAULT NULL,
  `adCode` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`id`));



---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- 05-April-2019 by Murugesan

ALTER TABLE `qqordermgmnt`.`pkginvoicexref`
ADD COLUMN `qty` INT(10) NULL AFTER `invoiceLineItemId`,
CHANGE COLUMN `invoiceId` `invoiceLineItemId` INT(20) NULL DEFAULT NULL ;

-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- 06-04-2019 by Dhaarun

CREATE TABLE `qqordermgmnt`.`slidocumentchecklist` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `invoiceId` VARCHAR(45) NOT NULL,
  `document` VARCHAR(45) NULL,
  PRIMARY KEY (`id`));


INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('18', 'PACKING_CHECK_LIST', 'Y');


INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('48', 'PACKING_CHECK_LIST', 'INVCOPIES', 'INVOICE (4 COPIES)');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('49', 'PACKING_CHECK_LIST', 'PACKLIST', 'PACKING LIST (4 COPIES)');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('50', 'PACKING_CHECK_LIST', 'SDFFORM', 'SDF FORM IN DUPLICATE');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('51', 'PACKING_CHECK_LIST', 'NONDG', 'NON-DG DECLARATION');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('52', 'PACKING_CHECK_LIST', 'POCOPY', 'PURCHASE ORDER COPY');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('53', 'PACKING_CHECK_LIST', 'GR', 'GR FORM/GR WAIVER');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('54', 'PACKING_CHECK_LIST', 'ARE', 'ARE-1 FORM IN DUPLICATE');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('55', 'PACKING_CHECK_LIST', 'VISA', 'VISA/AEPC ENDORSEMENT');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('56', 'PACKING_CHECK_LIST', 'LAB', 'LAB ANALYSIS REPORT');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('57', 'PACKING_CHECK_LIST', 'MSDS', 'MSDS');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('58', 'PACKING_CHECK_LIST', 'PHYTP', 'PHYTOSANITARY CERT');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('59', 'PACKING_CHECK_LIST', 'GSP', 'GSP CERTIFICATE');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('60', 'PACKING_CHECK_LIST', 'APPENIII', 'APPENDIX III');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('61', 'PACKING_CHECK_LIST', 'ANNEXIV', 'ANNEXURE IV');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('62', 'PACKING_CHECK_LIST', 'LTD', 'LETTER TO DC');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('63', 'PACKING_CHECK_LIST', 'PAT', 'PATMENT ADVICE');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('64', 'PACKING_CHECK_LIST', 'FEMA', 'Export declaration ( FEMA )');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('65', 'PACKING_CHECK_LIST', 'EXPVAL', 'Export Value declaration');



INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('66', 'PART_UNIT_MEASUREMENT', 'CMS', 'Centimetre');
-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- 07-04-2019 by Dhaarun


-- Gstin Number update
UPDATE `qqordermgmnt`.`codes` SET `desc` = '33AAAFQ6880G1Z7' WHERE (`id` = '35');

UPDATE `qqordermgmnt`.`codes` SET `category` = 'PART_UNIT_MEASUREMENT' WHERE (`id` = '66');

-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 08-04-2019 by Murugesan

ALTER TABLE `qqordermgmnt`.`pkgdetail`
RENAME TO  `qqordermgmnt`.`pkgmaster` ;

ALTER TABLE `qqordermgmnt`.`pkginvoicexref`
RENAME TO  `qqordermgmnt`.`pkgdetail` ;

ALTER TABLE `qqordermgmnt`.`pkgmaster`
ADD COLUMN `pkgNo` INT(10) NULL AFTER `id`,
CHANGE COLUMN `modifiedBy` `modifiedBy` INT(20) NULL ;

ALTER TABLE `qqordermgmnt`.`invoice`
ADD COLUMN `currConvRs` DECIMAL(10,3) NULL AFTER `signatory`,
ADD COLUMN `undertakingLUT` CHAR(1) NULL AFTER `currConvRs`;

ALTER TABLE `qqordermgmnt`.`pkgmaster`
CHANGE COLUMN `weightUnit` `weightUnit` VARCHAR(50) NULL DEFAULT NULL ,
CHANGE COLUMN `dimensionUnit` `dimensionUnit` VARCHAR(50) NULL DEFAULT NULL ;

ALTER TABLE `qqordermgmnt`.`slidocumentchecklist`
ADD COLUMN `value` VARCHAR(100) NULL AFTER `document`;

ALTER TABLE `qqordermgmnt`.`slidocumentchecklist`
RENAME TO  `qqordermgmnt`.`slidocuments` ;


-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- 09-04-2019

ALTER TABLE `qqordermgmnt`.`slidocuments`
ADD COLUMN `isDeleted` TINYINT(1) NULL DEFAULT 0 AFTER `value`;

ALTER TABLE `qqordermgmnt`.`pkgmaster`
CHANGE COLUMN `pkgType` `pkgType` VARCHAR(50) NULL DEFAULT NULL ;

ALTER TABLE `qqordermgmnt`.`invoice`
ADD COLUMN `invoiceStatus` VARCHAR(45) NULL DEFAULT 'NEW' AFTER `modifiedDt`;


-- ---------------------------------------------------------------------------------------------------------------------------------------------------

-- 10-04-2019

INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('19', 'PACKAGE_TYPE', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('67', 'PACKAGE_TYPE', 'BOX', 'Box');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('68', 'PACKAGE_TYPE', 'PALLETS', 'Pallets');


INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('20', 'INVOICE_STATUS', 'Y');


INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('69', 'INVOICE_STATUS', 'NEW', 'New');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('70', 'INVOICE_STATUS', 'CANCELED', 'Canceled');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('71', 'INVOICE_STATUS', 'SHIPPED', 'Shipped');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('72', 'INVOICE_STATUS', 'PAYREC', 'Payment Recived');
-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 16-04-19 by dhaarun bank details

INSERT INTO `qqordermgmnt`.`bank` (`id`, `bankName`, `accountNumber`, `ifscCode`, `swiftcode`, `adCode`) VALUES ('1', 'CANARA BANK', '1238257000278', 'CNRB0001238', 'CNRBINBBOXC', '0242214');
-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 19-04-19 by dhaarun par pice table and invoicereftable


ALTER TABLE `qqordermgmnt`.`partprice`
ADD COLUMN `partCategory` VARCHAR(50) NULL DEFAULT NULL AFTER `value`;



CREATE TABLE `qqordermgmnt`.`invoicexrefpo` (
  `id` INT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `invoiceId` INT(20) NOT NULL,
  `poId` INT(20) NOT NULL,
  PRIMARY KEY (`id`));

-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 22-04-19 by dhaarun part pice and currency in poLine item


ALTER TABLE `qqordermgmnt`.`polineitem`
ADD COLUMN `currency` VARCHAR(10) NULL DEFAULT NULL AFTER `unit`,
ADD COLUMN `partPrice` INT(20) NULL DEFAULT NULL AFTER `currency`;

-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 24-04-19 by Murugesan PAN Number in vendor table

ALTER TABLE `qqordermgmnt`.`vendor`
ADD COLUMN `panNo` VARCHAR(45) NULL AFTER `vendorName`,
ADD COLUMN `gstinNo` VARCHAR(20) NULL AFTER `panNo`,
ADD COLUMN `ieCode` VARCHAR(45) NULL AFTER `gstinNo`;

update qqordermgmnt.vendor set panNo = 'AAAFQ6880G', gstinNo = '33AAAFQ6880G1Z7', ieCode = 'AAAFQ6880G'  where vendorid=1;

INSERT INTO `qqordermgmnt`.`address` (`parentId`, `parentEntity`, `type`, `streetNo`, `streetName`, `lineTwo`, `city`, `province`, `country`, `postalCd`, `createdDt`) VALUES ('1', 'V', 'B', 'No 354 C', 'Avarampalayam Road', 'New Sidhapudur', 'Coimbatore', 'TN', 'IN', '641044', '2019-02-11 19:07:18');

ALTER TABLE `qqordermgmnt`.`address`
CHANGE COLUMN `country` `country` VARCHAR(3) NULL DEFAULT NULL ;


update qqordermgmnt.address set country = 'USA' where country = 'US';
update qqordermgmnt.address set country = 'GER' where country = 'GR';
update qqordermgmnt.address set country = 'IND' where country = 'IN';

INSERT INTO `qqordermgmnt`.`codeassociation` (`category`, `picklist`) VALUES ('PROVINCE', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `desc`) VALUES ('PROVINCE', 'TN', 'Tamil Nadu');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `desc`) VALUES ('PROVINCE', 'PA', 'Pennsylvania');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `desc`) VALUES ('PROVINCE', 'TX', 'Texas');

INSERT INTO `qqordermgmnt`.`people` (`id`, `externalId`, `parentType`, `parentId`, `category`, `firstName`, `lastName`) VALUES ('14', '3', 'P', '2', 'B', 'Jacob', 'Shelby');
INSERT INTO `qqordermgmnt`.`people` (`id`, `externalId`, `parentType`, `parentId`, `category`, `firstName`, `lastName`) VALUES ('15', '3', 'P', '1', 'B', 'Matthew', 'McClay');


INSERT INTO `qqordermgmnt`.`email` (`id`, `parentId`, `parentEntity`, `type`, `emailId`) VALUES ('13', '14', 'H', 'C', 'jacob.shelby@technipfmc.com');
INSERT INTO `qqordermgmnt`.`email` (`id`, `parentId`, `parentEntity`, `type`, `emailId`) VALUES ('14', '15', 'H', 'C', 'matthew.mcclay@fmcti.com');


INSERT INTO `qqordermgmnt`.`phone` (`id`, `parentId`, `parentEntity`, `type`, `phoneNo`) VALUES ('13', '14', 'H', 'C', '+1254965825');
INSERT INTO `qqordermgmnt`.`phone` (`id`, `parentId`, `parentEntity`, `type`, `phoneNo`) VALUES ('14', '15', 'H', 'C', '+919944354704');

ALTER TABLE `qqordermgmnt`.`invoice`
CHANGE COLUMN `supplyPlace` `supplyPlace` INT(20) NULL DEFAULT NULL ;


-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 29-04-19 by Dhaarun new column in pkgDetail


UPDATE `qqordermgmnt`.`plant` SET `deliveryTerms` = 'EX works Coimbatore/ INDIA' WHERE (`id` = '1');
UPDATE `qqordermgmnt`.`plant` SET `deliveryTerms` = 'EX works Coimbatore/ INDIA' WHERE (`id` = '2');
UPDATE `qqordermgmnt`.`plant` SET `deliveryTerms` = 'EX works Coimbatore/ INDIA' WHERE (`id` = '3');


ALTER TABLE `qqordermgmnt`.`pkgdetail`
ADD COLUMN `weightPrPiece` DECIMAL(15,3) NULL AFTER `invoiceLineItemId`;


UPDATE `qqordermgmnt`.`address` SET `streetName` = 'FMC Technologies Inc -- Erie', `lineThree` = 'McClelland Avenue' WHERE (`id` = '2');



-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 29-04-19 by Dhaarun Report type in codes tablle.


INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('22', 'REPORT_TYPE', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('76', 'REPORT_TYPE', 'CUSTOMER', 'CUSTOMER');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('77', 'REPORT_TYPE', 'DOMAIN', 'DOMAIN');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('78', 'REPORT_TYPE', 'GEO', 'GEO');

-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 02-05-19 by Murugesan added new column in purchorder (postatus)


ALTER TABLE `qqordermgmnt`.`purchorder`
ADD COLUMN `poStatus` VARCHAR(10) NULL AFTER `poRevision`;

-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 02-05-19 by Dhaarun added new column in Pkg detail and master (postatus)

ALTER TABLE `qqordermgmnt`.`pkgdetail`
ADD COLUMN `isDeleted` TINYINT(1) NULL DEFAULT NULL AFTER `qty`;


ALTER TABLE `qqordermgmnt`.`pkgmaster`
ADD COLUMN `isDeleted` TINYINT(1) NULL DEFAULT NULL AFTER `dimensionUnit`;


-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 15-05-19 by Dhaarun Poline lineItem chnages and customer Name change


UPDATE `qqordermgmnt`.`company` SET `desc` = 'TechnipFMC' WHERE (`id` = '1');


ALTER TABLE `qqordermgmnt`.`polineitem`
CHANGE COLUMN `partPrice` `partPrice` DECIMAL(10,3) NULL DEFAULT NULL ;

-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 16-05-19 by Dhaarun codes  added report.


INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('79', 'REPORT_TYPE', 'PLANT', 'PLANT');

-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 20-05-19 by Dhaarun codes  added places for port of discharge.

INSERT INTO `qqordermgmnt`.`places` (`id`, `code`, `description`, `type`) VALUES ('13', 'CLVD', 'CLEVELAND, OH', 'CTY');

-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 22-05-19 by Dhaarun Set   province and postalCd for Address.

UPDATE `qqordermgmnt`.`address` SET `province` = 'SH', `postalCd` = '25474' WHERE (`id` = '5');
UPDATE `qqordermgmnt`.`address` SET `province` = 'SH', `postalCd` = '25474' WHERE (`id` = '6');

-- codes  added places for port of discharge.

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('80', 'PROVINCE', 'SH', 'Schleswig-Holstein');

 -- Places  added places for port of discharge.
 INSERT INTO `qqordermgmnt`.`places` (`id`, `code`, `description`, `type`) VALUES ('14', 'HAM', 'HAMBURG', 'CTY');


-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 27-05-19 by Dhaarun Set   CHART_TYPE.

INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('23', 'CHART_TYPE', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('81', 'CHART_TYPE', 'line', 'line');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('82', 'CHART_TYPE', 'bar', 'bar');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('83', 'CHART_TYPE', 'pie', 'pie');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('84', 'CHART_TYPE', 'doughnut', 'doughnut');

-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 29-05-19 by Dhaarun Set   PENDING_ORD_RPT_TYPE.

INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('24', 'PENDING_ORD_RPT_TYPE', 'Y');


INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('85', 'PENDING_ORD_RPT_TYPE', 'CUSTOMER', 'CUSTOMER');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('86', 'PENDING_ORD_RPT_TYPE', 'PLANT', 'PLANT');

ALTER TABLE `qqordermgmnt`.`purchorder`
CHANGE COLUMN `poDate` `poDate` DATETIME NOT NULL ;



-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 29-05-19 by Murugesan adding Payment Terms & Delivery Terms (Multiple - many to many)

INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('26', 'PAYMENT_TERMS','Y');
INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('27', 'DELIVERY_TERMS','Y');


INSERT INTO `qqordermgmnt`.`codes`(`id`,`category`,`code`,`desc`,`activeDt`,`createdDt`)
VALUES ('89','DELIVERY_TERMS','FCA','FCA Coimbatore/ INDIA','2018-01-01 00:00:00', now());


INSERT INTO `qqordermgmnt`.`codes`(`id`,`category`,`code`,`desc`,`activeDt`,`createdDt`)
VALUES ('90','DELIVERY_TERMS','EXW','EXW Coimbatore/ INDIA','2018-01-01 00:00:00', now());


INSERT INTO `qqordermgmnt`.`codes`(`id`,`category`,`code`,`desc`,`activeDt`,`createdDt`)
VALUES ('91','PAYMENT_TERMS','58','58 Days NET','2018-01-01 00:00:00', now());


INSERT INTO `qqordermgmnt`.`codes`(`id`,`category`,`code`,`desc`,`activeDt`,`createdDt`)
VALUES ('92','PAYMENT_TERMS','30','30 Days Net','2018-01-01', now());

CREATE TABLE `qqordermgmnt`.`plantpaymentterms` (
  `id` BIGINT(10) NOT NULL AUTO_INCREMENT,
  `plantId` BIGINT(10) NULL,
  `paymentTerms` VARCHAR(25) NULL,
  `effectiveDt` datetime DEFAULT NULL,
  `expiryDt` datetime DEFAULT NULL,
  `createdDt` DATETIME NULL,
  `modifiedDt` DATETIME NULL,
  PRIMARY KEY (`id`));


CREATE TABLE `qqordermgmnt`.`plantdeliveryterms` (
  `id` BIGINT(10) NOT NULL AUTO_INCREMENT,
  `plantId` BIGINT(10) NULL,
  `deliveryTerms` VARCHAR(25) NULL,
  `effectiveDt` datetime DEFAULT NULL,
  `expiryDt` datetime DEFAULT NULL,
  `createdDt` DATETIME NULL,
  `modifiedDt` DATETIME NULL,
  PRIMARY KEY (`id`));

ALTER TABLE `qqordermgmnt`.`plant`
DROP COLUMN `deliveryTerms`,
DROP COLUMN `pmntTerms`;

  ---- --- ---  ----   ABOVE DATA PUT IN AWS.... ... . ... .. .. . ..

Insert into plantdeliveryterms (plantid, deliveryTerms, effectiveDt, createdDt)
select id,'EXW',now(), now() from plant;

Insert into plantdeliveryterms (plantid, deliveryTerms, effectiveDt, createdDt)
select id,'FCA',now(), now() from plant;

Insert into plantpaymentterms (plantid, paymentTerms, effectiveDt, createdDt)
select id,'58',now(), now() from plant;

-- to fetch deliveryTermsId along with Poid to update PO
-- select  po.id, pdt.id
-- from purchorder po, plantdeliveryterms pdt
-- where po.plantid = pdt.plantid and pdt.deliveryTerms = 'EXW'
-- order by po.id;


-- ---------------------------------------------------------------------------------------------------------------------------------------------------
-- 06-06-19 by Dhaarun Set   Address Formmated.    DONE IN AWS

UPDATE `qqordermgmnt`.`address` SET `streetName` = 'Wagner Avenue', `lineTwo` = 'FMC Technologies Measurement Solutions Inc', `lineThree` = 'P.O Box 10428', `lineFour` = '' WHERE (`id` = '1');
UPDATE `qqordermgmnt`.`address` SET `streetName` = 'McClelland Avenue', `lineTwo` = 'FMC Technologies Inc -- Erie', `lineThree` = '' WHERE (`id` = '2');
UPDATE `qqordermgmnt`.`address` SET `streetName` = 'W Washinton', `lineTwo` = 'FMC Fluid Control', `lineThree` = '' WHERE (`id` = '3');
UPDATE `qqordermgmnt`.`address` SET `streetNo` = '', `streetName` = 'Regentstrasse 1', `lineTwo` = 'FMC Technologies Measurement Solutions', `lineThree` = 'Smith Meter GmbH', `lineFour` = '' WHERE (`id` = '5');
UPDATE `qqordermgmnt`.`address` SET `streetNo` = '', `streetName` = 'Regentstrasse 1', `lineTwo` = 'TechnipFMC', `lineThree` = '', `postalCd` = 'D-25474' WHERE (`id` = '6');
UPDATE `qqordermgmnt`.`address` SET `lineTwo` = 'FMC Technologies, Inc. Fluid Control Division', `lineThree` = '' WHERE (`id` = '4');


UPDATE `qqordermgmnt`.`codes` SET `desc` = 'GER' WHERE (`id` = '45');


INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('25', 'SLI_SI', 'Y');


INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('87', 'SLI_SI', 'SLILUT', 'IGST Unpaid shipment (LUT)');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('88', 'SLI_SI', 'SLIIGST', 'IGST paid shipment (NON LUT)');

-- ------------------------------------------------------------------------------------------------------------------------------------------------------
-- 07-06-19 by Dhaarun Set

Update qqordermgmnt.purchorder set pymntTerms = 1 , dvryTerms =1 ;

ALTER TABLE `qqordermgmnt`.`purchorder`
CHANGE COLUMN `dvryTerms` `dvryTermsId` INT(20) NULL DEFAULT NULL ,
CHANGE COLUMN `pymntTerms` `pymntTermsId` INT(20) NULL DEFAULT NULL ;

-- ------------------------------------------------------------------------------------------------------------------------------------------------------
-- 07-06-19 by Dhaarun Set  --- DONE IN  AWS

INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('28', 'PART_IMAGE', 'Y');


INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('93', 'PART_IMAGE', 'IMAGE', 'IMAGE');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('94', 'PART_IMAGE', 'CASTING', 'CASTING');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('95', 'PART_IMAGE', 'MACHINING', 'MACHINING');


ALTER TABLE `qqordermgmnt`.`partimage`
ADD COLUMN `imageFileName` VARCHAR(500) NULL AFTER `imageData`;


ALTER TABLE `qqordermgmnt`.`partimage`
ADD COLUMN `imageType` VARCHAR(500) NULL DEFAULT NULL AFTER `imageFileName`;

ALTER TABLE `qqordermgmnt`.`partimage`
ADD COLUMN `remarks` VARCHAR(800) NULL DEFAULT NULL AFTER `imageType`;

-- ------------------------------------------------------------------------------------------------------------------------------------------------------
-- 07-06-19 by Dhaarun Set codesassociation in workShift ,  created invoice status   --- DONE IN  AWS


INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('29', 'WORK_SHIFT', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('96', 'WORK_SHIFT', '1ST', '1st Shift');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('97', 'WORK_SHIFT', '2ST', '2st Shift');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('98', 'WORK_SHIFT', '3ST', '3st Shift');

INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('30', 'PROCESS_NAME', 'Y');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('99', 'PROCESS_NAME', 'ZINC-PHOSPHATING', 'Zinc Phosphating');



CREATE TABLE `qqordermgmnt`.`invoicestatus` (
  `id` INT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `invoiceId` INT(20) NOT NULL,
  `invoiceStatus` VARCHAR(100) NULL DEFAULT NULL,
  `statusDate` DATETIME NOT NULL,
  `remarks` VARCHAR(200) NULL DEFAULT NULL,
  `createdBy` INT(20) NULL DEFAULT NULL,
  `createdDt` DATETIME NULL DEFAULT NULL,
  `modifiedBy` INT(20) NULL DEFAULT NULL,
  `modifiedDt` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`));


-- ------------------------------------------------------------------------------------------------------------------------------------------------------
-- 07-06-19 by Dhaarun payment terms added, hardness spec added and packinglist added   ---


INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`) VALUES ('112', 'PAYMENT_TERMS', '60');
UPDATE `qqordermgmnt`.`codes` SET `desc` = '60 Days Net' WHERE (`id` = '112');





INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('31', 'HARDNESS_SPEC', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('113', 'HARDNESS_SPEC', '120-150', '120 - 150 BHN');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('114', 'HARDNESS_SPEC', '130-187', '130 - 187 BHN');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('115', 'HARDNESS_SPEC', '172-229', '172 - 229 BHN');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('116', 'HARDNESS_SPEC', '187-241', '187 - 241 BHN');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('117', 'HARDNESS_SPEC', '207-255', '207 - 255 BHN');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('118', 'HARDNESS_SPEC', '187-Max', '187 - Max BHN');

INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('32', 'SLI_DOCUMENT_LIST', 'Y');
update  qqordermgmnt.codes set category = 'SLI_DOCUMENT_LIST' where category = 'PACKING_CHECK_LIST';

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('119', 'PACKING_CHECK_LIST', 'RUST', 'Rustic');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('120', 'PACKING_CHECK_LIST', 'VCI', 'VCI');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('121', 'PACKING_CHECK_LIST', 'SLICAGEL', 'Silica Gel');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('122', 'PACKING_CHECK_LIST', 'SEPCHECK', 'Separator Check');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('123', 'PACKING_CHECK_LIST', 'PLCEDAMAGECHK', 'Placement inside the box without damage');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('124', 'PACKING_CHECK_LIST', 'VCITAP', 'Covered with VCI tap');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('125', 'PACKING_CHECK_LIST', 'INSPRERT', 'Inspection report kept inside the box');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('126', 'PACKING_CHECK_LIST', 'STEELCOVER', 'Box covered with steel belt');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('127', 'PACKING_CHECK_LIST', 'PACKDETAILRETURN', 'Packing details written on the box');

-- ------------------------------------------------------------------------------------------------------------------------------------------------------
-- 17-06-19 by Dhaarun payment terms added, hardness spec added and packinglist added   ---


INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('33', 'PACKING_CHECK_LIST_AFTER', 'Y');

UPDATE `qqordermgmnt`.`codeassociation` SET `category` = 'PACKING_CHECK_LIST_BFRE' WHERE (`id` = '18');


UPDATE `qqordermgmnt`.`codes` SET `category` = 'PACKING_CHECK_LIST_BFRE' WHERE (`id` = '119');
UPDATE `qqordermgmnt`.`codes` SET `category` = 'PACKING_CHECK_LIST_BFRE' WHERE (`id` = '120');
UPDATE `qqordermgmnt`.`codes` SET `category` = 'PACKING_CHECK_LIST_BFRE' WHERE (`id` = '121');
UPDATE `qqordermgmnt`.`codes` SET `category` = 'PACKING_CHECK_LIST_BFRE' WHERE (`id` = '122');
UPDATE `qqordermgmnt`.`codes` SET `category` = 'PACKING_CHECK_LIST_BFRE' WHERE (`id` = '123');
UPDATE `qqordermgmnt`.`codes` SET `category` = 'PACKING_CHECK_LIST_AFTER' WHERE (`id` = '124');
UPDATE `qqordermgmnt`.`codes` SET `category` = 'PACKING_CHECK_LIST_AFTER' WHERE (`id` = '125');
UPDATE `qqordermgmnt`.`codes` SET `category` = 'PACKING_CHECK_LIST_AFTER' WHERE (`id` = '126');
UPDATE `qqordermgmnt`.`codes` SET `category` = 'PACKING_CHECK_LIST_AFTER' WHERE (`id` = '127');




CREATE TABLE `qqordermgmnt`.`pkgchecklistmaster` (
  `id` INT(20) UNSIGNED NOT NULL,
  `invoiceId` INT(20) NULL DEFAULT NULL,
  `partId` INT(20) NULL DEFAULT NULL,
  `packStartTime` DATETIME NULL DEFAULT NULL,
  `packEndTime` DATETIME NULL DEFAULT NULL,
  `shift` VARCHAR(45) NULL DEFAULT NULL,
  `packBoxSize` VARCHAR(45) NULL DEFAULT NULL,
  `vciBagSize` VARCHAR(45) NULL DEFAULT NULL,
  `silicaWt` VARCHAR(45) NULL DEFAULT NULL,
  `qtyPerBox` INT NULL DEFAULT NULL,
  `packingIncharge` VARCHAR(100) NULL,
  `createdBy` VARCHAR(45) NULL,
  `createdDt` DATETIME NULL,
  `modifiedBy` VARCHAR(45) NULL,
  `modifiedDt` DATETIME NULL,
  PRIMARY KEY (`id`));

ALTER TABLE `qqordermgmnt`.`pkgchecklistmaster`
CHANGE COLUMN `id` `id` INT(20) UNSIGNED NOT NULL AUTO_INCREMENT ;


INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('34', 'ATS_CONTENT_SHEET', 'Y');


INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('132', 'ATS_CONTENT_SHEET', 'COC', 'Certificate of  Compiance (COC)');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('133', 'ATS_CONTENT_SHEET', 'BALONDRAW', 'Balloon Drawing');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('134', 'ATS_CONTENT_SHEET', 'FIR', 'Final Inspection Report');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('135', 'ATS_CONTENT_SHEET', 'MTC', 'Material Test Certificate');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('136', 'ATS_CONTENT_SHEET', 'COCANNEL', 'COC - Anneal');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('137', 'ATS_CONTENT_SHEET', 'HTTREPO', 'HT Test report');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('138', 'ATS_CONTENT_SHEET', 'COCCOAT', 'COC - Coat ');

-- ------------------------------------------------------------------------------------------------------------------------------------------------------
-- 18-06-19 by Dhaarun SPECIFICATION    ---


INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('35', 'SPECIFICATION', 'Y');


INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('128', 'SPECIFICATION', 'MSPEC', 'Material Specification');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('129', 'SPECIFICATION', 'CSPEC', 'Coating Specification');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('130', 'SPECIFICATION', 'PSPEC', 'Process Specification');


ALTER TABLE `qqordermgmnt`.`standard`
ADD COLUMN `specType` VARCHAR(100) NULL DEFAULT NULL AFTER `standardNumber`;



INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('131', 'PART_IMAGE', 'DBI', 'DBI');



CREATE TABLE `qqordermgmnt`.`ats` (
  `id` INT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `poId` INT(20) NULL DEFAULT NULL,
  `partId` INT(20) NULL DEFAULT NULL,
  `invoiceId` INT(20) NULL DEFAULT NULL,
  `atsQty` INT(20) NULL DEFAULT NULL,
  `heatCode` VARCHAR(80) NULL DEFAULT NULL,
  `hardnessSpec` VARCHAR(100) NULL DEFAULT NULL,
  `hardnessActual` VARCHAR(100) NULL DEFAULT NULL,
  `processDate` DATETIME NULL DEFAULT NULL,
  `cocNo` VARCHAR(65) NULL DEFAULT NULL,
  `cocDate` DATETIME NULL DEFAULT NULL,
  `cocHeatNo` VARCHAR(45) NULL DEFAULT NULL,
  `atsDate` DATETIME NULL DEFAULT NULL,
  `createdDt` DATETIME NULL DEFAULT NULL,
  `createdBy` VARCHAR(45) NULL DEFAULT NULL,
  `modifiedDt` DATETIME NULL DEFAULT NULL,
  `modifiedBy` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`id`));


ALTER TABLE `qqordermgmnt`.`pkgchecklistmaster`
ADD COLUMN `plantId` INT(20) NULL DEFAULT NULL AFTER `invoiceId`;

-- ------------------------------------------------------------------------------------------------------------------------------------------------------
28-JUN-2019

UPDATE `qqordermgmnt`.`codeassociation` SET `category` = 'SALES_ORD_RPT_TYPE' WHERE (`id` = '24');

UPDATE `qqordermgmnt`.`codes` SET `category` = 'SALES_ORD_RPT_TYPE' WHERE (`id` = '85');
UPDATE `qqordermgmnt`.`codes` SET `category` = 'SALES_ORD_RPT_TYPE' WHERE (`id` = '86');

-- ---------------------------------------------------------------------------------------------------------------------------------------------x   ---------
-- 26-06-19 by dhaarun Added new customer.
INSERT INTO `qqordermgmnt`.`company` (`id`, `name`, `type`, `desc`, `taxId`, `hierarchy`) VALUES ('5', 'Engrave Engineering and Services Pvt. Ltd.', 'CORP', 'Engrave Engineering and Services Pvt. Ltd.', '27', '0');


INSERT INTO `qqordermgmnt`.`plant` (`id`, `companyId`, `plantCode`, `desc`, `vendorCode`, `domesticInd`, `currency`, `dutyStruct`, `createdDt`) VALUES ('8', '5', 'Sector-2', 'Haridwar', '001', 'Y', 'INR', '18% GST', '2019-06-27 12:27:35');


INSERT INTO `qqordermgmnt`.`address` (`id`, `parentId`, `parentEntity`, `type`, `streetNo`, `streetName`, `lineTwo`, `lineThree`, `city`, `province`, `country`, `postalCd`, `createdDt`) VALUES ('16', '8', 'P', 'B', 'Plot No-5', 'IIE', 'Sector-2', 'Sidul', 'Haridwar', 'UT', 'IND', '249403', '2019-06-27 19:07:18');

INSERT INTO `qqordermgmnt`.`address` (`id`, `parentId`, `parentEntity`, `type`, `streetNo`, `streetName`, `lineTwo`, `lineThree`, `city`, `province`, `country`, `postalCd`, `createdDt`) VALUES ('17','8', 'P', 'D', 'Plot No-5', 'IIE', 'Sector-2', 'Sidul', 'Haridwar', 'UT', 'IND', '249403', '2019-06-27 19:07:18');

INSERT INTO `qqordermgmnt`.`people` (`id`, `externalId`, `parentType`, `parentId`, `category`, `firstName`) VALUES ('16', '3', 'P', '5', 'B', 'K Sunil');

INSERT INTO `qqordermgmnt`.`email` (`id`, `parentId`, `parentEntity`, `type`, `emailId`) VALUES ('15', '16', 'H', 'C', 'sunil@eesind.com');

INSERT INTO `qqordermgmnt`.`phone` (`id`, `parentId`, `parentEntity`, `type`, `phoneNo`) VALUES ('15', '16', 'H', 'C', '+91 1334239092');

-- 26-06-19 by dhaarun Added new Buyer.


INSERT INTO `qqordermgmnt`.`people` (`id`, `externalId`, `parentType`, `parentId`, `category`, `firstName`, `lastName`) VALUES ('17', '3', 'P', '2', 'B', 'Jeremy', 'Caldwell');
INSERT INTO `qqordermgmnt`.`email` (`id`, `parentId`, `parentEntity`, `type`, `emailId`) VALUES ('16', '17', 'H', 'C', 'Jeremy.Caldwell@technipfmc.com');


INSERT INTO `qqordermgmnt`.`phone` (`id`, `parentId`, `parentEntity`, `type`) VALUES ('16', '17', 'H', 'C');
UPDATE `qqordermgmnt`.`phone` SET `phoneNo` = '+1 (254) 977' WHERE (`id` = '16');


-- ------------------------------------------------------------------------------------------------------------------------------------------------------
-- by dhaarun added boxNo, bag size, isSeelected, ats Contetnt sheet, nda


ALTER TABLE `qqordermgmnt`.`pkgchecklistmaster`
ADD COLUMN `boxNumber` VARCHAR(50) NULL DEFAULT NULL AFTER `partId`;

INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('36', 'PACK_BOX_SIZE', 'Y');
INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('37', 'VCI_BAG_SIZE', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('139', 'VCI_BAG_SIZE', 'VCISIZE1', '12x23x28');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('140', 'VCI_BAG_SIZE', 'VCISIZE2', '23x876x7');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('141', 'PACK_BOX_SIZE', 'BOXSIZE1', '23x72x82');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('142', 'PACK_BOX_SIZE', 'BOXSIZE2', '43x77x77');

ALTER TABLE `qqordermgmnt`.`pkgchecklist`
ADD COLUMN `isSelected` TINYINT(1) NULL DEFAULT NULL AFTER `comments`;

ALTER TABLE `qqordermgmnt`.`pkgchecklist`
CHANGE COLUMN `isSelected` `isSelected` TINYINT(1) NULL DEFAULT 0 ;

CREATE TABLE `qqordermgmnt`.`atscontentsheet` (
  `id` INT(20) UNSIGNED NOT NULL AUTO_INCREMENT,x
  `atsId` INT(20) NULL DEFAULT NULL,
  `contentCode` VARCHAR(500) NULL DEFAULT NULL,
  `description` VARCHAR(500) NULL DEFAULT NULL,
  `fileName` VARCHAR(500) NULL DEFAULT NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `qqordermgmnt`.`nda` (
  `id` INT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `companyName` VARCHAR(800) NULL DEFAULT NULL,
  `ndaDate` DATETIME NULL DEFAULT NULL,
  `addressLine1` VARCHAR(400) NULL DEFAULT NULL,
  `addressLine2` VARCHAR(400) NULL DEFAULT NULL,
  `city` VARCHAR(80) NULL DEFAULT NULL,
  `state` VARCHAR(80) NULL DEFAULT NULL,
  `pin` VARCHAR(80) NULL DEFAULT NULL,
  `gstNo` VARCHAR(80) NULL DEFAULT NULL,
  `contactNO` VARCHAR(80) NULL DEFAULT NULL,
  `suppRepName` VARCHAR(100) NULL DEFAULT NULL,
  `supprepTitle` VARCHAR(100) NULL DEFAULT NULL,
  `qqRep` VARCHAR(100) NULL DEFAULT NULL,
  `createdDt` DATETIME NULL DEFAULT NULL,
  `createdBy` INT(20) NULL DEFAULT NULL,
  `modifiedBy` INT(20) NULL DEFAULT NULL,
  `modifiedDt` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`id`));

-- ------------------------------------------------------------------------------------------------------------------------------------------------------
-- by dhaarun 27-06-2019 added approved by

ALTER TABLE `qqordermgmnt`.`ats`
ADD COLUMN `preparedBy` INT(20) NULL DEFAULT NULL AFTER `atsDate`,
ADD COLUMN `approvedBy` INT(20) NULL DEFAULT NULL AFTER `preparedBy`;


UPDATE `qqordermgmnt`.`codes` SET `code` = 'LUTFY19' WHERE (`id` = '47');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('143', 'PAYMENT_DECLARATION', 'LUTFY20', 'Supply Meant for Export On LUT AD330419000313N dated 01/04/2019. (IGST UNPAID)');


UPDATE `qqordermgmnt`.`invoice` SET `paymentDeclaration` = 'LUTFY19' WHERE (`paymentDeclaration` = 'LUT');

UPDATE `qqordermgmnt`.`invoice` SET `undertakingLUT` = 'Y' WHERE (`paymentDeclaration` = 'LUTFY19');


ALTER TABLE `qqordermgmnt`.`ats`
ADD COLUMN `materialSpec` VARCHAR(500) NULL DEFAULT NULL AFTER `hardnessActual`;
-- ------------------------------------------------------------------------------------------------------------------------------------------------------
-- by dhaarun 01-07-2019

UPDATE `qqordermgmnt`.`people` SET `parentId` = '8' WHERE (`id` = '16');

UPDATE `qqordermgmnt`.`people` SET `firstName` = 'Sunil', `lastName` = 'K' WHERE (`id` = '16');


ALTER TABLE `qqordermgmnt`.`ats`
ADD COLUMN `heatTreatmentSpec` VARCHAR(500) NULL DEFAULT NULL AFTER `cocHeatNo`;

ALTER TABLE `qqordermgmnt`.`user`
ADD COLUMN `designation` VARCHAR(1005) NULL DEFAULT NULL AFTER `pwd`;


UPDATE `qqordermgmnt`.`user` SET `designation` = 'Managing Partner' WHERE (`id` = '1');
UPDATE `qqordermgmnt`.`user` SET `designation` = 'CEO' WHERE (`id` = '2');
UPDATE `qqordermgmnt`.`user` SET `designation` = 'Programmer Analyst' WHERE (`id` = '3');
UPDATE `qqordermgmnt`.`user` SET `designation` = 'Engineer - Quality' WHERE (`id` = '8');
UPDATE `qqordermgmnt`.`user` SET `designation` = 'Engineer - Development' WHERE (`id` = '9');
UPDATE `qqordermgmnt`.`user` SET `designation` = 'Sr. Manager Purchase' WHERE (`id` = '4');
UPDATE `qqordermgmnt`.`user` SET `designation` = 'Engineer Materials' WHERE (`id` = '5');
UPDATE `qqordermgmnt`.`user` SET `designation` = 'Engineer Planning' WHERE (`id` = '6');
UPDATE `qqordermgmnt`.`user` SET `designation` = 'Accountant' WHERE (`id` = '7');



UPDATE `qqordermgmnt`.`user` SET `firstName` = 'MB Shafee', `lastName` = 'Ahmed' WHERE (`id` = '4');
UPDATE `qqordermgmnt`.`user` SET `firstName` = 'Selva Sesu', `lastName` = 'Rajesh A' WHERE (`id` = '8');
UPDATE `qqordermgmnt`.`user` SET `lastName` = 'Kumar P' WHERE (`id` = '9');
UPDATE `qqordermgmnt`.`user` SET `lastName` = 'A G' WHERE (`id` = '3');
UPDATE `qqordermgmnt`.`user` SET `firstName` = 'K Amrish' WHERE (`id` = '5');
UPDATE `qqordermgmnt`.`user` SET `lastName` = 'Mohamed' WHERE (`id` = '5');


ALTER TABLE `qqordermgmnt`.`ats`
ADD COLUMN `hardnessActualHigher` VARCHAR(100) NULL DEFAULT NULL AFTER `hardnessActualLower`,
CHANGE COLUMN `hardnessActual` `hardnessActualLower` VARCHAR(100) NULL DEFAULT NULL ;


-- ------------------------------------------------------------------------------------------------------------------------------------------------------
-- by dhaarun 02-07-2019

INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('38', 'INVOICE_STATUS_LABEL', 'Y');

UPDATE `qqordermgmnt`.`codes` SET `code` = 'VS1' WHERE (`id` = '139');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'VS2' WHERE (`id` = '140');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'BS1' WHERE (`id` = '141');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'BS2' WHERE (`id` = '142');

UPDATE `qqordermgmnt`.`codes` SET `code` = 'CUST' WHERE (`id` = '76');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'DOM' WHERE (`id` = '77');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'PLT' WHERE (`id` = '79');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'LINE' WHERE (`id` = '81');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'BAR' WHERE (`id` = '82');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'PIE' WHERE (`id` = '83');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'DON' WHERE (`id` = '84');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'CUS' WHERE (`id` = '85');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'PLN' WHERE (`id` = '86');

UPDATE `qqordermgmnt`.`codes` SET `code` = 'CAN' WHERE (`id` = '101');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'SHP' WHERE (`id` = '102');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'SBR' WHERE (`id` = '103');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'INVCU' WHERE (`id` = '104');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'PR' WHERE (`id` = '105');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'IGRC' WHERE (`id` = '110');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'CLS' WHERE (`id` = '111');

UPDATE `qqordermgmnt`.`codes` SET `code` = 'SLG' WHERE (`id` = '121');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'SPC' WHERE (`id` = '122');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'PLD' WHERE (`id` = '123');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'VTP' WHERE (`id` = '124');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'IRT' WHERE (`id` = '125');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'STB' WHERE (`id` = '126');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'PDE' WHERE (`id` = '127');

INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('38', 'INVOICE_STATUS_LABEL', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('144', 'INVOICE_STATUS', 'DBK', 'DBK value Remarks');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('145', 'INVOICE_STATUS_LABEL', 'CANATTR1', 'Cancel Remarks');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('146', 'INVOICE_STATUS_LABEL', 'SHPATTR1', 'Shipping Remarks');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('147', 'INVOICE_STATUS_LABEL', 'SBRATTR1', 'Shipping Bill Receipt');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('148', 'INVOICE_STATUS_LABEL', 'INVCUATTR1', 'Invoice to Customer Remarks');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('149', 'INVOICE_STATUS_LABEL', 'PRATTR1', 'Payment Link');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('150', 'INVOICE_STATUS_LABEL', 'FIRCATTR1', 'Firc Remarks');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('151', 'INVOICE_STATUS_LABEL', 'EBRCATTR1', 'Ebrc Remarks');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('152', 'INVOICE_STATUS_LABEL', 'DDBATTR1', 'DDB Remarks');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('153', 'INVOICE_STATUS_LABEL', 'MEISATTR1', 'Meis Remarks');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('154', 'INVOICE_STATUS_LABEL', 'IGRCATTR1', 'Value');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('155', 'INVOICE_STATUS_LABEL', 'CANATTR1', 'Cancel Remarks');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('156', 'INVOICE_STATUS_LABEL', 'CLSATTR1', 'Closing Remarks');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('157', 'INVOICE_STATUS_LABEL', 'DBKATTR1', 'DBK Remarks');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('158', 'INVOICE_STATUS_LABEL', 'SBRATTR2', 'Shipping Bill Remarks');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('159', 'INVOICE_STATUS_LABEL', 'PRATTR2', 'Payment Link Remarks');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('160', 'INVOICE_STATUS_LABEL', 'IGRCATTR2', 'IGST Remarks ');

-- ------------------------------------------------------------------------------------------------------------------------------------------------------
-- by dhaarun 03-07-2019

ALTER TABLE `qqordermgmnt`.`nda`
ADD COLUMN `country` VARCHAR(100) NULL DEFAULT NULL AFTER `pin`;

ALTER TABLE `qqordermgmnt`.`ats`
ADD COLUMN `poLineId` INT(20) NULL DEFAULT NULL AFTER `invoiceId`;

UPDATE `qqordermgmnt`.`partcommodity` SET `commodityCode` = '7326908688' WHERE (`id` = '41');
UPDATE `qqordermgmnt`.`partcommodity` SET `commodityCode` = '7326908688' WHERE (`id` = '46');
UPDATE `qqordermgmnt`.`partcommodity` SET `commodityCode` = '8481903000' WHERE (`id` = '45');

UPDATE `qqordermgmnt`.`address` SET `streetName` = 'W Washington' WHERE (`id` = '3');

ALTER TABLE `qqordermgmnt`.`invoicestatus`
ADD COLUMN `attribute1` VARCHAR(100) NULL DEFAULT NULL AFTER `statusDate`,
ADD COLUMN `attribute2` VARCHAR(100) NULL DEFAULT NULL AFTER `attribute1`,
ADD COLUMN `attribute3` VARCHAR(100) NULL DEFAULT NULL AFTER `attribute2`,
ADD COLUMN `attribute4` VARCHAR(100) NULL DEFAULT NULL AFTER `attribute3`;
-- ------------------------------------------------------------------------------------------------------------------------------------------------------


UPDATE `qqordermgmnt`.`codes` SET `code` = 'CNS', `desc` = 'Content Sheet' WHERE (`id` = '132');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'COG', `desc` = 'COC -Genaral' WHERE (`id` = '136');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'CHT', `desc` = 'COC - HT' WHERE (`id` = '138');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'BD' WHERE (`id` = '133');



UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Part Dipped in Rustic Oil' WHERE (`id` = '119');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'VCI Bag Damage free' WHERE (`id` = '120');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Silica Gel Placed in safer place' WHERE (`id` = '121');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Separator are Placed in defined location' WHERE (`id` = '122');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Parts are placed in box with out dust and damage as per the work instruction' WHERE (`id` = '123');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'VCI bag is sealed by VCI tap' WHERE (`id` = '124');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Inspection reports are properly placed and taped' WHERE (`id` = '125');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Close Box is sealed by steel belt' WHERE (`id` = '126');


INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('161', 'PACKING_CHECK_LIST_BFRE', 'OLD', 'Oil draining time is given');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('162', 'PACKING_CHECK_LIST_BFRE', 'PCBI', 'Packing Photos -Before closing the Box');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('163', 'PACKING_CHECK_LIST_AFTER', 'PCAI', 'Packing Photos - Completed View');


ALTER TABLE `qqordermgmnt`.`invoice`
ADD COLUMN `shippingThrough` VARCHAR(100) NULL DEFAULT NULL AFTER `undertakingLUT`;

-- -----------------------------
-- 09-July-2019
ALTER TABLE `qqordermgmnt`.`codes`
ADD COLUMN `displaySeq` INT(10) NULL DEFAULT 0 AFTER `notes`;

-- -----------------------------
-- 20-July-2019
INSERT INTO `qqordermgmnt`.`places` (`id`, `code`, `description`, `type`) VALUES ('15', 'INKAT1', 'INKAT1', 'CTY');

-- -----------------------------
-- 22-July-2019

ALTER TABLE `qqordermgmnt`.`purchorder`
ADD COLUMN `poFileName` VARCHAR(200) NULL DEFAULT NULL AFTER `billToAddrId`;

-- -------------------------------
ALTER TABLE `qqordermgmnt`.`invoice`
ADD COLUMN `invoiceType` VARCHAR(100) NULL DEFAULT NULL AFTER `poId`;

-- ------------------------------------------------------------------------------------------------------------------------------------------------------
-- 26-July-2019
-- dhaarun

INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('39', 'CP_CATEGORY', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('171', 'CP_CATEGORY', 'PL', 'Pre Launch');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('172', 'CP_CATEGORY', 'PRD', 'Production');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('173', 'CP_CATEGORY', 'PT', 'Prototype');

UPDATE `qqordermgmnt`.`codes` SET `code` = 'AWBBL', `desc` = 'Air Way Bill / Bill of Loading' WHERE (`id` = '101');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'IGRC', `desc` = 'IGST / LUT' WHERE (`id` = '104');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'INVCU', `desc` = 'Invoice to Accounts Customer' WHERE (`id` = '102');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'DDB', `desc` = 'Duty Draw Back' WHERE (`id` = '105');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'PR', `desc` = 'Payment Recived Status' WHERE (`id` = '103');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'NEW', `desc` = 'NEW' WHERE (`id` = '110');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'SBR', `desc` = 'Shipphing Bill' WHERE (`id` = '106');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'FIRC', `desc` = 'FIRC' WHERE (`id` = '107');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'EDPMS', `desc` = 'EDPMS' WHERE (`id` = '108');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'DELETE', `desc` = 'DELETE' WHERE (`id` = '144');




UPDATE `qqordermgmnt`.`codes` SET `code` = 'AWBBLATTR1', `desc` = 'AWB number' WHERE (`id` = '145');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'INVCUATTR1', `desc` = 'Date of sent ' WHERE (`id` = '146');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'PRATTR1', `desc` = 'Actual Payment Date' WHERE (`id` = '147');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'IGRCATTR1', `desc` = 'NA / Amount' WHERE (`id` = '148');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'DDBATTR1', `desc` = 'Recived Date' WHERE (`id` = '149');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'SBRATTR1', `desc` = 'SB Date' WHERE (`id` = '150');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'FIRCATTR1', `desc` = 'Date' WHERE (`id` = '151');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'EDPMSATTR1', `desc` = 'Update or Not' WHERE (`id` = '152');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Applied / not applied' WHERE (`id` = '153');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'AWBBLATTR2', `desc` = 'Hard copy Recived' WHERE (`id` = '154');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'INVCUATTR2', `desc` = ' Sent / not send ' WHERE (`id` = '155');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'PRATTR2', `desc` = 'Payment Link NO' WHERE (`id` = '156');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'IGRCATTR2', `desc` = 'IGST Recivced Date' WHERE (`id` = '157');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'DDBATTR2', `desc` = 'Value' WHERE (`id` = '158');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'SBRATTR2', `desc` = 'SB No' WHERE (`id` = '159');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'MEISATTR2', `desc` = 'Receviced or not recevied' WHERE (`id` = '160');


INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('164', 'INVOICE_STATUS_LABEL', 'PRATTR3', 'Payment Status received or not');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('165', 'INVOICE_STATUS_LABEL', 'IGRCATTR3', 'Receviced or not recevied');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('166', 'INVOICE_STATUS_LABEL', 'DDBATTR3', 'Receviced or not recevied');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('167', 'INVOICE_STATUS_LABEL', 'SBRATTR3', 'SB Port');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('168', 'INVOICE_STATUS_LABEL', 'MEISATTR3', 'Receviced Date');


INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('169', 'INVOICE_STATUS_LABEL', 'PRATTR4', 'Payment Recivied date');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('170', 'INVOICE_STATUS_LABEL', 'SBRATTR4', 'SB Recived Hard copy?');



ALTER TABLE `qqordermgmnt`.`invoicestatus`
CHANGE COLUMN `statusDate` `statusDate` DATETIME NULL DEFAULT NULL ;

ALTER TABLE `qqordermgmnt`.`company`
CHANGE COLUMN `desc` `description` VARCHAR(200) NULL DEFAULT NULL ;

-- ------------------------------------------------------------------------------------------------------------------------------------------------------


ALTER TABLE `qqordermgmnt`.`plant`
CHANGE COLUMN `desc` `description` VARCHAR(200) NULL DEFAULT NULL ;


ALTER TABLE `qqordermgmnt`.`invoicelineitem`
ADD COLUMN `toolPaymentDescription` VARCHAR(100) NULL DEFAULT NULL AFTER `invoiceQty`;

INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('40', 'TOOL_PAYMENT', 'Y');



INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('174', 'TOOL_PAYMENT', 'ADV', 'Advance');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('175', 'TOOL_PAYMENT', 'BAL', 'Balance');


ALTER TABLE `qqordermgmnt`.`invoicelineitem`
CHANGE COLUMN `invoiceQty` `invoiceQty` DECIMAL(5,2) NULL DEFAULT NULL ;

ALTER TABLE `qqordermgmnt`.`invoicelineitem`
CHANGE COLUMN `invoiceQty` `invoiceQty` DECIMAL(10,2) NULL DEFAULT NULL ;

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('176', 'TOOL_PAYMENT', 'FUL', 'Full Payment');
-- ------------------------------------------------------------------------------------------------------------------------------------------------------
--                             AWS DONE
-- ------------------------------------------------------------------------------------------------------------------------------------------------------




INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('41', 'ADDRESS_TYPE', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('177', 'ADDRESS_TYPE', 'B',  'Billing Address' );
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('178', 'ADDRESS_TYPE', 'D', 'Delivery Address');




INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('42', 'MACHINE_TYPE', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('179', 'MACHINE_TYPE', 'HMC',  'HMC' );
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('180', 'MACHINE_TYPE', 'VMC', 'VMC');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('181', 'MACHINE_TYPE', 'VTL', 'VTL');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('182', 'MACHINE_TYPE', 'TC', 'Turning center');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('183', 'MACHINE_TYPE', 'LM', 'Lathe machine');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('184', 'MACHINE_TYPE', 'CMM', 'CMM');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('185', 'MACHINE_TYPE', 'TRI', 'Trimos');

-- ------------------------------------------------------------------------------------------------------------------------------------------------------

INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('43', 'COMPANY_TYPE', 'Y');


INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('186', 'COMPANY_TYPE', 'CORP',  'Corporation' );
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('187', 'COMPANY_TYPE', 'PVT', 'Private Limited');


INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('44', 'SPECVAL_TYPE', 'Y');



INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('188', 'SPECVAL_TYPE', 'LEN',  'Length' );
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('189', 'SPECVAL_TYPE', 'WT', 'Weight');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('190', 'SPECVAL_TYPE', 'VOL',  'Volume' );
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('191', 'SPECVAL_TYPE', 'TEM', 'Temparature');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('192', 'SPECVAL_TYPE', 'DEG', 'Degree');


INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('45', 'RESPONS_PERSON', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('193', 'RESPONS_PERSON', 'STR',  'Store Keeper' );
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('194', 'RESPONS_PERSON', 'OPT', 'Operator');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('195', 'RESPONS_PERSON', 'INS',  'Inspector' );

INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('46', 'SAMPLE_FREQUENCY', 'Y');



INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('196', 'SAMPLE_FREQUENCY', 'NBR',  'Number' );
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('197', 'SAMPLE_FREQUENCY', 'LOT',  'LOT' );
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('198', 'SAMPLE_FREQUENCY', 'SHIFT',  'Shift' );

-- ------------------------------------------------------------------------------------------------------------------------------------------------------

ALTER TABLE `qqordermgmnt`.`invoice`
CHANGE COLUMN `invDate` `invDate` DATETIME NULL DEFAULT NULL ;

-- ------------------------------------------------------------------------------------------------------------------------------------------------------
--                             AWS DONE
-- ------------------------------------------------------------------------------------------------------------------------------------------------------

UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Received or not' WHERE (`id` = '164');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Hard copy Received' WHERE (`id` = '154');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Received Date' WHERE (`id` = '149');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Applied / Not applied' WHERE (`id` = '153');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Sent / Not send ' WHERE (`id` = '155');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Payment Link Num' WHERE (`id` = '156');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'IGST Received Date' WHERE (`id` = '157');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Received or not' WHERE (`id` = '160');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Received or not' WHERE (`id` = '165');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Received or not' WHERE (`id` = '166');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Payment Received date' WHERE (`id` = '169');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Received Date' WHERE (`id` = '168');

UPDATE `qqordermgmnt`.`codes` SET `category` = 'INVOICE_STATUS_LABEL' WHERE (`id` = '146');

UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Sent On' WHERE (`id` = '146');


UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Payment Recived' WHERE (`id` = '103');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Invoice to Customer Accounts' WHERE (`id` = '102');


UPDATE `qqordermgmnt`.`company` SET `name` = 'Futuretech Engineers', `description` = 'Futuretech Engineers' WHERE (`id` = '3');


UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Payment Received' WHERE (`id` = '103');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Shipping Bill' WHERE (`id` = '106');
UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Air-Way Bill / Bill of Loading' WHERE (`id` = '101');

UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Payment Link Number' WHERE (`id` = '156');

UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Updated or Not' WHERE (`id` = '152');



INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('47', 'COMPANY_TYPE', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('199', 'COMPANY_TYPE', 'CROP', 'Corporate');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('200', 'COMPANY_TYPE', 'PVT', 'Private limited');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('201', 'COMPANY_TYPE', 'PUB', 'Public Limited');


UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Millimeter' WHERE (`id` = '29');



UPDATE `qqordermgmnt`.`purchorder` SET `poStatus` = 'REVISED' WHERE (`poStatus` = 'REVISIED');
-- ------------------------------------------------------------------------------------------------------------------------------------------------------
--                             AWS DONE
-- ------------------------------------------------------------------------------------------------------------------------------------------------------

UPDATE `qqordermgmnt`.`codes` SET `category` = 'INVOICE_STATUS_MAIN' WHERE (`id` = '110');
UPDATE `qqordermgmnt`.`codes` SET `category` = 'INVOICE_STATUS_MAIN' WHERE (`id` = '111');
UPDATE `qqordermgmnt`.`codes` SET `category` = 'INVOICE_STATUS_MAIN' WHERE (`id` = '144');


INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('48', 'INVOICE_STATUS_MAIN', 'Y');

UPDATE `qqordermgmnt`.`codes` SET `desc` = 'Received Date' WHERE (`id` = '151');
-- ------------------------------------------------------------------------------------------------------------------------------------------------------
--                             AWS DONE
-- ------------------------------------------------------------------------------------------------------------------------------------------------------

INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('49', 'ITEM_SEVERITY', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('206', 'ITEM_SEVERITY', 'C', 'Critical');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('207', 'ITEM_SEVERITY', 'P', 'Process');


INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('50', 'CP_CALIBRATION', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('208', 'CP_CALIBRATION', 'HM', 'Heightmaster');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('209', 'CP_CALIBRATION', 'VC', 'Venrier  caliper');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('210', 'CP_CALIBRATION', 'BG', 'Bore gauge');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('211', 'CP_CALIBRATION', 'RG', 'Radius gauge');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('212', 'CP_CALIBRATION', 'SRC', 'Surface roughness comparator');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('213', 'CP_CALIBRATION', 'V', 'visual');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('214', 'CP_CALIBRATION', 'DV', 'Depth vernier');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('215', 'CP_CALIBRATION', 'CMM', 'CMM');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('216', 'CP_CALIBRATION', 'PV', 'Programm verify');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('217', 'CP_CALIBRATION', 'PPG', 'Plain plug gauge');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('218', 'CP_CALIBRATION', 'DDV', 'Digital Depth vernier');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('219', 'CP_CALIBRATION', 'TV', 'Tool verify');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('220', 'CP_CALIBRATION', 'TPG', 'Thread plug gauge');
-- ------------------------------------------------------------------------------------------------------------------------------------------------------
--                             AWS DONE
-- ------------------------------------------------------------------------------------------------------------------------------------------------------

INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('51', 'MAKE', 'Y');



INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('221', 'MAKE', 'FQ', 'FORQQ');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('222', 'MAKE', 'MI', 'Mitsubishi');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('223', 'MAKE', 'SD', 'SANDVIK');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('224', 'MAKE', 'TT', 'Taegu Tec');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('225', 'MAKE', 'KM', 'Kennametal');

-- ------------------------------------------------------------------------------------------------------------------------------------------------------


INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('52', 'HOLDER_TYPE', 'Y');


INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('226', 'HOLDER_TYPE', 'C', 'Collet');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('227', 'HOLDER_TYPE', 'DH', 'Drill Holder');

-- ------------------------------------------------------------------------------------------------------------------------------------------------------
-- ------------------------------------------------------------------------------------------------------------------------------------------------------
--                             AWS DONE
-- ------------------------------------------------------------------------------------------------------------------------------------------------------


INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('53', 'TOOL_TYPE', 'Y');
INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('54', 'INSERT_TYPE', 'Y');


INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('228', 'INSERT_TYPE', 'T', 'Insert two side');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`) VALUES ('229', 'TOOL_TYPE', 'T', 'Tool type');

-- ------------------------------------------------------------------------------------------------------------------------------------------------------

ALTER TABLE `qqordermgmnt`.`company`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `hierarchy`,
ADD COLUMN   `createdDt` datetime DEFAULT NULL,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL,
ADD COLUMN   `modifiedDt` datetime DEFAULT NULL;

ALTER TABLE `qqordermgmnt`.`plant`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `dutyStruct`,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL;

ALTER TABLE `qqordermgmnt`.`address`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `postalCd`,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL;

ALTER TABLE `qqordermgmnt`.`people`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `otherInfo`,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL;

ALTER TABLE `qqordermgmnt`.`plantdeliveryterms`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `expiryDt`,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL;

ALTER TABLE `qqordermgmnt`.`plantpaymentterms`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `expiryDt`,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL;

ALTER TABLE `qqordermgmnt`.`part`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `companyId`,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL after `createdDt`;

ALTER TABLE `qqordermgmnt`.`partcommodity`
ADD COLUMN  `modifiedBy` int(20) DEFAULT NULL after `createdBy`,
ADD COLUMN   `modifiedDt` datetime DEFAULT NULL;

ALTER TABLE `qqordermgmnt`.`partcustomerrequirement`
ADD COLUMN  `modifiedBy` int(20) DEFAULT NULL after `createdBy`,
ADD COLUMN   `modifiedDt` datetime DEFAULT NULL;

ALTER TABLE `qqordermgmnt`.`partdomain`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `domain`,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL after `createdDt`;

ALTER TABLE `qqordermgmnt`.`partimage`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `remarks`,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL after `createdDt`;

ALTER TABLE `qqordermgmnt`.`partrelationxref`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `childid`,
ADD COLUMN   `createdDt` datetime DEFAULT NULL,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL,
ADD COLUMN   `modifiedDt` datetime DEFAULT NULL;

ALTER TABLE `qqordermgmnt`.`partrevisionamendment`
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL,
ADD COLUMN   `modifiedDt` datetime DEFAULT NULL;

ALTER TABLE `qqordermgmnt`.`partstandard`
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL,
ADD COLUMN   `modifiedDt` datetime DEFAULT NULL;

ALTER TABLE `qqordermgmnt`.`standard`
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL,
ADD COLUMN   `modifiedDt` datetime DEFAULT NULL;

ALTER TABLE `qqordermgmnt`.`codeassociation`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `picklist`,
ADD COLUMN   `createdDt` datetime DEFAULT NULL,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL,
ADD COLUMN   `modifiedDt` datetime DEFAULT NULL;

 ALTER TABLE `qqordermgmnt`.`codes`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `displaySeq`,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL after `createdDt`;

ALTER TABLE `qqordermgmnt`.`pkgdetail`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `isDeleted`,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL after `createdDt`;

ALTER TABLE `qqordermgmnt`.`phone`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `extension`,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL after `createdDt`;

ALTER TABLE `qqordermgmnt`.`email`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `emailId`,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL after `createdDt`;

ALTER TABLE `qqordermgmnt`.`bank`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `adCode`,
ADD COLUMN   `createdDt` datetime DEFAULT NULL,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL after `createdDt`,
ADD COLUMN   `modifiedDt` datetime DEFAULT NULL;

ALTER TABLE `qqordermgmnt`.`user`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `roles`,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL after `createdDt`;

ALTER TABLE `qqordermgmnt`.`vendor`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `ieCode`,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL after `createdDt`;

-- ------------------------------------------------------------------------------------------------------------------------------------------------------


ALTER TABLE `qqordermgmnt`.`codes`
CHANGE COLUMN `desc` `description` VARCHAR(200) NULL DEFAULT NULL ;


INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('55', 'TASK_PART_STATUS', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('230', 'TASK_PART_STATUS', 'APV', 'Approved');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('231', 'TASK_PART_STATUS', 'RJ', 'Rejected');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('232', 'TASK_PART_STATUS', 'HI', 'Hold for Inspection');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('233', 'TASK_PART_STATUS', 'HR', 'Hold for Research');

INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('56', 'SPL_DECLARATION', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('234', 'SPL_DECLARATION', 'REX2019', '19th March 2019');


ALTER TABLE `qqordermgmnt`.`invoice`
ADD COLUMN `splDeclaration` VARCHAR(45) NULL DEFAULT NULL AFTER `paymentDeclaration`;


ALTER TABLE `qqordermgmnt`.`codes`
CHANGE COLUMN `description` `description` VARCHAR(1000) NULL DEFAULT NULL ;

UPDATE `qqordermgmnt`.`codes` SET `description` = '\"The Exporter \" REX NO : INREXAAAFQ6880GEC016 \" dated  19th March 2019 of the products covered by this documents declares that except where otherwise clearly indicate these products are of INDIA preferentaila Orgin  according to rules of orgin of the generalised system of preference of the European Union and that the Orgin Criterionment is \" P \" customs traiff no' WHERE (`id` = '234');


ALTER TABLE `qqordermgmnt`.`invoice`
CHANGE COLUMN `splDeclaration` `splDeclaration` VARCHAR(1000) NULL DEFAULT NULL ;

ALTER TABLE `qqordermgmnt`.`vendor`
CHANGE COLUMN `vendorid` `id` INT(11) NOT NULL AUTO_INCREMENT ;

ALTER TABLE `qqordermgmnt`.`invoice`
ADD COLUMN `igst` INT(10) NULL DEFAULT NULL AFTER `undertakingLUT`,
ADD COLUMN `cgst` INT(10) NULL DEFAULT NULL AFTER `igst`,
ADD COLUMN `sgst` INT(10) NULL DEFAULT NULL AFTER `cgst`;


INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('235', 'PROVINCE', 'UT', 'Uttarakhand');

INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('57', 'ACTIVE_STATUS', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('236', 'ACTIVE_STATUS', 'TRUE', 'Active', '1');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('237', 'ACTIVE_STATUS', 'FALSE', 'Inactive', '2');


INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('58', 'TOOL_CHANGEAT', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('238', 'TOOL_CHANGEAT', 'B', 'Before');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('239', 'TOOL_CHANGEAT', 'AF', 'After');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('240', 'TOOL_CHANGEAT', 'AT', 'At');


INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('59', 'ROLES', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('241', 'ROLES', 'ROLE_ADMIN', 'ROLE_ADMIN', '1');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('242', 'ROLES', 'ROLE_WORK_READ', 'ROLE_WORK_READ', '2');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('243', 'ROLES', 'ROLE_WORK_WRITE', 'ROLE_WORK_WRITE', '3');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('244', 'ROLES', 'ROLE_PLAN_READ', 'ROLE_PLAN_READ', '4');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('245', 'ROLES', 'ROLE_PLAN_WRITE', 'ROLE_PLAN_WRITE', '5');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('246', 'ROLES', 'ROLE_GENERIC_READ', 'ROLE_GENERIC_READ', '6');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('247', 'ROLES', 'ROLE_ALL_READ', 'ROLE_ALL_READ', '7');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('248', 'ROLES', 'ROLE_ALL_WRITE', 'ROLE_ALL_WRITE', '8');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('249', 'ROLES', 'ROLE_COMPANY_READ', 'ROLE_COMPANY_READ', '9');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('250', 'ROLES', 'ROLE_INVOICE_READ', 'ROLE_INVOICE_READ', '10');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('251', 'ROLES', 'ROLE_INVOICE_WRITE', 'ROLE_INVOICE_WRITE', '11');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('252', 'ROLES', 'ROLE_PART_READ', 'ROLE_PART_READ', '12');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('253', 'ROLES', 'ROLE_PART_WRITE', 'ROLE_PART_WRITE', '13');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('254', 'ROLES', 'ROLE_PO_READ', 'ROLE_PO_READ', '14');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('255', 'ROLES', 'ALL_READ', 'ALL_READ', '15');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('256', 'ROLES', 'ROLE_PO_WRITE', 'ROLE_PO_WRITE', '16');

INSERT INTO `qqordermgmnt`.`codeassociation` (`id`, `category`, `picklist`) VALUES ('60', 'DESIGNATION', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('257', 'DESIGNATION', 'MP', 'Managing Partner', '1');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('258', 'DESIGNATION', 'CEO', 'CEO', '2');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('259', 'DESIGNATION', 'PA', 'Programmer Analyst', '3');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('260', 'DESIGNATION', 'SMP', 'Sr. Manager Purchase', '4');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('261', 'DESIGNATION', 'EM', 'Engineer Materials', '5');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('262', 'DESIGNATION', 'EP', 'Engineer Planning', '6');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('263', 'DESIGNATION', 'ACC', 'Accountant', '7');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('264', 'DESIGNATION', 'EQ', 'Engineer - Quality', '8');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('265', 'DESIGNATION', 'ED', 'Engineer - Development', '9');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('266', 'DESIGNATION', 'TRA', 'Traning', '10');


UPDATE `qqordermgmnt`.`codes` SET `description` = 'Beginning of process' WHERE (`id` = '236');
DELETE FROM `qqordermgmnt`.`codes` WHERE (`id` = '237');
UPDATE `qqordermgmnt`.`codes` SET `description` = 'During the process' WHERE (`id` = '238');



UPDATE `qqordermgmnt`.`codes` SET `description` = 'Production' WHERE (`id` = '24');


INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('267', 'PAYMENT_TERMS', '60LC', '60 Days LC', '0');

UPDATE `qqordermgmnt`.`codes` SET `code` = 'FMR', `description` = 'FACE MILL ROUGH' WHERE (`id` = '229');



INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('268', 'TOOL_TYPE', 'FMF', 'FACE MILL FINISH');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('269', 'TOOL_TYPE', 'D', 'DRILLING');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('270', 'TOOL_TYPE', 'HM', 'HOLE MILLING');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('271', 'TOOL_TYPE', 'BR', 'BORE ROUGHING');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('272', 'TOOL_TYPE', 'C', 'CHAMFERING');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('273', 'TOOL_TYPE', 'R', 'REAMERING');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('274', 'TOOL_TYPE', 'BF', 'BORE FINISHING');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('275', 'TOOL_TYPE', 'G', 'GROOVING');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('276', 'TOOL_TYPE', 'ODR', 'OD ROUGHING');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('277', 'TOOL_TYPE', 'ODF', 'OD FINISHNG');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('278', 'TOOL_TYPE', 'FM', 'FACE MILLING');



UPDATE `qqordermgmnt`.`codes` SET `code` = 'SPT', `description` = 'SPT' WHERE (`id` = '222');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'DU', `description` = 'DUTCH' WHERE (`id` = '224');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'SH', `description` = 'SHANLA' WHERE (`id` = '225');


INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('279', 'MAKE', 'AZ', 'AZTECH');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('280', 'MAKE', 'WI', 'WIDIA');

UPDATE `qqordermgmnt`.`codes` SET `code` = 'I', `description` = 'INSERTS' WHERE (`id` = '228');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('281', 'INSERT_TYPE', 'DCT', 'DIRECT CARBIDE TOOLS');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('282', 'MAKE', 'FL', 'FALCON');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`) VALUES ('283', 'MAKE', 'BI', 'BILZ');

UPDATE `qqordermgmnt`.`codes` SET `code` = 'SC', `description` = 'Side lock type' WHERE (`id` = '227');

INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `description`, `displaySeq`) VALUES ('284', 'MACHINE_TYPE', 'BT', 'BT40', '0');

ALTER TABLE `qqordermgmnt`.`places`
ADD COLUMN `createdBy` INT(20) NULL DEFAULT NULL AFTER `modifiedDt`,
ADD COLUMN `modifiedBy` INT(20) NULL DEFAULT NULL AFTER `createdBy`;

ALTER TABLE `qqordermgmnt`.`invoice`
ADD COLUMN `awbFileName` VARCHAR(100) NULL DEFAULT NULL AFTER `shippingThrough`;

DROP TABLE `qqordermgmnt`.`user`;

ALTER TABLE `qqordermgmnt`.`part`
ADD COLUMN `msl` BIGINT(20) NULL DEFAULT NULL AFTER `resourceInd`,
ADD COLUMN `openingStock` BIGINT(20) NULL DEFAULT NULL AFTER `msl`,
ADD COLUMN `safetyStock` BIGINT(20) NULL DEFAULT NULL AFTER `openingStock`,
ADD COLUMN `safetyStockUnit` VARCHAR(10) NULL DEFAULT NULL AFTER `safetyStock`,
ADD COLUMN `jobType` VARCHAR(100) NULL DEFAULT NULL AFTER `safetyStock`;


ALTER TABLE `qqordermgmnt`.`invoice`
ADD COLUMN `scheme` VARCHAR(1000) NULL DEFAULT NULL AFTER `splInstruction`;


ALTER TABLE `qqordermgmnt`.`invoice`
ADD COLUMN `secondSplInstruction` VARCHAR(1000) NULL DEFAULT NULL AFTER `scheme`;

-- CREATED AND DROPED

-- CREATE TABLE `qqordermgmnt`.`childpartreq` (
--   `id` INT unsigned NOT NULL AUTO_INCREMENT,
--   `partId` INT(20) NOT NULL,
--   `childId` INT(20) NOT NULL,
--   `qty` INT(20) NOT NULL,
--   `createdBy` INT(20) NULL,
--   `createdDt` DATETIME NULL,
--   `modifiedBy` INT(20) NULL,
--   `modifiedDt` DATETIME NULL,
--   PRIMARY KEY (`id`));
--
-- ALTER TABLE `qqordermgmnt`.`childpartreq`
-- CHANGE COLUMN `id` `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT ;
--
-- Drop TABLE `qqordermgmnt`.`childpartreq`;

ALTER TABLE `qqordermgmnt`.`partrelationxref`
ADD COLUMN `qty` INT(10) NOT NULL AFTER `childId`;


ALTER TABLE `qqordermgmnt`.`part`
DROP COLUMN `safetyStockUnit`,
DROP COLUMN `safetyStock`,
DROP COLUMN `openingStock`,
DROP COLUMN `msl`;

------- AWS IMPLEMENTS DONE FOR ABOVE CODE IN Q&Q---

UPDATE `qqordermgmnt`.`codes` SET `code` = '1' WHERE (category = 'MONTH' and description = 'January');
UPDATE `qqordermgmnt`.`codes` SET `code` = '2' WHERE (category = 'MONTH' and description = 'February');
UPDATE `qqordermgmnt`.`codes` SET `code` = '3' WHERE (category = 'MONTH' and description = 'March');
UPDATE `qqordermgmnt`.`codes` SET `code` = '4' WHERE (category = 'MONTH' and description = 'April');
UPDATE `qqordermgmnt`.`codes` SET `code` = '5' WHERE (category = 'MONTH' and description = 'May');
UPDATE `qqordermgmnt`.`codes` SET `code` = '6' WHERE (category = 'MONTH' and description = 'June');
UPDATE `qqordermgmnt`.`codes` SET `code` = '7' WHERE (category = 'MONTH' and description = 'July');
UPDATE `qqordermgmnt`.`codes` SET `code` = '8' WHERE (category = 'MONTH' and description = 'August');
UPDATE `qqordermgmnt`.`codes` SET `code` = '9' WHERE (category = 'MONTH' and description = 'September');
UPDATE `qqordermgmnt`.`codes` SET `code` = '10' WHERE (category = 'MONTH' and description = 'October');
UPDATE `qqordermgmnt`.`codes` SET `code` = '11' WHERE (category = 'MONTH' and description = 'November');
UPDATE `qqordermgmnt`.`codes` SET `code` = '12' WHERE (category = 'MONTH' and description = 'DeceincrementalData.sql:1798mber');



ALTER TABLE `qqordermgmnt`.`codes`
ADD INDEX `idx_category` (`category` ASC) VISIBLE;
;



UPDATE `qqordermgmnt`.`codes` SET `code` = '01' WHERE (category = 'MONTH' and description = 'January');
UPDATE `qqordermgmnt`.`codes` SET `code` = '02' WHERE (category = 'MONTH' and description = 'February');
UPDATE `qqordermgmnt`.`codes` SET `code` = '03' WHERE (category = 'MONTH' and description = 'March');
UPDATE `qqordermgmnt`.`codes` SET `code` = '04' WHERE (category = 'MONTH' and description = 'April');
UPDATE `qqordermgmnt`.`codes` SET `code` = '05' WHERE (category = 'MONTH' and description = 'May');
UPDATE `qqordermgmnt`.`codes` SET `code` = '06' WHERE (category = 'MONTH' and description = 'June');
UPDATE `qqordermgmnt`.`codes` SET `code` = '07' WHERE (category = 'MONTH' and description = 'July');
UPDATE `qqordermgmnt`.`codes` SET `code` = '08' WHERE (category = 'MONTH' and description = 'August');
UPDATE `qqordermgmnt`.`codes` SET `code` = '09' WHERE (category = 'MONTH' and description = 'September');

-- AWS Q & Q Done

ALTER TABLE `qqordermgmnt`.`codes`
ADD COLUMN `isUserGenerated` VARCHAR(1) NULL DEFAULT NULL AFTER `description`;

-- AWS Q&Q  AND FT AWS Done

ALTER TABLE `qqordermgmnt`.`pkgdetail`
CHANGE COLUMN `weightPrPiece` `weightPrPiece` DECIMAL(15,4) NULL DEFAULT NULL ;


ALTER TABLE `qqordermgmnt`.`invoice`
CHANGE COLUMN `igst` `igst` DECIMAL(5,3) NULL DEFAULT NULL ,
CHANGE COLUMN `cgst` `cgst` DECIMAL(5,3) NULL DEFAULT NULL ,
CHANGE COLUMN `sgst` `sgst` DECIMAL(5,3) NULL DEFAULT NULL ;



ALTER TABLE `qqordermgmnt`.`polineitem`
ADD COLUMN `currentStatus` VARCHAR(100) NULL DEFAULT NULL AFTER `isDeleted`;


CREATE TABLE `qqordermgmnt`.`polineitemxcurrentstatus` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `poLineItemId` int(20) DEFAULT NULL,
  `currentStatus` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
   `createdBy` INT(20) NULL DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
   `modifiedBy` INT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;


ALTER TABLE `qqordermgmnt`.`address`
ADD COLUMN `lineOne` VARCHAR(500) NULL AFTER `type`;

-- set sql_safe_updates = 0;
UPDATE `qqordermgmnt`.`address` SET `lineOne` = concat(`streetNo`, ' ', `streetName`);

ALTER TABLE `qqordermgmnt`.`address`
DROP COLUMN `streetNo`,
DROP COLUMN `streetName`;


ALTER TABLE `qqordermgmnt`.`polineitemxcurrentstatus`
ADD COLUMN `type` VARCHAR(20) NULL DEFAULT NULL AFTER `id`,
CHANGE COLUMN `poLineItemId` `lineItemId` VARCHAR(200) NULL DEFAULT NULL ;

ALTER TABLE `qqordermgmnt`.`polineitemxcurrentstatus`
ADD COLUMN `status` VARCHAR(45) NULL DEFAULT NULL AFTER `date`;


ALTER TABLE `qqordermgmnt`.`invoicelineitem`
ADD COLUMN `currentStatus` VARCHAR(100) NULL DEFAULT NULL AFTER `toolPaymentDescription`;

-- AWS Q & Q Done


CREATE TABLE IF NOT EXISTS `qqordermgmnt`.`countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sortname` varchar(3) NOT NULL,
  `name` varchar(150) NOT NULL,
  `phonecode` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=249 ;

CREATE TABLE IF NOT EXISTS `qqordermgmnt`.`states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `country_id` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4121 ;

CREATE TABLE IF NOT EXISTS  `qqordermgmnt`.`cities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `state_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=47577 ;
-- AWS Q & Q Done and FT done


ALTER TABLE `qqordermgmnt`.`address`
CHANGE COLUMN `city` `city` INT(20) NULL DEFAULT NULL ,
CHANGE COLUMN `province` `province` INT(20) NULL DEFAULT NULL ,
CHANGE COLUMN `country` `country` INT(20) NULL DEFAULT NULL ;



CREATE TABLE `qqordermgmnt`.`currencyexchangerate` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `currency` char(3) NOT NULL,
  `value` decimal(10,3) DEFAULT NULL,
  `effectiveDt` datetime DEFAULT NULL,
  `expiryDt` datetime DEFAULT NULL,
  `createdBy` int(20) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedBy` int(20) DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

ALTER TABLE `qqordermgmnt`.`invoice`
ADD COLUMN `paymentTermsCode` VARCHAR(100) NULL AFTER `paymentDeclaration`,
ADD COLUMN `paymentTermsText` VARCHAR(100) NULL AFTER `paymentTermsCode`;

-- 05-01-2021
ALTER TABLE `qqordermgmnt`.`invoice`
ADD COLUMN `sliInstruction` VARCHAR(1000) NULL DEFAULT NULL AFTER `splDeclaration`;

-- 23-01-2021
ALTER TABLE `qqordermgmnt`.`plant`
ADD COLUMN `taxId` VARCHAR(45) NULL DEFAULT NULL AFTER `domesticInd`;


CREATE TABLE `qqordermgmnt`.`rfq` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `companyId` int(20) NOT NULL,
  `package` varchar(100) DEFAULT NULL,
  `packageProjectName` varchar(200) DEFAULT NULL,
  `materialCustomerReference` varchar(100) DEFAULT NULL,
  `drawingNumber` varchar(100) DEFAULT NULL,
  `partName` varchar(200) DEFAULT NULL,
  `revNo` varchar(50) DEFAULT NULL,
  `material` varchar(100) DEFAULT NULL,
  `grade` varchar(100) DEFAULT NULL,
  `materialGradeFullVersion` varchar(300) DEFAULT NULL,
  `mspec` varchar(50) DEFAULT NULL,
  `weightInKg` decimal(10,3) DEFAULT NULL,
  `volumePerYear` int(10) DEFAULT NULL,
  `revisedVolume` int(10) DEFAULT NULL,
  `delivery` varchar(200) DEFAULT NULL,
  `targetPrice` int(20) DEFAULT NULL,
  `outPrice` int(20) DEFAULT NULL,
  `castingSupplier` varchar(200) DEFAULT NULL,
  `mcSupplier` varchar(200) DEFAULT NULL,
  `tier` varchar(200) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `coating` varchar(200) DEFAULT NULL,
  `machining` varchar(200) DEFAULT NULL,
  `leakTesting` varchar(200) DEFAULT NULL,
  `heatTreatment` varchar(200) DEFAULT NULL,
  `welding` varchar(200) DEFAULT NULL,
  `inspection` varchar(200) DEFAULT NULL,
  `painting` varchar(200) DEFAULT NULL,
  `ndt` varchar(200) DEFAULT NULL,
  `others` varchar(200) DEFAULT NULL,

  `createdBy` int(20) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedBy` int(20) DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
);
