--  02-Nov-2019 - - AG

INSERT INTO `qqordermgmnt`.`codeassociation` (`category`, `picklist`) VALUES ('SPEC_VALIDATION', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('SPEC_VALIDATION', 'A', 'AUTO', '0');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('SPEC_VALIDATION', 'M', 'MANUAL', '0');


INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('INVOICE_STATUS_MAIN', 'CAN', 'Cancelled', '0');


INSERT INTO `qqordermgmnt`.`codeassociation` (`category`, `picklist`) VALUES ('PLACES_CATEGORY', 'Y');


INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('PLACES_CATEGORY', 'CRY', 'Country', '1');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('PLACES_CATEGORY', 'CTY', 'City', '2');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('PLACES_CATEGORY', 'SUP', 'Supply Place', '3');
 --- from

-- INVOICE STATUES DUE DATE
INSERT INTO `qqordermgmnt`.`codeassociation` (`category`, `picklist`) VALUES ('INV_STATUS_DUE_DATE', 'Y');



INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('INV_STATUS_DUE_DATE', 'AWBBL', '30', '1');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('INV_STATUS_DUE_DATE', 'INVCU', '30', '2');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('INV_STATUS_DUE_DATE', 'PR', '30', '3');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('INV_STATUS_DUE_DATE', 'IGRC', '30', '4');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('INV_STATUS_DUE_DATE', 'DDB', '30', '5');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('INV_STATUS_DUE_DATE', 'SBR', '30', '6');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('INV_STATUS_DUE_DATE', 'FIRC', '30', '7');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('INV_STATUS_DUE_DATE', 'EDPMS', '30', '8');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('INV_STATUS_DUE_DATE', 'MEIS', '30', '9');



INSERT INTO `qqordermgmnt`.`codeassociation` (`category`, `picklist`) VALUES ('DEPARTMENT', 'Y');


INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DEPARTMENT', 'TO', 'TOOLINGS', '1');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DEPARTMENT', 'HR', 'HR', '2');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DEPARTMENT', 'OP', 'Operator', '3');


INSERT INTO `qqordermgmnt`.`codeassociation` (`category`, `picklist`) VALUES ('TASK_TYPE', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('TASK_TYPE', 'RW', 'REWORK', '1');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('TASK_TYPE', 'INS', 'INSPECTION', '2');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('TASK_TYPE', 'TK', 'TASK', '3');



-- REJECTION_ROOT_CAUSE

INSERT INTO `qqordermgmnt`.`codeassociation` (`category`, `picklist`) VALUES ('REJECTION_ROOT_CAUSE', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'WC', 'Wrong clamping', '1');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'WO', 'Wrong offset', '2');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'TB', 'Tool broken', '3');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'BP', 'Butting problem', '4');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'PC', 'Power cut', '5');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'ST', 'Setting', '6');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'WTS', 'Wrong tool selection', '7');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'TW', 'Tool wear', '8');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'IW', 'Insert wear', '9');

 - - -- - - - - - -
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'TWS', 'Tool wrong setup', '10');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'IWS', 'Insert wrong setup', '11');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'CFI', 'Coolant flow issue', '12');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'ICO', 'Insert chip out', '13');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'PE', 'Program error', '14');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'HD', 'Handling damage', '15');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'MP', 'Material problem', '16');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'MCP', 'Machine Problem', '17');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'APP', 'Air pressure problem', '18');


INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'TOP', 'Tool problem', '19');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'MCA', 'Machine accident', '20');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'INE', 'Instrument error', '21');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'WRM', 'Wrong measurement', '22');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'OFI', 'Oil flow issue', '23');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'IXE', 'Index error', '24'); -- changed
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'TOS', 'Tool Shortage ', '25');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'INWS', 'Instrument wrong setting', '26');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'FIP', 'Fixture problem', '27');



INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'WRHO', 'Wrong Height offset', '28');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'SCL', 'screw Loosed', '29');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'CSP', 'Casting problem', '30');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'WRA', 'Wrong adjustment', '31');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'PRWC', 'Programm wrong call', '32');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'CHPP', 'Chuck pressure problem', '33');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'TOWL', 'Tool wrong loading', '34');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'TORU', 'Tool runout', '35');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'BBTF', 'Boring bar touch in face', '36');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'PRP', 'Probe problem', '37');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'TOLO', 'Tool loosed', '38');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'JAWP', 'Jaws problem', '39');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'POC', 'Previous opn w/o complete', '40');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'PROP', 'Previous opn problem', '41');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'BTNC', 'Bore tolerance not closed', '42');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'CHL', 'Chip Lock', '43');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'GAP', 'Gauge problem', '44');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'HAP', 'Hardness problem', '45');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'CHP', 'Chuck problem', '46');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'EXTL', 'EXCESS TOOL LENGTH', '47');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'PROPR', 'PROCESS PROBLEM', '48');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'UNT', 'UNWANTED TOOLS', '49');


INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'CR', 'Careless ', '50');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'IEDTL', 'Index error due to Tool load', '51');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'INB', 'Insert broken', '52');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'POSP', 'Position problem', '53');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'TOTR', 'Tool  trial', '54');
-- INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'INWS', 'Instrument wrong setting', '55');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_ROOT_CAUSE', 'TOLS', 'Tool Shortage ', '56');



-- REJECTION_SYSTEMS

INSERT INTO `qqordermgmnt`.`codeassociation` (`category`, `picklist`) VALUES ('REJECTION_SYSTEMS', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SYSTEMS', 'SFU', 'System Follow Up', '1');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SYSTEMS', 'SNFU', 'System Not Follow Up', '2');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SYSTEMS', 'SNA', 'System Not Available', '3');

-- DEPARTMENT

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DEPARTMENT', 'MS', 'M/C SHOP', '4');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DEPARTMENT', 'AD', 'ADMIN', '5');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DEPARTMENT', 'QA', 'QA', '6');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DEPARTMENT', 'DE', 'DEVELOP', '7');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DEPARTMENT', 'AC', 'ACCOUNTS', '8');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DEPARTMENT', 'OF', 'OFFICE', '9');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DEPARTMENT', 'PR', 'PRODUCTION', '10');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DEPARTMENT', 'ST', 'STORES', '11');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DEPARTMENT', 'PU', 'PURCHASE', '12');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DEPARTMENT', 'MA', 'MAINTANACE', '13');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DEPARTMENT', 'PA', 'PACKING', '14');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DEPARTMENT', 'HE', 'HELPER', '15');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DEPARTMENT', 'LA', 'LATHE', '16');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DEPARTMENT', 'IN', 'INTEREST', '17');


-- DESIGNATION
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','OPV', 'OPERATOR - VMC',  '11' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','ADM', 'ADMIN MANAGER',  '12' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','QUM ', 'QUALITY MANAGER',  '13' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','PRM', 'PRODUCTION MANAGER',  '14' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','ACI', 'ACCOUNTS INCHARGE',  '15' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','SWE', 'SWEEPER',  '16' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','SQE', 'Sr.Quality Engineer',  '17' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','OVT', 'OPERATOR - VTL',  '18' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','SQC', 'Sr. QUALITY Engineer - CMM',  '19' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','SIT', 'SHIFT INCHARGE - TC',  '20' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','SIV', 'SHIFT INCHARGE - VMC',  '21' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','TOI', 'TOOLINGS INCHARGE',  '22' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','DEI', 'Development Incharge',  '23' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','TEL', 'Team Leader',  '24' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','STM', 'STORE INCHARGE',  '25' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','PUR', 'PURCHASE INCHARGE',  '26' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','MAT', 'Maintanance Technician',  '27' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','JQE', 'Jr.Quality Engineer',  '28' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','OPH', 'OPERATOR - HMC',  '29' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','OTC', 'OPERATOR - TC',  '30' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','HEL', 'HELPER',  '31' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','TOL', 'TOOLINGS ',  '32' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','SHM', 'SHIFT INCHARGE',  '33' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','MIM', 'MAINTENANCE MANAGER',  '34' );
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('DESIGNATION','TLN', 'TOOLING TECHNICIAN',  '35' );


INSERT INTO `qqordermgmnt`.`codeassociation` (`category`, `picklist`) VALUES ('FAMILY_STATUS', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('FAMILY_STATUS', 'UM', 'UN MARRIED', '1');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('FAMILY_STATUS', 'MR', 'MARRIED', '2');



INSERT INTO `qqordermgmnt`.`codeassociation` (`category`, `picklist`) VALUES ('REJECTION_STATUS', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_STATUS', 'OPE', 'OPEN', '1');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_STATUS', 'CLS', 'CLOSED', '2');


INSERT INTO `qqordermgmnt`.`codeassociation` (`category`, `picklist`) VALUES ('REJECTION_SINGLE_WORD', 'Y');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'BOS',   'Bore over size',  '0');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'BOD',   'Bore Damage',  '1');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'BDO',   'Bore depth over size',  '2');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'BDU',   'Bore depth Under size',  '3');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'BLM',   'Bore line mark',  '4');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'BOO',   'Bore ovality',  '5');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'BSM',   'Bore step mark',  '6');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'BUS',   'Bore under size',  '7');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'BUN',   'Bore unwash',  '8');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'BVI',   'Bore vibration',  '9');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'CRP',   'Casting reference problem',  '10');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'CDA',   'Chamfer Damage',  '11');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'COS',   'Chamfer over size',  '12');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'CUN',   'Chamfer uneven',  '13');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'CPR',   'Concentricity problem',  '14');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'DOS',   'Depth over size',  '15');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'DUS',   'Depth Under size',  '16');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'DPR',   'Distance problem',  '17');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'FDA',   'Face damage',  '18');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'FFP',   'Face finish poor',  '19');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'FUN',   'Face unwash',  '20');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'FAP',   'Faceout problem',  '21');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'FPR',   'Flatness problem',  '22');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'GDA',   'Groove damage',  '23');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'GDO',   'Groove depth over size',  '24');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'GDU',   'Groove depth under size',  '25');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'GOS',   'Groove dia over size',  '26');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'GUS',   'Groove dia under size',  '27');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'GDS',   'Groove Distance over size',  '28');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'GIU',   'Groove Distance under size',  '29');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'GWS',   'Groove width over size',  '30');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'GWU',   'Groove width under size',  '31');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'HAD',   'Hole damage',  '32');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'HDO',   'Hole dia over size',  '33');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'HDU',   'Hole dia under size',  '34');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'LUS',   'Length under size',  '35');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'ODA',   'Od Damage',  '36');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'ODO',   'Od depth over size',  '37');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'ODU',   'Od depth Under size',  '38');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'OLM',   'Od line mark',  '39');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'OOV',   'Od ovality',  '40');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'OOS',   'Od over size',  '41');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'OSN',   'Od step mark',  '42');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'OUS',   'Od under size',  '43');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'OUN',   'Od unwash',  '44');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'OVI',   'Od vibration',  '45');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'PER',   'Perpendicularity problem',  '46');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'PBR',   'Piece Broken',  '47');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'POP',   'Position problem',  '48');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'RDA',   'Radius Damage',  '49');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'ROS',   'Radius over size',  '50');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'SIS',   'Shifting issue',  '51');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'SOS',   'Spot face depth over size',  '52');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'SFS',   'Spot face depth under size',  '53');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'SFO',   'Spot face over size',  '54');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'SFT',   'Spot face thickness over size',  '55');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'SFU',   'Spot face thickness under size',  '56');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'SUS',   'Spot face under size',  '57');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'TUS',   'Thickness under size',  '58');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'TDA',   'Thread damage',  '59');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'TDU',   'Thread depth under size',  '60');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'TGN',   'Thread Go not enter',  '61');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'TNG',   'Thread No Go enter',  '62');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'TOP',   'Thread open',  '63');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'TLU',   'Total length under size',  '64');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_SINGLE_WORD', 'WTP',   'Wall thickness problem',  '65');

INSERT INTO `qqordermgmnt`.`codeassociation` ( `category`, `picklist`) VALUES ('REJECTION_REPORT_TYPE', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_REPORT_TYPE', 'OW', 'Operator wise' ,1);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_REPORT_TYPE', 'PW', 'Part wise', 2);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_REPORT_TYPE', 'SW', 'System wise', 3);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_REPORT_TYPE', 'FR', 'Rework reason wise', 4);

-- --
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('ROLES', 'INVOICE_STATUS_WRITE', 'INVOICE_STATUS_WRITE', '17');
 --- --

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `activeDt`, `displaySeq`) VALUES ('TRANSPORT_MODE', 'ROD', 'By - Road', '2018-12-01 15:04:04', '3');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_REPORT_TYPE', 'IW', 'Incharge wise', '5');

INSERT INTO `qqordermgmnt`.`codeassociation` (`category`, `picklist`) VALUES ('APP_TIME_ZONE', 'Y');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `activeDt`, `displaySeq`, `createdBy`, `createdDt`)
VALUES ('APP_TIME_ZONE', 'TZ', 'IST', '2017-01-01', '1', '2', '2019-11-28');


INSERT INTO `qqordermgmnt`.`codeassociation` (`category`, `picklist`) VALUES ('SHIFT', 'Y');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('SHIFT', '1ST', '1st Shift' ,1);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('SHIFT', '2ND', '2st Shift', 2);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('SHIFT', '3RD', '3st Shift', 3);

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('TASK_PART_STATUS', 'NEW', 'New', 0);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`) VALUES ('TASK_PART_STATUS', 'RW', 'Re-Work');

UPDATE `qqordermgmnt`.`codes` SET `description` = 'INITIAL' WHERE (`id` = '372');

ALTER TABLE `qqordermgmnt`.`codes`
ADD INDEX `category` (`category` ASC) VISIBLE;

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_REPORT_TYPE', 'MW', 'Machine wise', '6');


INSERT INTO `qqordermgmnt`.`codeassociation` (`category`, `picklist`) VALUES ('IDLE_REASON', 'Y');


INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'NOP', 'No operator', '1');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'REW', 'Rework', '2');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'PRP', 'Process problem', '3');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'ITC', 'Insert / tool change', '4');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'TDI', 'Tool delay/Issues', '5');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'FID', 'Fixture delay', '6');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'FIT', 'Fir Time', '7');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'PIT', 'Pir Time', '8');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'MAI', 'Maintanence', '9');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'MAC', 'Machine cleaning', '10');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'CTC', 'Coolant tank cleaning', '11');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'MBD', 'M/C break down', '12');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'POC', 'Power cut', '13');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'AIP', 'Air pressure', '14');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'SET', 'Setting', '15');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'RES', 'ReSetting', '16');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'MAA', 'Machine accident', '17');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'FIW', 'Fixture work', '18');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'DEV', 'Development', '19');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'MEE', 'Meeting', '20');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'LOW', 'Loading work', '21');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'CAS', 'Casting Issue', '22');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'NOO', 'No load', '23');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'LOA', 'Load feeding delay', '24');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'INE', 'Inefficiency', '25');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'INS', 'Instrument Delay', '26');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'PRT', 'Process Trail', '27');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'UNS', 'Unplanned Setting', '28');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'STT', 'Setter Delay', '29'); -- changed later


INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `activeDt`, `displaySeq`, `createdBy`, `createdDt`) VALUES ('APP_TIME_ZONE', 'TZ_MYSQL', 'Asia/Calcutta', '2017-01-01 00:00:00', '2', '2', '2019-12-21 00:00:00');



INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('REJECTION_REPORT_TYPE', 'RR', 'Rejection RCCA Chart', '7');

INSERT INTO `qqordermgmnt`.`codeassociation` ( `category`, `picklist`) VALUES ('IDLETIME_REPORT_TYPE', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLETIME_REPORT_TYPE', 'MCW', 'Machine wise' ,1);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLETIME_REPORT_TYPE', 'RSW', 'Reason wise', 2);


INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('TOOL_INVOICE_STATUS', 'INVCU', 'Invoice to Customer Accounts', '1');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('TOOL_INVOICE_STATUS', 'PR', 'Payment Received', '2');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('TOOL_INVOICE_STATUS', 'FIRC', 'FIRC', '3');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('TOOL_INVOICE_STATUS', 'EDPMS', 'EDPMS', '4');


INSERT INTO `qqordermgmnt`.`codeassociation` (`category`, `picklist`) VALUES ('TOOL_INVOICE_STATUS', 'Y');


INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLETIME_REPORT_TYPE', 'MRW', 'Machine and Reason Wise', '3');



INSERT INTO `qqordermgmnt`.`codeassociation` (`category`, `picklist`) VALUES ('PROCESS_TYPE', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('PROCESS_TYPE', 'FIP', 'Initial Process', '1');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('PROCESS_TYPE', 'MCH', 'Machining Process', '2');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('PROCESS_TYPE', 'FIN', 'Final Process', '3');



INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'HOL', 'Holiday', '30');

INSERT INTO `qqordermgmnt`.`codeassociation` ( `category`, `picklist`) VALUES ('EFFICIENCY_REPORT_TYPE', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('EFFICIENCY_REPORT_TYPE', 'MA', 'Machine Efficiency Vs Actual' ,1);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('EFFICIENCY_REPORT_TYPE', 'MP', 'Machine Efficiency Vs Planned', 2);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('IDLE_REASON', 'NEI', 'Network Issue', '31');




INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('ROLES', 'PENDING_READ', 'PENDING_READ', '18');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('ROLES', 'COMPANY_READ', 'COMPANY_READ', '19');


INSERT INTO `qqordermgmnt`.`codeassociation` ( `category`, `picklist`) VALUES ('MONTH', 'Y');


INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('MONTH', 'JA', 'January' ,1);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('MONTH', 'FE', 'February', 2);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('MONTH', 'MA', 'March', 3);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('MONTH', 'AI', 'April' ,4);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('MONTH', 'MY', 'May', 5);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('MONTH', 'JN', 'June', 6);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('MONTH', 'JL', 'July' ,7);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('MONTH', 'AU', 'August', 8);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('MONTH', 'SE', 'September', 8);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('MONTH', 'OC', 'October' ,10);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('MONTH', 'NV', 'November', 11);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('MONTH', 'DE', 'December', 12);

INSERT INTO `qqordermgmnt`.`codeassociation` ( `category`, `picklist`) VALUES ('SAFETY_STOCK_UNIT', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('SAFETY_STOCK_UNIT', 'NO', 'Number' ,1);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('SAFETY_STOCK_UNIT', 'PT', 'Percent', 2);

INSERT INTO `qqordermgmnt`.`codeassociation` ( `category`, `picklist`) VALUES ('JOB_TYPE', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('JOB_TYPE', 'BO', 'Bought Out' ,1);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('JOB_TYPE', 'MC', 'Machining', 2);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('JOB_TYPE', 'JB', 'Jobbing', 3);


INSERT INTO `qqordermgmnt`.`codeassociation` ( `category`, `picklist`) VALUES ('P_AND_L', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('P_AND_L', 'INC', 'Income' ,1);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('P_AND_L', 'EXP', 'Expenditure', 2);
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('P_AND_L', 'OEX', 'OtherExpenditure', 3);



INSERT INTO `qqordermgmnt`.`codeassociation` (`category`, `picklist`) VALUES ('CASTING_REJECTION', 'Y');


INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'BH', 'Blow holes ','0');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'PH', 'Pin holes','1');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'SH', 'Shrinkage ','2');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'PO', 'Porosity','3');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'VR', 'Crack','4');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'DA', 'Damage','5');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'SI', 'Sand inclusion','6');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'SG', 'Slag inclusion','7');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'SH', 'Shift or mismatch','8');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'SA', 'Sand drop','9');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'SC', 'Scabbing','10');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'CO', 'Cold metal','11');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'SA', 'Sand fusion','12');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'RU', 'Rust','13');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'MB', 'Mould broken','14');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'RO', 'Run out','15');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'HH', 'High hardness','16');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'LH', 'Low hardness','17');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'CG', 'Compacted graphite','18');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'CA', 'Carbides','19');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('CASTING_REJECTION', 'CR', 'Carbon exploded','20');


---- Query implemented in th Q & Q AWS


INSERT INTO `qqordermgmnt`.`codes` (category, code,description,displaySeq,createdBy,createdDt) values ('P_AND_L','PBI', 'Profit before Interest & Depreciation',4,2,now());
INSERT INTO `qqordermgmnt`.`codes` (category, code,description,displaySeq,createdBy,createdDt) values ('P_AND_L','INT', 'Interests',5,2,now());
INSERT INTO `qqordermgmnt`.`codes` (category, code,description,displaySeq,createdBy,createdDt) values ('P_AND_L','CPR', 'Cash Profit',6,2,now());
INSERT INTO `qqordermgmnt`.`codes` (category, code,description,displaySeq,createdBy,createdDt) values ('P_AND_L','DPR', 'Depreciation',7,2,now());
INSERT INTO `qqordermgmnt`.`codes` (category, code,description,displaySeq,createdBy,createdDt) values ('P_AND_L','PBPIS', 'Profit before Partners'' Interest & Salary',8,2,now());
INSERT INTO `qqordermgmnt`.`codes` (category, code,description,displaySeq,createdBy,createdDt) values ('P_AND_L','ODC', 'Other Deductions',9,2,now());
INSERT INTO `qqordermgmnt`.`codes` (category, code,description,displaySeq,createdBy,createdDt) values ('P_AND_L','PL', 'Profit / Loss',10,2,now());
INSERT INTO `qqordermgmnt`.`codes` (category, code,description,displaySeq,createdBy,createdDt) values ('P_AND_L','RPY', 'Repayments',11,2,now());
INSERT INTO `qqordermgmnt`.`codes` (category, code,description,displaySeq,createdBy,createdDt) values ('P_AND_L','CS', 'Cash Surplus',12,2,now());
INSERT INTO `qqordermgmnt`.`codes` (category, code,description,displaySeq,createdBy,createdDt) values ('P_AND_L','CPRP', 'Cash Profit %',13,2,now());
INSERT INTO `qqordermgmnt`.`codes` (category, code,description,displaySeq,createdBy,createdDt) values ('P_AND_L','PLP', 'Profit / Loss %',14,2,now());


INSERT INTO `qqordermgmnt`.`codes` (category, code,description,displaySeq,createdBy,createdDt) values ('P_AND_L','CON', 'Contribution',3,2,now());

---- Query implemented in th Q & Q AWS

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`) VALUES ('TASK_PART_STATUS', 'CRJ', 'Casting Rejection');
UPDATE `qqordermgmnt`.`codes` SET `description` = 'Machining Rejection' WHERE (`category` = 'TASK_PART_STATUS' AND code ='RJ');

---- Query implemented in th Q & Q AWS &&& FT
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `activeDt`, `displaySeq`) VALUES ('MACHINE_TYPE', 'CGM', 'Cylindrical Grinding Machine', '2018-12-27 18:29:00', '0');


INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `activeDt`, `displaySeq`, `createdBy`) VALUES ('CP_CALIBRATION', 'MIC', 'Micrometer', '2019-09-01 07:43:36', '0', '3');

UPDATE `qqordermgmnt`.`codes` SET `description` = 'vernier  caliper' WHERE (`category` = 'CP_CALIBRATION' and code = 'VC');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `activeDt`, `displaySeq`, `createdBy`) VALUES ('CP_CALIBRATION', 'TPV', 'Thread plug gauge with vernier caliper', '2019-09-01 07:43:36', '0', '3');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `activeDt`, `displaySeq`, `createdBy`) VALUES ('CP_CALIBRATION', 'SFC', 'Surface finish Comparator', '2019-09-01 07:43:36', '0', '3');


INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `activeDt`, `displaySeq`, `createdBy`) VALUES ('MACHINE_TYPE', 'VIS', 'Visual', '2018-12-27 18:29:00', '0', '3');


INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `activeDt`, `displaySeq`, `createdBy`) VALUES ('SPECVAL_TYPE', 'THI', 'Thickness', '2018-12-27 18:29:00', '0', '0');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `activeDt`, `displaySeq`, `createdBy`) VALUES ('SPECVAL_TYPE', 'DIA', 'Diameter', '2018-12-27 18:29:00', '0', '0');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `activeDt`, `displaySeq`, `createdBy`) VALUES ('SPECVAL_TYPE', 'FIN', 'Finish', '2018-12-27 18:29:00', '0', '0');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `activeDt`, `displaySeq`, `createdBy`) VALUES ('SAFETY_STOCK_UNIT', 'NO', 'Kilo' , '2018-12-27 18:29:00', 3, '0');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `activeDt`, `displaySeq`, `createdBy`) VALUES ('SAFETY_STOCK_UNIT', 'PT', 'Meter', '2018-12-27 18:29:00', 4, '0');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'KG' WHERE (`category` = 'SAFETY_STOCK_UNIT' and description = 'Kilo');
UPDATE `qqordermgmnt`.`codes` SET `code` = 'MT' WHERE (`category` = 'SAFETY_STOCK_UNIT' and description = 'Meter');

--------

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('PROVINCE', 'DL', 'Delhi', '0');

INSERT INTO `qqordermgmnt`.`codeassociation` (`category`, `picklist`, `createdBy`, `createdDt`)
VALUES ('PO_NUMBER_SERIES', 'Y', '2', '2020-02-25');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `isUserGenerated`, `displaySeq`, `createdBy`, `createdDt`)
VALUES ('PO_NUMBER_SERIES', 'PONOS', 'QQFY', 'N', '1', '2', '2020-02-25');

---- Query implemented in th Q & Q AWS
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'CAT', 'CARBIDE TOOLS', '0', '3', '2020-01-07 09:20:24', '2020-01-07 09:20:24');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'HST', 'HSS TOOLS', '0', '3', '2020-01-07 09:20:24', '2020-01-07 09:20:24');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'TAP', 'TAPS', '0', '3', '2020-01-07 09:20:24', '2020-01-07 09:20:24');


INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `isUserGenerated`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('MAKE', 'AL', 'ALPHA PRECISION', 'Y', '0', '3', '2020-01-07 09:20:24', '2020-01-07 09:20:24');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `isUserGenerated`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('MAKE', 'AD', 'ADDISON', 'Y', '0', '3', '2020-01-07 09:20:24', '2020-01-07 09:20:24');

INSERT INTO `qqordermgmnt`.`codeassociation` (`category`, `picklist`) VALUES ('VALIDATION_TYPE', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('VALIDATION_TYPE', 'DD', 'DROPDOWN', '0');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('VALIDATION_TYPE', 'NO', 'NUMBER', '1');
---- Query implemented in th Q & Q AWS


INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `isUserGenerated`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('MAKE', 'AC', 'ACCKEE', 'Y', '0', '3', '2020-01-07 09:20:24', '2020-01-07 09:20:24');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `isUserGenerated`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('MAKE', 'PL', 'PALBIT', 'Y', '0', '3', '2020-01-07 09:20:24', '2020-01-07 09:20:24');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `isUserGenerated`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('MAKE', 'IS', 'ISCAR', 'Y', '0', '3', '2020-01-07 09:20:24', '2020-01-07 09:20:24');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `isUserGenerated`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('MAKE', 'WD', 'WIDAX', 'Y', '0', '3', '2020-01-07 09:20:24', '2020-01-07 09:20:24');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `isUserGenerated`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('MAKE', 'MT', 'MASSTOOLINGS', 'Y', '0', '3', '2020-01-07 09:20:24', '2020-01-07 09:20:24');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `isUserGenerated`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('MAKE', 'EC', 'ECHAIN', 'Y', '0', '3', '2020-01-07 09:20:24', '2020-01-07 09:20:24');



INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'FMC', 'FACE MILL CUTTER', '0', '3', now(),now());
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'RBB', 'ROUGH BORING BAR', '0', '3', now(),now());
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'FBB', 'FINISH BORING BAR', '0', '3', now(),now());
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'BOF', 'BACK BORE FINISHING BAR', '0', '3', now(),now());
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'BCT', 'BACK CHAMFER TOOL', '0', '3', now(),now());
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'SFM', 'SIDE & FACE MILLING CUTTER', '0', '3', now(),now());
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'BBB', 'BACK BORING BAR', '0', '3', now(),now());
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'GRC', 'GROOVING CUTTER', '0', '3', now(),now());
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'BAC', 'BACK CHAMFER', '0', '3', now(),now());
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'HFC', 'HIGH FEED CUTTER', '0', '3', now(),now());
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'PAC', 'PARTING CUTTER', '0', '3', now(),now());
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'BOH', 'BORING HOLDER', '0', '3', now(),now());
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'ITH', 'INTERNAL THREADING HOLDER', '0', '3', now(),now());
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'IGH', 'ID GROOVING HOLDER', '0', '3', now(),now());
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'ITB', 'INTERNAL THREADING BAR', '0', '3', now(),now());
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'OGH', 'OD GROOVING HOLDER', '0', '3', now(),now());
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'TUH', 'TURNING HOLDER', '0', '3', now(),now());
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('TOOL_TYPE', 'FGH', 'FACE GROOVING HOLDER', '0', '3', now(),now());
---- Query implemented in th Q & Q AWS   AND FT AWS on 9th-march-2020

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `activeDt`, `expireDt`, `displaySeq`, `createdBy`, `createdDt`) VALUES ('PROVINCE', 'KA', 'Karnataka', '2018-12-27 18:29:00', '2018-12-27 18:29:00', '0', '3', '2020-03-09 09:20:24');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `activeDt`, `expireDt`, `displaySeq`, `createdBy`, `createdDt`) VALUES ('PROVINCE', 'GU', 'Gujarat', '2018-12-27 18:29:00', '2018-12-27 18:29:00', '0', '3', '2020-03-09 09:20:24');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `activeDt`, `expireDt`, `displaySeq`, `createdBy`, `createdDt`) VALUES ('PROVINCE', 'MH', 'Maharastra', '2018-12-27 18:29:00', '2018-12-27 18:29:00', '0', '3', '2020-03-09 09:20:24');


INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `isUserGenerated`, `activeDt`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('SAFETY_STOCK_UNIT', 'LT', 'Litre', 'Y', '2018-12-27 18:29:00', '5', '3', '2020-03-09 18:29:00', '2020-03-09 18:29:00');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `isUserGenerated`, `activeDt`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('SAFETY_STOCK_UNIT', 'SE', 'SET', 'Y', '2018-12-27 18:29:00', '5', '3', '2020-03-09 18:29:00', '2020-03-09 18:29:00');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `isUserGenerated`, `activeDt`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('SAFETY_STOCK_UNIT', 'RE', 'REEM', 'Y', '2018-12-27 18:29:00', '5', '3', '2020-03-09 18:29:00', '2020-03-09 18:29:00');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `isUserGenerated`, `activeDt`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('SAFETY_STOCK_UNIT', 'PO', 'Pocket', 'Y', '2018-12-27 18:29:00', '5', '3', '2020-03-09 18:29:00', '2020-03-09 18:29:00');


INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `isUserGenerated`, `activeDt`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('MAKE', 'DI', 'DIJET', 'Y', '2018-12-27 18:29:00', '0', '3', '2020-03-09 18:29:00', '2020-03-09 18:29:00');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `isUserGenerated`, `activeDt`, `displaySeq`, `createdBy`, `createdDt`, `modifiedDt`) VALUES ('MAKE', 'KO', 'KORLOY', 'Y', '2018-12-27 18:29:00', '0', '3', '2020-03-09 18:29:00', '2020-03-09 18:29:00');


INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `isUserGenerated`, `activeDt`, `displaySeq`, `createdBy`, `createdDt`) VALUES ('HOLDER_TYPE', 'FMT', 'FACE MILL TYPE', 'Y', '2018-12-27 18:29:00', '0', '3', '2020-01-07 09:20:24');


INSERT INTO `qqordermgmnt`.`codeassociation` (`category`, `picklist`) VALUES ('EDUCATION', 'Y');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('EDUCATION', 'ITI', 'ITI', '1');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('EDUCATION', 'DIP', 'DIPLOMA', '2');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('EDUCATION', 'DEG', 'DEGREE', '3');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('EDUCATION', 'SSLC', '10th', '4');
INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`, `displaySeq`) VALUES ('EDUCATION', 'HSC', '+2', '5');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`) VALUES ('TOOL_INVOICE_STATUS', 'MEIS', 'MEIS');

UPDATE `qqordermgmnt`.`codes` SET `description` = 'MEIS / SEPS ' WHERE (`code` = 'MEIS' and `category` = 'INVOICE_STATUS');
UPDATE `qqordermgmnt`.`codes` SET `description` = 'MEIS / SEPS ' WHERE (`code` = 'MEIS' and `category` = 'TOOL_INVOICE_STATUS');

INSERT INTO `qqordermgmnt`.`codes` (`category`, `code`, `description`) VALUES ('PAYMENT_TERMS', 'OT', 'Others');


-- <<<<<<< Vendor Table Changes Added 4 columns Phone No, Email , District code , state code >>>>>
ALTER TABLE `qqordermgmnt`.`vendor`
    ADD COLUMN `phoneNo` VARCHAR(50) NULL DEFAULT NULL AFTER `ieCode`,
ADD COLUMN `email` VARCHAR(100) NULL DEFAULT NULL AFTER `phoneNo`,
ADD COLUMN `DistrictCode` INT NULL DEFAULT NULL AFTER `email`,
ADD COLUMN `stateCode` INT NULL DEFAULT NULL AFTER `DistrictCode`;

-- Update to insert values in vendor table

UPDATE `qqordermgmnt`.`vendor` SET `phoneNo` = '8220092333', `email` = 'vikram@qqsworld.com,sales@qqsworld.com', `DistrictCode` = '559', `stateCode` = '33' WHERE (`id` = '1');

