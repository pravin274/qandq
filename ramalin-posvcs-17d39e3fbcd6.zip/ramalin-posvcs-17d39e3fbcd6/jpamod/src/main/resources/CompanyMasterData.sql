

truncate table company;
INSERT INTO `company` VALUES (1,NULL,'TechnipFMC','CORP','TechipFMC','23-456789',0);
INSERT INTO `company` VALUES (2,NULL,'Sakthi Gear Products','CORP','Sakthi Gear Products','24',0);
INSERT INTO `company` VALUES (3,NULL,'Future tech Engineers','CORP','Future tech Engineers','25',0);
INSERT INTO `company` VALUES (4,NULL,'Reliance Machine Tools','CORP','Reliance Machine Tools','26',0);

truncate table plant;
INSERT INTO `plant` VALUES (1,1,'1101','Erie Plant','158564','N','USD','58','EXW Coimbatore/ INDIA','Zero Rated','2018-12-04 15:07:35','2018-12-04 15:07:40'),
(2,1,'EFST','Stephenville','158564','N','USD','58','EXW Coimbatore/ INDIA','Zero Rated',NULL,NULL);
INSERT INTO `plant` VALUES (3,1,'1201','Ellerbek','158564','N','EURO','58','EXW Coimbatore/ INDIA','Zero Rated','2019-02-04 12:27:35','2019-02-04 15:07:40');
INSERT INTO `plant` VALUES (4,2,'Unit 1','Coimbatore','SGP - 1 - 103','Y','INR','30','DAP','18% GST','2019-02-04 12:27:35','2019-02-04 15:07:40');
INSERT INTO `plant` VALUES (5,2,'Branch','Coimbatore','SGP - 2 - 103','Y','INR','30','DAP','18% GST','2019-02-04 12:27:35','2019-02-04 15:07:40');
INSERT INTO `plant` VALUES (6,3,'MachineShop','Coimbatore','FTE - 101','Y','INR','30','DAP','18% GST','2019-02-04 12:27:35','2019-02-04 15:07:40');
INSERT INTO `plant` VALUES (7,4,'Inserts - Trader','Chennai','RDT - 104','Y','INR','30','DAP','18% GST','2019-02-04 12:27:35','2019-02-04 15:07:40');


truncate table address;

INSERT INTO `address` (id,parentid,parentEntity,type,streetNo,streetname,linetwo,linethree,linefour,city,province,country,postalcd,createdDt,modifiedDt)
VALUES (1,1,'P','B','1602','FMC Technologies Measurement Solutions Inc','P.O Box 10428','Wagner Avenue','','Erie','PA','US','16514-0428',now(),now()),
(2,1,'P','D','1648','McClelland Avenue','','','','Erie','PA','US','16510',now(),now());

INSERT INTO `address` (id,parentid,parentEntity,type,streetNo,streetname,linetwo,linethree,linefour,city,province,country,postalcd,createdDt,modifiedDt)
VALUES (3,2,'P','B','2825','FMC Fluid Control','W Washinton','','','Stephenville','TX','US','76401',now(),now()),
(4,2,'P','D','2830','West Frey','','''','','Stephenville','TX','US','76401',now(),now());


INSERT INTO `address` (id,parentid,parentEntity,type,streetNo,streetname,linetwo,linethree,linefour,city,province,country,postalcd,createdDt,modifiedDt)
VALUES (5,3,'P','B','25474','FMC Technologies Measurement Solutions','Smith Meter GmbH','Regentstrasse 1','','ELLERBEK','','GR','',now(),now()),
(6,3,'P','D','D-25474','TechnipFMC','Smith Meter GmbH','Regentstrasse 1','','ELLERBEK','','GR','',now(),now());

INSERT INTO `address` (id,parentid,parentEntity,type,streetNo,streetname,linetwo,linethree,linefour,city,province,country,postalcd,createdDt,modifiedDt)
VALUES (7,4,'P','B','7/4','School Street','Chinnavedampatti Post','','Ganapathy','Coimbatore','TN','IN','641049',now(),now()),
(8,4,'P','D','7/4','School Street','Chinnavedampatti Post','','Ganapathy','Coimbatore','TN','IN','641049',now(),now());


INSERT INTO `address` (id,parentid,parentEntity,type,streetNo,streetname,linetwo,linethree,linefour,city,province,country,postalcd,createdDt,modifiedDt)
VALUES (9,5,'P','B','S F No 99','Vvadugapalayam','Salayur Pirivu','Naranapuram village','Annur Taluk','Coimbatore','TN','IN','641107',now(),now()),
(10,5,'P','D','S F No 99','Vvadugapalayam','Salayur Pirivu','Naranapuram village','Annur Taluk','Coimbatore','TN','IN','641107',now(),now());

INSERT INTO `address` (id,parentid,parentEntity,type,streetNo,streetname,linetwo,linethree,linefour,city,province,country,postalcd,createdDt,modifiedDt)
VALUES (11,6,'P','B','418/1','Athipalayam Road','Chinnavedampatti','','','Coimbatore','TN','IN','641049',now(),now()),
(12,6,'P','D','418/1','Athipalayam Road','Chinnavedampatti','','','Coimbatore','TN','IN','641049',now(),now());


INSERT INTO `address` (id,parentid,parentEntity,type,streetNo,streetname,linetwo,linethree,linefour,city,province,country,postalcd,createdDt,modifiedDt)
VALUES (13,7,'P','B','Plot No: 6 & 7','Association Road','Madavaram','','','Chennai','TN','IN','600060',now(),now()),
(14,7,'P','D','Plot No: 6 & 7','Association Road','Madavaram','','','Chennai','TN','IN','600060',now(),now());


truncate table people;

insert into people (id,externalid,parentType,parentId, category,firstName,lastName,middleInitial,otherInfo,createdDt,modifiedDt)
values (1,1,'P',1,'B','Gandhi','Baskar','','',now(),now());


insert into people (id,externalid,parentType,parentId, category,firstName,lastName,middleInitial,otherInfo,createdDt,modifiedDt)
values (2,1,'P',1,'B','Kevin','Schaaf','','',now(),now());

insert into people (id,externalid,parentType,parentId, category,firstName,lastName,middleInitial,otherInfo,createdDt,modifiedDt)
values (3,2,'P',2,'B','Anthony','Williams','','',now(),now());

insert into people (id,externalid,parentType,parentId, category,firstName,lastName,middleInitial,otherInfo,createdDt,modifiedDt)
values (4,3,'P',3,'B','Holger','knief','','',now(),now());

insert into people (id,externalid,parentType,parentId, category,firstName,lastName,middleInitial,otherInfo,createdDt,modifiedDt)
values (5,3,'P',4,'B','Shanmugasundaram','','','',now(),now());


insert into people (id,externalid,parentType,parentId, category,firstName,lastName,middleInitial,otherInfo,createdDt,modifiedDt)
values (6,3,'P',4,'B','Raja','','','',now(),now());

insert into people (id,externalid,parentType,parentId, category,firstName,lastName,middleInitial,otherInfo,createdDt,modifiedDt)
values (7,3,'P',5,'B','Easwaran','Ranjith','','',now(),now());

insert into people (id,externalid,parentType,parentId, category,firstName,lastName,middleInitial,otherInfo,createdDt,modifiedDt)
values (8,3,'P',6,'B','Peter','','','',now(),now());

insert into people (id,externalid,parentType,parentId, category,firstName,lastName,middleInitial,otherInfo,createdDt,modifiedDt)
values (9,3,'P',6,'B','Ravi','','','',now(),now());

insert into people (id,externalid,parentType,parentId, category,firstName,lastName,middleInitial,otherInfo,createdDt,modifiedDt)
values (10,3,'P',7,'B','Venkat Raman','','','',now(),now());

insert into people (id,externalid,parentType,parentId, category,firstName,lastName,middleInitial,otherInfo,createdDt,modifiedDt)
values (11,3,'P',7,'B','Aravindan','','','',now(),now());

insert into people (id,externalid,parentType,parentId, category,firstName,lastName,middleInitial,otherInfo,createdDt,modifiedDt)
values (12,3,'V',1,'R','GnanaSekar','','','',now(),now());

truncate table qqordermgmnt.vendor;
insert into qqordermgmnt.vendor (vendorid,vendorName,createdDt,modifiedDt) values (1,'Q&Q Solutions', now(), now());

