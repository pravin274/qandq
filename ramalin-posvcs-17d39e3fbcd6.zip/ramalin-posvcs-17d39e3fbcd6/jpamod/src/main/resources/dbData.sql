/*
SQLyog Community v12.5.0 (64 bit)
MySQL - 5.7.20 : Database - qqordermgmnt
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`qqordermgmnt` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `qqordermgmnt`;

/*Data for the table `address` */

insert  into `address`(`id`,`parentId`,`parentEntity`,`type`,`streetNo`,`streetName`,`lineTwo`,`lineThree`,`lineFour`,`city`,`province`,`country`,`postalCd`,`createdDt`,`modifiedDt`) values 
(1,1,'C','H','2','Gaskill','L2','L3','L4','Mt Laurel','NJ','US','08054',NULL,NULL),
(2,1,'C','H','2','Gaskill',NULL,'dummy',NULL,'Mt Laurel','NJ','US','08054','2018-12-17 11:11:14',NULL),
(3,1,'P','H','2','Gaskill',NULL,'dummy',NULL,'Mt Laurel','NJ','US','08054','2019-01-01 21:20:30',NULL),
(4,1,'H','C','20','Church Road','L2','L3','L4','Mt Laurel','NJ','US','08054','2019-01-28 08:37:58',NULL);

/*Data for the table `codeassociation` */

insert  into `codeassociation`(`id`,`category`,`picklist`) values 
(1,'PART_CATEGORY','Y'),
(2,'PART_STAGE','Y'),
(3,'PART_DOMAIN','Y'),
(4,'PART_WT_UNIT','Y'),
(5,'PART_TYPE','Y'),
(6,'PART_STATUS','Y');


/*Data for the table `codes` */

insert  into `codes`(`id`,`category`,`code`,`desc`,`activeDt`,`expireDt`,`notes`,`createdDt`,`modifiedDt`) values 
(1,'PART_CATEGORY','CST','Casting','2018-12-01 15:02:28','2028-12-27 15:02:35',NULL,'2018-12-27 15:02:59','2018-12-27 15:03:03'),
(2,'PART_CATEGORY','MCN','Machining','2018-12-01 15:03:57',NULL,NULL,'2018-12-27 15:04:25','2018-12-27 15:04:21'),
(3,'PART_CATEGORY','ALY','Assembly','2018-12-01 15:04:04',NULL,NULL,'2018-12-27 15:04:12','2018-12-27 15:04:17'),
(4,'PART_STAGE','PODT','PoDate','2018-12-01 18:26:16',NULL,NULL,'2018-12-27 18:26:26','2018-12-27 18:26:31'),
(5,'PART_STAGE','SHIP','ShippedDate','2018-12-01 18:27:15',NULL,NULL,'2018-12-27 18:27:25','2018-12-27 18:27:30'),
(6,'PART_STAGE','APRV','ApprovedDate','2018-12-01 18:28:00',NULL,NULL,'2018-12-27 18:28:07','2018-12-27 18:28:13'),
(7,'PART_STAGE','FARV','FirstApproval','2018-12-01 18:28:47',NULL,NULL,'2018-12-27 18:28:54','2018-12-27 18:29:00'),
(8,'PART_DOMAIN','MINE','Mining','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(9,'PART_DOMAIN','OAG','Oil and Gas','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(10,'PART_DOMAIN','AGRI','Agriculture','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(11,'PART_DOMAIN','AUTO','Automotive','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(12,'PART_DOMAIN','ENRG','Energy','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(13,'PART_DOMAIN','MAHA','Material Handling','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(14,'PART_DOMAIN','INFR','Infrastructure','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(15,'PART_DOMAIN','AERO','Aerospace','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(16,'PART_WT_UNIT','METER','Meter','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(17,'PART_WT_UNIT','KGS','Kilogram','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(18,'PART_WT_UNIT','SET','Set','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(19, 'PART_TYPE', 'TOOL', 'Tool', '2018-12-01 00:00:00',NULL,NULL, '2018-12-01 00:00:00',NULL),
(20, 'PART_TYPE', 'FAI', 'FAI', '2018-12-01 00:00:00',NULL,NULL, '2018-12-01 00:00:00',NULL),
(21, 'PART_TYPE', 'PROD', 'Prodcution', '2018-12-01 00:00:00',NULL,NULL, '2018-12-01 00:00:00',NULL);
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`) VALUES ('22', 'PART_STATUS', 'SAMP', 'Sample', '2018-12-01 00:00:00', '2018-12-01 00:00:00');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`) VALUES ('23', 'PART_STATUS', 'PPAP', 'PPAP', '2018-12-01 00:00:00', '2018-12-01 00:00:00');
INSERT INTO `qqordermgmnt`.`codes` (`id`, `category`, `code`, `desc`, `activeDt`, `createdDt`) VALUES ('24', 'PART_STATUS', 'PROD', 'Prodcution', '2018-12-01 00:00:00', '2018-12-01 00:00:00');
/*Data for the table `company` */

insert  into `company`(`id`,`parentId`,`name`,`type`,`desc`,`taxId`,`hierarchy`) values 
(1,NULL,'FMC','CORP','TechipFMC','23-456789',0);

/*Data for the table `email` */

insert  into `email`(`id`,`parentId`,`parentEntity`,`type`,`emailId`,`createdDt`,`modifiedDt`) values 
(1,1,'C','H','ramalin@yahoo.com','2018-12-04 22:02:23',NULL),
(2,1,'H','C','rama@qqsworld.com','2019-01-28 08:38:28',NULL);

/*Data for the table `part` */

insert  into `part`(`id`,`name`,`number`,`partRevNo`,`partRevDt`,`partRevOrder`,`drawingNo`,`drawingRevNo`,`drawingRevDt`,`QQSCode`,`QQSRevNo`,`QQSRevDt`,`projectName`,`category`,`materialSpec`,`castingWt`,`castingWtUnit`,`rfqVolume`,`mbq`,`uom`,`resourceInd`,`createdDt`,`modifiedDt`) values 
(1,'CROSSHEAD CASTING, WELL SERVICE PUMP','P531157','1',NULL,0,'DR-001','0',NULL,'FMC-002',NULL,NULL,'FMC Oil ','CST','MS0001',3,'K',10,10,'KG','N',NULL,NULL),
(2,'CROSSHEAD CASTING, WELL SERVICE PUMP','P531157','2','2019-01-26 13:09:02',1,'DR-001','1','2019-01-26 13:09:27','FMC-002',NULL,NULL,NULL,'ALY',NULL,NULL,NULL,NULL,10,NULL,NULL,NULL,NULL),
(3,'Rama','Sudalayandi','34',NULL,NULL,'DR-001',NULL,NULL,'QQS1',NULL,NULL,'Temp','MIN','m',12,'K',11,10,'l','Y',NULL,NULL),
(4,'Test Part','1234',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,10,NULL,NULL,NULL,NULL),
(5,'Part4','abc',NULL,NULL,NULL,'d2',NULL,NULL,'qqs2',NULL,NULL,'P2',NULL,'M',12,'K',11,12,'L','Y',NULL,NULL),
(6,'Part4','abc',NULL,NULL,NULL,'d2',NULL,NULL,'qqs2',NULL,NULL,'P2',NULL,'M',12,'K',11,12,'L','Y',NULL,NULL),
(7,'Part5','P5',NULL,NULL,NULL,'D5',NULL,NULL,'Q5',NULL,NULL,'P2','CST','M',12,'K',10,10,'L','Y',NULL,NULL),
(8,'Sekar','S011',NULL,NULL,NULL,'DS001',NULL,NULL,'QQS1',NULL,NULL,'P2','ALY','M02',34,'G',10,10,'U','Y',NULL,NULL),
(9,'Part10','P531158','2',NULL,NULL,'DR-001',NULL,NULL,'qqs3',NULL,NULL,NULL,'ALY',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*Data for the table `partchronology` */

insert  into `partchronology`(`id`,`partNo`,`stage`,`stageDt`,`createdBy`,`createdDt`,`modifiedBy`,`modifiedDt`) values 
(1,1,'PODT','2018-12-20 11:03:29',1,'2018-12-27 11:03:40',1,'2018-12-27 11:03:44'),
(2,1,'SHIP','2018-12-27 11:04:10',1,'2018-12-27 11:04:24',1,'2018-12-27 11:04:30');

/*Data for the table `partdomain` */

insert  into `partdomain`(`id`,`partId`,`domain`,`createdDt`,`modifiedDt`) values 
(1,1,'MIN','2018-12-27 11:02:26','2018-12-27 11:02:33'),
(2,1,'AGR','2018-12-27 11:02:46','2018-12-27 11:02:51');

/*Data for the table `partimage` */

insert  into `partimage`(`id`,`partId`,`imageData`,`createdDt`,`modifiedDt`) values 
(1,1,NULL,'2018-12-27 11:05:07','2018-12-27 11:05:12');

/*Data for the table `partprice` */

insert  into `partprice`(`id`,`partId`,`currency`,`value`,`priceDesc`,`defaultInd`,`effectiveDt`,`createdDt`,`modifiedDt`) values
(1,1,'USD',650,NULL,'Y','2018-12-27 11:01:16','2018-12-27 11:01:16','2018-12-27 11:01:26'),
(2,1,'INR',50000,NULL,'N','2018-12-27 11:01:16','2018-12-27 11:01:44','2018-12-27 11:01:49');

/*Data for the table `partrelationxref` */

insert  into `partrelationxref`(`id`,`parentId`,`childId`) values 
(1,1,4),
(3,2,4),
(4,2,5);

/*Data for the table `partstatus` */

insert  into `partstatus`(`id`,`partId`,`status`,`desc`,`createdBy`,`createdDt`,`modifiedBy`,`modifiedDt`) values 
(1,1,'SAMP','Sample prepared',1,'2018-12-27 11:05:57',1,'2018-12-27 11:06:03');

/*Data for the table `people` */

insert  into `people`(`id`,`externalId`,`parentType`,`parentId`,`category`,`firstName`,`lastName`,`middleInitial`,`otherInfo`,`createdDt`,`modifiedDt`) values 
(1,'RAMA','C',1,'RESP','Rama','Sudalayandi',NULL,'Test Data','2018-12-05 21:32:57','2018-12-05 21:33:06');

/*Data for the table `phone` */

insert  into `phone`(`id`,`parentId`,`parentEntity`,`type`,`phoneNo`,`extension`,`createdDt`,`modifiedDt`) values 
(1,1,'C','H','8569149198',NULL,'2018-12-12 22:02:01',NULL),
(2,1,'H','C','8562666303',NULL,'2019-01-28 08:38:50',NULL);

/*Data for the table `plant` */

insert  into `plant`(`id`,`companyId`,`plantCode`,`desc`,`vendorCode`,`domesticInd`,`currency`,`pmntTerms`,`deliveryTerms`,`dutyStruct`,`createdDt`,`modifiedDt`) values 
(1,1,'1101','Erie Plant',NULL,NULL,NULL,NULL,NULL,NULL,'2018-12-04 15:07:35','2018-12-04 15:07:40'),
(2,1,'1102','Dallas Plant',NULL,NULL,NULL,NULL,NULL,NULL,'2019-01-26 12:17:28',NULL);

/*Data for the table `plantaddrxref` */

/*Data for the table `plantbuyer` */

/*Data for the table `polineitem` */

insert  into `polineitem`(`id`,`poId`,`partId`,`item`,`material`,`revision`,`description`,`quantity`,`unit`,`partPriceId`,`deliveryDate`,`createdDt`,`modifiedDt`,`createdBy`,`modifiedBy`) values
(1,1,1,'00044','P531157','E','Well Service Pump. 13.00 dia alloy steel per spec 27',4,'each',1,NULL,'2018-12-22 14:24:12','2019-01-27 20:44:55',1,1),
(2,1,1,'00055','P531432','E','Crosshead trunnion casting 27',4,'each',1,NULL,'2018-12-22 14:24:12','2019-01-27 20:44:55',1,1);

/*Data for the table `purchorder` */

insert  into `purchorder`(`id`,`companyId`,`plantId`,`poNumber`,`poDate`,`department`,`buyer`,`qqRespPerson`,`vendorCode`,`dvryAddrId`,`dvryTerms`,`pymntTerms`,`billToAddrId`,`createdDt`,`modifiedDt`,`createdBy`,`modifiedBy`) values
(1,1,1,'0002UP','2019-01-15','EFST',1,1,1,1,'EXT Coimbatore','Net 90 days - twice',1,'2018-12-22 14:24:12','2019-01-27 20:45:01',1,1),
(2,1,1,'0003UP','2019-01-30','EFST',1,1,1,1,'EXT CBE','Net 45 days',1,'2019-01-28 11:30:48','2019-01-28 11:30:56',1,1);

/*Data for the table `user` */

insert  into `user`(`id`,`firstName`,`lastName`,`userName`,`pwd`,`active`,`roles`,`createdDt`,`modifiedDt`) values 
(2,'Muruk','Nambi','muruks','77b288f465118e58e97bbe6381016788',1,'ADMIN','2019-01-26','2019-01-26');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
