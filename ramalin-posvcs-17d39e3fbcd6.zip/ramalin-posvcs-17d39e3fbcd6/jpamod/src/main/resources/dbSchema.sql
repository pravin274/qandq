/*
SQLyog Community v12.5.0 (64 bit)
MySQL - 5.7.20 : Database - qqordermgmnt
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`qqordermgmnt` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `qqordermgmnt`;

/*Table structure for table `address` */

DROP TABLE IF EXISTS `address`;

CREATE TABLE `address` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(20) NOT NULL,
  `parentEntity` varchar(20) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `streetNo` varchar(50) DEFAULT NULL,
  `streetName` varchar(100) DEFAULT NULL,
  `lineTwo` varchar(100) DEFAULT NULL,
  `lineThree` varchar(100) DEFAULT NULL,
  `lineFour` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `country` varchar(3) DEFAULT NULL,
  `postalCd` varchar(20) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

/*Table structure for table `bank` */

DROP TABLE IF EXISTS `bank`;

CREATE TABLE `bank` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `bankName` varchar(500) DEFAULT NULL,
  `accountNumber` varchar(50) DEFAULT NULL,
  `ifscCode` varchar(50) DEFAULT NULL,
  `swiftcode` varchar(45) DEFAULT NULL,
  `adCode` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `codeassociation` */

DROP TABLE IF EXISTS `codeassociation`;

CREATE TABLE `codeassociation` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(24) NOT NULL,
  `picklist` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

/*Table structure for table `codes` */

DROP TABLE IF EXISTS `codes`;

CREATE TABLE `codes` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(24) NOT NULL,
  `code` varchar(24) NOT NULL,
  `desc` varchar(200) DEFAULT NULL,
  `activeDt` datetime DEFAULT NULL,
  `expireDt` datetime DEFAULT NULL,
  `notes` varchar(512) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

/*Table structure for table `company` */

DROP TABLE IF EXISTS `company`;

CREATE TABLE `company` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(20) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `type` varchar(20) DEFAULT NULL,
  `desc` varchar(200) DEFAULT NULL,
  `taxId` varchar(40) DEFAULT NULL,
  `hierarchy` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

/*Table structure for table `email` */

DROP TABLE IF EXISTS `email`;

CREATE TABLE `email` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(20) DEFAULT NULL,
  `parentEntity` varchar(20) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `emailId` varchar(100) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

/*Table structure for table `invoice` */

DROP TABLE IF EXISTS `invoice`;

CREATE TABLE `invoice` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `serialNo` varchar(20) NOT NULL,
  `plantId` int(20) NOT NULL,
  `invDate` date DEFAULT NULL,
  `transport` varchar(5) DEFAULT NULL,
  `poId` int(20) DEFAULT NULL,
  `supplyTime` datetime DEFAULT NULL,
  `supplyPlace` int(20) DEFAULT NULL,
  `preCarriage` varchar(5) DEFAULT NULL,
  `placeReceipt` varchar(5) DEFAULT NULL,
  `vesselNo` varchar(50) DEFAULT NULL,
  `portLoad` int(20) DEFAULT NULL,
  `portDischarge` int(20) DEFAULT NULL,
  `finalDest` varchar(200) DEFAULT NULL,
  `countryOrigin` int(20) DEFAULT NULL,
  `countryOfFinal` int(20) DEFAULT NULL,
  `splInstruction` varchar(300) DEFAULT NULL,
  `declaration` varchar(5) DEFAULT NULL,
  `paymentDeclaration` varchar(45) DEFAULT NULL,
  `bankId` int(10) DEFAULT NULL,
  `signatory` int(20) DEFAULT NULL,
  `currConvRs` decimal(10,3) DEFAULT NULL,
  `undertakingLUT` char(1) DEFAULT NULL,
  `createdBy` int(20) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedBy` int(20) DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  `invoiceStatus` varchar(45) DEFAULT 'NEW',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `invoicelineitem` */

DROP TABLE IF EXISTS `invoicelineitem`;

CREATE TABLE `invoicelineitem` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoiceId` int(20) unsigned NOT NULL,
  `poLineId` int(20) unsigned NOT NULL,
  `invoiceQty` int(10) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  `createdBy` int(11) DEFAULT NULL,
  `modifiedBy` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `invoicexrefpo` */

DROP TABLE IF EXISTS `invoicexrefpo`;

CREATE TABLE `invoicexrefpo` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoiceId` int(20) NOT NULL,
  `poId` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `part` */

DROP TABLE IF EXISTS `part`;

CREATE TABLE `part` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `number` varchar(50) DEFAULT NULL,
  `partRevNo` varchar(10) DEFAULT NULL,
  `partRevDt` datetime DEFAULT NULL,
  `partRevOrder` int(2) DEFAULT NULL,
  `drawingNo` varchar(50) DEFAULT NULL,
  `drawingRevNo` varchar(10) DEFAULT NULL,
  `drawingRevDt` datetime DEFAULT NULL,
  `QQSCode` varchar(50) DEFAULT NULL,
  `QQSRevNo` varchar(10) DEFAULT NULL,
  `QQSRevDt` datetime DEFAULT NULL,
  `projectName` varchar(100) DEFAULT NULL,
  `category` char(5) DEFAULT NULL,
  `materialSpec` varchar(200) DEFAULT NULL,
  `castingWt` decimal(10,3) DEFAULT NULL,
  `castingWtUnit` char(5) DEFAULT NULL,
  `rfqVolume` int(10) DEFAULT NULL,
  `mbq` int(10) DEFAULT NULL,
  `uom` char(5) DEFAULT NULL,
  `resourceInd` char(5) DEFAULT NULL,
  `companyId` int(20) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

/*Table structure for table `partchronology` */

DROP TABLE IF EXISTS `partchronology`;

CREATE TABLE `partchronology` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `partNo` int(20) unsigned NOT NULL,
  `stage` varchar(10) DEFAULT NULL,
  `stageDt` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `createdBy` int(20) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedBy` int(20) DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

/*Table structure for table `partcommodity` */

DROP TABLE IF EXISTS `partcommodity`;

CREATE TABLE `partcommodity` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `partId` int(20) unsigned NOT NULL,
  `commodityCode` varchar(50) DEFAULT NULL,
  `countryCode` varchar(3) DEFAULT NULL,
  `effectiveDt` datetime DEFAULT NULL,
  `expiryDt` datetime DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `createdBy` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

/*Table structure for table `partcustomerrequirement` */

DROP TABLE IF EXISTS `partcustomerrequirement`;

CREATE TABLE `partcustomerrequirement` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `partId` int(20) NOT NULL,
  `noteNumber` varchar(500) COLLATE latin1_bin NOT NULL,
  `customerRequirement` varchar(500) COLLATE latin1_bin NOT NULL,
  `createdDt` datetime DEFAULT NULL,
  `createdBy` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `partdomain` */

DROP TABLE IF EXISTS `partdomain`;

CREATE TABLE `partdomain` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `partId` int(20) unsigned NOT NULL,
  `domain` char(5) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

/*Table structure for table `partimage` */

DROP TABLE IF EXISTS `partimage`;

CREATE TABLE `partimage` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `partId` int(20) unsigned NOT NULL,
  `imageData` blob,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `partprice` */

DROP TABLE IF EXISTS `partprice`;

CREATE TABLE `partprice` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `partId` int(20) NOT NULL,
  `currency` char(3) NOT NULL,
  `value` decimal(10,3) DEFAULT NULL,
  `partCategory` varchar(50) DEFAULT NULL,
  `priceDesc` varchar(200) DEFAULT NULL,
  `defaultInd` char(1) DEFAULT NULL,
  `effectiveDt` datetime DEFAULT NULL,
  `expiryDt` datetime DEFAULT NULL,
  `createdBy` int(20) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedBy` int(20) DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

/*Table structure for table `partrelationxref` */

DROP TABLE IF EXISTS `partrelationxref`;

CREATE TABLE `partrelationxref` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(20) NOT NULL,
  `childId` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

/*Table structure for table `partrevisionamendment` */

DROP TABLE IF EXISTS `partrevisionamendment`;

CREATE TABLE `partrevisionamendment` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `partId` int(20) NOT NULL,
  `revisionNumber` varchar(500) COLLATE latin1_bin NOT NULL,
  `revisionDescription` varchar(500) COLLATE latin1_bin NOT NULL,
  `revisionDate` datetime DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `createdBy` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `partstandard` */

DROP TABLE IF EXISTS `partstandard`;

CREATE TABLE `partstandard` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `partId` varchar(20) NOT NULL,
  `standardNumber` varchar(500) NOT NULL,
  `standardDescription` varchar(500) NOT NULL,
  `standardSpecificDescription` varchar(500) DEFAULT NULL,
  `revisionNumber` varchar(20) DEFAULT NULL,
  `standardLink` varchar(500) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `createdBy` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

/*Table structure for table `people` */

DROP TABLE IF EXISTS `people`;

CREATE TABLE `people` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `externalId` varchar(100) DEFAULT NULL,
  `parentType` varchar(5) DEFAULT NULL,
  `parentId` int(20) DEFAULT NULL,
  `category` varchar(5) DEFAULT NULL,
  `firstName` varchar(30) DEFAULT NULL,
  `lastName` varchar(30) DEFAULT NULL,
  `middleInitial` varchar(10) DEFAULT NULL,
  `otherInfo` varchar(300) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

/*Table structure for table `phone` */

DROP TABLE IF EXISTS `phone`;

CREATE TABLE `phone` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(20) DEFAULT NULL,
  `parentEntity` varchar(20) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `phoneNo` varchar(50) DEFAULT NULL,
  `extension` varchar(50) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

/*Table structure for table `pkgchecklist` */

DROP TABLE IF EXISTS `pkgchecklist`;

CREATE TABLE `pkgchecklist` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `pkgId` int(20) DEFAULT NULL,
  `code` varchar(20) DEFAULT NULL,
  `comments` varchar(512) DEFAULT NULL,
  `imgLocation` varchar(100) DEFAULT NULL,
  `createdBy` int(20) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedBy` int(11) DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

/*Table structure for table `pkgdetail` */

DROP TABLE IF EXISTS `pkgdetail`;

CREATE TABLE `pkgdetail` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `pkgId` int(20) DEFAULT NULL,
  `invoiceLineItemId` int(20) DEFAULT NULL,
  `qty` int(10) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `pkginvoicexref` */

DROP TABLE IF EXISTS `pkginvoicexref`;

CREATE TABLE `pkginvoicexref` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `pkgId` int(20) DEFAULT NULL,
  `invoiceId` int(20) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `pkgmaster` */

DROP TABLE IF EXISTS `pkgmaster`;

CREATE TABLE `pkgmaster` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `pkgNo` int(10) DEFAULT NULL,
  `shipId` varchar(100) DEFAULT NULL,
  `pkgType` varchar(50) DEFAULT NULL,
  `totalQty` int(10) DEFAULT NULL,
  `netWeight` decimal(15,3) DEFAULT NULL,
  `grossWeight` decimal(15,3) DEFAULT NULL,
  `weightUnit` varchar(50) DEFAULT NULL,
  `height` decimal(10,3) DEFAULT NULL,
  `length` decimal(10,3) DEFAULT NULL,
  `width` decimal(10,3) DEFAULT NULL,
  `dimensionUnit` varchar(50) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `createdBy` int(20) DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  `modifiedBy` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `places` */

DROP TABLE IF EXISTS `places`;

CREATE TABLE `places` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(5) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `type` varchar(3) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

/*Table structure for table `plant` */

DROP TABLE IF EXISTS `plant`;

CREATE TABLE `plant` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `companyId` int(20) NOT NULL,
  `plantCode` varchar(50) DEFAULT NULL,
  `desc` varchar(200) DEFAULT NULL,
  `vendorCode` varchar(50) DEFAULT NULL,
  `domesticInd` char(1) DEFAULT NULL,
  `currency` char(3) DEFAULT NULL,
  `pmntTerms` varchar(100) DEFAULT NULL,
  `deliveryTerms` varchar(200) DEFAULT NULL,
  `dutyStruct` varchar(200) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Table structure for table `plantaddrxref` */

DROP TABLE IF EXISTS `plantaddrxref`;

CREATE TABLE `plantaddrxref` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `plantId` int(20) NOT NULL,
  `addressId` int(20) NOT NULL,
  `type` char(2) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `plantbuyer` */

DROP TABLE IF EXISTS `plantbuyer`;

CREATE TABLE `plantbuyer` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `plantId` int(20) NOT NULL,
  `peopleId` int(20) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `notes` varchar(200) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `polineitem` */

DROP TABLE IF EXISTS `polineitem`;

CREATE TABLE `polineitem` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `poId` int(20) NOT NULL,
  `partType` varchar(20) DEFAULT NULL,
  `partId` int(20) NOT NULL,
  `item` varchar(100) DEFAULT NULL,
  `material` varchar(100) DEFAULT NULL,
  `revision` varchar(20) DEFAULT NULL,
  `description` varchar(800) DEFAULT NULL,
  `quantity` int(10) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `currency` varchar(10) DEFAULT NULL,
  `partPrice` int(20) DEFAULT NULL,
  `partPriceId` int(11) DEFAULT NULL,
  `deliveryDate` datetime DEFAULT NULL,
  `commodityCodeId` int(11) DEFAULT NULL,
  `poLineToolId` int(11) DEFAULT NULL,
  `isDeleted` tinyint(1) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  `createdBy` int(11) DEFAULT NULL,
  `modifiedBy` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

/*Table structure for table `polinetool` */

DROP TABLE IF EXISTS `polinetool`;

CREATE TABLE `polinetool` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(800) DEFAULT NULL,
  `price` decimal(10,0) DEFAULT NULL,
  `toolNo` varchar(30) DEFAULT NULL,
  `revNo` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

/*Table structure for table `purchorder` */

DROP TABLE IF EXISTS `purchorder`;

CREATE TABLE `purchorder` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `companyId` int(20) DEFAULT NULL,
  `plantId` int(20) DEFAULT NULL,
  `poNumber` varchar(80) NOT NULL,
  `poDate` date NOT NULL,
  `department` varchar(50) DEFAULT NULL,
  `buyer` int(20) DEFAULT NULL,
  `qqRespPerson` int(20) DEFAULT NULL,
  `vendorCode` varchar(50) DEFAULT NULL,
  `dvryAddrId` int(20) DEFAULT NULL,
  `dvryTerms` varchar(800) DEFAULT NULL,
  `pymntTerms` varchar(800) DEFAULT NULL,
  `billToAddrId` int(20) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  `poRevision` varchar(10) DEFAULT NULL,
  `createdBy` int(20) DEFAULT NULL,
  `modifiedBy` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

/*Table structure for table `slidocuments` */

DROP TABLE IF EXISTS `slidocuments`;

CREATE TABLE `slidocuments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoiceId` varchar(45) NOT NULL,
  `document` varchar(45) DEFAULT NULL,
  `value` varchar(100) DEFAULT NULL,
  `isDeleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `standard` */

DROP TABLE IF EXISTS `standard`;

CREATE TABLE `standard` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `standardNumber` varchar(500) COLLATE latin1_bin NOT NULL,
  `standardDescription` varchar(500) COLLATE latin1_bin NOT NULL,
  `revisionNumber` varchar(20) COLLATE latin1_bin DEFAULT NULL,
  `standardLink` varchar(500) COLLATE latin1_bin DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `createdBy` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(25) DEFAULT NULL,
  `lastName` varchar(25) DEFAULT NULL,
  `userName` varchar(50) DEFAULT NULL,
  `pwd` varchar(256) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `roles` varchar(256) DEFAULT NULL,
  `createdDt` date DEFAULT NULL,
  `modifiedDt` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Table structure for table `vendor` */

DROP TABLE IF EXISTS `vendor`;

CREATE TABLE `vendor` (
  `vendorid` int(11) NOT NULL AUTO_INCREMENT,
  `vendorName` varchar(100) DEFAULT NULL,
  `panNo` varchar(45) DEFAULT NULL,
  `gstinNo` varchar(20) DEFAULT NULL,
  `ieCode` varchar(45) DEFAULT NULL,
  `createdDt` date DEFAULT NULL,
  `modifiedDt` date DEFAULT NULL,
  PRIMARY KEY (`vendorid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
