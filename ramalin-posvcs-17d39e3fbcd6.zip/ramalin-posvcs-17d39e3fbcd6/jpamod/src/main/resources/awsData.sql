/*
SQLyog Community v12.5.0 (64 bit)
MySQL - 5.6.40-log : Database - qqordermgmnt
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`qqordermgmnt` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `qqordermgmnt`;

/*Data for the table `address` */

insert  into `address`(`id`,`parentId`,`parentEntity`,`type`,`streetNo`,`streetName`,`lineTwo`,`lineThree`,`lineFour`,`city`,`province`,`country`,`postalCd`,`createdDt`,`modifiedDt`) values 
(1,1,'P','B','1602','FMC Technologies Measurement Solutions Inc','P.O Box 10428','Wagner Avenue','','Erie','PA','US','16514-0428','2019-02-12 13:00:33','2019-02-12 13:00:33'),
(2,1,'P','D','1648','McClelland Avenue','','','','Erie','PA','US','16510','2019-02-12 13:00:33','2019-02-12 13:00:33'),
(3,2,'P','B','2825','FMC Fluid Control','W Washinton','','','Stephenville','TX','US','76401','2019-02-12 13:00:33','2019-02-12 13:00:33'),
(4,2,'P','D','2830','West Frey','','\'','','Stephenville','TX','US','76401','2019-02-12 13:00:33','2019-02-12 13:00:33'),
(5,3,'P','B','25474','FMC Technologies Measurement Solutions','Smith Meter GmbH','Regentstrasse 1','','ELLERBEK','','GR','','2019-02-12 13:00:33','2019-02-12 13:00:33'),
(6,3,'P','D','D-25474','TechnipFMC','Smith Meter GmbH','Regentstrasse 1','','ELLERBEK','','GR','','2019-02-12 13:00:33','2019-02-12 13:00:33'),
(7,4,'P','B','7/4','School Street','Chinnavedampatti Post','','Ganapathy','Coimbatore','TN','IN','641049','2019-02-12 13:00:33','2019-02-12 13:00:33'),
(8,4,'P','D','7/4','School Street','Chinnavedampatti Post','','Ganapathy','Coimbatore','TN','IN','641049','2019-02-12 13:00:33','2019-02-12 13:00:33'),
(9,5,'P','B','S F No 99','Vvadugapalayam','Salayur Pirivu','Naranapuram village','Annur Taluk','Coimbatore','TN','IN','641107','2019-02-12 13:00:33','2019-02-12 13:00:33'),
(10,5,'P','D','S F No 99','Vvadugapalayam','Salayur Pirivu','Naranapuram village','Annur Taluk','Coimbatore','TN','IN','641107','2019-02-12 13:00:33','2019-02-12 13:00:33'),
(11,6,'P','B','418/1','Athipalayam Road','Chinnavedampatti','','','Coimbatore','TN','IN','641049','2019-02-12 13:00:34','2019-02-12 13:00:34'),
(12,6,'P','D','418/1','Athipalayam Road','Chinnavedampatti','','','Coimbatore','TN','IN','641049','2019-02-12 13:00:34','2019-02-12 13:00:34'),
(13,7,'P','B','Plot No: 6 & 7','Association Road','Madavaram','','','Chennai','TN','IN','600060','2019-02-12 13:00:34','2019-02-12 13:00:34'),
(14,7,'P','D','Plot No: 6 & 7','Association Road','Madavaram','','','Chennai','TN','IN','600060','2019-02-12 13:00:34','2019-02-12 13:00:34');

/*Data for the table `codeassociation` */

insert  into `codeassociation`(`id`,`category`,`picklist`) values 
(1,'PART_CATEGORY','Y'),
(2,'PART_STAGE','Y'),
(3,'PART_DOMAIN','Y'),
(4,'PART_WT_UNIT','Y'),
(5,'PART_TYPE','Y'),
(6,'PART_STATUS','Y'),
(7,'PART_RESOURCE','Y'),
(8,'PART_UNIT_MEASUREMENT','Y'),
(9,'TRANSPORT_MODE','Y'),
(10,'GSTIN_CODE','Y'),
(11,'IE_CODE','Y'),
(12,'PRE_CARRIAGE','Y');

/*Data for the table `codes` */

insert  into `codes`(`id`,`category`,`code`,`desc`,`activeDt`,`expireDt`,`notes`,`createdDt`,`modifiedDt`) values 
(1,'PART_CATEGORY','CST','Casting','2018-12-01 15:02:28','2028-12-27 15:02:35',NULL,'2018-12-27 15:02:59','2018-12-27 15:03:03'),
(2,'PART_CATEGORY','MCN','Machining','2018-12-01 15:03:57',NULL,NULL,'2018-12-27 15:04:25','2018-12-27 15:04:21'),
(3,'PART_CATEGORY','ALY','Assembly','2018-12-01 15:04:04',NULL,NULL,'2018-12-27 15:04:12','2018-12-27 15:04:17'),
(4,'PART_STAGE','PODT','PoDate','2018-12-01 18:26:16',NULL,NULL,'2018-12-27 18:26:26','2018-12-27 18:26:31'),
(5,'PART_STAGE','SHIP','ShippedDate','2018-12-01 18:27:15',NULL,NULL,'2018-12-27 18:27:25','2018-12-27 18:27:30'),
(6,'PART_STAGE','APRV','ApprovedDate','2018-12-01 18:28:00',NULL,NULL,'2018-12-27 18:28:07','2018-12-27 18:28:13'),
(7,'PART_STAGE','FARV','FirstApproval','2018-12-01 18:28:47','2019-02-18 08:13:10',NULL,'2018-12-27 18:28:54','2018-12-27 18:29:00'),
(8,'PART_DOMAIN','MINE','Mining','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(9,'PART_DOMAIN','OAG','Oil and Gas','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(10,'PART_DOMAIN','AGRI','Agriculture','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(11,'PART_DOMAIN','AUTO','Automotive','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(12,'PART_DOMAIN','ENRG','Energy','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(13,'PART_DOMAIN','MAHA','Material Handling','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(14,'PART_DOMAIN','INFR','Infrastructure','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(15,'PART_DOMAIN','AERO','Aerospace','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(16,'PART_WT_UNIT','LBS','lbs','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(17,'PART_WT_UNIT','KGS','Kilogram','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(18,'PART_WT_UNIT','SET','Set','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(19,'PART_TYPE','TOOL','Tool','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(20,'PART_TYPE','FAI','FAI','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(21,'PART_TYPE','PROD','Prodcution','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(22,'PART_STATUS','SAMP','Sample','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(23,'PART_STATUS','PPAP','PPAP','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(24,'PART_STATUS','PROD','Prodcution','2018-12-01 00:00:00',NULL,NULL,'2018-12-01 00:00:00',NULL),
(25,'PART_CATEGORY','FST','Fasteners','2018-12-01 15:04:04',NULL,NULL,'2018-12-27 15:04:12','2018-12-27 15:04:17'),
(26,'PART_CATEGORY','BUS','Bush','2018-12-01 15:04:04',NULL,NULL,'2018-12-27 15:04:12','2018-12-27 15:04:17'),
(27,'PART_RESOURCE','RES','Resourcing','2018-12-01 15:04:04',NULL,NULL,'2018-12-27 15:04:12','2018-12-27 15:04:17'),
(28,'PART_RESOURCE','NPI','NPI','2018-12-01 15:04:04',NULL,NULL,'2018-12-27 15:04:12','2018-12-27 15:04:17'),
(29,'PART_UNIT_MEASUREMENT','MM','Milimeter','2018-12-01 15:04:04',NULL,NULL,'2018-12-27 15:04:12','2018-12-27 15:04:17'),
(30,'PART_UNIT_MEASUREMENT','MTR','Meter','2018-12-01 15:04:04',NULL,NULL,'2018-12-27 15:04:12','2018-12-27 15:04:17'),
(31,'PART_UNIT_MEASUREMENT','INCH','Inches','2018-12-01 15:04:04',NULL,NULL,'2018-12-27 15:04:12','2018-12-27 15:04:17'),
(32,'PART_UNIT_MEASUREMENT','UNIT','Unit','2018-12-01 15:04:04',NULL,NULL,'2018-12-27 15:04:12','2018-12-27 15:04:17'),
(33,'TRANSPORT_MODE','AIR','By - Air','2018-12-01 15:04:04',NULL,NULL,'2018-12-27 15:04:12','2018-12-27 15:04:17'),
(34,'TRANSPORT_MODE','SEA','By - Sea','2018-12-01 15:04:04',NULL,NULL,'2018-12-27 15:04:12','2018-12-27 15:04:17'),
(35,'GSTIN_CODE','GSTIN-CODE','33AAAFQ68880G1Z7','2018-12-01 15:04:04',NULL,NULL,'2018-12-27 15:04:12','2018-12-27 15:04:17'),
(36,'IE_CODE','IE-CODE','AAAFQ6880G','2018-12-01 15:04:04',NULL,NULL,'2018-12-27 15:04:12','2018-12-27 15:04:17'),
(37,'PRE_CARRIAGE','ROAD','BY ROAD','2018-12-01 15:04:04',NULL,NULL,'2018-12-27 15:04:12','2018-12-27 15:04:17');

/*Data for the table `company` */

insert  into `company`(`id`,`parentId`,`name`,`type`,`desc`,`taxId`,`hierarchy`) values 
(1,NULL,'TechnipFMC','CORP','TechipFMC','23-456789',0),
(2,NULL,'Sakthi Gear Products','CORP','Sakthi Gear Products','24',0),
(3,NULL,'Future tech Engineers','CORP','Future tech Engineers','25',0),
(4,NULL,'Reliance Machine Tools','CORP','Reliance Machine Tools','26',0);

/*Data for the table `email` */

insert  into `email`(`id`,`parentId`,`parentEntity`,`type`,`emailId`,`createdDt`,`modifiedDt`) values 
(1,1,'C','H','ramalin@yahoo.com','2018-12-04 22:02:23',NULL),
(2,1,'H','C','rama@qqsworld.com','2019-01-28 08:38:28',NULL);

/*Data for the table `invoice` */

/*Data for the table `part` */

insert  into `part`(`id`,`name`,`number`,`partRevNo`,`partRevDt`,`partRevOrder`,`drawingNo`,`drawingRevNo`,`drawingRevDt`,`QQSCode`,`QQSRevNo`,`QQSRevDt`,`projectName`,`category`,`materialSpec`,`castingWt`,`castingWtUnit`,`rfqVolume`,`mbq`,`uom`,`resourceInd`,`companyId`,`createdDt`,`modifiedDt`) values 
(1,'CROSSHEAD ASSEMBLY,  F/ DRILL BUSHINGS, WELL SERVICE PUMP 12.250 DIA','P537405','F','2019-02-27 07:58:17',NULL,'DU500009497','E','2019-02-27 07:58:17','NA','NA','2019-02-27 07:58:17','WELL SERVICE PUMP','ALY','MOD 8630 LOW ALLOY STEEL',57,'KGS',2200,100,'UNIT','RES',1,NULL,NULL),
(2,'CROSSHEAD, F/ DRILL BUSHINGS, WELL SERVICE PUMP, 12.250 DIA,W/MILLED SIDES, ALLOY STEEL','P537403','H','2019-02-27 11:32:21',NULL,'DU500009495','H','2019-02-27 11:32:21','NA','NA','2019-02-27 11:32:21','WELL SERVICE PUMP','MCN','MOD 8630 LOW ALLOY STEEL',52,'KGS',NULL,NULL,'UNIT','RES',1,NULL,NULL),
(3,'CROSSHEAD TRUNNION, F/ DRILL BUSHINGS,8630 ALLOY STEEL','P537404','E','2019-02-27 12:01:01',NULL,'DU500009496','E','2019-02-27 12:01:01','NA','NA','2019-02-27 12:01:01','WELL SERVICE PUMP','MCN','MOD 8630 LOW ALLOY STEEL',4,'KGS',NULL,NULL,'UNIT','RES',1,NULL,NULL),
(4,'CAP SCREW; 12 POINT, 3/4?10 UNC?2A X5.500 LONG, PER IFI 115, SAE J58, J429GRADE 8 ALLOY STEEL, BLACK PHOSPHATECOATED, NOT FOR OFF?SHORE USE, W/ DRILLED HEAD','P532353','F','2019-02-27 12:06:22',NULL,'NA','NA','2019-02-27 12:06:22','NA','NA','2019-02-27 12:06:22','WELL SERVICE PUMP','FST','SAE J 429 GRADE 8',0,'KGS',NULL,NULL,'UNIT','RES',1,NULL,NULL),
(5,'DRILL BUSHING, EXTRA THIN WALLED,.8518/.8515 OD X .755 ID X .625 LONG,STEEL','P537284','A','2019-02-27 12:13:06',NULL,'NA','NA','2019-02-27 12:13:06','NA','NA','2019-02-27 12:13:06','WELL SERVICE PUMP','FST','AISI 52100',0,'KGS',NULL,NULL,'UNIT','RES',1,NULL,NULL),
(6,'CROSSHEAD CASTING, WELL SERVICE PUMP,13.00 DIA ALLOY STEEL PER SPEC M25022','P531157','F','2019-02-27 12:21:15',NULL,'DU500000581','D','2019-02-27 12:21:15','NA','NA','2019-02-27 12:21:15','WELL SERVICE PUMP','CST','MOD 8630 LOW ALLOY STEEL',84,'KGS',NULL,NULL,'UNIT','RES',1,NULL,NULL),
(7,'CROSSHEAD TRUNNION CASTING, 8630 ALLOYSTEEL PER FMC SPEC M25022','P531432','C','2019-02-27 12:29:40',NULL,'DU500001673','C','2019-02-27 12:29:40','NA','NA','2019-02-27 12:29:40','WELL SERVICE PUMP','CST','MOD 8630 LOW ALLOY STEEL',5,'KGS',NULL,NULL,'UNIT','RES',1,NULL,NULL),
(8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL);

/*Data for the table `partchronology` */

insert  into `partchronology`(`id`,`partNo`,`stage`,`stageDt`,`status`,`createdBy`,`createdDt`,`modifiedBy`,`modifiedDt`) values 
(1,1,'APRV','2018-11-27 18:30:00','SAMP',5,'2019-02-27 08:22:35',NULL,NULL),
(2,1,'PODT','2018-06-17 18:30:00','PROD',5,'2019-02-27 08:22:35',NULL,NULL);

/*Data for the table `partcommodity` */

insert  into `partcommodity`(`id`,`partId`,`commodityCode`,`countryCode`,`effectiveDt`,`expiryDt`,`createdDt`,`createdBy`) values 
(1,1,'8413.91.9080','USA','2018-10-29 18:30:00',NULL,'2019-02-27 08:26:58',5),
(2,2,'8413.91.9080','USA','2017-12-31 18:30:00',NULL,'2019-02-27 11:55:07',5),
(3,3,'8413.91.9080','USA','2017-12-31 18:30:00',NULL,'2019-02-27 12:05:55',5),
(4,4,'8413.91.9080','USA','2017-12-31 18:30:00',NULL,'2019-02-27 12:12:22',5),
(5,5,'8413.91.9080','USA','2017-12-31 18:30:00',NULL,'2019-02-27 12:17:43',5);

/*Data for the table `partcustomerrequirement` */

insert  into `partcustomerrequirement`(`id`,`partId`,`noteNumber`,`customerRequirement`,`createdDt`,`createdBy`) values 
(1,1,'NOTE 1','FASTEN CROSSHEAD TRUNNIONS (QTY 2) TO CROSSHEAD. TORQUE 3/4?10 12 PT. CAPSCREW 350 FT?LBS.',NULL,NULL),
(2,1,'NOTE 2','MATCH MARK CROSSHEAD BODIES AND TRUNNIONS. USE SEQUENTIAL NUMBERS SUCH AS A1, A2,...B1, B2 ON CROSSHEADS. USE SAME SEQUENCE NUMBER WITH L & R ADDED ON TRUNNIONS. SEE DRAWING.',NULL,NULL),
(3,1,'NOTE 3','AT LOCATION SHOWN ON DRAWING, STAMP THE FOLLOWING INFORMATION: TechnipFMC PART# (CURRENT REV LETTER)',NULL,NULL),
(4,2,'NOTE 1','AT LOCATION SHOWN ON DRAWING, RESTAMP CASTING IDENTIFICATION: PART # (CURRENT REV LATTER) BATCH# VENDOR CODE',NULL,NULL),
(5,2,'NOTE 2','IF CASTING SUPPLIER IDENTIFICATION IS MACHINED OFF, IT SHALL BE APPLIED BY STAMPING BELOW THE PART NUMBER AND BATCH NUMBER IN NOTE1.',NULL,NULL),
(6,4,'NOTE 1','DRILL THREE 0.098 DIA. HOLES THRU HEAD AT 120 DEG. SPACING',NULL,NULL),
(7,5,'NOTE 1','FOR ENGINEERING PURPOSES ONLY USE MODEL DU500009275',NULL,NULL),
(8,6,'NOTE 1','FOR Q00207 SECTION 12.0, MAP OR RECORD OF INDICATIONS ARE NOT REQUIRED.',NULL,NULL);

/*Data for the table `partdomain` */

insert  into `partdomain`(`id`,`partId`,`domain`,`createdDt`,`modifiedDt`) values 
(1,1,'OAG','2019-02-27 08:27:17',NULL),
(2,2,'OAG','2019-02-27 11:55:33','2019-02-27 11:55:59'),
(3,3,'OAG','2019-02-27 12:06:06',NULL),
(4,4,'OAG','2019-02-27 12:12:37','2019-02-27 12:12:57'),
(5,5,'OAG','2019-02-27 12:17:56',NULL),
(6,6,'OAG','2019-02-27 12:28:46',NULL),
(7,7,'OAG','2019-02-27 12:37:37',NULL);

/*Data for the table `partimage` */

/*Data for the table `partprice` */

insert  into `partprice`(`id`,`partId`,`currency`,`value`,`priceDesc`,`defaultInd`,`effectiveDt`,`expiryDt`,`createdBy`,`createdDt`,`modifiedBy`,`modifiedDt`) values 
(1,1,'USD',500.000,NULL,'Y','2019-03-01 06:59:08','2020-03-29 18:30:00',NULL,NULL,NULL,NULL);

/*Data for the table `partrelationxref` */

insert  into `partrelationxref`(`id`,`parentId`,`childId`) values 
(1,3,7),
(2,2,6),
(3,1,2),
(4,1,3),
(5,1,4),
(6,1,5);

/*Data for the table `partrevisionamendment` */

/*Data for the table `partstandard` */

insert  into `partstandard`(`id`,`partId`,`standardNumber`,`standardDescription`,`standardSpecificDescription`,`revisionNumber`,`standardLink`,`createdDt`,`createdBy`) values 
(1,'1','Q00021','FCD USE ONLY - IDENTIFICATION REQUIREMENTS FOR FLUID CONTROL MATERIALS AND COMPONENTS','PART TRACEBILITY','L',NULL,NULL,NULL),
(2,'1','Q00024','PRESSURE PUMPING USE ONLY - VISUAL INSPECTION, HANDLING, STORAGE AND SHIPPING REQUIREMENTS FOR FLUID CONTROL EQUIPMENT','VI & PARTS HANDLING','I',NULL,NULL,NULL),
(3,'1','Q50186','FCD USE ONLY - SPECIAL PACKAGING REQUIREMENTS TO PREVENT CORROSION ON METALLIC EQUIPMENT','SAFE PACKING','A',NULL,NULL,NULL),
(4,'2','Q00021','FCD USE ONLY - IDENTIFICATION REQUIREMENTS FOR FLUID CONTROL MATERIALS AND COMPONENTS','PART TRACEBILITY','L',NULL,NULL,NULL),
(5,'2','Q00024','PRESSURE PUMPING USE ONLY - VISUAL INSPECTION, HANDLING, STORAGE AND SHIPPING REQUIREMENTS FOR FLUID CONTROL EQUIPMENT','VI & SAFE PACKING','I',NULL,NULL,NULL),
(6,'3','Q00021','FCD USE ONLY - IDENTIFICATION REQUIREMENTS FOR FLUID CONTROL MATERIALS AND COMPONENTS','PART TRACEBILITY','L',NULL,NULL,NULL),
(7,'3','Q00024','PRESSURE PUMPING USE ONLY - VISUAL INSPECTION, HANDLING, STORAGE AND SHIPPING REQUIREMENTS FOR FLUID CONTROL EQUIPMENT','VI & SAFE PACKING ','I',NULL,NULL,NULL),
(8,'4','Q00021','FCD USE ONLY - IDENTIFICATION REQUIREMENTS FOR FLUID CONTROL MATERIALS AND COMPONENTS','PART TRACEBILITY','L',NULL,NULL,NULL),
(9,'4','Q00024','PRESSURE PUMPING USE ONLY - VISUAL INSPECTION, HANDLING, STORAGE AND SHIPPING REQUIREMENTS FOR FLUID CONTROL EQUIPMENT','VI & SAFE PACKING','I',NULL,NULL,NULL),
(10,'5','Q00024','PRESSURE PUMPING USE ONLY - VISUAL INSPECTION, HANDLING, STORAGE AND SHIPPING REQUIREMENTS FOR FLUID CONTROL EQUIPMENT','VI & SAFE PACKING','I',NULL,NULL,NULL),
(11,'5','Q00021','FCD USE ONLY - IDENTIFICATION REQUIREMENTS FOR FLUID CONTROL MATERIALS AND COMPONENTS','PART TRACEBILITY','L',NULL,NULL,NULL),
(12,'6','Q00021','FCD USE ONLY - IDENTIFICATION REQUIREMENTS FOR FLUID CONTROL MATERIALS AND COMPONENTS','PART TRACEBILITY','L',NULL,NULL,NULL),
(13,'6','Q00020','FCD USE ONLY - MATERIAL AND HEAT TREAT CERTIFICATION REQUIREMENTS FOR FLUID CONTROL TRACEABLE COMPONENTS','REPORTS REQUIREMENT','J',NULL,NULL,NULL),
(14,'6','Q01206','GENERAL MATERIAL AND HEAT TREATMENT REQUIREMENTS FOR WELLHEAD, CHRISTMAS TREE, MANIFOLD AND RELATED EQUIPMENT','GEN HT REQUIREMENT','AA',NULL,NULL,NULL),
(15,'6','Q01207','HEAT TREATMENT OF STEEL PARTS','HT REQUIRMENT','U',NULL,NULL,NULL),
(16,'6','Q00207','FCD USE ONLY - SPECIFICATION FOR WET MAGNETIC PARTICLE EXAMINATION OF MACHINED, CAST, AND FORGED PARTS - API 6A PSL 3 ACCEPTANCE CRITERIA','ACCEPTANCE CRITERIA','C',NULL,NULL,NULL),
(17,'6','Q50153','FCD USE ONLY - DATA BOOK ELIGIBLE METALLIC COMPONENT','DATA BOOK','A',NULL,NULL,NULL),
(18,'7','Q00021','FCD USE ONLY - IDENTIFICATION REQUIREMENTS FOR FLUID CONTROL MATERIALS AND COMPONENTS','PART TRACEBILITY','L',NULL,NULL,NULL),
(19,'7','Q00303','CERTIFICATE OF COMPLIANCE','COC','F',NULL,NULL,NULL);

/*Data for the table `people` */

insert  into `people`(`id`,`externalId`,`parentType`,`parentId`,`category`,`firstName`,`lastName`,`middleInitial`,`otherInfo`,`createdDt`,`modifiedDt`) values 
(1,'1','P',1,'B','Gandhi','Baskar','','','2019-02-12 13:00:34','2019-02-12 13:00:34'),
(2,'1','P',1,'B','Kevin','Schaaf','','','2019-02-12 13:00:34','2019-02-12 13:00:34'),
(3,'2','P',2,'B','Anthony','Williams','','','2019-02-12 13:00:34','2019-02-12 13:00:34'),
(4,'3','P',3,'B','Holger','knief','','','2019-02-12 13:00:34','2019-02-12 13:00:34'),
(5,'3','P',4,'B','Shanmugasundaram','','','','2019-02-12 13:00:34','2019-02-12 13:00:34'),
(6,'3','P',4,'B','Raja','','','','2019-02-12 13:00:34','2019-02-12 13:00:34'),
(7,'3','P',5,'B','Easwaran','Ranjith','','','2019-02-12 13:00:34','2019-02-12 13:00:34'),
(8,'3','P',6,'B','Peter','','','','2019-02-12 13:00:34','2019-02-12 13:00:34'),
(9,'3','P',6,'B','Ravi','','','','2019-02-12 13:00:34','2019-02-12 13:00:34'),
(10,'3','P',7,'B','Venkat Raman','','','','2019-02-12 13:00:34','2019-02-12 13:00:34'),
(11,'3','P',7,'B','Aravindan','','','','2019-02-12 13:00:34','2019-02-12 13:00:34'),
(12,'3','V',1,'R','GnanaSekar','','','','2019-02-12 13:00:34','2019-02-12 13:00:34');

/*Data for the table `phone` */

insert  into `phone`(`id`,`parentId`,`parentEntity`,`type`,`phoneNo`,`extension`,`createdDt`,`modifiedDt`) values 
(1,1,'C','H','8569149198',NULL,'2018-12-12 22:02:01',NULL),
(2,1,'H','C','8562666303',NULL,'2019-01-28 08:38:50',NULL);

/*Data for the table `places` */

/*Data for the table `plant` */

insert  into `plant`(`id`,`companyId`,`plantCode`,`desc`,`vendorCode`,`domesticInd`,`currency`,`pmntTerms`,`deliveryTerms`,`dutyStruct`,`createdDt`,`modifiedDt`) values 
(1,1,'1101','Erie Plant','158564','N','USD','58','EXW Coimbatore/ INDIA','Zero Rated','2018-12-04 15:07:35','2018-12-04 15:07:40'),
(2,1,'EFST','Stephenville','158564','N','USD','58','EXW Coimbatore/ INDIA','Zero Rated',NULL,NULL),
(3,1,'1201','Ellerbek','158564','N','EUR','58','EXW Coimbatore/ INDIA','Zero Rated','2019-02-04 12:27:35','2019-02-04 15:07:40'),
(4,2,'Unit 1','Coimbatore','SGP - 1 - 103','Y','INR','30','DAP','18% GST','2019-02-04 12:27:35','2019-02-04 15:07:40'),
(5,2,'Branch','Coimbatore','SGP - 2 - 103','Y','INR','30','DAP','18% GST','2019-02-04 12:27:35','2019-02-04 15:07:40'),
(6,3,'MachineShop','Coimbatore','FTE - 101','Y','INR','30','DAP','18% GST','2019-02-04 12:27:35','2019-02-04 15:07:40'),
(7,4,'Inserts - Trader','Chennai','RDT - 104','Y','INR','30','DAP','18% GST','2019-02-04 12:27:35','2019-02-04 15:07:40');

/*Data for the table `plantaddrxref` */

/*Data for the table `plantbuyer` */

/*Data for the table `polineitem` */

/*Data for the table `polinetool` */

/*Data for the table `purchorder` */

insert  into `purchorder`(`id`,`companyId`,`plantId`,`poNumber`,`poDate`,`department`,`buyer`,`qqRespPerson`,`vendorCode`,`dvryAddrId`,`dvryTerms`,`pymntTerms`,`billToAddrId`,`createdDt`,`modifiedDt`,`poRevision`,`createdBy`,`modifiedBy`) values 
(1,1,2,'4500147245','2019-03-04',NULL,3,12,'158564',4,'EXW Coimbatore/ INDIA','58',3,'2019-03-07 07:05:09','2019-03-07 07:05:09','1',1,1),
(2,1,2,'4500147245','2018-06-17',NULL,3,12,'158564',4,'EXW Coimbatore/ INDIA','58',3,'2019-03-08 09:53:15','2019-03-08 10:00:57','2',3,3);

/*Data for the table `standard` */

insert  into `standard`(`id`,`standardNumber`,`standardDescription`,`revisionNumber`,`standardLink`,`createdDt`,`createdBy`) values 
(1,'Q00020','FCD USE ONLY - MATERIAL AND HEAT TREAT CERTIFICATION REQUIREMENTS FOR FLUID CONTROL TRACEABLE COMPONENTS','J','',NULL,NULL),
(2,'Q00021','FCD USE ONLY - IDENTIFICATION REQUIREMENTS FOR FLUID CONTROL MATERIALS AND COMPONENTS','L','',NULL,NULL),
(3,'Q00024','PRESSURE PUMPING USE ONLY - VISUAL INSPECTION, HANDLING, STORAGE AND SHIPPING REQUIREMENTS FOR FLUID CONTROL EQUIPMENT','I','',NULL,NULL),
(4,'Q00188','PRESSURE PUMPING USE ONLY - SKETCHES OF CRITICAL AREAS OF CAST PRODUCT SHAPES - FOR POROSITY ACCEPTANCE CRITERIA','N','',NULL,NULL),
(5,'Q00207','FCD USE ONLY - SPECIFICATION FOR WET MAGNETIC PARTICLE EXAMINATION OF MACHINED, CAST, AND FORGED PARTS - API 6A PSL 3 ACCEPTANCE CRITERIA','C','',NULL,NULL),
(6,'Q00303','CERTIFICATE OF COMPLIANCE','F','',NULL,NULL),
(7,'Q01205','MINIMUM REQUIREMENTS FOR HEAT TREATMENT EQUIPMENT QUALIFICATION','D','',NULL,NULL),
(8,'Q01206','GENERAL MATERIAL AND HEAT TREATMENT REQUIREMENTS FOR WELLHEAD, CHRISTMAS TREE, MANIFOLD AND RELATED EQUIPMENT','AA','',NULL,NULL),
(9,'Q01207','HEAT TREATMENT OF STEEL PARTS','U','',NULL,NULL),
(10,'Q01209','CUSTOM FORGING SPECIFICATION FOR CARBON, LOW ALLOY, MARTENSITIC AND PH STAINLESS STEELS FOR CRITICAL SERVICE','M','',NULL,NULL),
(11,'Q50153','FCD USE ONLY - DATA BOOK ELIGIBLE METALLIC COMPONENT','A','',NULL,NULL),
(12,'Q50186','FCD USE ONLY - SPECIAL PACKAGING REQUIREMENTS TO PREVENT CORROSION ON METALLIC EQUIPMENT','A','',NULL,NULL),
(13,'PS01060','ZINC PHOSPHATING','021.00','',NULL,NULL),
(14,'PS01153','HEAT TREATMENT OF CASTINGS','23','',NULL,NULL),
(15,'M10142 ','PRESSURE PUMPING USE ONLY - IRON CASTING - GRAY ASTM A48 CLASS 30','C','',NULL,NULL),
(16,'C85041','FCD USE ONLY - COATING SPECIFICATION FOR FMC PUMP RAW CASTINGS AND WELDMENTS','B','',NULL,NULL);

/*Data for the table `user` */

insert  into `user`(`id`,`firstName`,`lastName`,`userName`,`pwd`,`active`,`roles`,`createdDt`,`modifiedDt`) values 
(1,'Gnan','S','gnan','61914d4a578da71c4e91cf560d28a90e',1,'ADMIN','2019-02-14',NULL),
(2,'Murugesan','Nambi','murug','3e989a426d5133a3181e3e9cd2071bc2',1,'ADMIN','2019-02-14',NULL),
(3,'Dhaarun','A','dhaarun','3e989a426d5133a3181e3e9cd2071bc2',1,'ADMIN','2019-02-14',NULL),
(4,'MB','Shafee','qqs003','f1254eb8f270e09fdcb993cc4c2a20ce',1,'ALL_READ;ALL_WRITE','2019-02-14',NULL),
(5,'Amrish','Guess','qqs004','f1254eb8f270e09fdcb993cc4c2a20ce',1,'ALL_READ;ALL_WRITE','2019-02-14',NULL),
(6,'Hariharabalan','R','qqs005','f1254eb8f270e09fdcb993cc4c2a20ce',1,'ALL_READ;ALL_WRITE','2019-02-14',NULL),
(7,'Prakash','D','qqs006','f1254eb8f270e09fdcb993cc4c2a20ce',1,'ALL_READ;ALL_WRITE','2019-02-14',NULL),
(8,'SelvaRajesh','S','qqs007','f1254eb8f270e09fdcb993cc4c2a20ce',1,'ALL_READ;ALL_WRITE','2019-02-14',NULL),
(9,'Rajesh','S','qqs008','f1254eb8f270e09fdcb993cc4c2a20ce',1,'ALL_READ;ALL_WRITE','2019-02-14',NULL);

/*Data for the table `vendor` */

insert  into `vendor`(`vendorid`,`vendorName`,`createdDt`,`modifiedDt`) values 
(1,'Q&Q Solutions','2019-02-12','2019-02-12');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
