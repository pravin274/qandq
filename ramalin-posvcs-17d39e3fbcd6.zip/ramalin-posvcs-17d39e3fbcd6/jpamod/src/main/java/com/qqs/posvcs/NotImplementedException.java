package com.qqs.posvcs;

public class NotImplementedException extends Exception {
}
