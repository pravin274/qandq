package com.qqs.posvcs.service;

import com.qqs.posvcs.model.PoLineItem;
import com.qqs.posvcs.model.PoLineItemxCurrentStatus;
import com.qqs.posvcs.model.PoLineTool;
import com.qqs.posvcs.repository.POLineItemRepository;
import com.qqs.posvcs.repository.POLineItemxCurrentStatusRepository;
import com.qqs.posvcs.repository.PoLineToolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.transaction.Transactional;
import java.util.*;

@Component
public class POLineItemDataService {
    @Autowired
    private POLineItemRepository repository;

    @Autowired
    private PoLineToolRepository poLineToolRepository;

    @Resource
    private POLineItemxCurrentStatusRepository poLineItemxCurrentStatusRepository;

    public Optional<PoLineItem> getPOLineItemById(Integer id) {
        return repository.findById(id);
    }

    public Iterable<PoLineItem> getPOLineItemByPOId(Integer poId) {
        return repository.findAllByPoId(poId);
    }

    public Optional<List<PoLineItem>> getAllPOLineItemsById(List<Integer> id) {
        Iterable<PoLineItem> result = repository.findAllById(id);
        List<PoLineItem> interim = new ArrayList<>();
        result.forEach(interim::add);
        Optional<List<PoLineItem>> optional = Optional.of(interim);
        return optional;
    }
    public Optional<PoLineTool> getPoLineToolsById(Integer id) {
        return poLineToolRepository.findById(id);
    }

    public Iterable<PoLineTool> getAllPoLineToolsById(Iterable<Integer> ids) {
        return poLineToolRepository.findAllById(ids);
    }


    public Optional<List<Object[]>> getShippingAttr(Iterable<Integer> poLineItemIds) {
        return repository.findShippingAttr(poLineItemIds);
    }

    @Transactional
    public PoLineItem savePOLineItems(PoLineItem item) {
        return repository.save(item);
    }

    @Transactional
    public Iterable<PoLineItem> savePOLineItems(Collection<PoLineItem> items) {
        return repository.saveAll(items);
    }


    @Transactional
    public PoLineTool savePoLineTool(PoLineTool tool) {
        return poLineToolRepository.save(tool);
    }

    @Transactional
    public Iterable<PoLineTool> savePoLineTools(Iterable<PoLineTool> tools) {
        return poLineToolRepository.saveAll(tools);
    }


    //POLineItemxCurrentStatus methods

    public Optional<PoLineItemxCurrentStatus> getPOLineItemxCurrentStatusById(Integer id) {
        return poLineItemxCurrentStatusRepository.findById(id);
    }

    public Optional<List<PoLineItemxCurrentStatus>> getPOLineItemxCurrentStatusByPOLineItemId(Integer poLineItemId) {
        return poLineItemxCurrentStatusRepository.findAllByPoLineItemId(poLineItemId);
    }

    public Optional<List<PoLineItemxCurrentStatus>> getPOLineItemxCurrentStatusById(List<Integer> id) {
        Iterable<PoLineItemxCurrentStatus> result = poLineItemxCurrentStatusRepository.findAllById(id);
        List<PoLineItemxCurrentStatus> interim = new ArrayList<>();
        result.forEach(interim::add);
        Optional<List<PoLineItemxCurrentStatus>> optional = Optional.of(interim);
        return optional;
    }

    @Transactional
    public PoLineItemxCurrentStatus savePOLineItemxCurrentStatus(PoLineItemxCurrentStatus item) {
        return poLineItemxCurrentStatusRepository.save(item);
    }

    @Transactional
    public Iterable<PoLineItemxCurrentStatus> saveAllPOLineItemxCurrentStatus(Collection<PoLineItemxCurrentStatus> item) {
        return poLineItemxCurrentStatusRepository.saveAll(item);
    }

    public Optional<PoLineItemxCurrentStatus> getPOLineItemxCurrentStatusByPOLineItemId(Integer poLineItemId, String Status) {
        return poLineItemxCurrentStatusRepository.findByPoLineItemIdAndStatus(poLineItemId, Status);
    }

    public Optional<PoLineItemxCurrentStatus> getPOLineItemxCurrentStatusByInvoiceLineItemIdAndType(Integer poLineItemId, String status, String type) {
        return poLineItemxCurrentStatusRepository.findByPoLineItemIdAndStatusAndType(poLineItemId, status, type);
    }

}
