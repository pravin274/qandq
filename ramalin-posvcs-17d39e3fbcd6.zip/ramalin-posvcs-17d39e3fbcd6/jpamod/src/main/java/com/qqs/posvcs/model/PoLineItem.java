package com.qqs.posvcs.model;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "polineitem", schema = "qqordermgmnt", catalog = "")
public class PoLineItem {
    private int id;
    private int poId;
    private int partId;
    private int poLineToolId;
    private String partType;
    private String item;
    private String material;
    private String revision;
    private String description;
    private Integer quantity;
    private String unit;
    private String currency;
    private Double partPrice;
    private Integer partPriceId;
    private Timestamp deliveryDate;
    private Integer commodityCodeId;
    private String currentStatus;
    private Timestamp createdDt;
    private Timestamp modifiedDt;
    private Integer createdBy;
    private Integer modifiedBy;
    private Boolean isDeleted; 



    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "poId")
    public int getPoId() {
        return poId;
    }

    public void setPoId(int poId) {
        this.poId = poId;
    }

    @Column(name = "partId")
    public int getPartId() {
        return partId;
    }

    public void setPartId(int partId) {
        this.partId = partId;
    }

    @Column(name = "poLineToolId")
    public int getPoLineToolId() { return poLineToolId; }

    public void setPoLineToolId(int poLineToolId) { this.poLineToolId = poLineToolId; }

    @Column(name = "partType")
    public String getPartType() {
        return partType;
    }

    public void setPartType(String partType) {
        this.partType = partType;
    }

    @Column(name = "item")
    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    @Column(name = "material")
    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    @Column(name = "revision")
    public String getRevision() {
        return revision;
    }

    public void setRevision(String revision) {
        this.revision = revision;
    }

    @Column(name = "description")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Column(name = "quantity")
    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    @Column(name = "unit")
    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    @Column(name = "currency")
    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @Column(name = "partPrice")
    public Double getPartPrice() {
        return partPrice;
    }

    public void setPartPrice(Double partPrice) {
        this.partPrice = partPrice;
    }

    @Column(name = "partPriceId")
    public Integer getPartPriceId() {
        return partPriceId;
    }

    public void setPartPriceId(Integer partPriceId) {
        this.partPriceId = partPriceId;
    }

    @Column(name = "commodityCodeId")
    public Integer getCommodityCodeId() { return commodityCodeId; }

    public void setCommodityCodeId(Integer commodityCodeId) {
        if (commodityCodeId != null) {
            this.commodityCodeId = commodityCodeId;
        }
    }

    @Column(name = "currentStatus")
    public String getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    public Timestamp getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(Timestamp deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }
    @Column(name = "isDeleted")
    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("PoLineItem{");
        sb.append("id=").append(id);
        sb.append(", poId=").append(poId);
        sb.append(", partId=").append(partId);
        sb.append(", partType=").append(partType);
        sb.append(", item='").append(item).append('\'');
        sb.append(", material='").append(material).append('\'');
        sb.append(", revision='").append(revision).append('\'');
        sb.append(", description='").append(description).append('\'');
        sb.append(", quantity=").append(quantity);
        sb.append(", unit='").append(unit).append('\'');
        sb.append(", currency='").append(currency).append('\'');
        sb.append(", partPrice='").append(partPrice).append('\'');
        sb.append(", partPriceId").append(partPriceId);
        sb.append(", deliveryDate=").append(deliveryDate);
        sb.append(", commidityCodeId=").append(commodityCodeId);
        sb.append(", createdDt=").append(createdDt);
        sb.append(", modifiedDt=").append(modifiedDt);
        sb.append(", createdBy=").append(createdBy);
        sb.append(", modifiedBy=").append(modifiedBy);
        sb.append(", isDeleted=").append(isDeleted);

        sb.append('}');
        return sb.toString();
    }
}
