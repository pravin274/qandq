package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.PkgMaster;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface PkgMasterRepository extends CrudRepository<PkgMaster, Integer> {

    @Query(value = "select * from pkgmaster where id in (select pkgId from pkgdetail pd, invoicelineitem ili where ili.id = pd.invoiceLineItemId and ili.invoiceId = ?1)", nativeQuery = true)
    Optional<List<PkgMaster>> findPkgByInvoice(Integer invoiceId);

}
