package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.Ats;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface AtsRepository extends CrudRepository<Ats, Integer> {


    Ats findAllById(Integer id);

}
