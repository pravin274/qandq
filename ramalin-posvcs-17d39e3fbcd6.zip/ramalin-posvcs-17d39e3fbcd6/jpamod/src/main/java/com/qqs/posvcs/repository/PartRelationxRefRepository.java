package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.PartRelationxRef;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface PartRelationxRefRepository extends CrudRepository<PartRelationxRef, Integer> {

    PartRelationxRef findByParentIdAndChildId(Integer partId, Integer childId);

    List<PartRelationxRef> findAllByParentId(Integer partId);

}
