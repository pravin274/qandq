package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.Part;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface PartRepository extends CrudRepository<Part, Integer> {

    @Query(value = "SELECT part.* FROM part INNER JOIN partrelationxref ON part.id = partrelationxref.childid WHERE partrelationxref.parentid = ?1", nativeQuery = true)
    List<Part> getAllChildPartsById(Integer partId);

    @Query(value = "SELECT ifnull(count(distinct number), 0) as totalPartCount FROM part; ", nativeQuery = true)
    Integer getTotalPartsCount();

    @Query(value = "SELECT  ifnull(count(distinct number), 0) as totalPartCount " +
            " FROM part WHERE id not in (select distinct childId from partrelationxref); ", nativeQuery = true)
    Integer getTotalParentPartsCount();

}
