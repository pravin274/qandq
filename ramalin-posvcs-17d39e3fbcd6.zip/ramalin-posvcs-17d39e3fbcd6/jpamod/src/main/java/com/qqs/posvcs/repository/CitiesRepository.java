package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.Cities;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface CitiesRepository extends CrudRepository<Cities, Integer> {

    @Query(value = "select * from cities where state_id = ?1", nativeQuery = true)
    Optional<List<Cities>> findCitiesByStateId(Integer stateId);

    @Query(value = "SELECT name FROM qqordermgmnt.cities where id = ?1", nativeQuery = true)
    Optional<String> findCityNameById(Integer cityId);
}
