package com.qqs.posvcs.model;

import javax.persistence.*;
import javax.persistence.Entity;
import java.sql.Timestamp;

@Entity
@Table(name = "address", schema = "qqordermgmnt", catalog = "")
public class Address {
    private int id;
    private int parentId;
    private String parentEntity;
    private String type;
    private String lineOne;
    private String lineTwo;
    private String lineThree;
    private String lineFour;
    private Integer city;
    private Integer province;
    private Integer country;
    private String postalCd;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    @javax.persistence.Column(name = "parentId")
    public int getParentId() {
        return parentId;
    }

    public void setParentId(int parentId) {
        this.parentId = parentId;
    }


    @javax.persistence.Column(name = "parentEntity")
    public java.lang.String getParentEntity() {
        return parentEntity;
    }

    public void setParentEntity(java.lang.String parentEntity) {
        this.parentEntity = parentEntity;
    }


    @javax.persistence.Column(name = "type")
    public java.lang.String getType() {
        return type;
    }

    public void setType(java.lang.String type) {
        this.type = type;
    }

    @javax.persistence.Column(name = "lineOne")
    public String getLineOne() {
        return lineOne;
    }

    public void setLineOne(String lineOne) {
        this.lineOne = lineOne;
    }

    @javax.persistence.Column(name = "lineTwo")
    public java.lang.String getLineTwo() {
        return lineTwo;
    }

    public void setLineTwo(java.lang.String lineTwo) {
        this.lineTwo = lineTwo;
    }


    @javax.persistence.Column(name = "lineThree")
    public java.lang.String getLineThree() {
        return lineThree;
    }

    public void setLineThree(java.lang.String lineThree) {
        this.lineThree = lineThree;
    }


    @javax.persistence.Column(name = "lineFour")
    public java.lang.String getLineFour() {
        return lineFour;
    }

    public void setLineFour(java.lang.String lineFour) {
        this.lineFour = lineFour;
    }

    @javax.persistence.Column(name = "city")
    public Integer getCity() {
        return city;
    }

    public void setCity(Integer city) {
        this.city = city;
    }

    @javax.persistence.Column(name = "province")
    public Integer getProvince() {
        return province;
    }

    public void setProvince(Integer province) {
        this.province = province;
    }

    @javax.persistence.Column(name = "country")
    public Integer getCountry() {
        return country;
    }

    public void setCountry(Integer country) {
        this.country = country;
    }


    @javax.persistence.Column(name = "postalCd")
    public java.lang.String getPostalCd() {
        return postalCd;
    }

    public void setPostalCd(java.lang.String postalCd) {
        this.postalCd = postalCd;
    }

    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        if (!super.equals(object)) return false;

        Address that = (Address) object;

        if (id != that.id) return false;
        if (parentId != that.parentId) return false;
        if (parentEntity != null ? !parentEntity.equals(that.parentEntity) : that.parentEntity != null) return false;
        if (type != null ? !type.equals(that.type) : that.type != null) return false;
        if (lineOne != null ? !lineOne.equals(that.lineOne) : that.lineOne != null) return false;
        if (lineTwo != null ? !lineTwo.equals(that.lineTwo) : that.lineTwo != null) return false;
        if (lineThree != null ? !lineThree.equals(that.lineThree) : that.lineThree != null) return false;
        if (lineFour != null ? !lineFour.equals(that.lineFour) : that.lineFour != null) return false;
        if (city != null ? !city.equals(that.city) : that.city != null) return false;
        if (province != null ? !province.equals(that.province) : that.province != null) return false;
        if (country != null ? !country.equals(that.country) : that.country != null) return false;
        if (postalCd != null ? !postalCd.equals(that.postalCd) : that.postalCd != null) return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (createdDt != null ? !createdDt.equals(that.createdDt) : that.createdDt != null) return false;
        if (modifiedBy != null ? !modifiedBy.equals(that.modifiedBy) : that.modifiedBy != null) return false;
        if (modifiedDt != null ? !modifiedDt.equals(that.modifiedDt) : that.modifiedDt != null) return false;

        return true;
    }

    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + id;
        result = 31 * result + parentId;
        result = 31 * result + (parentEntity != null ? parentEntity.hashCode() : 0);
        result = 31 * result + (type != null ? type.hashCode() : 0);
        result = 31 * result + (lineOne != null ? lineOne.hashCode() : 0);
        result = 31 * result + (lineTwo != null ? lineTwo.hashCode() : 0);
        result = 31 * result + (lineThree != null ? lineThree.hashCode() : 0);
        result = 31 * result + (lineFour != null ? lineFour.hashCode() : 0);
        result = 31 * result + (city != null ? city.hashCode() : 0);
        result = 31 * result + (province != null ? province.hashCode() : 0);
        result = 31 * result + (country != null ? country.hashCode() : 0);
        result = 31 * result + (postalCd != null ? postalCd.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDt != null ? createdDt.hashCode() : 0);
        result = 31 * result + (modifiedBy != null ? modifiedBy.hashCode() : 0);
        result = 31 * result + (modifiedDt != null ? modifiedDt.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Address{");
        sb.append("id=").append(id);
        sb.append(", parentId=").append(parentId);
        sb.append(", parentEntity='").append(parentEntity).append('\'');
        sb.append(", type='").append(type).append('\'');
        sb.append(", lineOne='").append(lineOne).append('\'');
        sb.append(", lineTwo='").append(lineTwo).append('\'');
        sb.append(", lineThree='").append(lineThree).append('\'');
        sb.append(", lineFour='").append(lineFour).append('\'');
        sb.append(", city='").append(city).append('\'');
        sb.append(", province='").append(province).append('\'');
        sb.append(", country='").append(country).append('\'');
        sb.append(", postalCd='").append(postalCd).append('\'');
        sb.append(", createdBy=").append(createdBy);
        sb.append(", createdDt=").append(createdDt);
        sb.append(", modifiedBy=").append(modifiedBy);
        sb.append(", modifiedDt=").append(modifiedDt);
        sb.append('}');
        return sb.toString();
    }
}
