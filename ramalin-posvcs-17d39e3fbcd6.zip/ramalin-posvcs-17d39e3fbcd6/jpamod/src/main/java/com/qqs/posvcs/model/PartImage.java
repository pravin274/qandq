package com.qqs.posvcs.model;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Arrays;

@Entity
@Table(name = "partimage", schema = "qqordermgmnt", catalog = "")
public class PartImage {
    private int id;
    private int partId;
    private byte[] imageData;
    private String imageFileName;
    private String remarks;
    private String imageType;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "partId")
    public int getPartId() {
        return partId;
    }

    public void setPartId(int partId) {
        this.partId = partId;
    }

    @Column(name = "imageData")
    public byte[] getImageData() {
        return imageData;
    }

    public void setImageData(byte[] imageData) {
        this.imageData = imageData;
    }

    @Column(name = "imageFileName")
    public String getImageFileName() {
        return imageFileName;
    }

    @Column(name = "imageType")
    public String getImageType() {
        return imageType;
    }

    public void setImageType(String imageType) {
        this.imageType = imageType;
    }


    public void setImageFileName(String imageFileName) {
        this.imageFileName = imageFileName;
    }
    @Column(name = "remarks")
    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PartImage partimage = (PartImage) o;

        if (id != partimage.id) return false;
        if (partId != partimage.partId) return false;
        if (!Arrays.equals(imageData, partimage.imageData)) return false;
        if (createdBy != null ? !createdBy.equals(partimage.createdBy) : partimage.createdBy != null) return false;
        if (createdDt != null ? !createdDt.equals(partimage.createdDt) : partimage.createdDt != null) return false;
        if (modifiedBy != null ? !modifiedBy.equals(partimage.modifiedBy) : partimage.modifiedBy != null) return false;
        if (modifiedDt != null ? !modifiedDt.equals(partimage.modifiedDt) : partimage.modifiedDt != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + partId;
        result = 31 * result + Arrays.hashCode(imageData);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDt != null ? createdDt.hashCode() : 0);
        result = 31 * result + (modifiedBy != null ? modifiedBy.hashCode() : 0);
        result = 31 * result + (modifiedDt != null ? modifiedDt.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("PartImage{");
        sb.append("id=").append(id);
        sb.append(", partId=").append(partId);
        sb.append(", imageData=");
        if (imageData == null) sb.append("null");
        else {
            sb.append('[');
            for (int i = 0; i < imageData.length; ++i)
                sb.append(i == 0 ? "" : ", ").append(imageData[i]);
            sb.append(']');
        }
        sb.append(", createdBy=").append(createdBy);
        sb.append(", createdDt=").append(createdDt);
        sb.append(", modifiedBy=").append(modifiedBy);
        sb.append(", modifiedDt=").append(modifiedDt);
        sb.append('}');
        return sb.toString();
    }
}
