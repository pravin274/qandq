package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.Bank;
import org.springframework.data.repository.CrudRepository;

public interface BankRepository extends CrudRepository<Bank, Integer> {
}
