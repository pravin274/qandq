package com.qqs.posvcs.service;

import com.qqs.posvcs.model.Email;
import com.qqs.posvcs.repository.EmailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Component
public class EmailDataService {
    @Autowired
    private EmailRepository repository;

    public Optional<Email> getEmailById(Integer id) {
        return repository.findById(id);
    }

    public Optional<List<Email>> findEmailByParentType(String parentType, Integer parentId){
        return repository.findEmailByParent(parentType, parentId);
    }

    public Optional<List<Email>> findEmailByCompany(Integer id) {
        return repository.findEmailByCompany(id);
    }

    public Optional<List<Email>> findAllByParentIdInAndParentEntity(List<Integer> parentIds, String parentEntity) {
        return repository.findAllByParentIdInAndParentEntity(parentIds, parentEntity);
    }

    @Transactional
    public Email saveEmail(Email item) {
        return repository.save(item);
    }
}
