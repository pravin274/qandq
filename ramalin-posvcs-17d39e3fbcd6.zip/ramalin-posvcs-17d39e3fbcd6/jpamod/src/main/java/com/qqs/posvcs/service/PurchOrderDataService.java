package com.qqs.posvcs.service;

import com.qqs.posvcs.model.PurchOrder;
import com.qqs.posvcs.repository.PurchOrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Component
public class PurchOrderDataService {
    @Autowired
    private PurchOrderRepository repository;

    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<PurchOrder> utils = new DataServiceUtils<>();


    public Optional<PurchOrder> getPurchaseOrderById(Integer id) {
        return repository.findById(id);
    }

    public Optional<List<PurchOrder>> findPurchOrderByCompany(Integer companyId) {
        return repository.findPurchOrderByCompany(companyId);
    }

    public Optional<List<Object[]>> findAllActivePo(String fromDate, String toDate) {
        return repository.findAllActivePo(fromDate, toDate);
    }


    public Optional<List<PurchOrder>> searchPurchaseOrders(List<SearchCriteria> params) {
        List<PurchOrder> result = utils.createPredicate(entityManager, params, PurchOrder.class);
        Optional<List<PurchOrder>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public Integer getTotalPOCount() {
        return repository.getTotalPOCount();
    }
    @Transactional
    public PurchOrder savePurchaseorder(PurchOrder item) {
        return repository.save(item);
    }

    @Transactional
    public void updatePurchaseorderStatus(String poNumber, String status) {
         repository.updatePOStatus(poNumber, status);
    }
}
