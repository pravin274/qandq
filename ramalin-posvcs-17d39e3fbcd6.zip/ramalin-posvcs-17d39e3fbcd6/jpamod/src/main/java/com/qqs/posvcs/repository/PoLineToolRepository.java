package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.PoLineTool;
import org.springframework.data.repository.CrudRepository;

public interface PoLineToolRepository extends CrudRepository<PoLineTool, Integer> {
}
