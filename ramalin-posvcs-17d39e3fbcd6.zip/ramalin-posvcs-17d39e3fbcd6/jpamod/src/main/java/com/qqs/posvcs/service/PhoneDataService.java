package com.qqs.posvcs.service;

import com.qqs.posvcs.model.Phone;
import com.qqs.posvcs.repository.PhoneRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Component
public class PhoneDataService {
    @Autowired
    private PhoneRepository repository;

    public Optional<Phone> getPhoneById(Integer id) {
        return repository.findById(id);
    }

    public Optional<List<Phone>> findPhoneByParentType(String parentType, Integer parentId){
        return repository.findPhoneByParent(parentType, parentId);
    }

    public Optional<List<Phone>> findPhoneByCompany(Integer companyId) {
        return repository.findPhoneByCompany(companyId);
    }

    public Optional<List<Phone>> findAllByParentIdInAndParentEntity(List<Integer> parentIds, String parentEntity) {
        return repository.findAllByParentIdInAndParentEntity(parentIds, parentEntity);
    }


    @Transactional
    public Phone savePhone(Phone item) {
        return repository.save(item);
    }
}
