package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.PartStandard;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface PartStandardRepository extends CrudRepository<PartStandard, Integer> {
    Optional<List<PartStandard>> findPartStandardByPartId(Integer partId);
}
