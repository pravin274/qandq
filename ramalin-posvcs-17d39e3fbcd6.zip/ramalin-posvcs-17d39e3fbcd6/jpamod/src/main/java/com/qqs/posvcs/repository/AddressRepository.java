package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.Address;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface AddressRepository extends CrudRepository<Address, Integer> {

    //Parent entity types are available at ParentEntityType enum

    @Query(value = "select * from qqordermgmnt.address where parentEntity = ?1 AND parentId = ?2", nativeQuery = true)
    Optional<List<Address>> findAddressesByParent(String parentType, Integer parentId);

    @Query(value = "select * from qqordermgmnt.address where parentEntity = 'C' AND parentId = ?1", nativeQuery = true)
    Optional<List<Address>> findAddressesByCompany(Integer companyId);

    @Query(value = "select * from qqordermgmnt.address where parentEntity = 'P' AND parentId = ?1", nativeQuery = true)
    Optional<List<Address>> findAddressesByPlant(Integer plantId);

    @Query(value = "select * from qqordermgmnt.address where parentEntity = 'H' AND parentId = ?1", nativeQuery = true)
    Optional<List<Address>> findAddressesByPeople(Integer peopleId);

}
