package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.States;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface StatesRepository extends CrudRepository<States, Integer> {

    @Query(value = "select * from states where country_id = ?1", nativeQuery = true)
    Optional<List<States>> findStatesByCountryId(Integer countryId);

    @Query(value = "SELECT name FROM qqordermgmnt.states where id = ?1", nativeQuery = true)
    Optional<String> findStateNameById(Integer stateId);
}
