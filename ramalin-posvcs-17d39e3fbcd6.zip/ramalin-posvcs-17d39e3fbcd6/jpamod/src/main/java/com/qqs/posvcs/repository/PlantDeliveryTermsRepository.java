package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.PlantDeliveryTerms;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface PlantDeliveryTermsRepository extends CrudRepository<PlantDeliveryTerms, Integer> {
    Optional<List<PlantDeliveryTerms>> findPlantDeliveryTermsByPlantId(Integer plantId);
    Optional<List<PlantDeliveryTerms>> findPlantDeliveryTermsByPlantIdIn(List<Integer> plantId);
    PlantDeliveryTerms findPlantDeliveryTermsById(Integer id);

}
