package com.qqs.posvcs.service;

import com.qqs.posvcs.model.Plant;
import com.qqs.posvcs.model.PlantDeliveryTerms;
import com.qqs.posvcs.model.PlantPaymentTerms;
import com.qqs.posvcs.repository.PlantDeliveryTermsRepository;
import com.qqs.posvcs.repository.PlantPaymentTermsRepository;
import com.qqs.posvcs.repository.PlantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Component
public class PlantDataService {
    @Autowired
    private PlantRepository repository;
    @Autowired
    private PlantDeliveryTermsRepository plantDeliveryTermsRepository;
    @Autowired
    private PlantPaymentTermsRepository plantPaymentTermsRepository;

    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<Plant> plantUtils = new DataServiceUtils<>();

    public Optional<Plant> getPlantById(Integer id) {
        return repository.findById(id);
    }

    public Optional<List<Plant>> getPlantsByCompany(Integer companyId) {
        return repository.findPlantByCompanyId(companyId);
    }

    public Iterable<Plant> getAllPlants() {
        return repository.findAll();
    }

    public Optional<List<Plant>> searchPlant(List<SearchCriteria> params) {
        List<Plant> result = plantUtils.createPredicate(entityManager, params, Plant.class);
        Optional<List<Plant>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public Optional<List<PlantDeliveryTerms>> getPlantDeliveryTermsByPlantId(Integer plantId) {
        return plantDeliveryTermsRepository.findPlantDeliveryTermsByPlantId(plantId);
    }

    public Optional<List<PlantDeliveryTerms>> getPlantDeliveryTermsByPlantIds(List<Integer> plantIds) {
        return plantDeliveryTermsRepository.findPlantDeliveryTermsByPlantIdIn (plantIds);
    }

    public Optional<List<PlantPaymentTerms>> getPlantPaymentTermsByPlantId(Integer plantId) {
        return plantPaymentTermsRepository.findPlantPaymentTermsByPlantId(plantId);
    }

    public Optional<List<PlantPaymentTerms>> getPlantPaymentTermsByPlantIds(List<Integer> plantIds) {
        return plantPaymentTermsRepository.findPlantPaymentTermsByPlantIdIn (plantIds);
    }

    public PlantDeliveryTerms getPlantDeliveryTermsById(Integer id) {
        return plantDeliveryTermsRepository.findPlantDeliveryTermsById(id);
    }

    public PlantPaymentTerms getPlantPaymentTermsById(Integer id) {
        return plantPaymentTermsRepository.findPlantPaymentTermsById (id);
    }

    @Transactional
    public Plant savePlant(Plant item) {
        return repository.save(item);
    }

    @Transactional
    public PlantDeliveryTerms savePlantDeliveryTerms(PlantDeliveryTerms item) {
        return plantDeliveryTermsRepository.save(item);
    }

    @Transactional
    public PlantPaymentTerms savePlantPaymentTerms(PlantPaymentTerms item) {
        return plantPaymentTermsRepository.save(item);
    }
}
