package com.qqs.posvcs.model;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.persistence.*;

@Entity
@Table(name = "polinetool", schema = "qqordermgmnt", catalog = "")
public class PoLineTool {
    private int id;
    private String description;
    private Integer price;
    private String toolNo;
    private String revNo;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "description")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Column(name = "price")
    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    @Column(name = "toolNo")
    public String getToolNo() {
        return toolNo;
    }

    public void setToolNo(String toolNo) {
        this.toolNo = toolNo;
    }

    @Column(name = "revNo")
    public String getRevNo() {
        return revNo;
    }

    public void setRevNo(String revNo) {
        this.revNo = revNo;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PoLineTool poLineTool = (PoLineTool) o;

        return new EqualsBuilder()
                .append(id, poLineTool.id)
                .append(description, poLineTool.description)
                .append(price, poLineTool.price)
                .append(toolNo, poLineTool.toolNo)
                .append(revNo, poLineTool.revNo)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(id)
                .append(description)
                .append(price)
                .append(toolNo)
                .append(revNo)
                .toHashCode();
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("PoLineTool{");
        sb.append("id=").append(id);
        sb.append("description=").append(description);
        sb.append("price=").append(price);
        sb.append("toolNo=").append(toolNo);
        sb.append("revNo=").append(revNo);
        sb.append('}');
        return sb.toString();
    }
}