package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.CodeAssociation;
import org.springframework.data.repository.CrudRepository;

public interface CodeAssociationRepository extends CrudRepository<CodeAssociation, Integer> {

}
