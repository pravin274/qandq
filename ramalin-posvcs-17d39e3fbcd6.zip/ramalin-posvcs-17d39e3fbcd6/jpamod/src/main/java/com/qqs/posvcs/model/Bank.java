package com.qqs.posvcs.model;


import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "bank", schema = "qqordermgmnt", catalog = "")
public class Bank {
    private int id;
    private String bankName;
    private String accountNumber;
    private String ifscCode;
    private String swiftcode;
    private String adCode;
    private Timestamp createdDt;
    private Integer createdBy;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "bankName")
    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    @Column(name = "accountNumber")
    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    @Column(name = "ifscCode")
    public String getIfscCode() {
        return ifscCode;
    }

    public void setIfscCode(String ifscCode) {
        this.ifscCode = ifscCode;
    }

    @Column(name = "swiftcode")
    public String getSwiftcode() {
        return swiftcode;
    }

    public void setSwiftcode(String swiftcode) {
        this.swiftcode = swiftcode;
    }

    @Column(name = "adCode")
    public String getAdCode() {
        return adCode;
    }

    public void setAdCode(String adCode) {
        this.adCode = adCode;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Bank Bank = (Bank) o;

        if (id != Bank.id) return false;

        if (bankName != null ? !bankName.equals(Bank.bankName) : Bank.bankName != null) return false;
        if (accountNumber != null ? !accountNumber.equals(Bank.accountNumber) : Bank.accountNumber != null) return false;
        if (ifscCode != null ? !ifscCode.equals(Bank.ifscCode) : Bank.ifscCode != null)
            return false;
        if (swiftcode != null ? !swiftcode.equals(Bank.swiftcode) : Bank.swiftcode != null) return false;
        if (adCode != null ? !adCode.equals(Bank.adCode) : Bank.adCode != null) return false;
        if (createdBy != null ? !createdBy.equals(Bank.createdBy) : Bank.createdBy != null) return false;
        if (createdDt != null ? !createdDt.equals(Bank.createdDt) : Bank.createdDt != null) return false;
        if (modifiedBy != null ? !modifiedBy.equals(Bank.modifiedBy) : Bank.modifiedBy != null) return false;
        if (modifiedDt != null ? !modifiedDt.equals(Bank.modifiedDt) : Bank.modifiedDt != null) return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (bankName != null ? bankName.hashCode() : 0);
        result = 31 * result + (accountNumber != null ? accountNumber.hashCode() : 0);
        result = 31 * result + (ifscCode != null ? ifscCode.hashCode() : 0);
        result = 31 * result + (swiftcode != null ? swiftcode.hashCode() : 0);
        result = 31 * result + (adCode != null ? adCode.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDt != null ? createdDt.hashCode() : 0);
        result = 31 * result + (modifiedBy != null ? modifiedBy.hashCode() : 0);
        result = 31 * result + (modifiedDt != null ? modifiedDt.hashCode() : 0);

        return result;
    }
}


