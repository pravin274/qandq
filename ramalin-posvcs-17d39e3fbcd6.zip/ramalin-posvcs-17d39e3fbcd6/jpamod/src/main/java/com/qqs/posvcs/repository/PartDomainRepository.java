package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.PartDomain;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface PartDomainRepository extends CrudRepository<PartDomain, Integer> {
    Optional<List<PartDomain>> findPartDomainsByPartId(Integer partId);
}
