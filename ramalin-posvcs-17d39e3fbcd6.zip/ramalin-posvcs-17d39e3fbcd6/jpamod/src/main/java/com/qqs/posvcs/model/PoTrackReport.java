package com.qqs.posvcs.model;

public interface PoTrackReport {
    Integer getInvoiceId();
    String getPONumber();
    String getPODate();
    String getPartNumber();
    String getPartRevisionNumber();
    String getDescription();
    String getHsCode();
    String getDueDate();
    String getItemNumber();
    String getPartType();
    String getPoQuantity();
    String getInvoiceQuantity();
    String getInvoiceNumber();
    String getInvoiceDate();
    String getCompanyName();
    String getPlantName();
    String getInvoiceStatus();
    String getPoStatus();
    String getPoRevision();
    Double getPartPrice();
    String getPricePerPart();
    Double getTotalInvoiceValueINR();
    String getCurrency();
    Double getTotalInvoiceValue();
    int getCompanyId();
    int getPlantId();
}
