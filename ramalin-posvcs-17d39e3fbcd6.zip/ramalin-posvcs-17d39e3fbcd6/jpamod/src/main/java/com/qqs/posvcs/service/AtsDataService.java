package com.qqs.posvcs.service;

import com.qqs.posvcs.model.Ats;
import com.qqs.posvcs.model.AtsContentSheet;
import com.qqs.posvcs.repository.AtsContentSheetRepository;
import com.qqs.posvcs.repository.AtsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Component
public class AtsDataService{

    @Autowired
    private AtsRepository atsRepository;

    @Resource
    private EntityManager entityManager;

    @Autowired
    private AtsContentSheetRepository atsContentSheetRepository;



    private DataServiceUtils<Ats> utils = new DataServiceUtils<>();

    public Optional<List<AtsContentSheet>> findAtsContentSheetByAts(Integer packageId) {
        return atsContentSheetRepository.findContetntListForAts(packageId);
    }


    public Optional<List<Ats>> searchAllAts(List<SearchCriteria> params) {
        List<Ats> result = utils.createPredicate(entityManager, params, Ats.class);
//        Optional<List<Ats>> resultSet = Optional.ofNullable(result);
        return Optional.ofNullable(result);
    }

    public Iterable<AtsContentSheet> saveAllAtsContentSheetList(Collection<AtsContentSheet> item) {
        return atsContentSheetRepository.saveAll(item);
    }


    public Ats getAtsByAtsId(Integer id) {
        return atsRepository.findAllById(id);
    }

    @Transactional
    public Ats saveAts(Ats item) {
        return atsRepository.save(item);
    }

    @Transactional
    public AtsContentSheet saveAtsContetnt(AtsContentSheet item) {
        return atsContentSheetRepository.save(item);
    }

}
