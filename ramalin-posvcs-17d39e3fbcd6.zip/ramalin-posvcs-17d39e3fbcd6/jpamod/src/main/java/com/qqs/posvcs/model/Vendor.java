package com.qqs.posvcs.model;


import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "vendor", schema = "qqordermgmnt", catalog = "")
public class Vendor {
    private int id;
    private String vendorName;
    private String panNo;
    private String gstinNo;
    private String phoneNumber;
    private String email;
    private Integer stateCode;
    private Integer districtCode;
    private String ieCode;
    private Timestamp createdDt;
    private Integer createdBy;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "vendorName")
    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    @Column(name = "panNo")
    public String getPanNo() {
        return panNo;
    }

    public void setPanNo(String panNo) {
        this.panNo = panNo;
    }

    @Column(name = "gstinNo")
    public String getGstinNo() {
        return gstinNo;
    }

    public void setGstinNo(String gstinNo) { this.gstinNo = gstinNo; }

    @Column(name = "stateCode")
    public Integer getStateCode() {
        return stateCode;
    }

    public void setStateCode(Integer stateCode) { this.stateCode = stateCode; }

    @Column(name = "DistrictCode")
    public Integer getDistrictCode() {
        return districtCode;
    }

    public void setDistrictCode(Integer districtCode) { this.districtCode = districtCode; }

    @Column(name = "email")
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) { this.email = email; }



    @Column(name = "phoneNo")
    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }


    @Column(name = "ieCode")
    public String getIeCode() {
        return ieCode;
    }

    public void setIeCode(String ieCode) {
        this.ieCode = ieCode;
    }


    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Vendor vendor = (Vendor) o;

        if (id != vendor.id) return false;
        if (vendorName != null ? !vendorName.equals(vendor.vendorName) : vendor.vendorName != null) return false;
        if (panNo != null ? !panNo.equals(vendor.panNo) : vendor.panNo != null) return false;
        if (gstinNo != null ? !gstinNo.equals(vendor.gstinNo) : vendor.gstinNo != null) return false;
        if (ieCode != null ? !panNo.equals(vendor.ieCode) : vendor.ieCode != null) return false;
        if (createdBy != null ? !createdBy.equals(vendor.createdBy) : vendor.createdBy != null) return false;
        if (createdDt != null ? !createdDt.equals(vendor.createdDt) : vendor.createdDt != null) return false;
        if (modifiedBy != null ? !modifiedBy.equals(vendor.modifiedBy) : vendor.modifiedBy != null) return false;
        if (modifiedDt != null ? !modifiedDt.equals(vendor.modifiedDt) : vendor.modifiedDt != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (vendorName != null ? vendorName.hashCode() : 0);
        result = 31 * result + (panNo != null ? panNo.hashCode() : 0);
        result = 31 * result + (gstinNo != null ? gstinNo.hashCode() : 0);
        result = 31 * result + (ieCode != null ? ieCode.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDt != null ? createdDt.hashCode() : 0);
        result = 31 * result + (modifiedBy != null ? modifiedBy.hashCode() : 0);
        result = 31 * result + (modifiedDt != null ? modifiedDt.hashCode() : 0);
        return result;
    }
}


