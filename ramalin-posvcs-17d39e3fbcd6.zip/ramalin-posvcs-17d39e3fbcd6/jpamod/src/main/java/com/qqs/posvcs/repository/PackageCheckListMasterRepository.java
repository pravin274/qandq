package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.PackCheckListMaster;
import org.springframework.data.repository.CrudRepository;

public interface PackageCheckListMasterRepository extends CrudRepository<PackCheckListMaster, Integer> {




    PackCheckListMaster findAllById(Integer id);

}
