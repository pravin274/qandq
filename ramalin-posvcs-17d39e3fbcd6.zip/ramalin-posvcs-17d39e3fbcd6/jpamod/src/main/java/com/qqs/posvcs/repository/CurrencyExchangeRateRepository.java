package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.CurrencyExchangeRate;
import org.springframework.data.repository.CrudRepository;

public interface CurrencyExchangeRateRepository extends CrudRepository<CurrencyExchangeRate, Integer> {
}
