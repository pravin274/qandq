package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.PendingOrderResult;
import com.qqs.posvcs.model.PurchOrder;
import com.qqs.posvcs.model.SalesOrderResult;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface PurchOrderRepository extends CrudRepository<PurchOrder, Integer> {

    @Query(value = "select * from purchOrder where companyId = ?1", nativeQuery = true)
    Optional<List<PurchOrder>> findPurchOrderByCompany(Integer companyId);

    @Query(value = "SELECT co.name as 'label', " +
            " if(month(?1) = month(?2) and year(?1) = year (?2), DATE_FORMAT(CONVERT_TZ(po.poDate,'GMT', cdd.description),'%Y-%m-%d'), " +
            " DATE_FORMAT(CONVERT_TZ(po.poDate,'GMT', cdd.description),'%Y-%m')) as 'xCoordinate',  " +
            " sum(partprice*quantity) as 'orgin' " +
            " FROM qqordermgmnt.polineitem pol, qqordermgmnt.purchorder po, company co, `qqordermgmnt`.`codes` cdd " +
            " where po.id = pol.poid and co.id = po.companyid and po.poStatus='ACTIVE' " +
            " and cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " + 
            " and podate between ?1 and ?2  " +
            " and po.companyId in ?3 group by 1,2 order by 1 desc, 2;", nativeQuery = true)
    Optional<List<Object[]>> findCustWiseOrderReportData(String fromDate, String toDate, List<String> selectedItemIds);

    @Query(value = "SELECT co.name as 'label', " +
            " if(month(?1) = month(?2) and year(?1) = year (?2), DATE_FORMAT(CONVERT_TZ(po.poDate,'GMT', cdd.description),'%Y-%m-%d'), " +
            " DATE_FORMAT(CONVERT_TZ(po.poDate,'GMT', cdd.description),'%Y-%m')) as 'xCoordinate', " +
            " sum(partprice*quantity) as 'orgin' " +
            " FROM qqordermgmnt.polineitem pol, qqordermgmnt.purchorder po, company co, `qqordermgmnt`.`codes` cdd " +
            " where po.id = pol.poid and co.id = po.companyid  and po.poStatus='ACTIVE' " +
            " and cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " +
            " and podate between ?1 and ?2  " +
            " group by 1,2 order by 1 desc, 2;", nativeQuery = true)
    Optional<List<Object[]>> findCustWiseOrderReportAllData(String fromDate, String toDate);

    @Query(value = "SELECT concat(co.name,' - ',plantcode) as 'label', " +
            " if(month(?1) = month(?2) and year(?1) = year (?2), DATE_FORMAT(CONVERT_TZ(po.poDate,'GMT', cdd.description),'%Y-%m-%d'), " +
            " DATE_FORMAT(CONVERT_TZ(po.poDate,'GMT', cdd.description),'%Y-%m')) as 'xCoordinate',  " +
            " sum(partprice*quantity) as 'orgin' " +
            " FROM qqordermgmnt.polineitem pol, qqordermgmnt.purchorder po, plant pl, company co, `qqordermgmnt`.`codes` cdd " + 
            " where po.id = pol.poid and pl.id = po.plantid and co.id = po.companyid  and po.poStatus='ACTIVE' " +
            " and cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " +
            " and podate between ?1 and ?2  " +
            " and pl.id in ?3 group by 1,2 order by 1 desc, 2;", nativeQuery = true)
    Optional<List<Object[]>> findPlantWiseOrderReportData(String fromDate, String toDate, List<String> selectedItemIds);

    @Query(value = "SELECT concat(co.name,' - ',plantcode) as 'label', " +
            " if(month(?1) = month(?2) and year(?1) = year (?2), DATE_FORMAT(CONVERT_TZ(po.poDate,'GMT', cdd.description),'%Y-%m-%d'), " +
            " DATE_FORMAT(CONVERT_TZ(po.poDate,'GMT', cdd.description),'%Y-%m')) as 'xCoordinate', " +
            " sum(partprice*quantity) as 'orgin' " +
            " FROM qqordermgmnt.polineitem pol, qqordermgmnt.purchorder po, plant pl, company co, `qqordermgmnt`.`codes` cdd " + 
            " where po.id = pol.poid and pl.id = po.plantid and co.id = po.companyid  and po.poStatus='ACTIVE' " +
            " and cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " +
            " and podate between ?1 and ?2  " +
            " group by 1,2 order by 1 desc, 2;", nativeQuery = true)
    Optional<List<Object[]>> findPlantWiseOrderReportAllData(String fromDate, String toDate);

    @Query(value = "SELECT  ifnull(cd.description,'Others') as 'label', " +
            " if(month(?1) = month(?2) and year(?1) = year (?2), DATE_FORMAT(CONVERT_TZ(po.poDate,'GMT', cdd.description),'%Y-%m-%d'), " +
            " DATE_FORMAT(CONVERT_TZ(po.poDate,'GMT', cdd.description),'%Y-%m')) as 'xCoordinate', " +
            " sum(partprice*quantity) as 'orgin' " +
            " FROM qqordermgmnt.polineitem pol inner join qqordermgmnt.purchorder po on po.id = pol.poid and po.poStatus='ACTIVE' " +
            " inner join plant pl on pl.id = po.plantid " +
            " INNER JOIN `qqordermgmnt`.`codes` cdd ON cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " +
            " left outer join partdomain pd on pd.partid = pol.partid left outer join codes cd on cd.code = pd.domain and cd.category='PART_DOMAIN'  " +
            " where  podate between ?1 and ?2  " +
            " and cd.code in ?3 group by 1,2 order by 1 desc, 2;", nativeQuery = true)
    Optional<List<Object[]>> findDomainWiseOrderReportData(String fromDate, String toDate, List<String> selectedItemIds);

    @Query(value = "SELECT  ifnull(cd.description,'Others') as 'label', " +
            " if(month(?1) = month(?2) and year(?1) = year (?2), DATE_FORMAT(CONVERT_TZ(po.poDate,'GMT', cdd.description),'%Y-%m-%d'), " +
            " DATE_FORMAT(CONVERT_TZ(po.poDate,'GMT', cdd.description),'%Y-%m')) as 'xCoordinate', " +
            " sum(partprice*quantity) as 'orgin'  \n" +
            " FROM qqordermgmnt.polineitem pol inner join qqordermgmnt.purchorder po on po.id = pol.poid  and po.poStatus='ACTIVE' " +
            " inner join plant pl on pl.id = po.plantid " +
            " INNER JOIN `qqordermgmnt`.`codes` cdd ON cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " +
            " left outer join partdomain pd on pd.partid = pol.partid left outer join codes cd on cd.code = pd.domain and cd.category='PART_DOMAIN'  " +
            " where  podate between ?1 and ?2  " +
            " group by 1,2 order by 1 desc, 2;", nativeQuery = true)
    Optional<List<Object[]>> findDomainWiseOrderReportAllData(String fromDate, String toDate);


    @Query(value = "SELECT  ifnull(cd.description,'Others') as 'label', " +
            " if(month(?1) = month(?2) and year(?1) = year (?2), DATE_FORMAT(CONVERT_TZ(po.poDate,'GMT', cdd.description),'%Y-%m-%d'), " +
            " DATE_FORMAT(CONVERT_TZ(po.poDate,'GMT', cdd.description),'%Y-%m')) as 'xCoordinate', " +
            " sum(partprice*quantity) as 'orgin'  \n" +
            " FROM qqordermgmnt.polineitem pol inner join qqordermgmnt.purchorder po on po.id = pol.poid  and po.poStatus='ACTIVE' " +
            " inner join plant pl on pl.id = po.plantid " +
            " INNER JOIN `qqordermgmnt`.`codes` cdd ON cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " +
            " inner join address ad on ad.parentid = pl.id and ad.parentEntity = 'P' and ad.type='B' inner join codes cd on cd.code = ad.country and cd.category='COUNTRY'\n" +
            " where  podate between ?1 and ?2 and cd.code in ?3 group by 1,2 order by 1 desc, 2;", nativeQuery = true)
    Optional<List<Object[]>> findGeoWiseOrderReportData(String fromDate, String toDate, List<String> selectedItemIds);

    @Query(value = "SELECT  ifnull(cd.description,'Others') as 'label',  " +
            " if(month(?1) = month(?2) and year(?1) = year (?2), DATE_FORMAT(CONVERT_TZ(po.poDate,'GMT', cdd.description),'%Y-%m-%d'), " +
            " DATE_FORMAT(CONVERT_TZ(po.poDate,'GMT', cdd.description),'%Y-%m')) as 'xCoordinate', " +
            " sum(partprice*quantity) as 'orgin'  \n" +
            " FROM qqordermgmnt.polineitem pol inner join qqordermgmnt.purchorder po on po.id = pol.poid  and po.poStatus='ACTIVE' " +
            " inner join plant pl on pl.id = po.plantid " +
            " INNER JOIN `qqordermgmnt`.`codes` cdd ON cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " +
            " inner join address ad on ad.parentid = pl.id and ad.parentEntity = 'P' and ad.type='B' inner join codes cd on cd.code = ad.country and cd.category='COUNTRY'\n" +
            " where  podate between ?1 and ?2 group by 1,2 order by 1 desc, 2;", nativeQuery = true)
    Optional<List<Object[]>> findGeoWiseOrderReportAllData(String fromDate, String toDate);


    // Sales Report methods

    @Query(value = "SELECT co.name as 'label', " +
            " if(month(?1) = month(?2) and year(?1) = year (?2), DATE_FORMAT(CONVERT_TZ(inv.invDate,'GMT', cdd.description),'%Y-%m-%d'), " +
            " DATE_FORMAT(CONVERT_TZ(inv.invDate,'GMT', cdd.description),'%Y-%m')) as 'xCoordinate',  " +
            " sum(partprice*invoiceQty) as 'orgin' " +
            " FROM qqordermgmnt.invoicelineitem invl, qqordermgmnt.invoice inv, " +
            " plant pl, company co, polineitem pol, qqordermgmnt.purchorder po, `qqordermgmnt`.`codes` cdd " +
            " where inv.id = invl.invoiceId and pl.id = inv.plantid and co.id = pl.companyid and pol.id = invl.poLineId  " +
            " and po.id = pol.poId and po.poStatus = 'ACTIVE'" +
            " and cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " +
            " and invDate between ?1 and ?2  " +
            " and co.id in ?3 group by 1,2 order by 1 desc, 2;", nativeQuery = true)
    Optional<List<Object[]>> findCustWiseSalesReportData(String fromDate, String toDate, List<String> selectedItemIds);

    @Query(value = "SELECT co.name as 'label', " +
            " if(month(?1) = month(?2) and year(?1) = year (?2), DATE_FORMAT(CONVERT_TZ(inv.invDate,'GMT', cdd.description),'%Y-%m-%d'), " +
            " DATE_FORMAT(CONVERT_TZ(inv.invDate,'GMT', cdd.description),'%Y-%m')) as 'xCoordinate',  " +
            " sum(partprice*invoiceQty) as 'orgin' FROM qqordermgmnt.invoicelineitem invl, qqordermgmnt.invoice inv, " +
            " plant pl, company co, polineitem pol, qqordermgmnt.purchorder po, `qqordermgmnt`.`codes` cdd " +
            " where inv.id = invl.invoiceId and pl.id = inv.plantid and co.id = pl.companyid and pol.id = invl.poLineId  " +
            " and po.id = pol.poId and po.poStatus = 'ACTIVE'" +
            " and cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " +
            " and invDate between ?1 and ?2  " +
            " group by 1,2 order by 1 desc, 2;", nativeQuery = true)
    Optional<List<Object[]>> findCustWiseSalesReportAllData(String fromDate, String toDate);

    @Query(value = "SELECT concat(co.name,' - ',plantcode) as 'label', " +
            " if(month(?1) = month(?2) and year(?1) = year (?2), DATE_FORMAT(CONVERT_TZ(inv.invDate,'GMT', cdd.description),'%Y-%m-%d'), DATE_FORMAT(CONVERT_TZ(inv.invDate,'GMT', cdd.description),'%Y-%m')) as 'xCoordinate',  " +
            " sum(partprice*invoiceQty) as 'orgin' FROM qqordermgmnt.invoicelineitem invl, qqordermgmnt.invoice inv, " +
            " plant pl, company co, polineitem pol, qqordermgmnt.purchorder po, `qqordermgmnt`.`codes` cdd " +
            " where inv.id = invl.invoiceId and pl.id = inv.plantid and co.id = pl.companyid and pol.id = invl.poLineId  " +
            " and po.id = pol.poId and po.poStatus = 'ACTIVE'" +
            " and cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " +
            " and invDate between ?1 and ?2  " +
            " and co.id in ?3 group by 1,2 order by 1 desc, 2;", nativeQuery = true)
    Optional<List<Object[]>> findPlantWiseSalesReportData(String fromDate, String toDate, List<String> selectedItemIds);

    @Query(value = "SELECT concat(co.name,' - ',plantcode) as 'label', " +
            " if(month(?1) = month(?2) and year(?1) = year (?2), DATE_FORMAT(CONVERT_TZ(inv.invDate,'GMT', cdd.description),'%Y-%m-%d'), DATE_FORMAT(CONVERT_TZ(inv.invDate,'GMT', cdd.description),'%Y-%m')) as 'xCoordinate',  " +
            " sum(partprice*invoiceQty) as 'orgin' FROM qqordermgmnt.invoicelineitem invl, qqordermgmnt.invoice inv, " +
            " plant pl, company co, polineitem pol, qqordermgmnt.purchorder po, `qqordermgmnt`.`codes` cdd " +
            " where inv.id = invl.invoiceId and pl.id = inv.plantid and co.id = pl.companyid and pol.id = invl.poLineId  " +
            " and po.id = pol.poId and po.poStatus = 'ACTIVE'" +
            " and cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " +
            " and invDate between ?1 and ?2  " +
            " group by 1,2 order by 1 desc, 2;", nativeQuery = true)
    Optional<List<Object[]>> findPlantWiseSalesReportAllData(String fromDate, String toDate);

    @Query(value = "SELECT  ifnull(cd.description,'Others') as 'label', " +
            " if(month(?1) = month(?2) and year(?1) = year (?2), DATE_FORMAT(CONVERT_TZ(inv.invDate,'GMT', cdd.description),'%Y-%m-%d'), DATE_FORMAT(CONVERT_TZ(inv.invDate,'GMT', cdd.description),'%Y-%m')) as 'xCoordinate', " +
            " sum(partprice*invoiceQty) as 'orgin'  " +
            " FROM qqordermgmnt.invoicelineitem invl inner join qqordermgmnt.invoice inv on inv.id = invl.invoiceId " +
            " inner join plant pl on pl.id = inv.plantid " +
            " INNER JOIN `qqordermgmnt`.`codes` cdd ON cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " +
            " inner join polineitem pol on pol.id = invl.poLineId  " +
            " inner join qqordermgmnt.purchorder po on po.id = pol.poId and po.poStatus = 'ACTIVE' " +
            " left outer join partdomain pd on pd.partid = pol.partid left outer join codes cd on cd.code = pd.domain and cd.category='PART_DOMAIN' " +
            " where inv.invDate between ?1 and ?2  " +
            " and cd.code in ?3 group by 1,2 order by 1 desc, 2;", nativeQuery = true)
    Optional<List<Object[]>> findDomainWiseSalesReportData(String fromDate, String toDate, List<String> selectedItemIds);

    @Query(value = "SELECT  ifnull(cd.description,'Others') as 'label', " +
            " if(month(?1) = month(?2) and year(?1) = year (?2), DATE_FORMAT(CONVERT_TZ(inv.invDate,'GMT', cdd.description),'%Y-%m-%d'), DATE_FORMAT(CONVERT_TZ(inv.invDate,'GMT', cdd.description),'%Y-%m')) as 'xCoordinate', " +
            " sum(partprice*invoiceQty) as 'orgin' " +
            " FROM qqordermgmnt.invoicelineitem invl inner join qqordermgmnt.invoice inv on inv.id = invl.invoiceId " +
            " inner join plant pl on pl.id = inv.plantid " +
            " INNER JOIN `qqordermgmnt`.`codes` cdd ON cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " +
            " inner join polineitem pol on pol.id = invl.poLineId  " +
            " inner join qqordermgmnt.purchorder po on po.id = pol.poId and po.poStatus = 'ACTIVE' " +
            " left outer join partdomain pd on pd.partid = pol.partid left outer join codes cd on cd.code = pd.domain and cd.category='PART_DOMAIN' " +
            " where inv.invDate between ?1 and ?2  " +
            " group by 1,2 order by 1 desc, 2;", nativeQuery = true)
    Optional<List<Object[]>> findDomainWiseSalesReportAllData(String fromDate, String toDate);

    @Query(value = "SELECT  ifnull(cd.description,'Others') as 'label', " +
            " if(month(?1) = month(?2) and year(?1) = year (?2), DATE_FORMAT(CONVERT_TZ(inv.invDate,'GMT', cdd.description),'%Y-%m-%d'), DATE_FORMAT(CONVERT_TZ(inv.invDate,'GMT', cdd.description),'%Y-%m')) as 'xCoordinate', " +
            " sum(partprice*invoiceQty) as 'orgin' " +
            " FROM qqordermgmnt.invoicelineitem invl inner join qqordermgmnt.invoice inv on inv.id = invl.invoiceId " +
            " inner join plant pl on pl.id = inv.plantId " +
            " INNER JOIN `qqordermgmnt`.`codes` cdd ON cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " +
            " inner join polineitem pol on pol.id = invl.poLineId " +
            " inner join qqordermgmnt.purchorder po on po.id = pol.poId and po.poStatus = 'ACTIVE' " +
            " inner join address ad on ad.parentid = pl.id and ad.parentEntity = 'P' and ad.type='B' " +
            " inner join codes cd on cd.code = ad.country and cd.category='COUNTRY' " +
            " where invDate between ?1 and ?2 and cd.code in ?3 " +
            " and cd.code in ?3 group by 1,2 order by 1 desc, 2;", nativeQuery = true)
    Optional<List<Object[]>> findGeoWiseSalesReportData(String fromDate, String toDate, List<String> selectedItemIds);


    @Query(value = "SELECT  ifnull(cd.description,'Others') as 'label', " +
            " if(month(?1) = month(?2) and year(?1) = year (?2), DATE_FORMAT(CONVERT_TZ(inv.invDate,'GMT', cdd.description),'%Y-%m-%d'), " +
            " DATE_FORMAT(CONVERT_TZ(inv.invDate,'GMT', cdd.description),'%Y-%m')) as 'xCoordinate', " +
            " sum(partprice*invoiceQty) as 'orgin' " +
            " FROM qqordermgmnt.invoicelineitem invl inner join qqordermgmnt.invoice inv on inv.id = invl.invoiceId " +
            " inner join plant pl on pl.id = inv.plantId " +
            " INNER JOIN `qqordermgmnt`.`codes` cdd ON cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " +
            " inner join polineitem pol on pol.id = invl.poLineId " +
            " inner join qqordermgmnt.purchorder po on po.id = pol.poId and po.poStatus = 'ACTIVE' " +
            " inner join address ad on ad.parentid = pl.id and ad.parentEntity = 'P' and ad.type='B' " +
            " inner join codes cd on cd.code = ad.country and cd.category='COUNTRY' " +
            " where invDate between ?1 and ?2 " +
            " group by 1,2 order by 1 desc, 2;", nativeQuery = true)
    Optional<List<Object[]>> findGeoWiseSalesReportAllData(String fromDate, String toDate);

    @Query(value = "select DATE_FORMAT(CONVERT_TZ(po.poDate,'GMT', cdd.description),'%Y/%m/%d') as poDate, cmpy.name as companyName, plnt.plantCode as plantName, " +
            " po.poNumber,  pol.item as poLineItemNo, pol.partType as poLineItemType, " +
            " ifnull(prt.number,plt.description) as partNumber, prt.partRevNo,  prt.name as partDesc, " +
            " DATE_FORMAT(CONVERT_TZ(pol.deliveryDate,'GMT', cdd.description),'%Y/%m/%d') as deliveryDate, " +
            " pol.quantity as poQty, pol.partPrice," +
            " pol.id as poLineId, cmpy.id as companyId, plnt.id as plantId " +
            " FROM qqordermgmnt.purchorder po inner join qqordermgmnt.polineitem pol on po.id = pol.poId and poStatus = 'ACTIVE' " +
            " left outer join part prt on prt.id = pol.partid " +
            " INNER JOIN `qqordermgmnt`.`codes` cdd ON cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " +
            " inner join company cmpy on cmpy.id = po.companyId " +
            " inner join plant plnt on plnt.id = po.plantId " +
            " left outer join polinetool plt on plt.id = pol.poLineToolId " +
            " where po.poDate between ?1 and ?2 " +
            " order by  po.poDate, po.poNumber, po.id,pol.item ;", nativeQuery = true)
    List<SalesOrderResult> findOrderData(String fromDate, String toDate);

    @Modifying
    @Query(value = " UPDATE qqordermgmnt.purchorder " +
            " SET poStatus = ?2 " +
            " WHERE poNumber = ?1 ;", nativeQuery = true)
    void updatePOStatus(String poNumber, String Status);

    @Query(value = "select cmpy.name as companyName, plnt.plantCode as plantName, po.poNumber, " +
            " po.poRevision as poRevision, po.poStatus as poStatus, " +
            " DATE_FORMAT(CONVERT_TZ(po.poDate,'GMT', cdd.description), '%Y-%m-%d') as poDate, " +
            " pol.partType as partType, pol.item as poItem, IFNULL(prt.name, plt.description) as partName, " +
            " IFNULL(prt.number, plt.description) as partNumber, prt.partRevNo, DATE_FORMAT(CONVERT_TZ(pol.deliveryDate,'GMT', cdd.description), '%Y-%m-%d') as deliveryDate,  " +
            " sum(pol.quantity) as poQty, pol.id, cmpy.id as companyId, plnt.id as plantId " +
            " FROM qqordermgmnt.purchorder po inner join qqordermgmnt.polineitem pol on po.id = pol.poId  " +
            " left outer join part prt on prt.id = pol.partid " +
            " left outer join polinetool plt on plt.id = pol.poLineToolId " +
            " INNER JOIN `qqordermgmnt`.`codes` cdd ON cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " +
            " inner join company cmpy on cmpy.id = po.companyId " +
            " inner join plant plnt on plnt.id = po.plantId " +
            " where po.poDate between ?1 and ?2 and poStatus = 'ACTIVE' " +
            " group by pol.id, po.poNumber, po.companyId, po.plantId, po.poDate, poItem, partNumber, prt.partRevNo, pol.deliveryDate, cdd.description " +
            " order by pol.deliveryDate ;", nativeQuery = true)
    List<PendingOrderResult> findPendingOrders(String fromDate, String toDate);

    @Query(value = "SELECT ifnull(count(distinct poNumber), 0) as totalPOCount FROM `qqordermgmnt`.`purchorder`; ",
            nativeQuery = true)
    Integer getTotalPOCount();

    @Query(value = "SELECT concat(po.poNumber, pl.item) as poLineNumber, Sum(pl.quantity) as poQty FROM qqordermgmnt.polineitem as pl " +
            "  inner join qqordermgmnt.purchorder as po on pl.poid = po.id  " +
            "  where po.poDate between ?1 and ?2 and po.poStatus = 'ACTIVE' group by poLineNumber; ",
            nativeQuery = true)
    Optional<List<Object[]>> findAllActivePo(String fromDate, String toDate);


}
