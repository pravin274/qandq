package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.PartCustomerRequirement;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface PartCustomerRequirementRepository extends CrudRepository<PartCustomerRequirement, Integer> {
     Optional<List<PartCustomerRequirement>> findPartCustomerRequirementByPartId(Integer partId);
}
