package com.qqs.posvcs.model;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;

@Entity
@Table(name = "polineitemxcurrentstatus", schema = "qqordermgmnt", catalog = "")

public class PoLineItemxCurrentStatus {
    private int id;
    private String type;
    private int poLineItemId;
    private String currentStatus;
    private Date date;
    private String status;
    private Timestamp createdDt;
    private Timestamp modifiedDt;
    private Integer createdBy;
    private Integer modifiedBy;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "type")
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


    @Column(name = "lineItemId")
    public int getPoLineItemId() {
        return poLineItemId;
    }

    public void setPoLineItemId(int poLineItemId) {
        this.poLineItemId = poLineItemId;
    }

    @Column(name = "currentStatus")
    public String getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    @Column(name = "date")
    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Column(name = "status")
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy(Integer createdBy) {
        return this.createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }


    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("PoLineItem{");
        sb.append("id=").append(id);
        sb.append(", type=").append(type);
        sb.append(", poLineItemId=").append(poLineItemId);
        sb.append(", currentStatus=").append(currentStatus);
        sb.append(", date=").append(date);
        sb.append(", createdDt=").append(createdDt);
        sb.append(", modifiedDt=").append(modifiedDt);
        sb.append(", createdBy=").append(createdBy);
        sb.append(", modifiedBy=").append(modifiedBy);

        sb.append('}');
        return sb.toString();
    }
}
