package com.qqs.posvcs.service;

import com.qqs.posvcs.model.Address;
import com.qqs.posvcs.repository.AddressRepository;
import com.qqs.posvcs.repository.CitiesRepository;
import com.qqs.posvcs.repository.CountriesRepository;
import com.qqs.posvcs.repository.StatesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Component
public class AddressDataService {
    @Autowired
    private AddressRepository repository;

    @Autowired
    private CountriesRepository countriesRepository;

    @Autowired
    private StatesRepository statesRepository;

    @Autowired
    private CitiesRepository citiesRepository;

    public Optional<Address> getAddressById(Integer id) {
        return repository.findById(id);
    }

    public Iterable<Address> findAddressByIds(List<Integer> ids) {
        return repository.findAllById(ids);
    }

    public Optional<List<Address>> findAddressesByCompany(Integer companyId) {
        return repository.findAddressesByCompany(companyId);
    }

    public Optional<List<Address>> findAddressesByPlant(Integer plantId) {
        return repository.findAddressesByPlant(plantId);
    }

    public Optional<String> findCountryNameById(Integer plantId) {
        return countriesRepository.findCountryNameById(plantId);
    }

    public Optional<String> findStateNameById(Integer plantId) {
        return statesRepository.findStateNameById(plantId);
    }

    public Optional<String> findCityNameById(Integer plantId) {
        return citiesRepository.findCityNameById(plantId);
    }

    public Optional<List<Address>> findAddressesByPeople(Integer peopleId) {
        return repository.findAddressesByPeople(peopleId);
    }

    public Optional<List<Address>> findAddressesForParentType(String parentType, Integer parentId) {
        return repository.findAddressesByParent(parentType, parentId);
    }

    @Transactional
    public Address saveAddress(Address item) {
        return repository.save(item);
    }
}
