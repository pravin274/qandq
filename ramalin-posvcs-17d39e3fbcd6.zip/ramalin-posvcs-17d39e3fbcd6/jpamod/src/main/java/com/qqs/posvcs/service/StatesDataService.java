package com.qqs.posvcs.service;

import com.qqs.posvcs.model.Address;
import com.qqs.posvcs.model.States;
import com.qqs.posvcs.repository.StatesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Component
public class StatesDataService {

    @Autowired
    private StatesRepository statesRepository;

    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<States> statesUtils = new DataServiceUtils<>();

    public Optional<States> getStateById(Integer id) {
        return statesRepository.findById(id);
    }

    public Optional<List<States>> findStatesByCountryId(Integer countryId) {
        return statesRepository.findStatesByCountryId(countryId);
    }

    public Optional<List<States>> searchStates(List<SearchCriteria> params) {
        List<States> result = statesUtils.createPredicate(entityManager, params, States.class);
        Optional<List<States>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public Iterable<States> getAllStates() {
        return statesRepository.findAll();
    }

    @Transactional
    public States saveState(States item) {
        return statesRepository.save(item);
    }

}
