package com.qqs.posvcs.model;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "part", schema = "qqordermgmnt", catalog = "")
public class Part {
    private int id;
    private String name;
    private Integer companyId;
    private String number;
    private String partRevNo;
    private Timestamp partRevDt;
    private Integer partRevOrder;
    private String drawingNo;
    private String drawingRevNo;
    private Timestamp drawingRevDt;
    private String qqsCode;
    private String qqsRevNo;
    private Timestamp qqsRevDt;
    private String projectName;
    private String category;
    private String materialSpec;
    private Double castingWt;
    private String castingWtUnit;
    private Integer rfqVolume;
    private Integer mbq;
    private String uom;
    private String resourceInd;
    private String jobType;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    @Column(name = "companyId")
    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    @Column(name = "number")
    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    @Column(name = "drawingNo")
    public String getDrawingNo() {
        return drawingNo;
    }

    public void setDrawingNo(String drawingNo) {
        this.drawingNo = drawingNo;
    }

    @Column(name = "QQSCode")
    public String getQqsCode() {
        return qqsCode;
    }

    public void setQqsCode(String qqsCode) {
        this.qqsCode = qqsCode;
    }

    @Column(name = "projectName")
    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    @Column(name = "category")
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    @Column(name = "materialSpec")
    public String getMaterialSpec() {
        return materialSpec;
    }

    public void setMaterialSpec(String materialSpec) {
        this.materialSpec = materialSpec;
    }

    @Column(name = "castingWt")
    public Double getCastingWt() {
        return castingWt;
    }

    public void setCastingWt(Double castingWt) {
        this.castingWt = castingWt;
    }

    @Column(name = "castingWtUnit")
    public String getCastingWtUnit() {
        return castingWtUnit;
    }

    public void setCastingWtUnit(String castingWtUnit) {
        this.castingWtUnit = castingWtUnit;
    }

    @Column(name = "rfqVolume")
    public Integer getRfqVolume() {
        return rfqVolume;
    }

    public void setRfqVolume(Integer rfqVolume) {
        this.rfqVolume = rfqVolume;
    }

    @Column(name = "mbq")
    public Integer getMbq() {
        return mbq;
    }

    public void setMbq(Integer mbq) {
        this.mbq = mbq;
    }

    @Column(name = "uom")
    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    @Column(name = "resourceInd")
    public String getResourceInd() {
        return resourceInd;
    }

    public void setResourceInd(String resourceInd) {
        this.resourceInd = resourceInd;
    }

    @Column(name = "jobType")
    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    @Basic
    @Column(name = "partRevNo")
    public String getPartRevNo() {
        return partRevNo;
    }

    public void setPartRevNo(String partRevNo) {
        this.partRevNo = partRevNo;
    }

    @Basic
    @Column(name = "partRevDt")
    public Timestamp getPartRevDt() {
        return partRevDt;
    }

    public void setPartRevDt(Timestamp partRevDt) {
        this.partRevDt = partRevDt;
    }

    @Basic
    @Column(name = "partRevOrder")
    public Integer getPartRevOrder() {
        return partRevOrder;
    }

    public void setPartRevOrder(Integer partRevOrder) {
        this.partRevOrder = partRevOrder;
    }

    @Basic
    @Column(name = "drawingRevNo")
    public String getDrawingRevNo() {
        return drawingRevNo;
    }

    public void setDrawingRevNo(String drawingRevNo) {
        this.drawingRevNo = drawingRevNo;
    }

    @Basic
    @Column(name = "drawingRevDt")
    public Timestamp getDrawingRevDt() {
        return drawingRevDt;
    }

    public void setDrawingRevDt(Timestamp drawingRevDt) {
        this.drawingRevDt = drawingRevDt;
    }

    @Basic
    @Column(name = "QQSRevNo")
    public String getQqsRevNo() {
        return qqsRevNo;
    }

    public void setQqsRevNo(String qqsRevNo) {
        this.qqsRevNo = qqsRevNo;
    }

    @Basic
    @Column(name = "QQSRevDt")
    public Timestamp getQqsRevDt() {
        return qqsRevDt;
    }

    public void setQqsRevDt(Timestamp qqsRevDt) {
        this.qqsRevDt = qqsRevDt;
    }


    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        Part part = (Part) o;

        return new EqualsBuilder()
                .append(id, part.id)
                .append(name, part.name)
                .append(name, part.companyId)
                .append(number, part.number)
                .append(partRevNo, part.partRevNo)
                .append(partRevDt, part.partRevDt)
                .append(partRevOrder, part.partRevOrder)
                .append(drawingNo, part.drawingNo)
                .append(drawingRevNo, part.drawingRevNo)
                .append(drawingRevDt, part.drawingRevDt)
                .append(qqsCode, part.qqsCode)
                .append(qqsRevNo, part.qqsRevNo)
                .append(qqsRevDt, part.qqsRevDt)
                .append(projectName, part.projectName)
                .append(category, part.category)
                .append(materialSpec, part.materialSpec)
                .append(castingWt, part.castingWt)
                .append(castingWtUnit, part.castingWtUnit)
                .append(rfqVolume, part.rfqVolume)
                .append(mbq, part.mbq)
                .append(uom, part.uom)
                .append(resourceInd, part.resourceInd)
                .append(jobType, part.jobType)
                .append(createdBy, part.createdBy)
                .append(createdDt, part.createdDt)
                .append(modifiedBy, part.modifiedBy)
                .append(modifiedDt, part.modifiedDt)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(id)
                .append(name)
                .append(companyId)
                .append(number)
                .append(partRevNo)
                .append(partRevDt)
                .append(partRevOrder)
                .append(drawingNo)
                .append(drawingRevNo)
                .append(drawingRevDt)
                .append(qqsCode)
                .append(qqsRevNo)
                .append(qqsRevDt)
                .append(projectName)
                .append(category)
                .append(materialSpec)
                .append(castingWt)
                .append(castingWtUnit)
                .append(rfqVolume)
                .append(mbq)
                .append(uom)
                .append(resourceInd)
                .append(jobType)
                .append(createdBy)
                .append(createdDt)
                .append(modifiedBy)
                .append(modifiedDt)
                .toHashCode();
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Part{");
        sb.append("id=").append(id);
        sb.append(", name='").append(name).append('\'');
        sb.append(", companyId='").append(companyId).append('\'');
        sb.append(", number='").append(number).append('\'');
        sb.append(", partRevNo='").append(partRevNo).append('\'');
        sb.append(", partRevDt=").append(partRevDt);
        sb.append(", partRevOrder=").append(partRevOrder);
        sb.append(", drawingNo='").append(drawingNo).append('\'');
        sb.append(", drawingRevNo='").append(drawingRevNo).append('\'');
        sb.append(", drawingRevDt=").append(drawingRevDt);
        sb.append(", qqsCode='").append(qqsCode).append('\'');
        sb.append(", qqsRevNo='").append(qqsRevNo).append('\'');
        sb.append(", qqsRevDt=").append(qqsRevDt);
        sb.append(", projectName='").append(projectName).append('\'');
        sb.append(", category='").append(category).append('\'');
        sb.append(", materialSpec='").append(materialSpec).append('\'');
        sb.append(", castingWt=").append(castingWt);
        sb.append(", castingWtUnit='").append(castingWtUnit).append('\'');
        sb.append(", rfqVolume=").append(rfqVolume);
        sb.append(", mbq=").append(mbq);
        sb.append(", uom='").append(uom).append('\'');
        sb.append(", resourceInd='").append(resourceInd).append('\'');
        sb.append(", jobType='").append(jobType).append('\'');
        sb.append(", createdBy=").append(createdBy);
        sb.append(", createdDt=").append(createdDt);
        sb.append(", modifiedBy=").append(modifiedBy);
        sb.append(", modifiedDt=").append(modifiedDt);
        sb.append('}');
        return sb.toString();
    }
}
