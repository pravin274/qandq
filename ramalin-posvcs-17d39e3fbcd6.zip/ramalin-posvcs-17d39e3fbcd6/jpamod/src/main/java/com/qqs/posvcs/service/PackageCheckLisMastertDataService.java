package com.qqs.posvcs.service;

import com.qqs.posvcs.model.PackCheckListMaster;
import com.qqs.posvcs.model.PkgCheckList;
import com.qqs.posvcs.repository.PackageCheckListMasterRepository;
import com.qqs.posvcs.repository.PkgCheckListRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Component
public class PackageCheckLisMastertDataService {


    @Autowired
    private PackageCheckListMasterRepository packageCheckListMasterRepository;

    @Autowired
    private PkgCheckListRepository pkgCheckListRepository;

    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<PackCheckListMaster> utils = new DataServiceUtils<>();


    public Optional<List<PkgCheckList>> findPkgCheckListByPkg(Integer packageId) {
        return pkgCheckListRepository.findCheckListForPackage(packageId);
    }

    public Optional<List<PkgCheckList>> findPkgCheckListByPkgAndCategory(Integer packageId, String code) {
        return pkgCheckListRepository.findCheckListForCategory(packageId, code);
    }

    public Iterable<PkgCheckList> saveAllPkgCheckList(Collection<PkgCheckList> item) {
        return pkgCheckListRepository.saveAll(item);
    }

    public Optional<PkgCheckList> getPkgCheckListById(Integer id) {
        return pkgCheckListRepository.findById(id);
    }

    public PackCheckListMaster getPackCheckListMasterById(Integer id) {
        return packageCheckListMasterRepository.findAllById(id);
    }

    public Optional<List<PackCheckListMaster>> searchPackCheckListMaster(List<SearchCriteria> params) {
        List<PackCheckListMaster> result = utils.createPredicate(entityManager, params, PackCheckListMaster.class);
        Optional<List<PackCheckListMaster>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    @Transactional
    public PackCheckListMaster savePackCheckListMaster(PackCheckListMaster item) {
        return packageCheckListMasterRepository.save(item);
    }

    @Transactional
    public PkgCheckList savePkgCheckList(PkgCheckList item) {
        return pkgCheckListRepository.save(item);
    }
}
