package com.qqs.posvcs.model;


import javax.persistence.*;

import java.sql.Timestamp;

@Entity
@Table(name = "invoicelineitem", schema = "qqordermgmnt", catalog = "")
public class InvoiceLineItem {

    private int id;
    private Integer invoiceId;
    private Integer poLineId;
    private Double invoiceQty;
    private String toolPaymentDescription;
    private String currentStatus;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "invoiceId")
    public Integer getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Integer invoiceId) {
        this.invoiceId = invoiceId;
    }

    @Column(name = "poLineId")
    public Integer getPoLineId() {
        return poLineId;
    }

    public void setPoLineId(Integer poLineId) {
        this.poLineId = poLineId;
    }

    @Column(name = "invoiceQty")
    public Double getInvoiceQty() {
        return invoiceQty;
    }

    public void setInvoiceQty(Double invoiceQty) {
        this.invoiceQty = invoiceQty;
    }

    @Column(name = "toolPaymentDescription")
    public String getToolPaymentDescription() {
        return toolPaymentDescription;
    }

    public void setToolPaymentDescription(String toolPaymentDescription) {
        this.toolPaymentDescription = toolPaymentDescription;
    }

    @Column(name = "currentStatus")
    public String getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        InvoiceLineItem InvoiceLineItem = (InvoiceLineItem) o;

        if (id != InvoiceLineItem.id) return false;
        if (invoiceId != InvoiceLineItem.invoiceId) return false;
        if (poLineId != null ? !InvoiceLineItem.equals(InvoiceLineItem.poLineId) : InvoiceLineItem.poLineId != null) return false;
        if (invoiceQty != null ? !InvoiceLineItem.equals(InvoiceLineItem.invoiceQty) : InvoiceLineItem.invoiceQty != null) return false;
        if (currentStatus != null ? !InvoiceLineItem.equals(InvoiceLineItem.currentStatus) : InvoiceLineItem.currentStatus != null) return false;
        if (createdBy != null ? !createdBy.equals(InvoiceLineItem.createdBy) : InvoiceLineItem.createdBy != null) return false;
        if (createdDt != null ? !createdDt.equals(InvoiceLineItem.createdDt) : InvoiceLineItem.createdDt != null) return false;
        if (modifiedBy != null ? !modifiedBy.equals(InvoiceLineItem.modifiedBy) : InvoiceLineItem.modifiedBy != null) return false;
        if (modifiedDt != null ? !modifiedDt.equals(InvoiceLineItem.modifiedDt) : InvoiceLineItem.modifiedDt != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (invoiceId != null ? invoiceId.hashCode() : 0);
        result = 31 * result + poLineId;
        result = 31 * result + (invoiceQty != null ? invoiceQty.hashCode() : 0);
        result = 31 * result + (currentStatus != null ? currentStatus.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDt != null ? createdDt.hashCode() : 0);
        result = 31 * result + (modifiedBy != null ? modifiedBy.hashCode() : 0);
        result = 31 * result + (modifiedDt != null ? modifiedDt.hashCode() : 0);
        return result;
    }
}
