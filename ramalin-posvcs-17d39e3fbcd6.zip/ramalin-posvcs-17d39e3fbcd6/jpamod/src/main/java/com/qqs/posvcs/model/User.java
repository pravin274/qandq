package com.qqs.posvcs.model;


public interface User {
    int getId();
    String getFirstName();
    String getLastName();
    String getUserName();
}
