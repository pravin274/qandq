package com.qqs.posvcs.model;

public interface SalesOrderResult {
    String getPoDate();
    String getCompanyName();
    String getPlantName();
    String getPoNumber();
    String getPoLineItemNo();
    String getPoLineItemType();
    String getPartNumber();
    String getPartRevNo();
    String getPartDesc();
    String getDeliveryDate();
    Integer getPoQty();
    Double getPartPrice();
    String getInvoiceNo();
    String getInvoiceDate();
    int getPoLineId();
    int getInvoiceId();
    int getInvoiceLineId();
    int getCompanyId();
    int getPlantId();
}
