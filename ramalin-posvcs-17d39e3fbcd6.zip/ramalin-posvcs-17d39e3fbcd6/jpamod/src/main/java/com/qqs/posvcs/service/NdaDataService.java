package com.qqs.posvcs.service;

import com.qqs.posvcs.model.NdaForm;
import com.qqs.posvcs.repository.NdaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Component
public class NdaDataService {

    @Autowired
    private NdaRepository ndaRepository;

    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<NdaForm> utils = new DataServiceUtils<>();


    @Transactional
    public NdaForm saveNda(NdaForm item) {
        return ndaRepository.save(item);
    }


    public Optional<NdaForm> getNdaById(Integer id) {
        return ndaRepository.findById(id);
    }

    public Iterable<NdaForm> getAllNda() {
        return ndaRepository.findAll();
    }

    public Optional<List<NdaForm>> searchNda(List<SearchCriteria> params) {
        List<NdaForm> result = utils.createPredicate(entityManager, params, NdaForm.class);
        Optional<List<NdaForm>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

}
