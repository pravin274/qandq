package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.NdaForm;
import org.springframework.data.repository.CrudRepository;

public interface NdaRepository extends CrudRepository<NdaForm, Integer> {
}
