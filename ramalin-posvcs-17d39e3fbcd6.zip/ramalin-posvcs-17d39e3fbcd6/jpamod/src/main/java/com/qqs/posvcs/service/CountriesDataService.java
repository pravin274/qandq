package com.qqs.posvcs.service;

import com.qqs.posvcs.model.Countries;
import com.qqs.posvcs.repository.CountriesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Component
public class CountriesDataService {

    @Autowired
    private CountriesRepository countriesRepository;

    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<Countries> countriesUtils = new DataServiceUtils<>();

    public Optional<Countries> getCountryById(Integer id) {
        return countriesRepository.findById(id);
    }

    public Optional<List<Countries>> searchCountries(List<SearchCriteria> params) {
        List<Countries> result = countriesUtils.createPredicate(entityManager, params, Countries.class);
        Optional<List<Countries>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public Iterable<Countries> getAllCountries() {
        return countriesRepository.findAll();
    }

    @Transactional
    public Countries saveCountry(Countries item) {
        return countriesRepository.save(item);
    }

}
