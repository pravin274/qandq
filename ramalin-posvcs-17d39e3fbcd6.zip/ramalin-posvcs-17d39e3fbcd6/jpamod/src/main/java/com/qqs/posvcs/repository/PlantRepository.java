package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.Plant;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface PlantRepository extends CrudRepository<Plant, Integer> {
    Optional<List<Plant>> findPlantByCompanyId(Integer companyId);
}
