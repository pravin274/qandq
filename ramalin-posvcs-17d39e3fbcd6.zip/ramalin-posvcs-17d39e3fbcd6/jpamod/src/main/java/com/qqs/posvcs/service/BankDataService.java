package com.qqs.posvcs.service;

import com.qqs.posvcs.model.Bank;
import com.qqs.posvcs.repository.BankRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;

@Component
public class BankDataService extends BaseDataService<Bank>  {

    @Autowired
    private BankRepository repository;
    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<Bank> bankUtils = new DataServiceUtils<>();

    @Override
    protected CrudRepository<Bank, Integer> getRepo() {
        return repository;
    }

    @Override
    protected EntityManager getEntityManager() {
        return entityManager;
    }

    @Override
    protected Class<Bank> getModelClass() {
        return Bank.class;
    }

    @Override
    protected DataServiceUtils<Bank> getSearchUtils() {
        return bankUtils;
    }

    @Transactional
    protected Bank saveBank(Bank bank) {
        return repository.save(bank);
    }
}
