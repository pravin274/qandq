package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.InvoiceStatusData;
import org.springframework.data.jpa.repository.Query;
import com.qqs.posvcs.model.InvoiceStatus;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface InvoiceStatusRepository extends CrudRepository<InvoiceStatus, Integer> {

    Optional<List<InvoiceStatus>> findAllByInvoiceId(Integer invoiceId);
//    Optional<List<InvoiceStatus>> findAllByInvoiceIdIn(List<Integer> invoiceId);

    @Query(value = "select inv.id as invoiceId, cd.code as invoiceStatus, invs.statusDate as statusDate, " +
            " invs.attribute1 as attribute1, invs.attribute2 as attribute2, invs.attribute3 as attribute3, " +
            " invs.attribute4 as attribute4, invs.remarks as remarks " +
            " from invoice inv inner join codes cd on cd.category = 'INVOICE_STATUS' and inv.id in ?1 " +
            " left outer join invoicestatus invs on inv.id = invs.invoiceId and invs.invoiceStatus = cd.code " +
            " order by inv.id, cd.code;" , nativeQuery = true)
    List<InvoiceStatusData> findAllByInvoiceIdIn(List<Integer> invoiceId);


}
