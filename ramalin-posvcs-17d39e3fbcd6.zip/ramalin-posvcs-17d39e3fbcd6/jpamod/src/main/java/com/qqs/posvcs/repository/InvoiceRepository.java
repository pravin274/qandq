package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.Invoice;
import com.qqs.posvcs.model.InvoiceReportData;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface InvoiceRepository extends CrudRepository<Invoice, Integer> {

    @Query(value = "SELECT invl.invoiceId, sum(invl.invoiceQty * pol.partPrice) " +
            " FROM qqordermgmnt.invoicelineitem invl, polineitem pol " +
            " where invl.poLineId = pol.id and invl.invoiceId in ?1 group by invl.invoiceId;", nativeQuery = true)
    Optional<List<Object[]>> getInvoiceValue(List<Integer> invoiceIds);

    @Query(value = "SELECT inv.id as invoiceId, inv.serialNo as invoiceNumber, " +
            " DATE_FORMAT(CONVERT_TZ(inv.invDate,'GMT', cdd.description) ,'%Y/%m/%d') as invoiceDate, " +
            " cm.name as companyName, pl.plantCode as plantName, sum(ilt.invoiceQty * pli.partPrice) as totalInvoiceValue, " +
            " cm.id as companyId, pl.id as plantId, inv.invoiceStatus as invoiceStatus " +
            " FROM qqordermgmnt.invoice inv, qqordermgmnt.invoicelineitem ilt, qqordermgmnt.polineitem pli, " +
            " qqordermgmnt.plant pl, qqordermgmnt.company cm, `qqordermgmnt`.`codes` cdd " +
            " where pl.id = inv.plantId and cm.id = pl.companyId and ilt.invoiceId = inv.id and pli.id = ilt.poLineId " +
            " and cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " +
            " and (inv.invoiceStatus != 'CAN' or inv.invoiceStatus is null) and inv.invDate between ?1 and ?2 " +
            " group by inv.id, inv.serialNo,inv.invDate, cm.name, pl.plantCode, cm.id, pl.id, inv.invoicestatus " +
            " order by inv.serialNo;" , nativeQuery = true)
    List<InvoiceReportData> findInvoiceReportData(String fromDate, String toDate);


    @Query(value = "select DISTINCT inv.* " +
            " from invoice inv, invoicelineitem ili, polineitem pli, purchorder po " +
            " where inv.id = ili.invoiceId and ili.poLineId = pli.id and po.id = pli.poid " +
            " and po.poNumber = ?1 ;" , nativeQuery = true)
    List<Invoice> findInvoiceByPoNumber(String poNumber);


}
