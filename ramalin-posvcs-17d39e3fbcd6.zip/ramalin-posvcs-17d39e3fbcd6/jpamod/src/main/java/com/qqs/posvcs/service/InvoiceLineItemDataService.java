package com.qqs.posvcs.service;

import com.qqs.posvcs.model.InvoiceLineItem;
import com.qqs.posvcs.repository.InvoiceLineItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.Collection;
import java.util.List;
import java.util.Optional;


@Component
// extends BaseDataService<InvoiceLineItem>
public class InvoiceLineItemDataService  {

    @Autowired
    private InvoiceLineItemRepository repository;

    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<InvoiceLineItem> invoiceUtils = new DataServiceUtils<>();

    protected CrudRepository<InvoiceLineItem, Integer> getRepo() {
        return repository;
    }

    public Iterable<InvoiceLineItem> getAllInvoiceLineItemById(Iterable<Integer> ids) {
        return repository.findAllById(ids);
    }

    public Iterable<InvoiceLineItem> getAllInvoiceLineItemByInvoiceId(Integer invoiceId) {
        return repository.findAllByInvoiceId(invoiceId);
    }

    public Optional<List<Object[]>> getShippedQtyByPOLineItems(Iterable<Integer> poLineItemIds, Integer invoiceId) {
        return repository.findShippedQtyByPoLineItems(poLineItemIds, invoiceId);
    }

    public Optional<List<Object[]>> getShippedQtyByPoNumbers(List<String> poNumbers) {
        return repository.findShippedQtyByPoNumbers(poNumbers);
    }

    @Transactional
    public InvoiceLineItem saveInvoiceLineItem(InvoiceLineItem item) {
        return repository.save(item);
    }

    @Transactional
    public Iterable<InvoiceLineItem> saveInvoiceLineItems(Collection<InvoiceLineItem> items) {
        return repository.saveAll(items);
    }
}
