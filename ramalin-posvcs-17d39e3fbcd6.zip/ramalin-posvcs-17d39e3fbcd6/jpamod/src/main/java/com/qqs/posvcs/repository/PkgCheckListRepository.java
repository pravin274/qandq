package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.PkgCheckList;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface PkgCheckListRepository extends CrudRepository<PkgCheckList, Integer> {
    @Query(value = "select * FROM pkgchecklist WHERE pkgId = ?1 AND code = ?2", nativeQuery = true)
    Optional<List<PkgCheckList>> findCheckListForCategory(Integer pkgId, String category);

    @Query(value = "select * FROM pkgchecklist WHERE pkgId = ?1", nativeQuery = true)
    Optional<List<PkgCheckList>> findCheckListForPackage(Integer pkgId);
}
