package com.qqs.posvcs.model;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "plant", schema = "qqordermgmnt", catalog = "")
public class Plant {
    private int id;
    private int companyId;
    private String plantCode;
    private String description;
    private String vendorCode;
    private String domesticInd;
    private String currency;
    private String dutyStruct;
    private String taxId;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "companyId")
    public int getCompanyId() {
        return companyId;
    }

    public void setCompanyId(int companyId) {
        this.companyId = companyId;
    }

    @Column(name = "plantCode")
    public String getPlantCode() {
        return plantCode;
    }

    public void setPlantCode(String plantCode) {
        this.plantCode = plantCode;
    }

    @Column(name = "description")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Column(name = "vendorCode")
    public String getVendorCode() {
        return vendorCode;
    }

    public void setVendorCode(String vendorCode) {
        this.vendorCode = vendorCode;
    }

    @Column(name = "domesticInd")
    public String getDomesticInd() {
        return domesticInd;
    }

    public void setDomesticInd(String domesticInd) {
        this.domesticInd = domesticInd;
    }

    @Column(name = "currency")
    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @Column(name = "dutyStruct")
    public String getDutyStruct() {
        return dutyStruct;
    }

    public void setDutyStruct(String dutyStruct) {
        this.dutyStruct = dutyStruct;
    }

    @Column(name = "taxId")
    public String getTaxId() {
        return taxId;
    }

    public void setTaxId(String taxId) {
        this.taxId = taxId;
    }

    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Plant plant = (Plant) o;

        if (id != plant.id) return false;
        if (companyId != plant.companyId) return false;
        if (plantCode != null ? !plantCode.equals(plant.plantCode) : plant.plantCode != null) return false;
        if (description != null ? !description.equals(plant.description) : plant.description != null) return false;
        if (vendorCode != null ? !vendorCode.equals(plant.vendorCode) : plant.vendorCode != null) return false;
        if (domesticInd != null ? !domesticInd.equals(plant.domesticInd) : plant.domesticInd != null) return false;
        if (currency != null ? !currency.equals(plant.currency) : plant.currency != null) return false;
        if (dutyStruct != null ? !dutyStruct.equals(plant.dutyStruct) : plant.dutyStruct != null) return false;
        if (taxId != null ? !taxId.equals(plant.taxId) : plant.taxId != null) return false;
        if (createdBy != null ? !createdBy.equals(plant.createdBy) : plant.createdBy != null) return false;
        if (createdDt != null ? !createdDt.equals(plant.createdDt) : plant.createdDt != null) return false;
        if (modifiedBy != null ? !modifiedBy.equals(plant.modifiedBy) : plant.modifiedBy != null) return false;
        if (modifiedDt != null ? !modifiedDt.equals(plant.modifiedDt) : plant.modifiedDt != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + companyId;
        result = 31 * result + (plantCode != null ? plantCode.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (vendorCode != null ? vendorCode.hashCode() : 0);
        result = 31 * result + (domesticInd != null ? domesticInd.hashCode() : 0);
        result = 31 * result + (currency != null ? currency.hashCode() : 0);
        result = 31 * result + (dutyStruct != null ? dutyStruct.hashCode() : 0);
        result = 31 * result + (taxId != null ? taxId.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDt != null ? createdDt.hashCode() : 0);
        result = 31 * result + (modifiedBy != null ? modifiedBy.hashCode() : 0);
        result = 31 * result + (modifiedDt != null ? modifiedDt.hashCode() : 0);
        return result;
    }
}
