package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.AtsContentSheet;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface AtsContentSheetRepository extends CrudRepository<AtsContentSheet, Integer> {

    @Query(value = "select * FROM atscontentsheet WHERE atsId = ?1", nativeQuery = true)
    Optional<List<AtsContentSheet>> findContetntListForAts(Integer pkgId);
}
