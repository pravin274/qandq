package com.qqs.posvcs;

public class DataServiceException extends Exception {
    public DataServiceException(String msg) {
        super(msg);
    }
}
