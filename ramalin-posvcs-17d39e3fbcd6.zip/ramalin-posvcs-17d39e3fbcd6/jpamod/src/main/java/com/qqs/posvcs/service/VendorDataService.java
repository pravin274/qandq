package com.qqs.posvcs.service;

import com.qqs.posvcs.model.Vendor;
import com.qqs.posvcs.repository.VendorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Component
public class VendorDataService {
    @Autowired
    private VendorRepository repository;
    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<Vendor> utils = new DataServiceUtils<>();


    public Optional<Vendor> getVendorById(Integer id) {
        return repository.findById(id);
    }

    public Optional<List<Vendor>> searchClient(List<SearchCriteria> params) {
        List<Vendor> result = utils.createPredicate(entityManager, params, Vendor.class);
        Optional<List<Vendor>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public Iterable<Vendor> getAllVendor() {
        Iterable<Vendor> result = repository.findAll();
        return result;
    }

    @Transactional
    public Vendor saveVendor(Vendor item) {
        return repository.save(item);
    }
}
