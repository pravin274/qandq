package com.qqs.posvcs.model;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "purchorder", schema = "qqordermgmnt")
public class PurchOrder {
    private int id;
    private Integer companyId;
    private Integer plantId;
    private String poNumber;
    private Timestamp poDate;
    private String department;
    private Integer buyer;
    private Integer qqRespPerson;
    private String vendorCode;
    private Integer dvryAddrId;
    private Integer dvryTermsId;
    private Integer pymntTermsId;
    private Integer billToAddrId;
    private String poRevision;
    private String poStatus;
    private String poFileName;
    private Timestamp createdDt;
    private Timestamp modifiedDt;
    private Integer createdBy;
    private Integer modifiedBy;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "companyId")
    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    @Column(name = "plantId")
    public Integer getPlantId() {
        return plantId;
    }

    public void setPlantId(Integer plantId) {
        this.plantId = plantId;
    }

    @Column(name = "poNumber")
    public String getPoNumber() {
        return poNumber;
    }

    public void setPoNumber(String poNumber) {
        this.poNumber = poNumber;
    }

    @Column(name = "poDate")
    public Timestamp getPoDate() {
        return poDate;
    }

    public void setPoDate(Timestamp poDate) {
        this.poDate = poDate;
    }

    @Column(name = "department")
    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    @Column(name = "buyer")
    public Integer getBuyer() {
        return buyer;
    }

    public void setBuyer(Integer coRespPerson) {
        this.buyer = coRespPerson;
    }

    @Column(name = "qqRespPerson")
    public Integer getQqRespPerson() {
        return qqRespPerson;
    }

    public void setQqRespPerson(Integer qqRespPerson) {
        this.qqRespPerson = qqRespPerson;
    }

    @Column(name = "vendorCode")
    public String getVendorCode() {
        return vendorCode;
    }

    public void setVendorCode(String vendorCode) {
        this.vendorCode = vendorCode;
    }

    @Column(name = "dvryAddrId")
    public Integer getDvryAddrId() {
        return dvryAddrId;
    }

    public void setDvryAddrId(Integer dvryAddrId) {
        this.dvryAddrId = dvryAddrId;
    }

    @Column(name = "dvryTermsId")
    public Integer getDvryTermsId() {
        return dvryTermsId;
    }

    public void setDvryTermsId(Integer dvryTermsId) {
        this.dvryTermsId = dvryTermsId;
    }

    @Column(name = "pymntTermsId")
    public Integer getPymntTermsId() {
        return pymntTermsId;
    }

    public void setPymntTermsId(Integer pymntTermsId) {
        this.pymntTermsId = pymntTermsId;
    }

    @Column(name = "billToAddrId")
    public Integer getBillToAddrId() {
        return billToAddrId;
    }

    public void setBillToAddrId(Integer billToAddrId) {
        this.billToAddrId = billToAddrId;
    }

    @Column(name = "poRevision")
    public String getPoRevision() {
        return poRevision;
    }

    public void setPoRevision(String poRevision) {
        this.poRevision = poRevision;
    }

    @Column(name = "poStatus")
    public String getPoStatus() {
        return poStatus;
    }

    public void setPoStatus(String poStatus) {
        this.poStatus = poStatus;
    }

    @Column(name = "poFileName")
    public String getPoFileName() {
        return poFileName;
    }

    public void setPoFileName(String poFileName) {
        this.poFileName = poFileName;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("PurchOrder{");
        sb.append("id=").append(id);
        sb.append(", companyId=").append(companyId);
        sb.append(", plantId=").append(plantId);
        sb.append(", poNumber='").append(poNumber).append('\'');
        sb.append(", poDate=").append(poDate);
        sb.append(", department='").append(department).append('\'');
        sb.append(", buyer=").append(buyer);
        sb.append(", qqRespPerson=").append(qqRespPerson);
        sb.append(", vendorCode=").append(vendorCode);
        sb.append(", dvryAddrId=").append(dvryAddrId);
        sb.append(", dvryTermsId='").append(dvryTermsId).append('\'');
        sb.append(", pymntTermsId='").append(pymntTermsId).append('\'');
        sb.append(", billToAddrId=").append(billToAddrId);
        sb.append(", poFileName").append(poFileName);
        sb.append(", createdDt=").append(createdDt);
        sb.append(", modifiedDt=").append(modifiedDt);
        sb.append(", createdBy=").append(createdBy);
        sb.append(", modifiedBy=").append(modifiedBy);
        sb.append('}');
        return sb.toString();
    }
}
