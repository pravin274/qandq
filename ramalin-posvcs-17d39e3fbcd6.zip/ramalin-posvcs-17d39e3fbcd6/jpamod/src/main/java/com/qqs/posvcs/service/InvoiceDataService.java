package com.qqs.posvcs.service;

import com.qqs.posvcs.model.*;
import com.qqs.posvcs.repository.InvoiceRepository;
import com.qqs.posvcs.repository.InvoiceStatusRepository;
import com.qqs.posvcs.repository.InvoicexRefPoRepository;
import com.qqs.posvcs.repository.SLIDocumentsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Component
public class InvoiceDataService extends BaseDataService<Invoice> {
    @Autowired
    private InvoiceRepository repository;
    @Autowired
    private SLIDocumentsRepository sliDocumentsrepository;
    @Autowired
    private InvoicexRefPoRepository invoicexRefPoRepository;

    @Autowired
    private InvoiceStatusRepository invoiceStatusRepository;


    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<Invoice> invoiceUtils = new DataServiceUtils<>();


    @Override
    protected CrudRepository<Invoice, Integer> getRepo() {
        return repository;
    }

    @Override
    protected EntityManager getEntityManager() {
        return entityManager;
    }

    @Override
    protected Class<Invoice> getModelClass() {
        return Invoice.class;
    }

    @Override
    protected DataServiceUtils<Invoice> getSearchUtils() {
        return invoiceUtils;
    }

    public Optional<List<InvoiceStatus>> getInvoiceStatusByInvoiceId(Integer invoiceId) {
        return invoiceStatusRepository.findAllByInvoiceId(invoiceId);
    }

    public List<InvoiceStatusData> getInvoiceStatusByInvoiceId(List<Integer> invoiceIds) {
        return invoiceStatusRepository.findAllByInvoiceIdIn(invoiceIds);
    }

    public Optional<List<SLIDocuments>> getSLIDocumentsByInvoiceId(Integer invoiceId) {
        return sliDocumentsrepository.findAllByInvoiceId(invoiceId);
    }

    public Optional<List<Integer>> getPOIdByInvoiceId(Integer invoiceId) {
        return invoicexRefPoRepository.getPOIdByInvoiceId(invoiceId);
    }

    @Transactional
    public Iterable<Invoicexrefpo> saveAllInvoicexrefPo(Iterable<Invoicexrefpo> invoicexrefpos) {
        return invoicexRefPoRepository.saveAll(invoicexrefpos);
    }

    @Transactional
    public Iterable<SLIDocuments> saveSLIDocuments(Iterable<SLIDocuments> item) {
        return sliDocumentsrepository.saveAll(item);
    }

    @Transactional
    public Iterable<InvoiceStatus> saveInvoiceStatus(Iterable<InvoiceStatus> item) {
        return invoiceStatusRepository.saveAll(item);
    }

    public Optional<List<Invoice>> searchInvoice(List<SearchCriteria> params) {
        List<Invoice> result = invoiceUtils.createPredicate(entityManager, params, Invoice.class);
        Optional<List<Invoice>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public Optional<List<Object[]>> getInvoiceValue(List<Integer> invoiceIds) {
        return repository.getInvoiceValue(invoiceIds);
    }

    public List<Invoice> getInvoiceByPoNumber (String poNumber) {
        return repository.findInvoiceByPoNumber(poNumber);
    }

    public InvoiceStatus saveInvoiceStatus(InvoiceStatus invoiceStatustoDb) {
        return   invoiceStatusRepository.save(invoiceStatustoDb);
    }
}
