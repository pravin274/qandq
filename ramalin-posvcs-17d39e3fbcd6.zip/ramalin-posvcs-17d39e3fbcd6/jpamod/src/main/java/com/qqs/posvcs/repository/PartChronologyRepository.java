package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.PartChronology;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface PartChronologyRepository extends CrudRepository<PartChronology, Integer> {
    Optional<List<PartChronology>> findPartChronologiesByPartNo(Integer partId);
}
