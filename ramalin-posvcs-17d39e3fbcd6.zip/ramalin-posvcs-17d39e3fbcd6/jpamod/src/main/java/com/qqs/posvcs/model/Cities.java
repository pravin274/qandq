package com.qqs.posvcs.model;


import javax.persistence.*;

@Entity
@Table(name = "cities", schema = "qqordermgmnt", catalog = "")
public class Cities {
    private int id;
    private String name;
    private int state_id;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(name = "state_id")
    public int getState_id() {
        return state_id;
    }

    public void setState_id(int state_id) {
        this.state_id = state_id;
    }
}
