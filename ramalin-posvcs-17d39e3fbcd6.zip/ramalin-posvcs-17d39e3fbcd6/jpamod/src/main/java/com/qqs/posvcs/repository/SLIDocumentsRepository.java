package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.SLIDocuments;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface SLIDocumentsRepository extends CrudRepository<SLIDocuments, Integer> {

    Optional<List<SLIDocuments>> findAllByInvoiceId(Integer invoiceId);

}
