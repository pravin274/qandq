package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.PartCommodity;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface PartCommodityRepository extends CrudRepository<PartCommodity, Integer> {
    Optional<List<PartCommodity>> findPartCommoditiesByPartId(Integer partId);
    Optional<List<PartCommodity>> findPartCommoditiesByPartIdIn(List<Integer> partIds);
}
