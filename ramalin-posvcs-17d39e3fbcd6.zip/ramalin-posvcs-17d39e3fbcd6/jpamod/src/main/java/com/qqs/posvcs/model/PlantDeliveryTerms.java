package com.qqs.posvcs.model;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "plantdeliveryterms", schema = "qqordermgmnt", catalog = "")
public class PlantDeliveryTerms {
    private int id;
    private int plantId;
    private String deliveryTerms;
    private Timestamp effectiveDt;
    private Timestamp expiryDt;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "plantId")
    public int getPlantId() {
        return plantId;
    }

    public void setPlantId(int plantId) {
        this.plantId = plantId;
    }

    @Basic
    @Column(name = "deliveryTerms")
    public String  getDeliveryTerms() {
        return deliveryTerms;
    }

    public void setDeliveryTerms(String deliveryTerms) {
        this.deliveryTerms = deliveryTerms;
    }

    @Basic
    @Column(name = "effectiveDt")
    public Timestamp getEffectiveDt() {
        return effectiveDt;
    }

    public void setEffectiveDt(Timestamp effectiveDt) {
        this.effectiveDt = effectiveDt;
    }

    @Basic
    @Column(name = "expiryDt")
    public Timestamp getExpiryDt() {
        return expiryDt;
    }

    public void setExpiryDt(Timestamp expiryDt) {
        this.expiryDt = expiryDt;
    }

    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PlantDeliveryTerms plantDeliveryTerms = (PlantDeliveryTerms) o;

        if (id != plantDeliveryTerms.id) return false;
        if (plantId != plantDeliveryTerms.plantId) return false;
        if (deliveryTerms != null ? !deliveryTerms.equals(plantDeliveryTerms.deliveryTerms) : plantDeliveryTerms.deliveryTerms != null) return false;
        if (effectiveDt != null ? !effectiveDt.equals(plantDeliveryTerms.effectiveDt) : plantDeliveryTerms.effectiveDt != null) return false;
        if (expiryDt != null ? !expiryDt.equals(plantDeliveryTerms.expiryDt) : plantDeliveryTerms.expiryDt != null) return false;
        if (createdBy != null ? !createdBy.equals(plantDeliveryTerms.createdBy) : plantDeliveryTerms.createdBy != null) return false;
        if (createdDt != null ? !createdDt.equals(plantDeliveryTerms.createdDt) : plantDeliveryTerms.createdDt != null) return false;
        if (modifiedBy != null ? !modifiedBy.equals(plantDeliveryTerms.modifiedBy) : plantDeliveryTerms.modifiedBy != null) return false;
        if (modifiedDt != null ? !modifiedDt.equals(plantDeliveryTerms.modifiedDt) : plantDeliveryTerms.modifiedDt != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + plantId;
        result = 31 * result + (deliveryTerms != null ? deliveryTerms.hashCode() : 0);
        result = 31 * result + (effectiveDt != null ? effectiveDt.hashCode() : 0);
        result = 31 * result + (expiryDt != null ? expiryDt.hashCode() : 0);
        result = 31 * result + (createdDt != null ? createdDt.hashCode() : 0);
        result = 31 * result + (modifiedDt != null ? modifiedDt.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDt != null ? createdDt.hashCode() : 0);
        result = 31 * result + (modifiedBy != null ? modifiedBy.hashCode() : 0);
        result = 31 * result + (modifiedDt != null ? modifiedDt.hashCode() : 0);
        return result;
    }
}
