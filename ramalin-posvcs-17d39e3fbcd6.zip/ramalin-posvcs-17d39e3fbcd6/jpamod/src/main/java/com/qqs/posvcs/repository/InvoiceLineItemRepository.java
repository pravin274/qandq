package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.InvoiceLineItem;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface InvoiceLineItemRepository extends CrudRepository<InvoiceLineItem, Integer> {
    Iterable<InvoiceLineItem> findAllByInvoiceId(Integer invoiceId);

    @Query(value = "select po.poNumber as poNumber, ifnull(pt.number,plt.description) as partNumber, " +
            " pli.partType as partType, pli.item as poItem, sum(invoiceQty) as shippedQty " +
            " from invoicelineitem ili inner join polineitem pli on ili.polineid = pli.id " +
            " inner join purchorder po on pli.poid = po.id " +
            " left outer join part pt on pt.id = pli.partId left outer join polinetool plt on plt.id = pli.poLineToolId " +
            " where poNumber in (select distinct poNumber from purchorder po1, polineitem pli1 " +
            " where po1.id = pli1.poid and pli1.id in ?1)  " +
            " and ili.invoiceId != ?2 group by poNumber, partNumber, partType, poItem ", nativeQuery = true)
    Optional<List<Object[]>> findShippedQtyByPoLineItems(Iterable<Integer> poLineItemIds, Integer invoiceId);

    @Query(value = "select po.poNumber as poNumber, ifnull(pt.number,plt.description) as partNumber, " +
            " pli.partType as partType, pli.item as poItem, sum(invoiceQty) as shippedQty, " +
            " group_concat(DISTINCT inv.serialNo order by inv.serialNo separator ', ') as invNumber, " +
            " group_concat(DISTINCT DATE_FORMAT(CONVERT_TZ(inv.invDate, 'GMT', cdd.description),'%Y/%m/%d') order by inv.serialNo separator ', ') as invDate " +
            " from invoicelineitem ili inner join polineitem pli on ili.polineid = pli.id " +
            " inner join invoice inv on inv.id = ili.invoiceId inner join purchorder po on pli.poid = po.id " +
            " INNER JOIN `qqordermgmnt`.`codes` cdd ON cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " +
            " left outer join part pt on pt.id = pli.partId left outer join polinetool plt on plt.id = pli.poLineToolId " +
            " where poNumber in ?1 group by poNumber, partNumber, partType, poItem ", nativeQuery = true)
    Optional<List<Object[]>> findShippedQtyByPoNumbers(Iterable<String> poNumbers);

}
