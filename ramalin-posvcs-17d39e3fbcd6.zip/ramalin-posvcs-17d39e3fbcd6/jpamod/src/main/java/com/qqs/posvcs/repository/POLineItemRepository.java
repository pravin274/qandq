package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.PoLineItem;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface POLineItemRepository extends CrudRepository<PoLineItem, Integer> {
    Iterable<PoLineItem> findAllByPoId(Integer poId);

    @Query(value = "select pli.id, po.poNumber as poNumber, ifnull(pt.number,plt.description) as partNumber, " +
            " pli.partType as partType, pli.item as poItem " +
            " from polineitem pli inner join purchorder po on pli.poid = po.id " +
            " left outer join part pt on pt.id = pli.partId left outer join polinetool plt on plt.id = pli.poLineToolId " +
            " where pli.id in ?1  ", nativeQuery = true)
    Optional<List<Object[]>> findShippingAttr(Iterable<Integer> poLineItemIds);

}
