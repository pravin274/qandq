package com.qqs.posvcs.service;

import com.qqs.posvcs.model.CurrencyExchangeRate;
import com.qqs.posvcs.repository.CurrencyExchangeRateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Component
public class CurrencyExchangeRateDataService {

    @Autowired
    private CurrencyExchangeRateRepository currencyExchangeRateRepository;

    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<CurrencyExchangeRate> currencyExchangeRateUtils = new DataServiceUtils<>();

    public Optional<CurrencyExchangeRate> findCurrencyExchangeRateById(Integer id) { return currencyExchangeRateRepository.findById(id); }

    public Optional<List<CurrencyExchangeRate>> searchCurrencyExchangeRates(List<SearchCriteria> params) {
        List<CurrencyExchangeRate> result = currencyExchangeRateUtils.createPredicate(entityManager, params, CurrencyExchangeRate.class);
        Optional<List<CurrencyExchangeRate>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public Iterable<CurrencyExchangeRate> getAllCurrencyExchangeRates() {
        return currencyExchangeRateRepository.findAll();
    }

    @Transactional
    public CurrencyExchangeRate saveCurrencyExchangeRates(CurrencyExchangeRate item) {
        return currencyExchangeRateRepository.save(item);
    }


}
