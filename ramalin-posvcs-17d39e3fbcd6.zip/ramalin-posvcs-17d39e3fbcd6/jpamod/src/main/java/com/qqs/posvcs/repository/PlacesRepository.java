package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.Places;
import org.springframework.data.repository.CrudRepository;

public interface PlacesRepository extends CrudRepository<Places, Integer> {
    
}
