package com.qqs.posvcs.model;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "partprice", schema = "qqordermgmnt", catalog = "")
public class PartPrice {
    private int id;
    private int partId;
    private String currency;
    private Double value;
    private String priceDesc;
    private String partCategory;
    private String defaultInd;
    private Timestamp effectiveDt;
    private Timestamp expiryDt;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "partId")
    public int getPartId() {
        return partId;
    }

    public void setPartId(int partId) {
        this.partId = partId;
    }

    @Basic
    @Column(name = "currency")
    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @Basic
    @Column(name = "value")
    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    @Basic
    @Column(name = "priceDesc")
    public String getPriceDesc() {
        return priceDesc;
    }

    public void setPriceDesc(String priceDesc) {
        this.priceDesc = priceDesc;
    }

    @Basic
    @Column(name = "partCategory")
    public String getPartCategory() {
        return partCategory;
    }

    public void setPartCategory(String partCategory) {
        this.partCategory = partCategory;
    }

    @Basic
    @Column(name = "defaultInd")
    public String getDefaultInd() {
        return defaultInd;
    }

    public void setDefaultInd(String defaultInd) {
        this.defaultInd = defaultInd;
    }

    @Basic
    @Column(name = "effectiveDt")
    public Timestamp getEffectiveDt() {
        return effectiveDt;
    }

    public void setEffectiveDt(Timestamp effectiveDt) {
        this.effectiveDt = effectiveDt;
    }

    @Basic
    @Column(name = "expiryDt")
    public Timestamp getExpiryDt() {
        return expiryDt;
    }

    public void setExpiryDt(Timestamp expiryDt) {
        this.expiryDt = expiryDt;
    }

    @Basic
    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Basic
    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Basic
    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Basic
    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PartPrice partprice = (PartPrice) o;

        if (id != partprice.id) return false;
        if (partId != partprice.partId) return false;
        if (currency != null ? !currency.equals(partprice.currency) : partprice.currency != null) return false;
        if (value != null ? !value.equals(partprice.value) : partprice.value != null) return false;
        if (priceDesc != null ? !priceDesc.equals(partprice.priceDesc) : partprice.priceDesc != null) return false;
        if (defaultInd != null ? !defaultInd.equals(partprice.defaultInd) : partprice.defaultInd != null) return false;
        if (effectiveDt != null ? !effectiveDt.equals(partprice.effectiveDt) : partprice.effectiveDt != null)
            return false;
        if (expiryDt != null ? !expiryDt.equals(partprice.expiryDt) : partprice.expiryDt != null) return false;
        if (createdBy != null ? !createdBy.equals(partprice.createdBy) : partprice.createdBy != null) return false;
        if (createdDt != null ? !createdDt.equals(partprice.createdDt) : partprice.createdDt != null) return false;
        if (modifiedBy != null ? !modifiedBy.equals(partprice.modifiedBy) : partprice.modifiedBy != null) return false;
        if (modifiedDt != null ? !modifiedDt.equals(partprice.modifiedDt) : partprice.modifiedDt != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + partId;
        result = 31 * result + (currency != null ? currency.hashCode() : 0);
        result = 31 * result + (value != null ? value.hashCode() : 0);
        result = 31 * result + (priceDesc != null ? priceDesc.hashCode() : 0);
        result = 31 * result + (defaultInd != null ? defaultInd.hashCode() : 0);
        result = 31 * result + (effectiveDt != null ? effectiveDt.hashCode() : 0);
        result = 31 * result + (expiryDt != null ? expiryDt.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDt != null ? createdDt.hashCode() : 0);
        result = 31 * result + (modifiedBy != null ? modifiedBy.hashCode() : 0);
        result = 31 * result + (modifiedDt != null ? modifiedDt.hashCode() : 0);
        return result;
    }

}
