package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.PlantDeliveryTerms;
import com.qqs.posvcs.model.PlantPaymentTerms;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface PlantPaymentTermsRepository extends CrudRepository<PlantPaymentTerms, Integer> {
    Optional<List<PlantPaymentTerms>> findPlantPaymentTermsByPlantId(Integer plantId);
    Optional<List<PlantPaymentTerms>> findPlantPaymentTermsByPlantIdIn(List<Integer> plantId);
    PlantPaymentTerms findPlantPaymentTermsById(Integer id);
}
