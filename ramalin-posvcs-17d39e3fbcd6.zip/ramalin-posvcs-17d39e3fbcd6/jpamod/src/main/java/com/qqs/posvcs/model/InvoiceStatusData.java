package com.qqs.posvcs.model;

public interface InvoiceStatusData {
    Integer getInvoiceId();

    String getInvoiceStatus();

    String getStatusDate();

    String getAttribute1();

    String getAttribute2();

    String getAttribute3();

    String getAttribute4();

    String getRemarks();

}
