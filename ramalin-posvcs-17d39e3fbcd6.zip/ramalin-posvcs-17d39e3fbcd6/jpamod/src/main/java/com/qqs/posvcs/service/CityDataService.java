package com.qqs.posvcs.service;

import com.qqs.posvcs.model.Cities;
import com.qqs.posvcs.model.Countries;
import com.qqs.posvcs.model.States;
import com.qqs.posvcs.repository.CitiesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Component
public class CityDataService {

    @Autowired
    private CitiesRepository citiesRepository;

    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<Cities> citiesUtils = new DataServiceUtils<>();

    public Optional<Cities> findCityById(Integer id) { return citiesRepository.findById(id); }

    public Optional<List<Cities>> findCitiesByStateId(Integer stateId) {
        return citiesRepository.findCitiesByStateId(stateId);
    }

    public Optional<List<Cities>> SearchCities(List<SearchCriteria> params) {
        List<Cities> result = citiesUtils.createPredicate(entityManager, params, Cities.class);
        Optional<List<Cities>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public Iterable<Cities> getAllCities() {
        return citiesRepository.findAll();
    }

    @Transactional
    public Cities saveCities(Cities item) {
        return citiesRepository.save(item);
    }


}
