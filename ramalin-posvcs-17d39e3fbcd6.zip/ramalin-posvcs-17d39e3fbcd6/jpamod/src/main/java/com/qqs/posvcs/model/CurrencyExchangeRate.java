package com.qqs.posvcs.model;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "currencyexchangerate", schema = "qqordermgmnt", catalog = "")
public class CurrencyExchangeRate {
    private int id;
    private String currency;
    private Double value;
    private Timestamp effectiveDt;
    private Timestamp expiryDt;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "currency")
    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @Basic
    @Column(name = "value")
    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    @Basic
    @Column(name = "effectiveDt")
    public Timestamp getEffectiveDt() {
        return effectiveDt;
    }

    public void setEffectiveDt(Timestamp effectiveDt) {
        this.effectiveDt = effectiveDt;
    }

    @Basic
    @Column(name = "expiryDt")
    public Timestamp getExpiryDt() {
        return expiryDt;
    }

    public void setExpiryDt(Timestamp expiryDt) {
        this.expiryDt = expiryDt;
    }

    @Basic
    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Basic
    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Basic
    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Basic
    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CurrencyExchangeRate currencyExchangeRate = (CurrencyExchangeRate) o;

        if (id != currencyExchangeRate.id) return false;
        if (currency != null ? !currency.equals(currencyExchangeRate.currency) : currencyExchangeRate.currency != null) return false;
        if (value != null ? !value.equals(currencyExchangeRate.value) : currencyExchangeRate.value != null) return false;
        if (effectiveDt != null ? !effectiveDt.equals(currencyExchangeRate.effectiveDt) : currencyExchangeRate.effectiveDt != null)
            return false;
        if (expiryDt != null ? !expiryDt.equals(currencyExchangeRate.expiryDt) : currencyExchangeRate.expiryDt != null) return false;
        if (createdBy != null ? !createdBy.equals(currencyExchangeRate.createdBy) : currencyExchangeRate.createdBy != null) return false;
        if (createdDt != null ? !createdDt.equals(currencyExchangeRate.createdDt) : currencyExchangeRate.createdDt != null) return false;
        if (modifiedBy != null ? !modifiedBy.equals(currencyExchangeRate.modifiedBy) : currencyExchangeRate.modifiedBy != null) return false;
        if (modifiedDt != null ? !modifiedDt.equals(currencyExchangeRate.modifiedDt) : currencyExchangeRate.modifiedDt != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (currency != null ? currency.hashCode() : 0);
        result = 31 * result + (value != null ? value.hashCode() : 0);
        result = 31 * result + (effectiveDt != null ? effectiveDt.hashCode() : 0);
        result = 31 * result + (expiryDt != null ? expiryDt.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDt != null ? createdDt.hashCode() : 0);
        result = 31 * result + (modifiedBy != null ? modifiedBy.hashCode() : 0);
        result = 31 * result + (modifiedDt != null ? modifiedDt.hashCode() : 0);
        return result;
    }
}
