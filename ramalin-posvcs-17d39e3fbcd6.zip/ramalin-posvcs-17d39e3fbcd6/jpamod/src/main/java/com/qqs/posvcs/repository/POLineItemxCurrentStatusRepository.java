package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.PoLineItemxCurrentStatus;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface POLineItemxCurrentStatusRepository extends CrudRepository<PoLineItemxCurrentStatus, Integer> {
    Optional<List<PoLineItemxCurrentStatus>> findAllByPoLineItemId(Integer lineItemId);

    Optional<PoLineItemxCurrentStatus> findByPoLineItemIdAndStatus(Integer lineItemId, String poLineId);

    Optional<PoLineItemxCurrentStatus> findByPoLineItemIdAndStatusAndType(Integer poLineItemId, String status, String type);


}
