package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.PartRevisionAmendment;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface PartRevisionAmendmentRepository extends CrudRepository<PartRevisionAmendment, Integer> {
     Optional<List<PartRevisionAmendment>> findPartRevisionAmendmentByPartId(Integer partId);
}
