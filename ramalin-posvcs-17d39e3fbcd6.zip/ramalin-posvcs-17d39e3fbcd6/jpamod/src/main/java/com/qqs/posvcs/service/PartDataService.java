package com.qqs.posvcs.service;

import com.qqs.posvcs.model.*;
import com.qqs.posvcs.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Component
public class PartDataService {
    @Autowired
    private PartRepository repository;
    @Autowired
    private PartChronologyRepository chronologyRepository;
    @Autowired
    private PartDomainRepository domainRepository;
    @Autowired
    private PartCommodityRepository commodityRepository;
    @Autowired
    private PartImageRepository imageRepository;
    @Autowired
    private PartPriceRepository priceRepository;
    @Autowired
    private PartRelationxRefRepository partRelationxRefRepository;
    @Autowired
    private PartStandardRepository partStandardRepository;
    @Autowired
    private PartCustomerRequirementRepository customerRequirementRepository;
    @Autowired
    private PartRevisionAmendmentRepository revisionAmendmentRepository;
    @Autowired
    private StandardRepository standardRepository;



    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<Part> utils = new DataServiceUtils<>();

    private DataServiceUtils<Standard> StandardUtils = new DataServiceUtils<>();


    public Optional<Part> getPartById(Integer id) {
        return repository.findById(id);
    }

    public Iterable<Part> getAllPartsById(Iterable<Integer> ids) {
        return repository.findAllById(ids);
    }

    public Optional<List<Part>> getAllChildPartsById(Integer parentPartId) {
        List<Part> result = repository.getAllChildPartsById(parentPartId);
        return Optional.of(result);
    }

    public Optional<List<PartChronology>> getChronologyByPart(Integer partId) {
        return chronologyRepository.findPartChronologiesByPartNo(partId);
    }

    public Optional<List<PartDomain>> getDomainByPart(Integer partId) {
        return domainRepository.findPartDomainsByPartId(partId);
    }

    public Optional<List<PartCommodity>> getCommodityByPart(Integer partId) {
        return commodityRepository.findPartCommoditiesByPartId(partId);
    }

    public Optional<List<PartCommodity>> getCommodityByPartIds(List<Integer> partIds) {
        return commodityRepository.findPartCommoditiesByPartIdIn(partIds);
    }

    public Iterable<PartCommodity> getAllCommodityById(Iterable<Integer> ids) {
        return commodityRepository.findAllById(ids);
    }

    public Optional<List<PartImage>> getImageByPart(Integer partId) {
        return imageRepository.findPartImagesByPartId(partId);
    }

    public Optional<List<PartPrice>> getPriceByPart(Integer partId) {
        return priceRepository.findPartPricesByPartId(partId);
    }

    public Optional<List<PartPrice>> getPriceByPartIds(List<Integer> partIds) {
        return priceRepository.findPartPricesByPartIdIn(partIds);
    }

    public Optional<List<PartStandard>> getStandardByPart(Integer partId) {
        return partStandardRepository.findPartStandardByPartId(partId);
    }

    public Optional<List<PartCustomerRequirement>> getPartCustomerRequirementByPart(Integer partId) {
        return customerRequirementRepository.findPartCustomerRequirementByPartId(partId);
    }
    public Optional<List<PartRevisionAmendment>> getPartRevisionAmendmentByPart(Integer partId) {
        return revisionAmendmentRepository.findPartRevisionAmendmentByPartId(partId);
    }

    public Iterable<Part> getAllParts() {
        return repository.findAll();
    }

    public Optional<List<Part>> searchParts(List<SearchCriteria> params) {
        List<Part> result = utils.createPredicate(entityManager, params, Part.class);
        Optional<List<Part>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }
    //Standard search
    public Optional<List<Standard>> searchStandards(List<SearchCriteria> params) {
        List<Standard> result = StandardUtils.createPredicate(entityManager, params, Standard.class);
        Optional<List<Standard>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public PartRelationxRef getPartRelationxRefByParentIdAndChildId(Integer parentId, Integer childId) {
        return partRelationxRefRepository.findByParentIdAndChildId(parentId, childId);
    }

    public List<PartRelationxRef> getPartRelationxRefByParentId(Integer parentId) {
        return partRelationxRefRepository.findAllByParentId(parentId);
    }

    public Integer getTotalPartsCount() {
        return repository.getTotalPartsCount();
    }

    public Integer getTotalParentPartsCount() {
        return repository.getTotalParentPartsCount();
    }

    @Transactional
    public Part savePart(Part item) {
        return repository.save(item);
    }
    
    //Standard Master save
    @Transactional
    public Standard saveMasterStandard(Standard item) {
        return standardRepository.save(item);
    }

    @Transactional
    public Iterable<PartChronology> saveChronology(Iterable<PartChronology> item) {
        return chronologyRepository.saveAll(item);
    }

    @Transactional
    public Iterable<PartDomain> saveDomain(Iterable<PartDomain> item) {
        return domainRepository.saveAll(item);
    }

    @Transactional
    public Iterable<PartImage> saveImage(Iterable<PartImage> item) {
        return imageRepository.saveAll(item);
    }

    @Transactional
    public Iterable<PartPrice> savePrice(Iterable<PartPrice> item) {
        return priceRepository.saveAll(item);
    }

    @Transactional
    public Iterable<PartCommodity> saveCommodity(Iterable<PartCommodity> item) {
        return  commodityRepository.saveAll(item);
    }

    @Transactional
    public Iterable<PartRelationxRef> saveChildParts(List<PartRelationxRef> item) {
        return  partRelationxRefRepository.saveAll(item);
    }

    @Transactional
    public Iterable<PartStandard> saveStandards(Iterable<PartStandard> item) {
        return  partStandardRepository.saveAll(item);
    }

    @Transactional
    public Iterable<PartCustomerRequirement> saveCustomerRequirement(Iterable<PartCustomerRequirement> item) {
        return  customerRequirementRepository.saveAll(item);
    }

    @Transactional
    public Iterable<PartRevisionAmendment> saveRevisionAmendment(Iterable<PartRevisionAmendment> item) {
        return  revisionAmendmentRepository.saveAll(item);
    }

    @Transactional
    public Iterable<PartImage> savePartImage(Iterable<PartImage> item) {
        return  imageRepository.saveAll(item);
    }


}
