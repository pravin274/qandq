package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.Invoice;
import com.qqs.posvcs.model.PoTrackReport;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface PoTrackRepository extends CrudRepository<Invoice, Integer> {

    @Query(value = "SELECT inv.id  as invoiceId, DATE_FORMAT(CONVERT_TZ(po.poDate,'GMT', cdd.description) ,'%Y/%m/%d')   " +
            "                         as PoDate, po.poNumber as pONumber, pli.item as itemNumber,  po.poStatus as poStatus,  " +
            "                         po.poRevision as poRevision, pli.partPrice as partPrice,   " +
            "                          IFNULL(prt.number, plt.toolno) as partNumber, IFNULL(prt.partRevNo, plt.revno) as partRevisionNumber,    " +
            "                                     IFNULL(prt.name, plt.description) as description,  cmd.commodityCode as hsCode, " +
            "                                     concat(pli.currency, '-', pli.partPrice)  as pricePerPart , pli.currency as currency, " +
            "                                     DATE_FORMAT(CONVERT_TZ(pli.deliveryDate,'GMT', cdd.description) ,'%Y/%m/%d')  as dueDate,    " +
            "                                     pli.partType as partType, inv.serialNo as invoiceNumber, pli.quantity as poQuantity, ilt.invoiceQty as invoiceQuantity,     " +
            "                                      DATE_FORMAT(CONVERT_TZ(inv.invDate,'GMT', cdd.description) ,'%Y/%m/%d') as invoiceDate,     " +
            "                                      cm.name as companyName, pl.plantCode as plantName, sum(ilt.invoiceQty * pli.partPrice) as totalInvoiceValue,  " +
            "                                      sum(ilt.invoiceQty * pli.partPrice * IFNULL(currConvRs, 1)) as   totalInvoiceValueINR, " +
            "                                      cm.id as companyId, pl.id as plantId, inv.invoiceStatus as invoiceStatus    " +
            "                                      from qqordermgmnt.purchorder as po    " +
            "                                                 inner join qqordermgmnt.polineitem pli on po.id = pli.poId  " +
            "                                                 left outer join qqordermgmnt.invoicelineitem ilt on ilt.poLineId = pli.id    " +
            "                                                       left outer join qqordermgmnt.invoice inv on ilt.invoiceId = inv.id    " +
            "                                                 inner join qqordermgmnt.plant pl on  pl.id = po.plantId     " +
            "                                                 inner join qqordermgmnt.company cm on cm.id = pl.companyId     " +
            "                                                 inner join qqordermgmnt.codes cdd on cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL'   " +
            "                                                 left outer join qqordermgmnt.part prt on prt.id = pli.partid     " +
            "                                                 left outer join qqordermgmnt.polinetool plt on plt.id = pli.poLineToolId    " +
            "                                                 left outer join qqordermgmnt.partcommodity cmd on cmd.id = pli.commodityCodeId  " +
            "                                                 where  (inv.invoiceStatus != 'CAN' or inv.invoiceStatus is null) and po.poDate between  " +
            "                                                 ?1 and ?2  " +
            "                                                 and po.poStatus != 'CANCELLED'   " +
            "                                                 group by inv.id, inv.serialNo,inv.invDate, cm.name, pl.plantCode, cm.id, pl.id, pli.id, inv.invoicestatus   " +
            "                                                 order by  po.poNumber, pli.item, po.poDate, inv.serialNo;", nativeQuery = true)
    List<PoTrackReport> findPoTrackReportData(String fromDate, String toDate);

//    @Query(value = "SELECT inv.id  as invoiceId, ANY_VALUE(DATE_FORMAT(CONVERT_TZ(po.poDate,'GMT', cdd.description) ,'%Y/%m/%d')) " +
//            "        as PoDate, po.poNumber as pONumber, pli.item as itemNumber,  po.poStatus as poStatus, " +
//            "        po.poRevision as poRevision, pli.partPrice as partPrice, " +
//            "        IFNULL(prt.number, plt.toolno) as partNumber, IFNULL(prt.partRevNo, plt.revno) as partRevisionNumber, " +
//            "        IFNULL(prt.name, plt.description) as description,  cmd.commodityCode as hsCode, " +
//            "        concat(pli.currency, '-', pli.partPrice)  as pricePerPart , pli.currency as currency, " +
//            "        ANY_VALUE(DATE_FORMAT(CONVERT_TZ(pli.deliveryDate,'GMT', cdd.description) ,'%Y/%m/%d'))  as dueDate, " +
//            "        pli.partType as partType, inv.serialNo as invoiceNumber, pli.quantity as poQuantity,  ANY_VALUE(ilt.invoiceQty) as invoiceQuantity, " +
//            "        ANY_VALUE(DATE_FORMAT(CONVERT_TZ(inv.invDate,'GMT', cdd.description) ,'%Y/%m/%d')) as invoiceDate, " +
//            "        cm.name as companyName, pl.plantCode as plantName, sum( ilt.invoiceQty * pli.partPrice) as totalInvoiceValue, " +
//            "        sum(ilt.invoiceQty * pli.partPrice * IFNULL(currConvRs, 1)) as   totalInvoiceValueINR, " +
//            "        cm.id as companyId, pl.id as plantId, inv.invoiceStatus as invoiceStatus " +
//            "        from qqordermgmnt.purchorder as po  " +
//            "        inner join qqordermgmnt.polineitem pli on po.id = pli.poId  " +
//            "        left outer join qqordermgmnt.invoicelineitem ilt on ilt.poLineId = pli.id " +
//            "        left outer join qqordermgmnt.invoice inv on ilt.invoiceId = inv.id  " +
//            "        inner join qqordermgmnt.plant pl on  pl.id = po.plantId " +
//            "        inner join qqordermgmnt.company cm on cm.id = pl.companyId " +
//            "        inner join qqordermgmnt.codes cdd on cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL'  " +
//            "        left outer join qqordermgmnt.part prt on prt.id = pli.partid  " +
//            "        left outer join qqordermgmnt.polinetool plt on plt.id = pli.poLineToolId  " +
//            "        left outer join qqordermgmnt.partcommodity cmd on cmd.id = pli.commodityCodeId  " +
//            "        where  (inv.invoiceStatus != 'CAN' or inv.invoiceStatus is null) and po.poDate between " +
//            "        '2010-01-01' and '2021-01-01'  " +
//            "        and po.poStatus != 'CANCELLED'  " +
//            "        group by inv.id, inv.serialNo,inv.invDate, cm.name, pl.plantCode, cm.id, pl.id, pli.id, inv.invoicestatus " +
//            "        order by  po.poNumber, pli.item, po.poDate, inv.serialNo;", nativeQuery = true)
//    List<PoTrackReport> findPoTrackReportData(String fromDate, String toDate);
}

