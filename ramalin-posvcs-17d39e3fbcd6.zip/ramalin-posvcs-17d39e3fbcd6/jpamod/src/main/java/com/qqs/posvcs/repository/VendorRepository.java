package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.Places;
import com.qqs.posvcs.model.Vendor;
import org.springframework.data.repository.CrudRepository;

public interface VendorRepository extends CrudRepository<Vendor, Integer> {
    
}
