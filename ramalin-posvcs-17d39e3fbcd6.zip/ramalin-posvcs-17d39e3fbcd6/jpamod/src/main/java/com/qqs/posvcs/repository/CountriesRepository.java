package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.Countries;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface CountriesRepository extends CrudRepository<Countries, Integer> {

    @Query(value = "SELECT name FROM qqordermgmnt.countries where id = ?1", nativeQuery = true)
    Optional<String> findCountryNameById(Integer countryId);

}
