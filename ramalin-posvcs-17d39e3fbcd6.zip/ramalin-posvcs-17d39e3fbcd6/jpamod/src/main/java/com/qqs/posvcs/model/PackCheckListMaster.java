package com.qqs.posvcs.model;


import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;

@Entity
@Table(name = "pkgchecklistmaster", schema = "qqordermgmnt", catalog = "")
public class PackCheckListMaster {

    private int id;
    private Integer invoiceId;
    private Integer plantId;
    private Integer companyId;
    private Integer partId;
    private Timestamp packStartTime;
    private Timestamp packEndTime;
    private String shift;
    private String boxNumber;
    private String packBoxSize;
    private String vciBagSize;
    private String silicaWt;
    private Integer qtyPerBox;
    private String packingIncharge;
//    private Set<PkgCheckList> PkgCheckList;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;


    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "invoiceId")
    public Integer getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Integer invoiceId) {
        this.invoiceId = invoiceId;
    }

    @Column(name = "plantId")
    public Integer getPlantId() {
        return plantId;
    }

    public void setPlantId(Integer plantId) {
        this.plantId = plantId;
    }

    @Column(name = "companyId")
    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }
    @Column(name = "partId")
    public Integer getPartId() {
        return partId;
    }

    public void setPartId(Integer partId) {
        this.partId = partId;
    }

    @Column(name = "packStartTime")
    public Timestamp getPackStartTime() {
        return packStartTime;
    }

    public void setPackStartTime(Timestamp packStartTime) {
        this.packStartTime = packStartTime;
    }

    @Column(name = "boxNumber")

    public String getBoxNumber() {
        return boxNumber;
    }

    public void setBoxNumber(String boxNumber) {
        this.boxNumber = boxNumber;
    }

    @Column(name = "packEndTime")
    public Timestamp getPackEndTime() {
        return packEndTime;
    }

    public void setPackEndTime(Timestamp packEndTime) {
        this.packEndTime = packEndTime;
    }

    @Column(name = "shift")
    public String getShift() {
        return shift;
    }

    public void setShift(String shift) {
        this.shift = shift;
    }

    @Column(name = "packBoxSize")
    public String getPackBoxSize() {
        return packBoxSize;
    }

    public void setPackBoxSize(String packBoxSize) {
        this.packBoxSize = packBoxSize;
    }

    @Column(name = "vciBagSize")
    public String getVciBagSize() {
        return vciBagSize;
    }

    public void setVciBagSize(String vciBagSize) {
        this.vciBagSize = vciBagSize;
    }

    @Column(name = "silicaWt")
    public String getSilicaWt() {
        return silicaWt;
    }

    public void setSilicaWt(String silicaWt) {
        this.silicaWt = silicaWt;
    }

    @Column(name = "qtyPerBox")
    public Integer getQtyPerBox() {
        return qtyPerBox;
    }

    public void setQtyPerBox(Integer qtyPerBox) {
        this.qtyPerBox = qtyPerBox;
    }

    @Column(name = "packingIncharge")
    public String getPackingIncharge() {
        return packingIncharge;
    }

    public void setPackingIncharge(String packingIncharge) {
        this.packingIncharge = packingIncharge;
    }

    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }



}
