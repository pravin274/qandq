package com.qqs.posvcs.model;

public interface PendingOrderResult {
    int getId();
    String getPoNumber();
    String getPartNumber();
    String getPartName();
    String getPartRevNo();
    String getPoRevision();
    String getPoStatus();
    String getPartType();
    String getPoItem();
    String getPoDate();
    String getDeliveryDate();
    int getPoQty();
    String getCompanyName();
    String getPlantName();
    int getCompanyId();
    int getPlantId();
}
