package com.qqs.posvcs.model;

public interface InvoiceReportData {
    int getInvoiceId();
    String getInvoiceNumber();
    String getInvoiceDate();
    String getCompanyName();
    String getPlantName();
    String getInvoiceStatus();
    Double getTotalInvoiceValue();
    int getCompanyId();
    int getPlantId();
}
