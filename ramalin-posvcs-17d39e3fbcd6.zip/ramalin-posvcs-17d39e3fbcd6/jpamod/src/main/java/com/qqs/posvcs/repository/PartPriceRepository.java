package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.PartPrice;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface PartPriceRepository extends CrudRepository<PartPrice, Integer> {
    Optional<List<PartPrice>> findPartPricesByPartId(Integer partId);
    Optional<List<PartPrice>> findPartPricesByPartIdIn (List<Integer> partId);
}
