package com.qqs.posvcs.service;

import com.qqs.posvcs.model.Company;
import com.qqs.posvcs.model.Plant;
import com.qqs.posvcs.repository.CompanyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component
public class CompanyDataService {
    @Autowired
    private CompanyRepository repository;
    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<Company> utils = new DataServiceUtils<>();

    public Optional<Company> getCompanyById(Integer id) {
        return repository.findById(id);
    }

    public Optional<List<Company>> searchClient(List<SearchCriteria> params) {
        List<Company> result = utils.createPredicate(entityManager, params, Company.class);
        Optional<List<Company>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public Iterable<Company> getAllCompany() {
        Iterable<Company> result = repository.findAll();
        return result;
    }

    @Transactional
    public Company saveCompany(Company item) {
        return repository.save(item);
    }
}
