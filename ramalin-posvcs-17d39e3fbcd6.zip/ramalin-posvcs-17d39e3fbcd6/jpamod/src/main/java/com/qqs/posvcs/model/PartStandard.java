package com.qqs.posvcs.model;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "partstandard", schema = "qqordermgmnt", catalog = "")
public class PartStandard{
    private int id;
    private int partId;
    private String standardNumber;
    private String standardDescription;
    private String standardSpecificDescription;
    private String revisionNumber;
    private String standardLink;
    private Timestamp createdDt;
    private Integer createdBy;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "partId")
    public int getPartId() {
        return partId;
    }

    public void setPartId(int partId) {
        this.partId = partId;
    }
    @Column(name = "standardNumber")
    public String getStandardNumber() {
        return standardNumber;
    }

    public void setStandardNumber(String standardNumber) {
        this.standardNumber = standardNumber;
    }
    @Column(name = "standardDescription")
    public String getStandardDescription() { 
        return standardDescription;
    }

    public void setStandardDescription(String standardDescription) {
        this.standardDescription = standardDescription;
    }
    @Column(name = "standardSpecificDescription")
    public String getStandardSpecificDescription() { 
        return standardSpecificDescription;
    }

    public void setStandardSpecificDescription(String standardSpecificDescription) {
        this.standardSpecificDescription = standardSpecificDescription;
    }
    @Column(name = "standardLink")
    public String getStandardLink() { 
        return standardLink;
    }

    public void setStandardLink(String standardLink) {
        this.standardLink = standardLink;
    }

    @Column(name = "revisionNumber")
    public String getRevisionNumber() { 
        return revisionNumber;
    }

    public void setRevisionNumber(String revisionNumber) {
        this.revisionNumber = revisionNumber;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }
    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PartStandard that = (PartStandard) o;

        if (id != that.id) return false;
        if (partId != that.partId) return false;
        if (standardNumber != null ? !standardNumber.equals(that.standardNumber) : that.standardNumber != null) return false;
        if (standardDescription != null ? !standardDescription.equals(that.standardDescription) : that.standardDescription != null) return false;
        if (standardSpecificDescription != null ? !standardSpecificDescription.equals(that.standardSpecificDescription) : that.standardSpecificDescription != null) return false;
        if (revisionNumber != null ? !revisionNumber.equals(that.revisionNumber) : that.revisionNumber != null) return false;
        if (standardLink != null ? !standardLink.equals(that.standardLink) : that.standardLink != null) return false;
        if (createdDt != null ? !createdDt.equals(that.createdDt) : that.createdDt != null) return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (modifiedBy != null ? !modifiedBy.equals(that.modifiedBy) : that.modifiedBy != null) return false;
        if (modifiedDt != null ? !modifiedDt.equals(that.modifiedDt) : that.modifiedDt != null) return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + partId;
        result = 31 * result + (standardNumber != null ? standardNumber.hashCode() : 0);
        result = 31 * result + (standardDescription != null ? standardDescription.hashCode() : 0);
        result = 31 * result + (standardSpecificDescription != null ? standardSpecificDescription.hashCode() : 0);
        result = 31 * result + (revisionNumber != null ? revisionNumber.hashCode() : 0);
        result = 31 * result + (standardLink != null ? standardLink.hashCode() : 0);
        result = 31 * result + (createdDt != null ? createdDt.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (modifiedBy != null ? modifiedBy.hashCode() : 0);
        result = 31 * result + (modifiedDt != null ? modifiedDt.hashCode() : 0);
        return result;
    }
}
