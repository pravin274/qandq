package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.PartImage;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface PartImageRepository extends CrudRepository<PartImage, Integer> {
    Optional<List<PartImage>> findPartImagesByPartId(Integer partId);
}
