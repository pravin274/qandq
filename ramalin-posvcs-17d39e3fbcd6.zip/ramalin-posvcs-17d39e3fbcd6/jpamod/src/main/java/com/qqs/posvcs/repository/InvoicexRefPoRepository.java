package com.qqs.posvcs.repository;

import com.qqs.posvcs.model.Invoicexrefpo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface InvoicexRefPoRepository extends CrudRepository<Invoicexrefpo, Integer> {
    @Query(value = "select poId from invoicexrefpo where invoiceId in (?1) ", nativeQuery = true)
    Optional<List<Integer>> getPOIdByInvoiceId(Integer invoiceId);

}
