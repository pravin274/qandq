package com.qqs.posvcs.service;

import com.qqs.posvcs.model.Places;
import com.qqs.posvcs.model.Places;
import com.qqs.posvcs.repository.PlacesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.Optional;

@Component
public class PlacesDataService extends BaseDataService<Places>{
    @Autowired
    private PlacesRepository repository;
    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<Places> searchUtils = new DataServiceUtils<>();


    @Override
    protected CrudRepository<Places, Integer> getRepo() {
        return repository;
    }

    @Override
    protected EntityManager getEntityManager() {
        return entityManager;
    }

    @Override
    protected Class<Places> getModelClass() {
        return Places.class;
    }

    @Override
    protected DataServiceUtils<Places> getSearchUtils() {
        return searchUtils;
    }

    @Transactional
    protected Places savePlaces(Places places) {
        return repository.save(places);
    }

    public Optional<Places> getPlacesById(Integer id) {
        return repository.findById(id);
    }

}
