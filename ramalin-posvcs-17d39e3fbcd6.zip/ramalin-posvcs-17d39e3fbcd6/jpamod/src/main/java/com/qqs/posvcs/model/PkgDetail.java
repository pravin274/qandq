package com.qqs.posvcs.model;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Entity
@Table(name = "pkgdetail", schema = "qqordermgmnt", catalog = "")
public class PkgDetail {
    private int id;
    private Integer pkgId;
    private Integer invoiceLineItemId;
    private BigDecimal weightPrPiece;
    private Integer qty;
    private Boolean isDeleted;
    private Timestamp createdDt;
    private Timestamp modifiedDt;
    private Integer createdBy;
    private Integer modifiedBy;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "pkgId")
    public Integer getPkgId() {
        return pkgId;
    }

    public void setPkgId(Integer pkgId) {
        this.pkgId = pkgId;
    }

    @Column(name = "invoiceLineItemId")
    public Integer getInvoiceLineItemId() {
        return invoiceLineItemId;
    }

    public void setInvoiceLineItemId(Integer invoiceId) {
        this.invoiceLineItemId = invoiceId;
    }

    @Column(name = "weightPrPiece")
    public BigDecimal getWeightPrPiece() {
        return weightPrPiece;
    }

    public void setWeightPrPiece(BigDecimal weightPrPiece) {
        this.weightPrPiece = weightPrPiece;
    }


    @Column(name = "qty")
    public Integer getQty() {
        return qty;
    }

    public void setQty(Integer qty) {
        this.qty = qty;
    }


    @Column(name = "isDeleted")
    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }


    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PkgDetail that = (PkgDetail) o;

        if (id != that.id) return false;
        if (pkgId != null ? !pkgId.equals(that.pkgId) : that.pkgId != null) return false;
        if (invoiceLineItemId != null ? !invoiceLineItemId.equals(that.invoiceLineItemId) : that.invoiceLineItemId != null) return false;
        if (weightPrPiece != null ? !weightPrPiece.equals(that.weightPrPiece) : that.weightPrPiece != null) return false;
        if (qty != null ? !qty.equals(that.qty) : that.qty != null) return false;
        if (isDeleted != null ? !isDeleted.equals(that.isDeleted) : that.isDeleted != null) return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (createdDt != null ? !createdDt.equals(that.createdDt) : that.createdDt != null) return false;
        if (modifiedBy != null ? !modifiedBy.equals(that.modifiedBy) : that.modifiedBy != null) return false;
        if (modifiedDt != null ? !modifiedDt.equals(that.modifiedDt) : that.modifiedDt != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (pkgId != null ? pkgId.hashCode() : 0);
        result = 31 * result + (invoiceLineItemId != null ? invoiceLineItemId.hashCode() : 0);
        result = 31 * result + (weightPrPiece != null ? weightPrPiece.hashCode() : 0);
        result = 31 * result + (qty != null ? qty.hashCode() : 0);
        result = 31 * result + (isDeleted != null ? isDeleted.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDt != null ? createdDt.hashCode() : 0);
        result = 31 * result + (modifiedBy != null ? modifiedBy.hashCode() : 0);
        result = 31 * result + (modifiedDt != null ? modifiedDt.hashCode() : 0);
        return result;
    }
}
