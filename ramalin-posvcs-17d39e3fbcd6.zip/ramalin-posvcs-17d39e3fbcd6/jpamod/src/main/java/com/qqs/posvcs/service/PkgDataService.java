package com.qqs.posvcs.service;

import com.qqs.posvcs.model.PkgCheckList;
import com.qqs.posvcs.model.PkgMaster;
import com.qqs.posvcs.model.PkgDetail;
import com.qqs.posvcs.repository.PkgCheckListRepository;
import com.qqs.posvcs.repository.PkgMasterRepository;
import com.qqs.posvcs.repository.PkgDetailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Component
public class PkgDataService {
    @Autowired
    private PkgMasterRepository repository;
    @Autowired
    private PkgDetailRepository pkgDetailRepository;

    public Optional<List<PkgMaster>> findPkgByInvoice(Integer invoiceId) {
        return repository.findPkgByInvoice(invoiceId);
    }

    public Optional<List<PkgDetail>> findPkgDetailByInvoiceLineItemIds(List<Integer> invoiceLineItemIds) {
        return pkgDetailRepository.findAllByInvoiceLineItemIdIn(invoiceLineItemIds);
    }



    @Transactional
    public Iterable<PkgMaster> saveAllPkgMaster(Iterable<PkgMaster> item) {
        return repository.saveAll(item);
    }

    @Transactional
    public Iterable<PkgDetail> saveAllPkgDetails(Iterable<PkgDetail> item) {
        return pkgDetailRepository.saveAll(item);
    }
}
