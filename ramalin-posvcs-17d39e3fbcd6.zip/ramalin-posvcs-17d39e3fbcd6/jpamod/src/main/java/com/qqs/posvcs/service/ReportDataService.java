package com.qqs.posvcs.service;

import com.qqs.posvcs.model.InvoiceReportData;
import com.qqs.posvcs.model.PendingOrderResult;
import com.qqs.posvcs.model.PoTrackReport;
import com.qqs.posvcs.model.SalesOrderResult;
import com.qqs.posvcs.repository.InvoiceRepository;
import com.qqs.posvcs.repository.PoTrackRepository;
import com.qqs.posvcs.repository.PurchOrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class ReportDataService  {

    @Autowired
    private PurchOrderRepository poRepository;

    @Autowired
    private InvoiceRepository invoiceRepository;

    @Autowired
    private PoTrackRepository poTrackRepository;

    public Optional<List<Object[]>>  getCustWiseOrderReportData(String fromDate, String toDate, List<String> selectedItemIds) {
        return poRepository.findCustWiseOrderReportData(fromDate, toDate, selectedItemIds);
    }

    public Optional<List<Object[]>>  getCustWiseOrderReportAllData (String fromDate, String toDate) {
        return poRepository.findCustWiseOrderReportAllData(fromDate, toDate);
    }

    public Optional<List<Object[]>>  getPlantWiseOrderReportData(String fromDate, String toDate, List<String> selectedItemIds) {
        return poRepository.findPlantWiseOrderReportData(fromDate, toDate, selectedItemIds);
    }

    public Optional<List<Object[]>>  getPlantWiseOrderReportAllData (String fromDate, String toDate) {
        return poRepository.findPlantWiseOrderReportAllData(fromDate, toDate);
    }

    public Optional<List<Object[]>>  getDomainWiseOrderReportData(String fromDate, String toDate, List<String> selectedItemIds) {
        return poRepository.findDomainWiseOrderReportData(fromDate, toDate, selectedItemIds);
    }

    public Optional<List<Object[]>>  getDomainWiseOrderReportAllData (String fromDate, String toDate) {
        return poRepository.findDomainWiseOrderReportAllData(fromDate, toDate);
    }

    public Optional<List<Object[]>>  getGeoWiseOrderReportData(String fromDate, String toDate, List<String> selectedItemIds) {
        return poRepository.findGeoWiseOrderReportData(fromDate, toDate, selectedItemIds);
    }

    public Optional<List<Object[]>>  getGeoWiseOrderReportAllData (String fromDate, String toDate) {
        return poRepository.findGeoWiseOrderReportAllData(fromDate, toDate);
    }

    public Optional<List<Object[]>>  getCustWiseSalesReportData(String fromDate, String toDate, List<String> selectedItemIds) {
        return poRepository.findCustWiseSalesReportData(fromDate, toDate, selectedItemIds);
    }

    public Optional<List<Object[]>>  getCustWiseSalesReportAllData (String fromDate, String toDate) {
        return poRepository.findCustWiseSalesReportAllData(fromDate, toDate);
    }

    public Optional<List<Object[]>>  getPlantWiseSalesReportData(String fromDate, String toDate, List<String> selectedItemIds) {
        return poRepository.findPlantWiseSalesReportData(fromDate, toDate, selectedItemIds);
    }

    public Optional<List<Object[]>>  getPlantWiseSalesReportAllData (String fromDate, String toDate) {
        return poRepository.findPlantWiseSalesReportAllData(fromDate, toDate);
    }

    public Optional<List<Object[]>>  getDomainWiseSalesReportData(String fromDate, String toDate, List<String> selectedItemIds) {
        return poRepository.findDomainWiseSalesReportData(fromDate, toDate, selectedItemIds);
    }

    public Optional<List<Object[]>>  getDomainWiseSalesReportAllData (String fromDate, String toDate) {
        return poRepository.findDomainWiseSalesReportAllData(fromDate, toDate);
    }

    public Optional<List<Object[]>>  getGeoWiseSalesReportData(String fromDate, String toDate, List<String> selectedItemIds) {
        return poRepository.findGeoWiseSalesReportData(fromDate, toDate, selectedItemIds);
    }

    public Optional<List<Object[]>>  getGeoWiseSalesReportAllData (String fromDate, String toDate) {
        return poRepository.findGeoWiseSalesReportAllData(fromDate, toDate);
    }

    public List<SalesOrderResult> getOrderData(String fromDate, String toDate) {
        return poRepository.findOrderData(fromDate, toDate);
    }

    public List<PendingOrderResult> getPendingOrdersData (String fromDate, String toDate) {
        return poRepository.findPendingOrders(fromDate, toDate);
    }

    public List<InvoiceReportData> getInvoiceReportData (String fromDate, String toDate) {
        return invoiceRepository.findInvoiceReportData(fromDate, toDate);
    }

    public List<PoTrackReport> getPoTrackReportData (String fromDate, String toDate) {
        return poTrackRepository.findPoTrackReportData(fromDate, toDate);
    }




}
