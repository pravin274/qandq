package com.qqs.posvcs;

import com.qqs.posvcs.model.PkgMaster;
import com.qqs.posvcs.model.PoLineTool;
import com.qqs.posvcs.service.POLineItemDataService;
import com.qqs.posvcs.service.PkgDataService;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class TestPurchOrder {
    static ApplicationContext context;

    @BeforeClass
    public static void setup() {
        context = new ClassPathXmlApplicationContext("applicationContext.xml");
    }

    @Test
    public void testRetrieveByCategory() {
        POLineItemDataService service = context.getBean(POLineItemDataService.class);
        Iterable<PoLineTool> result = service.getAllPoLineToolsById(Arrays.asList(new Integer[]{1}));
        result.forEach(r -> {
            System.out.println(r);
        });
    }

    @Test
    public void testPkgDetails() {
        PkgDataService service = context.getBean(PkgDataService.class);
        Optional<List<PkgMaster>> result = service.findPkgByInvoice(1);
        result.get().forEach(r -> System.out.println(r));
    }
}
