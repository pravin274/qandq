package com.qqs.posvcs;

import com.qqs.posvcs.model.*;
import com.qqs.posvcs.service.*;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class TestSaveData {
    static ApplicationContext context;

    @BeforeClass
    public static void setup() {
        context = new ClassPathXmlApplicationContext("applicationContext.xml");
    }

    @Test
    public void testSaveAddress() {
        AddressDataService dataService = context.getBean(AddressDataService.class);
        Address address = new Address();
        address.setParentId(1);
        address.setType("H");
        address.setParentEntity("C");
        address.setLineOne("24");
        address.setLineTwo("Gaskill");
//        address.setStreetNo("2");
//        address.setStreetName("Gaskill");
        address.setLineThree("dummy");
//        address.setCity("Mt Laurel");
//        address.setProvince("NJ");
//        address.setCountry("US");
        address.setPostalCd("08054");
        address.setCreatedDt(new Timestamp(System.currentTimeMillis()));
        Address addressFromDB = dataService.saveAddress(address);
        Optional<Address> addressOpt = dataService.getAddressById(address.getId());
        System.out.println(addressOpt.get());
        Assert.assertEquals(addressFromDB.getCity(), addressOpt.get().getCity());
    }

    @Test
    public void testPurchOrder(){
        PurchOrderDataService dataService = context.getBean(PurchOrderDataService.class);
        PurchOrder po = dataService.getPurchaseOrderById(1).get();
        po.setDvryTermsId(po.getDvryTermsId());
        PurchOrder saved = dataService.savePurchaseorder(po);
        System.out.println(saved.getDvryTermsId());
        Assert.assertEquals(po.getDvryTermsId(), saved.getDvryTermsId());
    }

    @Test
    public void testPkgCheckList() {
        PkgDataService dataService = context.getBean(PkgDataService.class);
        PkgCheckList checkList = new PkgCheckList();
        checkList.setCode("VLD");
        checkList.setPkgId(1);
        checkList.setImgLocation("undisclosed");
        checkList.setComments("Test list");
        List<PkgCheckList> items = new ArrayList<>(1);
        items.add(checkList);
//        dataService.saveAllPkgCheckList(items);
    }
}
