package com.qqs.posvcs;

import com.qqs.posvcs.model.*;
import com.qqs.posvcs.service.PartDataService;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class TestPartData {
    static ApplicationContext context;

    @BeforeClass
    public static void setup() {
        context = new ClassPathXmlApplicationContext("applicationContext.xml");
    }

    @Test
    public void testRetrievePart() {
        PartDataService dataService = context.getBean(PartDataService.class);
        Optional<Part> part = dataService.getPartById(1);
        System.out.println(part.get());

        //chronologies
        Optional<List<PartChronology>> chronologies = dataService.getChronologyByPart(1);
        System.out.println(chronologies.get());

        //domains
        Optional<List<PartDomain>> domains = dataService.getDomainByPart(1);
        System.out.println(domains.get());

        //images
        Optional<List<PartImage>> images = dataService.getImageByPart(1);
        System.out.println(images.get());

        //prices
        Optional<List<PartPrice>> prices = dataService.getPriceByPart(1);
        System.out.println(prices.get());
       
        // Standard
        Optional<List<PartStandard>> standard = dataService.getStandardByPart(1);
        System.out.println(standard.get());
       

    }

    @Test
    public void testSavePart(){
        PartDataService dataService = context.getBean(PartDataService.class);
        Part part = new Part();
        part.setName("Test Part");
        part.setNumber("1234");
        part.setMbq(10);
        Part saved = dataService.savePart(part);
        Assert.assertEquals(10l, (long)saved.getMbq());
    }

    @Test
    public void testSavePartPrice(){
        PartDataService dataService = context.getBean(PartDataService.class);
        PartPrice pp = new PartPrice();
        pp.setPartId(1);
        pp.setCurrency("INR");
        pp.setValue(35.22);
        pp.setPriceDesc("Test");
        pp.setDefaultInd("N");
        pp.setEffectiveDt(new Timestamp(1549883497000l));
        pp.setExpiryDt(new Timestamp(1549883497000l));
        pp.setCreatedDt(new Timestamp(1549883497000l));
        pp.setCreatedBy(1);
        pp.setModifiedDt(new Timestamp(1549883497000l));
        pp.setModifiedBy(1);
        List<PartPrice> toSave = Arrays.asList(new PartPrice[]{pp});
        dataService.savePrice(toSave);
    }
}
