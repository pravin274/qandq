package com.qqs.posvcs;

import com.qqs.posvcs.model.*;
import com.qqs.posvcs.service.*;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.*;

public class TestMasterData {
    static ApplicationContext context;

    @BeforeClass
    public static void setup() {
        context = new ClassPathXmlApplicationContext("applicationContext.xml");
    }

    @Test
    public void testRetrieveAddress() {
        AddressDataService dataService = context.getBean(AddressDataService.class);
        Optional<Address> address = dataService.getAddressById(1);
        System.out.println(address.get());
    }

    @Test
    public void testRetrieveEmail() {
        EmailDataService dataService = context.getBean(EmailDataService.class);
        Optional<Email> email = dataService.getEmailById(1);
        System.out.println(email.get());
    }

    @Test
    public void testRetrieveCompany() {
        CompanyDataService dataService = context.getBean(CompanyDataService.class);
        Optional<Company> company = dataService.getCompanyById(1);
        System.out.println(company.get());
    }

    @Test
    public void testSearchCompany() {
        CompanyDataService dataService = context.getBean(CompanyDataService.class);
        List<SearchCriteria> params = new ArrayList<>(1);
        SearchCriteria sc = new SearchCriteria();
        sc.setKey("taxId");
        sc.setValue("23-456789");
        sc.setOperation(":");
        params.add(sc);
        Optional<List<Company>> company = dataService.searchClient(params);
        System.out.println(company.get());
    }

    @Test
    public void testRetrievePhone() {
        PhoneDataService dataService = context.getBean(PhoneDataService.class);
        Optional<Phone> phone = dataService.getPhoneById(1);
        System.out.println(phone.get());
    }

    @Test
    public void testRetrievePlant() {
        PlantDataService dataService = context.getBean(PlantDataService.class);
        Optional<Plant> plant = dataService.getPlantById(1);
        System.out.println(plant.get());
    }

    @Test
    public void testRetrievePlantByCompany() {
        PlantDataService dataService = context.getBean(PlantDataService.class);
        Optional<List<Plant>> plant = dataService.getPlantsByCompany(1);
        System.out.println(plant.get());
    }

    @Test
    public void testRetrieveAddressByCompany() {
        AddressDataService dataService = context.getBean(AddressDataService.class);
        Optional<List<Address>> plant = dataService.findAddressesByCompany(1);
        System.out.println(plant.get());
    }

    @Test
    public void testRetrievePhoneByCompany() {
        PhoneDataService dataService = context.getBean(PhoneDataService.class);
        Optional<List<Phone>> plant = dataService.findPhoneByCompany(1);
        System.out.println(plant.get());
    }

    @Test
    public void testRetrieveEmailByCompany() {
        EmailDataService dataService = context.getBean(EmailDataService.class);
        Optional<List<Email>> plant = dataService.findEmailByCompany(1);
        System.out.println(plant.get());
    }

    @Test
    public void testRetrievePOByCompany() {
        PurchOrderDataService dataService = context.getBean(PurchOrderDataService.class);
        Optional<List<PurchOrder>> po = dataService.findPurchOrderByCompany(1);
        System.out.println(po.get());
    }

    @Test
    public void testUpdatePO() {
        PurchOrderDataService dataService = context.getBean(PurchOrderDataService.class);
        Optional<List<PurchOrder>> po = dataService.findPurchOrderByCompany(1);
        System.out.println(po.get());
        PurchOrder single = po.get().get(0);
        single.setModifiedBy(33);
        PurchOrder saved = dataService.savePurchaseorder(single);
        System.out.println(saved);
    }

    @Test
    public void testRetrievePOLineItemById() {
        POLineItemDataService dataService = context.getBean(POLineItemDataService.class);
        Optional<PoLineItem> po = dataService.getPOLineItemById(1);
        System.out.println(po.get());
    }

    @Test
    public void testSearchPOByCompany() {
        PurchOrderDataService dataService = context.getBean(PurchOrderDataService.class);
        SearchCriteria sc = new SearchCriteria();
        sc.setKey("companyId");
        sc.setValue("1");
        sc.setOperation(":");
        List<SearchCriteria> criteria = new ArrayList<>();
        criteria.add(sc);
        Optional<List<PurchOrder>> po = dataService.searchPurchaseOrders(criteria);
        System.out.println(po.get());
    }

    @Test
    public void testRetrieveInvoice() {
        InvoiceDataService dataService = context.getBean(InvoiceDataService.class);
        Optional<Invoice> invoice = dataService.getEntityById(1);
        System.out.println(invoice.get());
    }
}
