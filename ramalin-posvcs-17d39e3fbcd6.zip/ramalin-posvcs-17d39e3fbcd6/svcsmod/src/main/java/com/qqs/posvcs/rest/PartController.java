package com.qqs.posvcs.rest;

import com.qqs.invsvcs.api.InvRequirements;
import com.qqs.posvcs.api.parts.*;
import com.qqs.posvcs.service.PartService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/part")
public class PartController {

    @Resource
    private PartService service;

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_PART_READ','ROLE_ALL_READ','ROLE_PART_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/byId", produces = "application/json")
    public ResponseEntity<Part> getPartById(@RequestParam Integer id,
                                            HttpServletRequest request) throws QQBusinessException {
        Part po = service.getPartById(id, request);
        ResponseEntity<Part> result = new ResponseEntity(po, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_PART_READ','ROLE_ALL_READ','ROLE_PART_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/form/search", produces = "application/json")
    public ResponseEntity<List<Part>> searchParts(@RequestParam Map<String, String> searchParam,
                                                  @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                  HttpServletRequest request) throws QQBusinessException {
        List<Part> formList = service.searchParts(searchParam, exactMatch.orElse(false));
        ResponseEntity<List<Part>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_PART_READ','ROLE_ALL_READ','ROLE_PART_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/form/getTotalParts", produces = "application/json")
    public ResponseEntity<Integer> getTotalParts(@RequestParam Map<String, String> searchParam,
                                                  @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                  HttpServletRequest request) throws QQBusinessException {
        Integer totalPartCount = service.getTotalParts(searchParam, exactMatch.orElse(false));
        ResponseEntity<Integer> result = new ResponseEntity(totalPartCount, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_PART_READ','ROLE_ALL_READ','ROLE_PART_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/standard/search", produces = "application/json")
    public ResponseEntity<List<Standard>> searchStandards(@RequestParam Map<String, String> searchParam,
                                                  @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                  HttpServletRequest request) throws QQBusinessException {
        List<Standard> formStandardList = service.searchStandards(searchParam, exactMatch.orElse(false));
        ResponseEntity<List<Standard>> result = new ResponseEntity(formStandardList, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_PART_READ','ROLE_ALL_READ','ROLE_PART_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/childpart", produces = "application/json")
    public ResponseEntity<List<Part>> retrieveChildParts(@RequestParam Integer partId,
                                                         HttpServletRequest request) throws QQBusinessException, IllegalAccessException, InstantiationException {
        List<Part> formList = service.getChildParts(partId);
        ResponseEntity<List<Part>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_PART_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/save", produces = "application/json")
    public ResponseEntity<Part> savePart(@RequestBody Part form, HttpServletRequest request) throws QQBusinessException {
        Part saved = service.savePart(form, request);
        ResponseEntity<Part> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_PART_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "standard/master/save", produces = "application/json")
    public ResponseEntity<Standard> saveMasterStandard(@RequestBody Standard form) throws QQBusinessException {
        Standard saved = service.saveMasterStandard(form);
        ResponseEntity<Standard> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_PART_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/chronology/save", produces = "application/json")
    public ResponseEntity<List<PartChronology>> savePartChronology(@RequestBody List<PartChronology> form) throws QQBusinessException {
        List<PartChronology> saved = service.savePartChronology(form);
        ResponseEntity<List<PartChronology>> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_PART_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/commodity/save", produces = "application/json")
    public ResponseEntity<List<PartCommodity>> savePartCommodity(@RequestBody List<PartCommodity> form) throws QQBusinessException {
        List<PartCommodity> saved = service.savePartCommodity(form);
        ResponseEntity<List<PartCommodity>> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_PART_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/price/save", produces = "application/json")
    public ResponseEntity<List<PartPrice>> savePartPrice(@RequestBody List<PartPrice> form) throws QQBusinessException {
        List<PartPrice> saved = service.savePartPrice(form);
        ResponseEntity<List<PartPrice>> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_PART_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/domain/save", produces = "application/json")
    public ResponseEntity<List<PartDomain>> savePartDomain(@RequestBody List<PartDomain> form) throws QQBusinessException {
        List<PartDomain> saved = service.savePartDomain(form);
        ResponseEntity<List<PartDomain>> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_PART_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/childpart/save", produces = "application/json")
    public ResponseEntity<List<PartRelationxRef>> saveChildParts(@RequestBody List<PartRelationxRef> form) throws QQBusinessException, IllegalAccessException, InstantiationException {
        List<PartRelationxRef> saved = service.saveChildParts(form);
        ResponseEntity<List<PartRelationxRef>> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_PART_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/standard/save", produces = "application/json")
    public ResponseEntity<List<PartStandard>> saveStandards(@RequestBody List<PartStandard> form) throws QQBusinessException {
        List<PartStandard> saved = service.saveStandards(form);
        ResponseEntity<List<PartStandard>> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_PART_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/customernotes/save", produces = "application/json")
    public ResponseEntity<List<PartCustomerRequirement>> saveCustomerRequirement(@RequestBody List<PartCustomerRequirement> form) throws QQBusinessException {
        List<PartCustomerRequirement> saved = service.saveCustomerRequirement(form);
        ResponseEntity<List<PartCustomerRequirement>> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_PART_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/revisionamendment/save", produces = "application/json")
    public ResponseEntity<List<PartRevisionAmendment>> saveRevisionAmendment(@RequestBody List<PartRevisionAmendment> form) throws QQBusinessException {
        List<PartRevisionAmendment> saved = service.saveRevisionAmendment(form);
        ResponseEntity<List<PartRevisionAmendment>> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_PART_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/partimage/save", produces = "application/json")
    public ResponseEntity<List<PartImage>> savePartImage(@RequestBody List<PartImage> form) throws QQBusinessException {
        List<PartImage> saved = service.savePartImage(form);
        ResponseEntity<List<PartImage>> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }


    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_PART_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/partclonesubsidiary", produces = "application/json")
    public ResponseEntity<String> clonePartSubsidiary(@RequestParam Integer  clonePartId , @RequestParam Integer  newPartId,
                                                        HttpServletRequest request) throws QQBusinessException {
        String saved = service.clonePartSubsidiary(clonePartId, newPartId);
        ResponseEntity<String> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_PART_READ','ROLE_ALL_READ','ROLE_PART_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/all", produces = "application/json")
    public ResponseEntity<Map<Integer, String>> getAllParts(HttpServletRequest request) throws QQBusinessException {
        Map<Integer, String> parts = service.getAllParts();
        ResponseEntity<Map<Integer, String>> result = new ResponseEntity(parts, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_PRODUCT_REQ_READ','ROLE_ALL_WRITE','ROLE_PRODUCT_REQ_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/partReq", produces = "application/json")
    public ResponseEntity<List<InvRequirements>> getPartReq(@RequestParam Timestamp reqFromDate,
                                                            HttpServletRequest request) throws QQBusinessException {
        List<InvRequirements> invRequirement = service.getInvRequirements(reqFromDate, request);
        ResponseEntity<List<InvRequirements>> result = new ResponseEntity(invRequirement, HttpStatus.OK);
        return result;
    }

}
