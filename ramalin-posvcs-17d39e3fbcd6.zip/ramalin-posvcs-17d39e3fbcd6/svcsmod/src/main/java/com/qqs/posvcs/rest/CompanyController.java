package com.qqs.posvcs.rest;

import com.qqs.posvcs.api.Company;
import com.qqs.posvcs.service.CompanyService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/company")
public class CompanyController {

    @Resource
    CompanyService companyService;

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_COMPANY_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/save", produces = "application/json")
    public ResponseEntity<Company> saveCompany(@RequestBody com.qqs.posvcs.api.Company form) throws QQBusinessException {
        com.qqs.posvcs.api.Company saved = companyService.saveCompany(form);
        ResponseEntity<Company> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_COMPANY_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/byId", produces = "application/json")
    public ResponseEntity<Company> getCompanyById(@RequestParam Integer id,
                                                  HttpServletRequest request) throws QQBusinessException {
        Company company = companyService.getCompanyById(id);
        ResponseEntity<Company> result = new ResponseEntity(company, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_MASTER_WRITE', 'ROLE_ALL_READ', 'ROLE_COMPANY_READ')")
    @RequestMapping(method = RequestMethod.GET, value = "/form/search", produces = "application/json")
    public ResponseEntity<List<Company>> searchClient(@RequestParam Map<String, String> searchParam,
                                                      @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                      HttpServletRequest request) throws QQBusinessException {
        List<Company> formList = companyService.searchClients(searchParam, exactMatch.orElse(false));
        ResponseEntity<List<Company>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_COMPANY_READ')")
    @RequestMapping(method = RequestMethod.GET, value = "/all", produces = "application/json")
    public ResponseEntity<List<Company>> getAllBasicInfo(HttpServletRequest request) throws QQBusinessException {
        List<Company> formList = companyService.getAllClients();
        ResponseEntity<List<Company>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }
}
