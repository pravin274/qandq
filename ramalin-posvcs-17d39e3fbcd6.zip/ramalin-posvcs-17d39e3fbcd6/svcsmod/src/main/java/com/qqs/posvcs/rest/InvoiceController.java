package com.qqs.posvcs.rest;

import com.qqs.posvcs.api.billing.Invoice;
import com.qqs.posvcs.api.billing.InvoiceStatus;
import com.qqs.posvcs.service.InvoiceService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/invoice")
public class InvoiceController {

    @Resource
    private InvoiceService service;


    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_INVOICE_WRITE', 'ROLE_INVOICE_READ')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/byId", produces = "application/json")
    public ResponseEntity<Invoice> getInvoiceById(@RequestParam Integer id,
                                                  HttpServletRequest request) throws QQBusinessException {
        Invoice invoice = service.getInvoiceById(id);
        ResponseEntity<Invoice> result = new ResponseEntity(invoice, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_INVOICE_WRITE', 'ROLE_INVOICE_READ')")
    @RequestMapping(method = RequestMethod.GET, value = "/form/search", produces = "application/json")
    public ResponseEntity<List<Invoice>> searchInvoices(@RequestParam Map<String, String> searchParam,
                                                        @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                        HttpServletRequest request) throws QQBusinessException {
        List<Invoice> formList = service.searchInvoices(searchParam, exactMatch.orElse(false));
        ResponseEntity<List<Invoice>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_INVOICE_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/save", produces = "application/json")
    public ResponseEntity<Invoice> saveInvoice(@RequestBody Invoice form) throws QQBusinessException {
        Invoice saved = service.saveInvoice(form);
        ResponseEntity<Invoice> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_INVOICE_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/savePkg", produces = "application/json")
    public ResponseEntity<Invoice> savePkg(@RequestBody Invoice form) throws QQBusinessException {
        Invoice saved = service.savePkg(form);
        ResponseEntity<Invoice> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_INVOICE_WRITE', 'ROLE_INVOICE_STATUS_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/saveInvStatus", produces = "application/json")
    public ResponseEntity<List<InvoiceStatus>> saveInvStatus(@RequestBody List<InvoiceStatus> form) throws QQBusinessException {
        List<InvoiceStatus> saved = service.saveInvStatus(form);
        ResponseEntity<List<InvoiceStatus>> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_INVOICE_WRITE', 'ROLE_INVOICE_READ')")
    @RequestMapping(method = RequestMethod.GET, value =  "/generateInvoice", produces="application/pdf")
    public ResponseEntity<org.springframework.core.io.Resource> generateInvoice(@RequestParam Integer invoiceId, String invoiceType, HttpServletRequest request,
                                HttpServletResponse response) throws QQBusinessException {

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        service.generateInvoice(invoiceId, stream,  invoiceType);
        org.springframework.core.io.Resource file = new ByteArrayResource(stream.toByteArray());
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.put(HttpHeaders.CONTENT_DISPOSITION, Collections.singletonList("attachment; filename=filledapp.pdf"));
        httpHeaders.put(HttpHeaders.CONTENT_TYPE, Collections.singletonList("application/pdf"));
        ResponseEntity<org.springframework.core.io.Resource> result = ResponseEntity
                .ok()
                .headers(httpHeaders)
                .body(file);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_INVOICE_WRITE', 'ROLE_INVOICE_READ')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/byPoNumber", produces = "application/json")
    public ResponseEntity<List<Invoice>> getInvoiceById(@RequestParam String poNumber,
                                                  HttpServletRequest request) throws QQBusinessException {
        List<Invoice> invoice = service.getInvoiceByPo(poNumber);
        ResponseEntity<List<Invoice>> result = new ResponseEntity(invoice, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_INVOICE_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/saveFileName", produces = "application/json")
    public ResponseEntity<Invoice> saveFileName(@RequestParam Integer invoiceId, String awbFileName) throws QQBusinessException {
        Invoice saved = service.saveFileName(invoiceId, awbFileName);
        ResponseEntity<Invoice> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }


}
