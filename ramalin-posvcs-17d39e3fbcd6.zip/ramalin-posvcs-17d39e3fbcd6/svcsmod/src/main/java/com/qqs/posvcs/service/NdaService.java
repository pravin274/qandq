package com.qqs.posvcs.service;

import com.qqs.posvcs.api.Address;
import com.qqs.posvcs.model.NdaForm;
import com.qqs.posvcs.model.Vendor;
import com.qqs.posvcs.service.startup.ApplicationCodeMap;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.pdf.PDFCreateService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.transaction.Transactional;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.qqs.posvcs.api.translation.ParentEntityType.VENDOR;
import static com.qqs.posvcs.service.translate.APITranslator.*;
import static com.qqs.posvcs.utils.Constants.PDF_NDA;
import static com.qqs.posvcs.utils.Constants.VENDOR_ID;


@Component
public class NdaService {

    Logger logger = LoggerFactory.getLogger(NdaForm.class);

    @Resource
    DataService ds;
    @Resource
    SearchCriteriaUtils searchCriteriaUtils;
    @Resource
    private ApplicationCodeMap systemCodeMap;
    @Resource
    private AddressService addressService;


    @Transactional
    public com.qqs.posvcs.api.reports.NdaForm saveNdaForm(com.qqs.posvcs.api.reports.NdaForm source) throws QQBusinessException {

        com.qqs.posvcs.api.reports.NdaForm ndaDataToAPI = null;

        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        try {
            com.qqs.posvcs.model.NdaForm ndaForm = NdaFormToDB.translate(source, com.qqs.posvcs.model.NdaForm.class, true);
            if(ndaForm.getId() > 0) {
                new DateUtils<NdaForm>().setTimeStamp(ndaForm, com.qqs.posvcs.model.NdaForm.class, true);
                ndaForm.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<NdaForm>().setTimeStamp(ndaForm, com.qqs.posvcs.model.NdaForm.class, false);
                ndaForm.setCreatedBy(loggedInUser);
            }

            com.qqs.posvcs.model.NdaForm ndaData = ds.getNdaDS().saveNda(ndaForm);

            ndaDataToAPI = NdaFormToAPI.translate(ndaData, com.qqs.posvcs.api.reports.NdaForm.class, true);
        } catch (Exception e) {
            logger.error("Save error ", e);
            throw new QQBusinessException("NdaForm  save error", e);
        }
        return ndaDataToAPI;
    }

    public com.qqs.posvcs.api.reports.NdaForm getNdaById(Integer id) throws QQBusinessException {
        com.qqs.posvcs.api.reports.NdaForm ndaToAPI = null;
        try {
            Optional<com.qqs.posvcs.model.NdaForm> saved = ds.getNdaDS().getNdaById(id);
            ndaToAPI = NdaFormToAPI.translate(saved.get(), com.qqs.posvcs.api.reports.NdaForm.class, true);
        } catch (Exception e) {
            logger.error("Save error ", e);
            throw new QQBusinessException("NdaForm  retrive error", e);
        }
        return ndaToAPI;
    }

    public List<com.qqs.posvcs.api.reports.NdaForm> searchNdaForm(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<NdaForm>> ndaForm = ds.getNdaDS().searchNda(conditions);
        if (!ndaForm.isPresent())
            throw new QQBusinessException("No NdaForm found for criteria");
        List<com.qqs.posvcs.api.reports.NdaForm> ndaList = null;
        try {
            ndaList = NdaFormToAPI.translate(ndaForm.get(), com.qqs.posvcs.api.reports.NdaForm.class, false);
        } catch (Exception e) {
            logger.error("Translation failed", e);
        }
        return ndaList;
    }

    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"ndaDate", "city", "ndaDateTo"}));
        Map<String, String> operators = new HashMap<>(2);
        operators.put("ndaDate", ">");
        if(params.get("ndaDateTo") != null && params.get("ndaDate") != null) {
            params.put("ndaDate", params.get("ndaDate") + "||" + params.get("ndaDateTo"));
            params.remove("ndaDateTo");
            operators.put("ndaDate", "^");
        } else if(params.get("ndaDateTo") != null) {
            operators.put("ndaDate", "<");
            params.put("ndaDate", params.get("ndaDateTo"));
            params.remove("ndaDateTo");
        }
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, operators, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }

    public void generatenNdaForm(Integer ndaId, ByteArrayOutputStream stream) throws QQBusinessException {
        generateNda(getNdaById(ndaId), stream);
    }

    public void generateNda(com.qqs.posvcs.api.reports.NdaForm ndaForm, ByteArrayOutputStream stream) throws QQBusinessException {

        Map<String, String> ndaFormPdfValueMap = new HashMap<>();
        Map<String, Map<String, com.qqs.posvcs.api.common.Codes>> codesMap = systemCodeMap.getCodeMap();

        // SimpleDateFormat
        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
        format.setTimeZone(TimeZone.getTimeZone(codesMap.get("APP_TIME_ZONE").get("TZ").getDescription()));

        String ndaDate = format.format(ndaForm.getNdaDate());

        Optional<Vendor> vendor = ds.getVendorDS().getVendorById(VENDOR_ID);
        String vendorGstinNo = "";
        String vendorName = "";
        String vendorAddressLineOne = "";
        String vendorAddressLineTwo = "";
        String vendorCity = "";
        String vendorPin = "";
        String ContactNo = "+91 97888 51016";
        String vendorRepTitle = "MANAGING PARTNER";

        if (vendor.isPresent()) {
            vendorName = vendor.get().getVendorName();
            vendorGstinNo = vendor.get().getGstinNo();
        }

        List<Address> vendorAddressList = (List) addressService.getAddressByParentType(VENDOR.getDbCode(), VENDOR_ID);
        Address vendorAddress = new Address();
        if (vendorAddressList != null && vendorAddressList.size() > 0) {
            vendorAddress = vendorAddressList.get(0);
            StringBuffer vendorAddressSB = new StringBuffer();
            vendorAddressLineOne = vendorAddress.getLineOne() == null ? "" : vendorAddress.getLineOne();
            vendorAddressLineTwo = vendorAddress.getLineTwo() == null ? "" : vendorAddress.getLineTwo();
//            vendorAddressLineOne = vendorAddress.getStreetNo() == null ? "" : vendorAddress.getStreetNo();
//            vendorAddressLineTwo = vendorAddress.getStreetName() == null ? "" : vendorAddress.getStreetName();
            vendorPin = vendorAddress.getPostalCd() == null ? "" :  vendorAddress.getPostalCd();
            vendorAddressSB.append(vendorAddress.getLineTwo() == null ? "" : vendorAddress.getLineTwo() + ",");
            vendorAddressSB.append(vendorAddress.getCity() == null ? "" : vendorAddress.getCity());
            vendorCity = vendorAddressSB.toString();
        }

        String firstPara = "This agreement is between Q & Q Solutions & related customers (hereinafter Q&Q RC, and M/s. " +
                ndaForm.getCompanyName() + ' ' + ndaForm.getAddressLine1() + ' ' + ndaForm.getAddressLine2() + ' ' +
                ndaForm.getCity() + ' ' + ndaForm.getPin() + ' ' + ndaForm.getState() +
                " (hereafter SUPPLIER) having a place of business at";

        ndaFormPdfValueMap.put("paragraph", firstPara);
        ndaFormPdfValueMap.put("supplierCompanyName", ndaForm.getCompanyName());
        ndaFormPdfValueMap.put("supplierAddressLineOne", ndaForm.getAddressLine1());
        ndaFormPdfValueMap.put("supplierAddressLineTwo", ndaForm.getAddressLine2());
        ndaFormPdfValueMap.put("supplierCity", ndaForm.getCity());
        ndaFormPdfValueMap.put("supplierPin", ndaForm.getPin());
        ndaFormPdfValueMap.put("supplierGstNo", ndaForm.getGstNo());
        ndaFormPdfValueMap.put("supplierContactNo", ndaForm.getContactNO());
        ndaFormPdfValueMap.put("supplierRepName", ndaForm.getSuppRepName());
        ndaFormPdfValueMap.put("supplierRepTitle", ndaForm.getSupprepTitle());
        ndaFormPdfValueMap.put("ndaDate", ndaDate);
        ndaFormPdfValueMap.put("vendorRepName", ndaForm.getQqRep());
        ndaFormPdfValueMap.put("vendorCompnayName", vendorName.toUpperCase());
        ndaFormPdfValueMap.put("vendorAddressLineOne", vendorAddressLineOne.toUpperCase());
        ndaFormPdfValueMap.put("vendorAddressLineTwo", vendorAddressLineTwo.toUpperCase());
        ndaFormPdfValueMap.put("vendorCity", vendorCity.toUpperCase());
        ndaFormPdfValueMap.put("vendorPin", vendorPin);
        ndaFormPdfValueMap.put("vendorGstNo", vendorGstinNo.toUpperCase());
        ndaFormPdfValueMap.put("vendorContactNo", ContactNo);
        ndaFormPdfValueMap.put("vendorRepTitle", vendorRepTitle);
        ndaFormPdfValueMap.put("supplierCompanyNameAgreement", ndaForm.getCompanyName().toUpperCase());

        try {
            PDFCreateService service = new PDFCreateService();
            String templateName;
            templateName = PDF_NDA;
            service.getPdfContent(ndaFormPdfValueMap, stream, templateName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
