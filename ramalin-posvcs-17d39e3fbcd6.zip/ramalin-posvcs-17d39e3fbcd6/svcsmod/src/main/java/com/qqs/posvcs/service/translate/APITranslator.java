package com.qqs.posvcs.service.translate;

import com.qqs.posvcs.api.reports.SalesOrderReportData;
import com.qqs.posvcs.model.*;
import com.qqs.qqsoft.utils.ApiUtils;
import com.qqs.qqsoft.utils.SearchCriteria;

public class APITranslator {
    public static ApiUtils<PurchOrder, com.qqs.posvcs.api.PurchOrder> poToAPI = new ApiUtils<>();
    public static ApiUtils<PoLineItem, com.qqs.posvcs.api.PoLineItem> lineItemToAPI = new ApiUtils<>();
    public static ApiUtils<Part, com.qqs.posvcs.api.parts.Part> partsToAPI = new ApiUtils<>();
    public static ApiUtils<Address, com.qqs.posvcs.api.Address> addressToAPI = new ApiUtils<>();
    public static ApiUtils<Phone, com.qqs.posvcs.api.Phone> phoneToAPI = new ApiUtils<>();
    public static ApiUtils<Email, com.qqs.posvcs.api.Email> emailToAPI = new ApiUtils<>();
    public static ApiUtils<Company, com.qqs.posvcs.api.Company> companyToAPI = new ApiUtils<>();
    public static ApiUtils<Plant, com.qqs.posvcs.api.Plant> plantToAPI = new ApiUtils<>();
    public static ApiUtils<Countries, com.qqs.posvcs.api.Countries> countriesToAPI = new ApiUtils<>();
    public static ApiUtils<States, com.qqs.posvcs.api.States> statesToAPI = new ApiUtils<>();
    public static ApiUtils<Cities, com.qqs.posvcs.api.Cities> citiesToAPI = new ApiUtils<>();
    public static ApiUtils<CurrencyExchangeRate, com.qqs.posvcs.api.CurrencyExchangeRate> currencyExchangeRateToAPI = new ApiUtils<>();

    public static ApiUtils<People, com.qqs.posvcs.api.common.People> peopleToAPI = new ApiUtils<>();
    public static ApiUtils<PartPrice, com.qqs.posvcs.api.parts.PartPrice> partPriceToAPI = new ApiUtils<>();
    public static ApiUtils<PartCommodity, com.qqs.posvcs.api.parts.PartCommodity> partCommodityToAPI = new ApiUtils<>();
    public static ApiUtils<PartChronology, com.qqs.posvcs.api.parts.PartChronology> partChronologyToAPI = new ApiUtils<>();
    public static ApiUtils<PartRelationxRef,com.qqs.posvcs.api.parts.PartRelationxRef> partRelationxRefToAPI = new ApiUtils<>();
    public static ApiUtils<PartDomain, com.qqs.posvcs.api.parts.PartDomain> partDomainToAPI = new ApiUtils<>();
    public static ApiUtils<PoLineTool, com.qqs.posvcs.api.PoLineTool> poLineToolToAPI = new ApiUtils<>();
    public static ApiUtils<PartStandard,com.qqs.posvcs.api.parts.PartStandard> partStandardToAPI = new ApiUtils<>();
    public static ApiUtils<PartStandard,com.qqs.posvcs.api.parts.PartCustomerRequirement> PartCustomerRequirementToAPI = new ApiUtils<>();
    public static ApiUtils<PartStandard,com.qqs.posvcs.api.parts.PartRevisionAmendment> PartRevisionAmendmentToAPI = new ApiUtils<>();
    public static ApiUtils<PartImage,com.qqs.posvcs.api.parts.PartImage> PartImageToAPI = new ApiUtils<>();
    public static ApiUtils<Standard, com.qqs.posvcs.api.parts.Standard> standardsToAPI = new ApiUtils<>();
    public static ApiUtils<Invoice, com.qqs.posvcs.api.billing.Invoice> invoiceToAPI = new ApiUtils<>();
    public static ApiUtils<InvoiceLineItem, com.qqs.posvcs.api.billing.InvoiceLineItem> invoiceLineToAPI = new ApiUtils<>();
    public static ApiUtils<SLIDocuments, com.qqs.posvcs.api.billing.SLIDocuments> sliDocumentsToAPI = new ApiUtils<>();
    public static ApiUtils<PkgMaster, com.qqs.posvcs.api.billing.PkgMaster> pkgMasterToAPI = new ApiUtils<>();
    public static ApiUtils<PkgDetail, com.qqs.posvcs.api.billing.PkgDetail> pkgDetailToAPI = new ApiUtils<>();
    public static ApiUtils<Places, com.qqs.posvcs.api.Places> placesToAPI = new ApiUtils<>();
    public static ApiUtils<Bank, com.qqs.posvcs.api.billing.Bank> bankToAPI = new ApiUtils<>();
    public static ApiUtils<Invoicexrefpo,com.qqs.posvcs.api.billing.Invoicexrefpo> invoicexRefPoToAPI = new ApiUtils<>();
    public static ApiUtils<Vendor, com.qqs.posvcs.api.Vendor> vendorToAPI = new ApiUtils<>();
    public static ApiUtils<Object[], SalesOrderReportData> salesOrderReportToAPI = new ApiUtils<>();
    public static ApiUtils<PlantDeliveryTerms, com.qqs.posvcs.api.PlantDeliveryTerms> plantDeliveryTermsToAPI = new ApiUtils<>();
    public static ApiUtils<PlantPaymentTerms, com.qqs.posvcs.api.PlantPaymentTerms> plantPaymentTermsToAPI = new ApiUtils<>();
    public static ApiUtils<InvoiceStatus, com.qqs.posvcs.api.billing.InvoiceStatus> InvoiceStatusToAPI = new ApiUtils<>();
    public static ApiUtils<InvoiceStatusData, com.qqs.posvcs.api.billing.InvoiceStatus> InvoiceStatusDataToAPI = new ApiUtils<>();
    public static ApiUtils<Ats, com.qqs.posvcs.api.reports.Ats> AtsToAPI = new ApiUtils<>();
    public static ApiUtils<PackCheckListMaster, com.qqs.posvcs.api.reports.PackCheckListMaster> PackCheckListMasterToAPI = new ApiUtils<>();
    public static ApiUtils<PkgCheckList, com.qqs.posvcs.api.billing.PkgCheckList> PkgCheckListToAPI = new ApiUtils<>();
    public static ApiUtils<AtsContentSheet, com.qqs.posvcs.api.reports.AtsContentSheet> AtsContentSheetListToAPI = new ApiUtils<>();
    public static ApiUtils<NdaForm, com.qqs.posvcs.api.reports.NdaForm> NdaFormToAPI = new ApiUtils<>();
    public static ApiUtils<UserEntity, com.qqs.posvcs.api.User> userToAPI = new ApiUtils<>();
    public static ApiUtils<User, com.qqs.posvcs.api.User> userIToAPI = new ApiUtils<>();
    public static ApiUtils<SearchCriteria, com.qqs.posvcs.service.SearchCriteria> searchCriteriaToJPA = new ApiUtils<>();
    public static ApiUtils<CodeAssociation, com.qqs.posvcs.api.common.CodeAssociation> codeAssociationToAPI = new ApiUtils<>();
    public static ApiUtils<Codes, com.qqs.posvcs.api.common.Codes> codesToAPI = new ApiUtils<>();
    public static ApiUtils<PoLineItemxCurrentStatus, com.qqs.posvcs.api.PoLineItemxCurrentStatus> poLineItemxCurrentStatusToAPI = new ApiUtils<>();



    public static ApiUtils<com.qqs.posvcs.api.PurchOrder, PurchOrder> poToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.PoLineItem, PoLineItem> lineItemToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.parts.Part, Part> partsToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.Address, Address> addressToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.Phone, Phone> phoneToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.Email, Email> emailToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.Company, Company> companyToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.Plant, Plant> plantToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.common.People, People> peopleToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.parts.PartPrice, PartPrice> partPriceToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.parts.PartCommodity, PartCommodity> partCommodityToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.parts.PartChronology, PartChronology> partChronologyToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.parts.PartRelationxRef, PartRelationxRef> partRelationxRefToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.parts.PartDomain, PartDomain> partDomainToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.PoLineTool, PoLineTool> poLineToolToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.parts.PartStandard , PartStandard> partStandardToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.parts.PartCustomerRequirement , PartCustomerRequirement> PartCustomerRequirementToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.parts.PartRevisionAmendment , PartRevisionAmendment> PartRevisionAmendmentToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.parts.PartImage , PartImage> PartImageToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.parts.Standard, Standard> standardsToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.billing.Invoice, Invoice> invoiceToDB= new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.billing.InvoiceLineItem, InvoiceLineItem> invoiceLineToDB= new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.billing.SLIDocuments, SLIDocuments> sliDocumentsToDB= new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.billing.PkgDetail, PkgDetail> pkgDetailToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.billing.PkgMaster, PkgMaster> pkgMasterToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.Places, Places> placesToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.billing.Bank, Bank> bankToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.billing.Invoicexrefpo, PartRelationxRef> invoicexRefPoToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.Vendor, Vendor> vendorToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.PlantDeliveryTerms, PlantDeliveryTerms> plantDeliveryTermsToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.PlantPaymentTerms, PlantPaymentTerms> plantPaymentTermsToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.billing.InvoiceStatus , InvoiceStatus> InvoiceStatusToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.reports.Ats , Ats> AtsToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.reports.PackCheckListMaster , PackCheckListMaster> PackCheckListMasterToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.billing.PkgCheckList, PkgCheckList> PkgCheckListToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.reports.AtsContentSheet, AtsContentSheet> AtsContentSheetListToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.reports.NdaForm, NdaForm> NdaFormToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.User, UserEntity> userToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.common.CodeAssociation , CodeAssociation> codeAssociationToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.common.Codes , Codes> codesToDB = new ApiUtils<>();
    public static ApiUtils< com.qqs.posvcs.api.PoLineItemxCurrentStatus , PoLineItemxCurrentStatus> poLineItemxCurrentStatusToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.Countries, Countries> countriesToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.States, States> statesToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.Cities, Cities> citiesToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.CurrencyExchangeRate, CurrencyExchangeRate> currencyExchangeRateToDB = new ApiUtils<>();


}
