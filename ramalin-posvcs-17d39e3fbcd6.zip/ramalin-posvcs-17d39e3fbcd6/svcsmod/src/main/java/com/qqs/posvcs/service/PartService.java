package com.qqs.posvcs.service;

import com.qqs.invsvcs.api.InvProductDetails;
import com.qqs.invsvcs.api.InvRequirements;
import com.qqs.qqsvcs.api.Schedule;
import com.qqs.posvcs.api.parts.*;
import com.qqs.posvcs.service.helper.PartServiceHelper;
import com.qqs.posvcs.utils.Constants;
import com.qqs.qqsoft.config.WebServiceConfiguration;
import com.qqs.qqsoft.utils.ApiUtils;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import com.qqs.qqsoft.QQBusinessException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;
import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;

import static com.qqs.posvcs.service.translate.APITranslator.*;


@Component
public class PartService {

    Logger logger = LoggerFactory.getLogger(PartService.class);

    @Resource
    private DataService ds;

    @Resource
    private PartDataService partDataService;

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    @Resource(name = "partChronologySubService")
    PartSubService partChronologySubService;

    @Resource(name = "partCommoditySubService")
    PartSubService partCommoditySubService;

    @Resource(name = "partDomainSubService")
    PartSubService partDomainSubService;

    @Resource(name = "partPriceSubService")
    PartSubService partPriceSubService;

    @Resource
    InvProductDetailService invProductDetailService;

    @Resource(name = "partStandardSubService")
    PartSubService partStandardSubService;

    @Resource(name = "partCustomerRequirementSubService")
    PartSubService partCustomerRequirementSubService;

    @Resource(name = "partRevisionAmendmentSubService")
    PartSubService partRevisionAmendmentSubService;

    @Resource(name = "partImageSubService")
    PartSubService partImageSubService;

    @Resource
    private PartServiceHelper helper;

    @Resource
    WebServiceConfiguration webServiceConfiguration;

    @Value("${app.qnqsvcs.url}")
    private String qnqsvcsURL;

    public Part getPartById(Integer partId, HttpServletRequest request) throws QQBusinessException {
        Optional<com.qqs.posvcs.model.Part> part = partDataService.getPartById(partId);
        if (part.isPresent()) {
            return helper.fillPartDetails(part.get(), request);
        }
        throw new QQBusinessException("Part not found");
    }

    public Integer getTotalParts(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.posvcs.model.Part>> partList = partDataService.searchParts(conditions);
        if (partList.isPresent()) {
            return partList.get().size();
        } else {
            return 0;
        }
    }

    public Map<Integer, String> getAllParts() throws QQBusinessException {
        Iterable<com.qqs.posvcs.model.Part> partList = partDataService.getAllParts();
        Map<Integer, String> partMap = new HashMap<>();
        partList.forEach(item -> {
            partMap.put(item.getId(), item.getNumber() + " - " + item.getPartRevNo());
        });
        return partMap;
    }

    public List<Part> searchParts(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.posvcs.model.Part>> partList = partDataService.searchParts(conditions);
        List<Part> returnVal = new ArrayList<>();
        if (partList.isPresent() && partList.get().size() > 0) {
            returnVal = convertToAPI(partList);
            List<Integer> partIds = new ArrayList<>(partList.get().size());
            for (Part part : returnVal) {
                partIds.add(part.getId());
            }

            Map<Integer, List<com.qqs.posvcs.model.PartPrice>> priceMap = helper.getPartPriceDetails(partIds);
            if (priceMap != null && !priceMap.isEmpty()) {
                for (Part p : returnVal) {
                    try {
                        p.setPrices(partPriceToAPI.translate(priceMap.get(p.getId()), com.qqs.posvcs.api.parts.PartPrice.class, false));
                    } catch (Exception e) {
                        logger.error("Part Price translation error", e);
                    }
                }
            }

            Map<Integer, List<com.qqs.posvcs.model.PartCommodity>> commodityMap = new HashMap<>();
            Optional<List<com.qqs.posvcs.model.PartCommodity>> commodityList = partDataService.getCommodityByPartIds(partIds);
            if (commodityList.isPresent()) {
                for (com.qqs.posvcs.model.PartCommodity partCommodity : commodityList.get()) {
                    if (commodityMap.get(partCommodity.getPartId()) == null) {
                        commodityMap.put(partCommodity.getPartId(), new ArrayList());
                    }
                    commodityMap.get(partCommodity.getPartId()).add(partCommodity);
                }
                for (Part part : returnVal) {
                    try {
                        part.setCommodities(partCommodityToAPI.translate(commodityMap.get(part.getId()), com.qqs.posvcs.api.parts.PartCommodity.class, false));
                    } catch (Exception e) {
                        logger.error("Part Price translation error", e);
                    }
                }
            }
        }
        return returnVal;
    }

    public List<Standard> searchStandards(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createStandardSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.posvcs.model.Standard>> partStandardList = partDataService.searchStandards(conditions);
        List<Standard> returnVal;
        returnVal = convertToStandardAPI(partStandardList);
        return returnVal;
    }

    private List<Standard> convertToStandardAPI(Optional<List<com.qqs.posvcs.model.Standard>> partStandardList) throws QQBusinessException {
        if (!partStandardList.isPresent())
            throw new QQBusinessException("No client found for StandardListSearch");
        List<Standard> result = null;
        try {
            result = new ApiUtils<com.qqs.posvcs.model.Standard, Standard>().translate(partStandardList.get(), Standard.class, false);
        } catch (Exception e) {
            logger.error("Parts translation error", e);
        }
        return result;
    }

    public List<Part> getChildParts(Integer parentPartId) throws QQBusinessException, InstantiationException, IllegalAccessException {
        Optional<List<com.qqs.posvcs.model.Part>> partList = partDataService.getAllChildPartsById(parentPartId);
        List<Part> partToApi = new ArrayList<>();
        partToApi = partsToAPI.translate(partList.get(), Part.class, true);
        partToApi.forEach(part -> {
            part.setQty(partDataService.getPartRelationxRefByParentIdAndChildId(parentPartId, part.getId()).getQty());
        });
        return partToApi;
    }

    private List<Part> convertToAPI(Optional<List<com.qqs.posvcs.model.Part>> partList) throws QQBusinessException {
        if (!partList.isPresent())
            throw new QQBusinessException("No client found for criteria");
        List<Part> result = null;
        try {
            result = new ApiUtils<com.qqs.posvcs.model.Part, Part>().translate(partList.get(), Part.class, false);
        } catch (Exception e) {
            logger.error("Parts translation error", e);
        }
        return result;
    }

    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"name", "number", "drawingNo", "qqsCode", "projectName", "partRevNo", "companyId"}));
        Map<String, String> operators = new HashMap<>(2);
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, operators, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }

    private List<SearchCriteria> createStandardSearchCriteria(Map<String, String> params, Boolean exactMatch) {
        List<SearchCriteria> conditions = new ArrayList<>(params.size());
        for (String p : params.keySet()) {
            SearchCriteria criteria = new SearchCriteria();
            Boolean validCriteria = false;
            criteria.setOperation(exactMatch ? "=" : ":");
            if (StringUtils.equalsIgnoreCase(p, "standardNumber")) {
                validCriteria = true;
            }
            if (StringUtils.equalsIgnoreCase(p, "standardDescription")) {
                validCriteria = true;
            }
            if (StringUtils.equalsIgnoreCase(p, "revisionNumber")) {
                validCriteria = true;
            }
            if (StringUtils.equalsIgnoreCase(p, "createdDt")) {
                criteria.setOperation(">");
                validCriteria = true;
            }
            if (validCriteria) {
                criteria.setKey(p);
                criteria.setValue(params.get(p));
                conditions.add(criteria);
            }
        }
        return conditions;
    }

    @Transactional
    public Part savePart(Part source, HttpServletRequest request) throws QQBusinessException {
        com.qqs.posvcs.model.Part toSave = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        Part savedAPI = null;
        try {
            toSave = partsToDB.translate(source, com.qqs.posvcs.model.Part.class, false);
            if (toSave.getId() > 0) {
                new DateUtils<com.qqs.posvcs.model.Part>().setTimeStamp(toSave, com.qqs.posvcs.model.Part.class, true);
                toSave.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.posvcs.model.Part>().setTimeStamp(toSave, com.qqs.posvcs.model.Part.class, false);
                toSave.setCreatedBy(loggedInUser);
            }
            com.qqs.posvcs.model.Part saved = partDataService.savePart(toSave);
            savedAPI = partsToAPI.translate(saved, Part.class, false);

            InvProductDetails invProductDetails = source.getInvProductDetails();
            invProductDetails.setProductId(savedAPI.getId());
            savedAPI.setInvProductDetails(invProductDetailService.saveInvProductDetails(invProductDetails, request));

        } catch (Exception e) {
            logger.error("Translation error in part save ", e);
        }
        return savedAPI;
    }

    //Standard Master save
    @Transactional
    public Standard saveMasterStandard(Standard source) throws QQBusinessException {
        com.qqs.posvcs.model.Standard toSave = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        Standard savedAPI = null;
        try {
            toSave = standardsToDB.translate(source, com.qqs.posvcs.model.Standard.class, false);
            if (toSave.getId() > 0) {
                new DateUtils<com.qqs.posvcs.model.Standard>().setTimeStamp(toSave, com.qqs.posvcs.model.Standard.class, true);
                toSave.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.posvcs.model.Standard>().setTimeStamp(toSave, com.qqs.posvcs.model.Standard.class, false);
                toSave.setCreatedBy(loggedInUser);
            }
            com.qqs.posvcs.model.Standard saved = partDataService.saveMasterStandard(toSave);
            savedAPI = standardsToAPI.translate(saved, Standard.class, false);
        } catch (Exception e) {
            logger.error("Translation error in Standard save ", e);
        }
        return savedAPI;
    }

    @Transactional
    public List<PartChronology> savePartChronology(List<PartChronology> chronologies) {
        return partChronologySubService.savePartSubsidiary(chronologies, partChronologyToDB,
                partChronologyToAPI, com.qqs.posvcs.model.PartChronology.class, PartChronology.class);
    }

    @Transactional
    public List<PartCommodity> savePartCommodity(List<PartCommodity> commodities) {
        return partCommoditySubService.savePartSubsidiary(commodities, partCommodityToDB, partCommodityToAPI,
                com.qqs.posvcs.model.PartCommodity.class, PartCommodity.class);
    }

    @Transactional
    public List<PartDomain> savePartDomain(List<PartDomain> domains) {
        return partDomainSubService.savePartSubsidiary(domains, partDomainToDB, partDomainToAPI,
                com.qqs.posvcs.model.PartDomain.class, PartDomain.class);
    }

    @Transactional
    public List<PartPrice> savePartPrice(List<PartPrice> partPrices) {
        return partPriceSubService.savePartSubsidiary(partPrices, partPriceToDB, partPriceToAPI,
                com.qqs.posvcs.model.PartPrice.class, PartPrice.class);
    }

    @Transactional
    public List<PartRelationxRef> saveChildParts(List<PartRelationxRef> partRelationxRefs) throws InstantiationException, IllegalAccessException {
        // Remove existing relations - This does not DELETE from db
//        Optional<List<com.qqs.posvcs.model.Part>> optFromDb = partDataService.getAllChildPartsById(partRelationxRefs.get(0).getParentId());
//        if (optFromDb.isPresent()) {
//            for (com.qqs.posvcs.model.Part p : optFromDb.get()) {
//                for (int i = 0; i < partRelationxRefs.size(); i++) {
//                    if (partRelationxRefs.get(i).getChildId() == p.getId()) {
//                        partRelationxRefs.remove(i);
//                        partRelationxRefs.get(i).setId(p.getId());
//                    }
//                }
//            }
//        }
//        return partRelationxRefSubService.savePartSubsidiary(partRelationxRefs, partRelationxRefToDB, partRelationxRefToAPI,
//                com.qqs.posvcs.model.PartRelationxRef.class, PartRelationxRef.class);
        List<PartRelationxRef> partRelationxRefToApi = new ArrayList<>();
        List<com.qqs.posvcs.model.PartRelationxRef> partRelationxRefsListFromDb = partDataService.getPartRelationxRefByParentId(partRelationxRefs.get(0).getParentId());
        partRelationxRefsListFromDb.forEach(partRefList -> {
            partRelationxRefs.forEach(partsRela -> {
                if (partsRela.getChildId() == partRefList.getChildId()) {
                    partsRela.setId(partRefList.getId());
                }
            });
        });

        List<com.qqs.posvcs.model.PartRelationxRef> partRelationxRefToDb = partRelationxRefToDB.translate(partRelationxRefs, com.qqs.posvcs.model.PartRelationxRef.class, true);
        partRelationxRefToApi = partRelationxRefToAPI.translate(partDataService.saveChildParts(partRelationxRefToDb), PartRelationxRef.class, true);
        ;


        return partRelationxRefToApi;
    }

    @Transactional
    public List<PartStandard> saveStandards(List<PartStandard> partStandard) {
        return partStandardSubService.savePartSubsidiary(partStandard, partStandardToDB, partStandardToAPI,
                com.qqs.posvcs.model.PartStandard.class, PartStandard.class);
    }

    @Transactional
    public List<PartCustomerRequirement> saveCustomerRequirement(List<PartCustomerRequirement> partCustomerRequirement) {
        return partCustomerRequirementSubService.savePartSubsidiary(partCustomerRequirement, PartCustomerRequirementToDB, PartCustomerRequirementToAPI,
                com.qqs.posvcs.model.PartCustomerRequirement.class, PartCustomerRequirement.class);
    }

    @Transactional
    public List<PartRevisionAmendment> saveRevisionAmendment(List<PartRevisionAmendment> partRevisionAmendment) {
        return partRevisionAmendmentSubService.savePartSubsidiary(partRevisionAmendment, PartRevisionAmendmentToDB, PartRevisionAmendmentToAPI,
                com.qqs.posvcs.model.PartRevisionAmendment.class, PartRevisionAmendment.class);
    }

    @Transactional
    public List<PartImage> savePartImage(List<PartImage> partImage) {
        return partImageSubService.savePartSubsidiary(partImage, PartImageToDB, PartImageToAPI,
                com.qqs.posvcs.model.PartImage.class, PartImage.class);
    }


    public String clonePartSubsidiary(Integer clonedPartId, Integer newPartId) throws QQBusinessException {
        Optional<List<com.qqs.posvcs.model.PartChronology>> chronology = partDataService.getChronologyByPart(clonedPartId);
        if (chronology.isPresent()) {
            chronology.get().forEach(partChronology -> {
                partChronology.setId(0);
                partChronology.setPartNo(newPartId);
            });
            partChronologySubService.savePartSubsidiary(chronology.get(), partChronologyToDB,
                    partChronologyToAPI, com.qqs.posvcs.model.PartChronology.class, PartChronology.class);
        }

        Optional<List<com.qqs.posvcs.model.PartDomain>> domain = partDataService.getDomainByPart(clonedPartId);
        if (domain.isPresent()) {
            domain.get().forEach(partDomain -> {
                partDomain.setId(0);
                partDomain.setPartId(newPartId);
            });
            partDomainSubService.savePartSubsidiary(domain.get(), partDomainToDB, partDomainToAPI,
                    com.qqs.posvcs.model.PartDomain.class, PartDomain.class);
        }

        Optional<List<com.qqs.posvcs.model.PartCommodity>> commodity = partDataService.getCommodityByPart(clonedPartId);
        if (commodity.isPresent()) {
            commodity.get().forEach(partCommodity -> {
                partCommodity.setId(0);
                partCommodity.setPartId(newPartId);
            });
            partCommoditySubService.savePartSubsidiary(commodity.get(), partCommodityToDB, partCommodityToAPI,
                    com.qqs.posvcs.model.PartCommodity.class, PartCommodity.class);
        }

        Optional<List<com.qqs.posvcs.model.PartStandard>> standard = partDataService.getStandardByPart(clonedPartId);
        if (standard.isPresent()) {
            standard.get().forEach(partStandard -> {
                partStandard.setId(0);
                partStandard.setPartId(newPartId);
            });
            partStandardSubService.savePartSubsidiary(standard.get(), partStandardToDB, partStandardToAPI,
                    com.qqs.posvcs.model.PartStandard.class, PartStandard.class);
        }
        Optional<List<com.qqs.posvcs.model.PartCustomerRequirement>> partCustomerRequirement = partDataService.getPartCustomerRequirementByPart(clonedPartId);
        if (partCustomerRequirement.isPresent()) {
            partCustomerRequirement.get().forEach(partPartCustomerRequirement -> {
                partPartCustomerRequirement.setId(0);
                partPartCustomerRequirement.setPartId(newPartId);
            });
            partCustomerRequirementSubService.savePartSubsidiary(partCustomerRequirement.get(), PartCustomerRequirementToDB, PartCustomerRequirementToAPI,
                    com.qqs.posvcs.model.PartCustomerRequirement.class, PartCustomerRequirement.class);
        }
        Optional<List<com.qqs.posvcs.model.PartRevisionAmendment>> partRevisionAmendment = partDataService.getPartRevisionAmendmentByPart(clonedPartId);
        if (partRevisionAmendment.isPresent()) {
            partRevisionAmendment.get().forEach(partPartRevisionAmendment -> {
                partPartRevisionAmendment.setId(0);
                partPartRevisionAmendment.setPartId(newPartId);
            });
            partRevisionAmendmentSubService.savePartSubsidiary(partRevisionAmendment.get(), PartRevisionAmendmentToDB, PartRevisionAmendmentToAPI,
                    com.qqs.posvcs.model.PartRevisionAmendment.class, PartRevisionAmendment.class);
        }
        String val = "Successfully part Cloned";
        return val;
    }

    public List<InvRequirements> getPartReq(Integer partId, Integer quantity, String jobType) {
        List<InvRequirements> invRequirementsList = new ArrayList<>();

        if(Constants.JOB_TYPE_BO.equalsIgnoreCase(jobType)) {
            InvRequirements invRequirement = new InvRequirements();
            invRequirement.setProductId(partId);
            invRequirement.setProductType(Constants.PRODUCT_TYPE_MAP.get("part"));
            invRequirement.setReqQuantity(Double.valueOf(quantity));
            invRequirementsList.add(invRequirement);
        } else {
            List<com.qqs.posvcs.model.PartRelationxRef> partRelationxRefsListFromDb = partDataService.getPartRelationxRefByParentId(partId);
            partRelationxRefsListFromDb.forEach(item -> {
                InvRequirements invRequirement = new InvRequirements();
                invRequirement.setProductId(item.getChildId());
                invRequirement.setProductType(Constants.PRODUCT_TYPE_MAP.get("part"));
                invRequirement.setReqQuantity(Double.valueOf(item.getQty() * quantity));
                invRequirementsList.add(invRequirement);

                // calling getPartReq recursively to get next level child part requirements
                invRequirementsList.addAll(getPartReq(item.getChildId(), (item.getQty() * quantity), jobType));
            });
        }
        return invRequirementsList;
    }

    public List<InvRequirements> getPartReq(Map<Integer, Integer> partMap, Map<Integer, String> jobTypeMap) throws QQBusinessException {
        List<InvRequirements> invRequirementsList = new ArrayList<>();
        Map<Integer, String> partList = getAllParts();

        partMap.forEach((k, v) -> {
            invRequirementsList.addAll(getPartReq(k, v, jobTypeMap.get(k)));
        });

        List<InvRequirements> invReqList = groupProduct(invRequirementsList);

        invReqList.forEach(item -> {
            item.setProductName(partList.get(item.getProductId()));
        });
        return invReqList;
    }

    public List<InvRequirements> getInvRequirements(Timestamp reqFrom, HttpServletRequest request) throws QQBusinessException {
        List<InvRequirements> invRequirementsList = new ArrayList<>();

        RestTemplate restTemplate = webServiceConfiguration.restTemplate(webServiceConfiguration.getHttpClient());
        HttpHeaders requestHeaders = new HttpHeaders();
        StringBuffer baseUrl = new StringBuffer();

        baseUrl.append(qnqsvcsURL).append(Constants.SCHEDULE_URL).append(reqFrom);
        requestHeaders.add("Authorization", request.getHeader("Authorization"));
        requestHeaders.add("Content-Type", "application/json; charset=UTF-8");

        HttpEntity requestEntity = new HttpEntity(null, requestHeaders);
        ResponseEntity response = restTemplate.exchange(baseUrl.toString(),
                HttpMethod.GET, requestEntity, new ParameterizedTypeReference<List<Schedule>>() {
                });
        List<Schedule> scheduleList = (List<Schedule>) response.getBody();

        Map<Integer, Integer> partScheduleMap = new HashMap<>();
        Map<Integer, String> jobTypeMap = new HashMap<>();

        scheduleList.forEach(item -> {
            partScheduleMap.put(item.getPartId(), item.getPlannedQuantity());
            jobTypeMap.put(item.getPartId(), item.getJobType());
        });
        invRequirementsList = getPartReq(partScheduleMap, jobTypeMap);

        return invRequirementsList;
    }

    public List<InvRequirements> groupProduct(List<InvRequirements> invRequirementsList) {
        Map<Integer, Double> partwiseReqQuantitySum = invRequirementsList.stream().collect(Collectors.groupingBy(item ->
                item.getProductId(), Collectors.summingDouble(item -> item.getReqQuantity())));
        Map<Integer, InvRequirements> uniqueReq = new HashMap<>();

        invRequirementsList.forEach(item -> {
            item.setReqQuantity(partwiseReqQuantitySum.get(item.getProductId()));
            uniqueReq.put(item.getProductId(), item);
        });

        List<InvRequirements> invReqList = new ArrayList<>(uniqueReq.values());
        return invReqList;
    }

    public Integer getTotalPartsCount () {
        return partDataService.getTotalPartsCount();
    }

    public Integer getTotalParentPartsCount () {
        return partDataService.getTotalParentPartsCount();
    }
}
