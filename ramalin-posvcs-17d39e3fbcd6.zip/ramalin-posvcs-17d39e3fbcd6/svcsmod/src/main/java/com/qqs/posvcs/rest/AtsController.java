package com.qqs.posvcs.rest;

import com.qqs.posvcs.api.reports.Ats;
import com.qqs.posvcs.api.reports.AtsContentSheet;
import com.qqs.posvcs.service.AtsService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.qqs.posvcs.utils.Constants.uploadFileFolder;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/ats")
public class AtsController {

    @Resource
    private AtsService atsService;

    @Value("${app.document.upload.location}")
    private String uploadFolder;



    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ATS_WRITE', 'ROLE_ALL_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "ats/save", produces = "application/json")
    public ResponseEntity<Ats> saveAts(@RequestBody com.qqs.posvcs.api.reports.Ats form) throws QQBusinessException {
        com.qqs.posvcs.api.reports.Ats saved = atsService.saveAts(form);
        ResponseEntity<Ats> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }


    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_ALL_WRITE','ROLE_ATS_READ','ROLE_ATS_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/ats/Search/byId", produces = "application/json")
    public ResponseEntity<Ats> getAtsSearchById(@RequestParam Integer id,
                                                HttpServletRequest request) throws QQBusinessException {
        Ats ats = atsService.getAtsSearchById(id);
        ResponseEntity<Ats> result = new ResponseEntity(ats, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_ALL_WRITE','ROLE_ATS_READ','ROLE_ATS_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "ats/form/search", produces = "application/json")
    public ResponseEntity<List<Ats>> searchAts(@RequestParam Map<String, String> searchParam,
                                                     @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                     HttpServletRequest request) throws QQBusinessException {
        List<Ats> formList = atsService.searchAllAts(searchParam, exactMatch.orElse(false));
        ResponseEntity<List<Ats>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ATS_WRITE', 'ROLE_ALL_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "ats/content/save", produces = "application/json")
    public ResponseEntity<com.qqs.posvcs.api.reports.AtsContentSheet> saveAtsContent(@RequestBody com.qqs.posvcs.api.reports.AtsContentSheet form) throws QQBusinessException {
        com.qqs.posvcs.api.reports.AtsContentSheet saved = atsService.saveAtsContent(form);
        ResponseEntity<AtsContentSheet> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ATS_WRITE', 'ROLE_ALL_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value =  "/generateATS", produces="application/pdf")
    public ResponseEntity<org.springframework.core.io.Resource> generateAts(@RequestParam Integer atsId, HttpServletRequest request,
                                                                            HttpServletResponse response) throws QQBusinessException {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        atsService.generateAts(atsId, stream);
        org.springframework.core.io.Resource file = new ByteArrayResource(stream.toByteArray());
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.put(HttpHeaders.CONTENT_DISPOSITION, Collections.singletonList("attachment; filename=filledapp.pdf"));
        httpHeaders.put(HttpHeaders.CONTENT_TYPE, Collections.singletonList("application/pdf"));
        ResponseEntity<org.springframework.core.io.Resource> result = ResponseEntity
                .ok()
                .headers(httpHeaders)
                .body(file);
        return result;
    }
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ATS_WRITE', 'ROLE_ALL_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value =  "/downLoadAtsFile", produces={"multipart/form-data"})
    public ResponseEntity<org.springframework.core.io.Resource> generateFile(@RequestParam String fileName, String documentType,
                                                                             HttpServletRequest request,
                                                                             HttpServletResponse response) throws QQBusinessException {
        ResponseEntity<org.springframework.core.io.Resource> result = null;
        if ("atsContentSheet".equals(documentType)) { // To Avoid Downloading from other folders
            String fileFolder = uploadFileFolder.get(documentType);
            ApplicationContext appContext =
                    new ClassPathXmlApplicationContext(new String[] {});
            org.springframework.core.io.Resource resource = appContext.getResource("file:" + uploadFolder + fileFolder + '/'  + fileName); // new ClassPathResource("file:" + uploadFolder + fileFolder + '/'  + fileName);
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=img.png");
             result = ResponseEntity
                    .ok()
                    .headers(httpHeaders)
                    .body(resource);
        }
        return result;

    }

}
