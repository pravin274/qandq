package com.qqs.posvcs.service;

import com.qqs.posvcs.api.PoLineItem;
import com.qqs.posvcs.api.PurchOrder;
import com.qqs.posvcs.model.PoLineItemxCurrentStatus;
import com.qqs.posvcs.service.helper.POServiceHelper;
import com.qqs.posvcs.service.translate.PartTranslator;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.ApiUtils;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import com.qqs.qqsoft.utils.SecurityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.transaction.Transactional;
import java.util.*;

import static com.qqs.posvcs.service.translate.APITranslator.*;
import static com.qqs.posvcs.utils.Constants.*;

@Component
public class POService {

    Logger logger = LoggerFactory.getLogger(POService.class);


    @Resource
    DataService ds;
    @Resource
    POServiceHelper helper;
    @Resource
    SearchCriteriaUtils searchCriteriaUtils;
    @Resource
    SecurityUtils security;

    public PurchOrder getPurchaseOrderById(Integer id) throws QQBusinessException {
        Optional<com.qqs.posvcs.model.PurchOrder> po = ds.getPurchOrderDS().getPurchaseOrderById(id);
        if (!po.isPresent())
            throw new QQBusinessException("No purchase order found");
        PurchOrder result = helper.fillPODetails(po.get());
        return result;
    }

    public PurchOrder saveFileName(Integer poId, String poFileName) throws QQBusinessException {
        com.qqs.posvcs.api.PurchOrder savedPoToAPi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        try {
            Optional<com.qqs.posvcs.model.PurchOrder> po = ds.getPurchOrderDS().getPurchaseOrderById(poId);
            if (po.isPresent()) {
                com.qqs.posvcs.model.PurchOrder poTodb = po.get();
                poTodb.setModifiedBy(loggedInUser);
                poTodb.setPoFileName(poFileName);
                poDateUtils.setTimeStamp(poTodb, com.qqs.posvcs.model.PurchOrder.class, true);

                com.qqs.posvcs.model.PurchOrder savedPo = ds.getPurchOrderDS().savePurchaseorder(poTodb);

                savedPoToAPi = poToAPI.translate(savedPo, com.qqs.posvcs.api.PurchOrder.class, false);
            }

        } catch (Exception e) {
            throw new QQBusinessException("Purchase order file save error", e);

        }
        return savedPoToAPi;
    }


    public List<PurchOrder> searchPurchaseOrders(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.posvcs.model.PurchOrder>> purchOrders = ds.getPurchOrderDS().searchPurchaseOrders(conditions);
        if (!purchOrders.isPresent())
            throw new QQBusinessException("No po found for criteria");
        List<PurchOrder> result = null;
        try {
            result = poToAPI.translate(purchOrders.get(), PurchOrder.class, false);
        } catch (Exception e) {
            logger.error("Translation failed", e);
        }
        return result;
    }

    public Integer getTotalPOCount() {
        return ds.getPurchOrderDS().getTotalPOCount();
    }

    @Transactional
    public PurchOrder savePurchaseOrder(PurchOrder source) throws QQBusinessException {

        PurchOrder savedToAPI = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        try {
            com.qqs.posvcs.model.PurchOrder po = poToDB.translate(
                    source, com.qqs.posvcs.model.PurchOrder.class, true);
            if (source.getId() > 0) {
                new DateUtils<com.qqs.posvcs.model.PurchOrder>().setTimeStamp(po, com.qqs.posvcs.model.PurchOrder.class, true);
                po.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.posvcs.model.PurchOrder>().setTimeStamp(po, com.qqs.posvcs.model.PurchOrder.class, false);
                po.setCreatedBy(loggedInUser);
            }
            po.setPoStatus(PO_STATUS_ACTIVE);
            // updating previous of this PO Status as reviced version
            if (source.getId() <= 0) {  // check for the new po
                ds.getPurchOrderDS().updatePurchaseorderStatus(source.getPoNumber(), PO_STATUS_REVISIED);
            }
            com.qqs.posvcs.model.PurchOrder saved = ds.getPurchOrderDS().savePurchaseorder(po);

            //Save Tools
            for (PoLineItem poLineItem : source.getPoLineItems()) {
                savePoLineItemTool(poLineItem);
            }
            List<com.qqs.posvcs.model.PoLineItem> lineItemsToSave = lineItemToDB.translate
                    (source.getPoLineItems(), com.qqs.posvcs.model.PoLineItem.class, true);
            for (com.qqs.posvcs.model.PoLineItem poLineItem : lineItemsToSave) {
                poLineItem.setPoId(saved.getId());
                if (poLineItem.getId() > 0) {
                    new DateUtils<com.qqs.posvcs.model.PoLineItem>().setTimeStamp(poLineItem, com.qqs.posvcs.model.PoLineItem.class, true);
                    poLineItem.setModifiedBy(loggedInUser);
                } else {
                    new DateUtils<com.qqs.posvcs.model.PoLineItem>().setTimeStamp(poLineItem, com.qqs.posvcs.model.PoLineItem.class, false);
                    poLineItem.setCreatedBy(loggedInUser);
                }
            }
            Iterable<com.qqs.posvcs.model.PoLineItem> savedPOLineItems = ds.getPoLineItemDS().savePOLineItems(lineItemsToSave);
            // Save Po Line Status
            savedPOLineItems.forEach(poLineItem -> {
                try {
                    PoLineItem poline = lineItemToAPI.translate(poLineItem, PoLineItem.class, true);
                    savePOLineCurrentStatus(poline);
                } catch (InstantiationException e) {
                    logger.error("lineItemToAPI translate error ", e);
                } catch (IllegalAccessException e) {
                    logger.error("lineItemToAPI translate error ", e);
                }

            });
            savedToAPI = poToAPI.translate(saved, PurchOrder.class, true);
        } catch (Exception e) {
            logger.error("Save error ", e);
            throw new QQBusinessException("Purchase order save error", e);
        }
        return savedToAPI;
    }

    DateUtils<com.qqs.posvcs.model.PoLineItem> poLineItemDateUtils = new DateUtils<>();
    DateUtils<com.qqs.posvcs.model.PurchOrder> poDateUtils = new DateUtils<>();

    public PurchOrder updatePurchaseOrder(PurchOrder source) throws QQBusinessException {
        PurchOrder savedToAPI = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        try {
            List<Integer> lineItemIds = new ArrayList<>(source.getPoLineItems().size());
            source.getPoLineItems().forEach(item -> {
                lineItemIds.add(item.getId());
            });
            List<com.qqs.posvcs.model.PoLineItem> lineItemsRetrieved =
                    ds.getPoLineItemDS().getAllPOLineItemsById(lineItemIds).get();
            Map<Integer, com.qqs.posvcs.model.PoLineItem> lineItemsToSave = new HashMap<>();
            lineItemsRetrieved.forEach(item -> {
                lineItemsToSave.put(item.getId(), item);
            });

            int dummyId = 10000;
            for (PoLineItem item : source.getPoLineItems()) {
                com.qqs.posvcs.model.PoLineItem toSave = lineItemsToSave.get(item.getId());
                savePoLineItemTool(item);
                if (toSave == null) {
                    toSave = lineItemToDB.translate(item, com.qqs.posvcs.model.PoLineItem.class, true, "id");
                    lineItemsToSave.put(++dummyId, toSave);
                    toSave.setPoId(source.getId());
                    poLineItemDateUtils.setTimeStamp(toSave, com.qqs.posvcs.model.PoLineItem.class, false);
                    toSave.setCreatedBy(loggedInUser);
                    toSave.setModifiedBy(loggedInUser);
                } else {
                    lineItemToDB.translate(item, toSave, true);
                    poLineItemDateUtils.setTimeStamp(toSave, com.qqs.posvcs.model.PoLineItem.class, true);
                    toSave.setModifiedBy(loggedInUser);
                }
            }
            ds.getPoLineItemDS().savePOLineItems(lineItemsToSave.values());
            source.getPoLineItems().forEach(poLineItem -> {
                Optional<PoLineItemxCurrentStatus> poLineCurentStatus =
                        ds.getPoLineItemDS().getPOLineItemxCurrentStatusByInvoiceLineItemIdAndType(poLineItem.getId(), CS_ACTIVE, CS_TYPEPO);
                if (poLineCurentStatus.isPresent()) {
                    if (!poLineCurentStatus.get().getCurrentStatus().equals(poLineItem.getCurrentStatus())) {
                        poLineCurentStatus.get().setStatus(CS_INACTIVE);
                        ds.getPoLineItemDS().savePOLineItemxCurrentStatus(poLineCurentStatus.get());
                        savePOLineCurrentStatus(poLineItem);
                    }
                } else {
                    savePOLineCurrentStatus(poLineItem);
                }
            });

            // Now save PO
            com.qqs.posvcs.model.PurchOrder poFromDb = ds.getPurchOrderDS().getPurchaseOrderById(source.getId()).get();
            source.setPoStatus(poFromDb.getPoStatus());
            poToDB.translate(source, poFromDb, "id", "poLineItems");
            poDateUtils.setTimeStamp(poFromDb, com.qqs.posvcs.model.PurchOrder.class, true);
            poFromDb.setModifiedBy(loggedInUser);
            com.qqs.posvcs.model.PurchOrder saved = ds.getPurchOrderDS().savePurchaseorder(poFromDb);
            savedToAPI = poToAPI.translate(saved, PurchOrder.class, true);
        } catch (Exception e) {
            logger.error("Save error ", e);
            throw new QQBusinessException("Purchase order save error", e);
        }
        return savedToAPI;
    }

    private void savePOLineCurrentStatus(PoLineItem poLineItem) {
        com.qqs.posvcs.model.PoLineItemxCurrentStatus lineCurrentStatus = new com.qqs.posvcs.model.PoLineItemxCurrentStatus();
        lineCurrentStatus.setPoLineItemId(poLineItem.getId());
        lineCurrentStatus.setCurrentStatus(poLineItem.getCurrentStatus());
        lineCurrentStatus.setDate(new Date());
        lineCurrentStatus.setStatus("ACTIVE");
        lineCurrentStatus.setType("PO");
        ds.getPoLineItemDS().savePOLineItemxCurrentStatus(lineCurrentStatus);
    }

    private void savePoLineItemTool(PoLineItem poLineItem) throws Exception {
        if (PartTranslator.PartType.Tool.getCode().equals(poLineItem.getPartType())) {
            com.qqs.posvcs.model.PoLineTool poLineTool = poLineToolToDB.translate(poLineItem.getPoLineTool(), com.qqs.posvcs.model.PoLineTool.class, false);
            com.qqs.posvcs.model.PoLineTool savedPoLineTool = ds.getPoLineItemDS().savePoLineTool(poLineTool);
            poLineItem.setPoLineToolId(savedPoLineTool.getId());
        }
    }

    private ApiUtils<com.qqs.posvcs.model.Address, com.qqs.posvcs.api.Address> addressTranslator =
            new ApiUtils<>();
    private ApiUtils<com.qqs.posvcs.model.PoLineItem, com.qqs.posvcs.api.PoLineItem> lineItemTranslator =
            new ApiUtils<>();
    private ApiUtils<com.qqs.posvcs.model.Company, com.qqs.posvcs.api.Company> companyTranslator =
            new ApiUtils<>();
    private ApiUtils<com.qqs.posvcs.model.Part, com.qqs.posvcs.api.parts.Part> partTranslator =
            new ApiUtils<>();

    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"companyId", "plantId", "poNumber", "poDate", "poDateTo", "poStatus", "poRevision"}));
        Map<String, String> operators = new HashMap<>(2);
        operators.put("poDate", ">");
        if (params.get("poDateTo") != null && params.get("poDate") != null) {
            params.put("poDate", params.get("poDate") + "||" + params.get("poDateTo"));
            params.remove("poDateTo");
            operators.put("poDate", "^");
        } else if (params.get("poDateTo") != null) {
            operators.put("poDate", "<");
            params.put("poDate", params.get("poDateTo"));
            params.remove("poDateTo");
        }
//        operators.put("poDateTo", "<");
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, operators, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }


}
