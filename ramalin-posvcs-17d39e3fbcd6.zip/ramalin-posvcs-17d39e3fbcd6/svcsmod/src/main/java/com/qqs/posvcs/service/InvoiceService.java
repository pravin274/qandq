package com.qqs.posvcs.service;


import com.qqs.posvcs.api.PurchOrder;
import com.qqs.posvcs.api.billing.*;
import com.qqs.posvcs.model.Plant;
import com.qqs.posvcs.model.PoLineItemxCurrentStatus;
import com.qqs.posvcs.service.helper.InvoiceServiceHelper;
import com.qqs.posvcs.service.startup.ApplicationCodeMap;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.transaction.Transactional;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.util.*;

import static com.qqs.posvcs.service.translate.APITranslator.*;
import static com.qqs.posvcs.utils.Constants.*;


@Component
public class InvoiceService {

    Logger logger = LoggerFactory.getLogger(InvoiceService.class);

    @Resource
    private DataService ds;

    @Resource
    private InvoiceDataService invoiceDataService;

    @Resource
    private PlantDataService plantDataService;

    @Resource
    private InvoiceLineItemDataService invoiceLineItemDataService;

    @Resource
    private PkgDataService pkgDataService;

    @Resource
    private InvoiceServiceHelper helper;

    @Resource
    private POService poService;

    @Resource
    private InvoiceGenerateHelper invoiceGenerateHelper;

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    @Resource
    private InvProductDetailService invProductDetailService;

    @Resource
    private ApplicationCodeMap systemCodeMap;


    public Invoice getInvoiceById(Integer id) throws QQBusinessException {
        try {
            Optional<com.qqs.posvcs.model.Invoice> invoice = invoiceDataService.getEntityById(id);
            if (invoice.isPresent()) {
                return helper.fillAdditionalDetails(invoice.get());
            }
        } catch (Exception e) {
            logger.error("Error fetching Invoice", e);
        }
        throw new QQBusinessException("No Invoice information found");
    }

    public List<Invoice> searchInvoices(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.posvcs.model.Invoice>> invoices = invoiceDataService.searchInvoice(conditions);
        if (!invoices.isPresent())
            throw new QQBusinessException("No client found for criteria for the invoice search");
        List<Invoice> result = null;
        try {
            result = invoiceToAPI.translate(invoices.get(), Invoice.class, false);
        } catch (Exception e) {
            logger.error("Error getting invoice", e);
        }
        return result;
    }

    @Transactional
    public Invoice saveInvoice(Invoice source) throws QQBusinessException {
        com.qqs.posvcs.model.Invoice toSave = null;
        Invoice savedAPI = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        try {
            //Saving Invoice
            toSave = invoiceToDB.translate(source, com.qqs.posvcs.model.Invoice.class, false);
            if (toSave.getId() > 0) {
                new DateUtils<com.qqs.posvcs.model.Invoice>().setTimeStamp(toSave, com.qqs.posvcs.model.Invoice.class, true);
                toSave.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.posvcs.model.Invoice>().setTimeStamp(toSave, com.qqs.posvcs.model.Invoice.class, false);
                toSave.setCreatedBy(loggedInUser);
            }
            com.qqs.posvcs.model.Invoice saved = invoiceDataService.saveEntities(toSave);

            // set undertakingLUT
            if (saved.getPaymentDeclaration().contains("LUT")) {
                saved.setUndertakingLUT("Y");
            }

            //Saving Invoice xref PO
            List<PurchOrder> poList = source.getPurchOrderList();
            List<Integer> newPOIds = new ArrayList<>();
            poList.forEach(item -> newPOIds.add(item.getId()));
            Iterable<com.qqs.posvcs.model.Invoicexrefpo> invoicexrefpos = new ArrayList<>();
            if (source.getId() > 0) {
                Optional<List<Integer>> poIds = invoiceDataService.getPOIdByInvoiceId(saved.getId());
                if (poIds.isPresent()) {
                    newPOIds.forEach(item -> {
                        if (!poIds.get().contains(item)) {
                            com.qqs.posvcs.model.Invoicexrefpo invoicexrefpo = new com.qqs.posvcs.model.Invoicexrefpo();
                            invoicexrefpo.setInvoiceId(saved.getId());
                            invoicexrefpo.setPoId(item);
                            ((ArrayList<com.qqs.posvcs.model.Invoicexrefpo>) invoicexrefpos).add(invoicexrefpo);
                        }
                    });
                }
            } else {
                newPOIds.forEach(item -> {
                    com.qqs.posvcs.model.Invoicexrefpo invoicexrefpo = new com.qqs.posvcs.model.Invoicexrefpo();
                    invoicexrefpo.setInvoiceId(saved.getId());
                    invoicexrefpo.setPoId(item);
                    ((ArrayList<com.qqs.posvcs.model.Invoicexrefpo>) invoicexrefpos).add(invoicexrefpo);
                });
            }
            invoiceDataService.saveAllInvoicexrefPo(invoicexrefpos);
            poList.clear();
            Optional<List<Integer>> poIds = invoiceDataService.getPOIdByInvoiceId(saved.getId());
            if (poIds.isPresent()) {
                poIds.get().forEach(item -> {
                    try {
                        poList.add(poService.getPurchaseOrderById(item));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }

            //Saving Invoice Line Item
            List<com.qqs.posvcs.model.InvoiceLineItem> lineItemsToSave = invoiceLineToDB.translate
                    (source.getInvoiceLineItems(), com.qqs.posvcs.model.InvoiceLineItem.class, true);
            for (com.qqs.posvcs.model.InvoiceLineItem invoiceLineItem : lineItemsToSave) {
                if (invoiceLineItem.getId() > 0) { // update
                    new DateUtils<com.qqs.posvcs.model.InvoiceLineItem>().setTimeStamp(invoiceLineItem, com.qqs.posvcs.model.InvoiceLineItem.class, true);
                    invoiceLineItem.setModifiedBy(loggedInUser);
                } else { // insert
                    new DateUtils<com.qqs.posvcs.model.InvoiceLineItem>().setTimeStamp(invoiceLineItem, com.qqs.posvcs.model.InvoiceLineItem.class, false);
                    invoiceLineItem.setCreatedBy(loggedInUser);
                }
                invoiceLineItem.setInvoiceId(saved.getId());
            }
            Iterable<com.qqs.posvcs.model.InvoiceLineItem> savedLineItems = invoiceLineItemDataService.saveInvoiceLineItems(lineItemsToSave);
            List<InvoiceLineItem> savedLineItemsAPI = invoiceLineToAPI.translate(savedLineItems, InvoiceLineItem.class, false);

//         Saving Invoice Line Item Current Status
            savedLineItemsAPI.forEach(invoiceLineItem -> {
                Optional<PoLineItemxCurrentStatus> invoiceLineCurrentStatus =
                        ds.getPoLineItemDS().getPOLineItemxCurrentStatusByInvoiceLineItemIdAndType(invoiceLineItem.getId(), CS_ACTIVE, CS_TYPEINVOICE);
                if (invoiceLineCurrentStatus.isPresent()) {
                    if (!invoiceLineCurrentStatus.get().getCurrentStatus().equals(invoiceLineItem.getCurrentStatus())) {
                        invoiceLineCurrentStatus.get().setStatus(CS_INACTIVE);
                        ds.getPoLineItemDS().savePOLineItemxCurrentStatus(invoiceLineCurrentStatus.get());
                        saveLineCurrentStatus(invoiceLineItem);
                    }
                } else {
                    saveLineCurrentStatus(invoiceLineItem);
                }

            });

            //Saving SLI documents details
            List<com.qqs.posvcs.api.billing.SLIDocuments> savedSLIDocumentsAPI = new ArrayList<>();
            if (source.getSliDocumentsList() != null) {
                List<com.qqs.posvcs.model.SLIDocuments> sliDocumentsToSave = sliDocumentsToDB.translate
                        (source.getSliDocumentsList(), com.qqs.posvcs.model.SLIDocuments.class, true);
                for (com.qqs.posvcs.model.SLIDocuments sliDocuments : sliDocumentsToSave) {
                    sliDocuments.setInvoiceId(saved.getId());
                }
                Iterable<com.qqs.posvcs.model.SLIDocuments> savedSLIDocuments = invoiceDataService.saveSLIDocuments(sliDocumentsToSave);
                savedSLIDocumentsAPI = sliDocumentsToAPI.translate(savedSLIDocuments, com.qqs.posvcs.api.billing.SLIDocuments.class, false);
            }
            savedAPI = invoiceToAPI.translate(saved, Invoice.class, false);

            Optional<Plant> plant = plantDataService.getPlantById(saved.getPlantId());
            if (plant.isPresent()) {
                savedAPI.setPlant(plantToAPI.translate(plant.get(), com.qqs.posvcs.api.Plant.class, false));
            }

            savedAPI.setInvoiceLineItems(savedLineItemsAPI);
            savedAPI.setSliDocumentsList(savedSLIDocumentsAPI);
            savedAPI.setPurchOrderList(poList);

            Optional<com.qqs.posvcs.model.Places> place = ds.getPlacesDS().getPlacesById(source.getCountryOfFinal());


            saveInvStatus(saved.getId(), saved.getInvoiceType(), place.get().getDescription());
        } catch (Exception e) {
            logger.error("Translation error in Invoice save ", e);
        }
        return savedAPI;
    }

    private void saveLineCurrentStatus(InvoiceLineItem LineItem) {
        com.qqs.posvcs.model.PoLineItemxCurrentStatus lineCurrentStatus = new com.qqs.posvcs.model.PoLineItemxCurrentStatus();
        lineCurrentStatus.setPoLineItemId(LineItem.getId());
        lineCurrentStatus.setCurrentStatus(LineItem.getCurrentStatus());
        lineCurrentStatus.setDate(new Date());
        lineCurrentStatus.setStatus(CS_ACTIVE);
        lineCurrentStatus.setType(CS_TYPEINVOICE);
        ds.getPoLineItemDS().savePOLineItemxCurrentStatus(lineCurrentStatus);
    }

    @Transactional
    public Invoice savePkg(Invoice source) throws QQBusinessException {
        Invoice savedAPI = source;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        try {
            //Saving Pkg Master & Details
            List<PkgMaster> savedPkgMasterAPI = null;
            List<PkgDetail> savedPkgDetailsAPI = null;
            List<PkgMaster> toAddMultiplePackage = new ArrayList<>();
            if (source.getPkgMasters() != null) {
                source.getPkgMasters().forEach(pgMas -> {
                    if ((pgMas.getBoxCount() != null) && (pgMas.getBoxCount() > 1)) {
                        for (int index = 1; index < pgMas.getBoxCount(); index++) {
                            PkgMaster locPackage = new PkgMaster();
                            PkgDetail locPackageDetail = new PkgDetail();
                            List<PkgDetail> locPackageDetailList = new ArrayList<>();
//                            locPackage = pgMas;
                            locPackage.setPkgType(pgMas.getPkgType());
                            locPackage.setTotalQty(pgMas.getTotalQty());
                            locPackage.setNetWeight(pgMas.getNetWeight());
                            locPackage.setGrossWeight(pgMas.getGrossWeight());
                            locPackage.setWeightUnit(pgMas.getWeightUnit());
                            locPackage.setHeight(pgMas.getHeight());
                            locPackage.setLength(pgMas.getLength());
                            locPackage.setWidth(pgMas.getWidth());
                            locPackage.setDimensionUnit(pgMas.getDimensionUnit());
                            locPackage.setIsDeleted(pgMas.getIsDeleted());
                            locPackage.setPkgNo(pgMas.getPkgNo() + index);
                            locPackageDetail.setPkgNo(locPackage.getPkgNo());
                            locPackageDetail.setWeightPrPiece(pgMas.getPkgDetails().get(0).getWeightPrPiece());
                            locPackageDetail.setInvoiceLineItemId(pgMas.getPkgDetails().get(0).getInvoiceLineItemId());
                            locPackageDetail.setQty(pgMas.getPkgDetails().get(0).getQty());
                            locPackageDetailList.add(locPackageDetail);
                            locPackage.setPkgDetails(locPackageDetailList);
                            toAddMultiplePackage.add(locPackage);
                        }
                    }
                });
            }
            if (!toAddMultiplePackage.isEmpty()) {
                toAddMultiplePackage.forEach(multiPak -> {
                    source.getPkgMasters().add(multiPak);
                });
            }
            if (source.getPkgMasters() != null) {
                List<com.qqs.posvcs.model.PkgMaster> pkgMasterToSave = pkgMasterToDB.translate
                        (source.getPkgMasters(), com.qqs.posvcs.model.PkgMaster.class, true);
                for (com.qqs.posvcs.model.PkgMaster pkgMaster : pkgMasterToSave) {
                    if (pkgMaster.getId() > 0) {
                        new DateUtils<com.qqs.posvcs.model.PkgMaster>().setTimeStamp(pkgMaster, com.qqs.posvcs.model.PkgMaster.class, true);
                        pkgMaster.setModifiedBy(loggedInUser);
                    } else {
                        new DateUtils<com.qqs.posvcs.model.PkgMaster>().setTimeStamp(pkgMaster, com.qqs.posvcs.model.PkgMaster.class, false);
                        pkgMaster.setCreatedBy(loggedInUser);
                    }
                }
                Iterable<com.qqs.posvcs.model.PkgMaster> savedPkgMaster = pkgDataService.saveAllPkgMaster(pkgMasterToSave);
                savedPkgMasterAPI = pkgMasterToAPI.translate(savedPkgMaster, PkgMaster.class, false);
                Map<Integer, Integer> pkgNoMap = new HashMap<>();
                savedPkgMaster.forEach(item -> { // storing PkgMasterId against PkgNo
                    pkgNoMap.put(item.getPkgNo(), item.getId());
                });
                List<PkgDetail> pkgDetailList = new ArrayList<>();
                source.getPkgMasters().forEach(pkgMaster -> {
                    if (pkgMaster.getPkgDetails() != null) {
                        pkgMaster.getPkgDetails().forEach(item -> {
                            item.setPkgId(pkgNoMap.get(item.getPkgNo()));
                            pkgDetailList.add(item);
                        });
                    }
                });
                if (!pkgDetailList.isEmpty()) {
                    List<com.qqs.posvcs.model.PkgDetail> pkgDetailsToSave = pkgDetailToDB.translate(pkgDetailList, com.qqs.posvcs.model.PkgDetail.class, false);
                    //Save Invoice current status
                    pkgDetailsToSave.forEach(item -> {
                        com.qqs.posvcs.model.PoLineItemxCurrentStatus lineCurrentStatus = new com.qqs.posvcs.model.PoLineItemxCurrentStatus();
                        lineCurrentStatus.setPoLineItemId(item.getInvoiceLineItemId());
                        lineCurrentStatus.setType(CS_TYPEINVOICE);
                        lineCurrentStatus.setDate(new Date());
                        lineCurrentStatus.setStatus(CS_ACTIVE);
                        ds.getPoLineItemDS().savePOLineItemxCurrentStatus(lineCurrentStatus);
                        if (lineCurrentStatus.getId() > 0) {
                            lineCurrentStatus.setModifiedBy(loggedInUser);
                        } else {
                            lineCurrentStatus.setCreatedBy(loggedInUser);
                        }
                    });

                    pkgDetailsToSave.forEach(item -> {
                        if (item.getId() > 0) {
                            try {
                                new DateUtils<com.qqs.posvcs.model.PkgDetail>().setTimeStamp(item, com.qqs.posvcs.model.PkgDetail.class, true);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            item.setModifiedBy(loggedInUser);
                        } else {
                            try {
                                new DateUtils<com.qqs.posvcs.model.PkgDetail>().setTimeStamp(item, com.qqs.posvcs.model.PkgDetail.class, false);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            item.setCreatedBy(loggedInUser);
                        }
                    });
                    Iterable<com.qqs.posvcs.model.PkgDetail> savedPkgDetail = pkgDataService.saveAllPkgDetails(pkgDetailsToSave);
                    savedPkgDetailsAPI = pkgDetailToAPI.translate(savedPkgDetail, PkgDetail.class, false);
                    Map<Integer, List<PkgDetail>> pkgDetailsMap = new HashMap<>();

                    savedPkgDetailsAPI.forEach(item -> {
                        if (pkgDetailsMap.get(item.getPkgId()) == null) {
                            pkgDetailsMap.put(item.getPkgId(), new ArrayList<>());
                        }
                        pkgDetailsMap.get(item.getPkgId()).add(item);
                    });
                    savedPkgMasterAPI.forEach(item -> {
                        item.setPkgDetails(pkgDetailsMap.get(item.getId()));
                    });
                }
                savedAPI.setPkgMasters(savedPkgMasterAPI);
            }
        } catch (Exception e) {
            logger.error("Translation error in InvoicePkg save ", e);
        }
        return savedAPI;
    }

    public void saveInvStatus(Integer invoiceId, String invoiceType, String countryOfFinal) {
        Optional<List<com.qqs.posvcs.model.InvoiceStatus>> invoiceStatusFromDb = invoiceDataService.getInvoiceStatusByInvoiceId(invoiceId);
        if (!invoiceStatusFromDb.isPresent()) {
            Map<String, Map<String, com.qqs.posvcs.api.common.Codes>> codesMap = systemCodeMap.getCodeMap();
            Map<String, com.qqs.posvcs.api.common.Codes> invoiceStatus = codesMap.get("INVOICE_STATUS");
            if (invoiceType.equals(NONTOOLINVOICE)) {
                invoiceStatus.forEach((key, val) -> {
                    // india take from the codes table
                    if (INDIA.equals(countryOfFinal)) {
                        if (NA_DOM_INV.contains(key)) {
                            saveInvStatusToDb(invoiceId, key, "NA");
                        } else {
                            saveInvStatusToDb(invoiceId, key, "Yet to update");
                        }
                    } else {
                        saveInvStatusToDb(invoiceId, key, "Yet to update");
                    }
                });
            } else {
                Map<String, com.qqs.posvcs.api.common.Codes> toolInvoiceStatus = codesMap.get("TOOL_INVOICE_STATUS");
                invoiceStatus.forEach((key, val) -> {
                    // Check for the stream fucntions. later
                    // Domestic check to be added.
                    com.qqs.posvcs.api.common.Codes code = toolInvoiceStatus.get(key);
                    if (code != null) {
                        saveInvStatusToDb(invoiceId, key, "Yet to update");
                    } else {
                        saveInvStatusToDb(invoiceId, key, "NA");
                    }
                });
            }
        }
    }

    public void saveInvStatusToDb(Integer invoiceId, String key, String statusText) {
        com.qqs.posvcs.model.InvoiceStatus invoiceStatusToDB = new com.qqs.posvcs.model.InvoiceStatus();
        invoiceStatusToDB.setAttribute1(statusText);
        invoiceStatusToDB.setAttribute2(statusText);
        invoiceStatusToDB.setAttribute3(statusText);
        invoiceStatusToDB.setAttribute4(statusText);
        invoiceStatusToDB.setInvoiceStatus(key);
        invoiceStatusToDB.setInvoiceId(invoiceId);
        invoiceDataService.saveInvoiceStatus(invoiceStatusToDB);
    }

    @Transactional
    public List<InvoiceStatus> saveInvStatus(List<InvoiceStatus> source) throws QQBusinessException {
        List<com.qqs.posvcs.model.InvoiceStatus> toSave;
        List<InvoiceStatus> savedAPI = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        try {
            List<InvoiceStatus> updatedSource = new ArrayList<>();
            source.stream().filter(status -> status.getAttribute1() != null).forEach(item -> updatedSource.add(item));


            List<com.qqs.posvcs.model.InvoiceStatus> invStatusModel = InvoiceStatusToDB.translate(updatedSource, com.qqs.posvcs.model.InvoiceStatus.class, true);
            invStatusModel.forEach(item -> {
                if (item.getId() > 0) {
                    try {
                        new DateUtils<com.qqs.posvcs.model.InvoiceStatus>().setTimeStamp(item, com.qqs.posvcs.model.InvoiceStatus.class, true);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    item.setModifiedBy(loggedInUser);
                } else {
                    try {
                        new DateUtils<com.qqs.posvcs.model.InvoiceStatus>().setTimeStamp(item, com.qqs.posvcs.model.InvoiceStatus.class, false);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    item.setCreatedBy(loggedInUser);
                }
            });
            Iterable<com.qqs.posvcs.model.InvoiceStatus> saved = invoiceDataService.saveInvoiceStatus(invStatusModel);
            savedAPI = InvoiceStatusToAPI.translate(saved, InvoiceStatus.class, false);
        } catch (Exception e) {
            logger.error("Translation error in Invoice Status save ", e);
        }
        return savedAPI;
    }

    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"plantId", "serialNo", "invoiceType", "invDate", "invoiceDateTo"}));
        Map<String, String> operators = new HashMap<>(2);
        operators.put("invDate", ">");
        if (params.get("invoiceDateTo") != null && params.get("invDate") != null) {
            params.put("invDate", params.get("invDate") + "||" + params.get("invoiceDateTo"));
            params.remove("invoiceDateTo");
            operators.put("invDate", "^");
        } else if (params.get("invoiceDateTo") != null) {
            operators.put("invDate", "<");
            params.put("invDate", params.get("invoiceDateTo"));
            params.remove("invoiceDateTo");
        }
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, operators, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }


    public void generateInvoice(Integer invoiceId, ByteArrayOutputStream stream, String invoiceType) throws QQBusinessException {
        invoiceGenerateHelper.generateInvoice(getInvoiceById(invoiceId), stream, invoiceType);
    }


    public Map<Integer, Double> getInvoiceValue(List<Integer> invoiceIds) {
        Map<Integer, Double> invoiceTotalValueMap = new HashMap<>();
        Optional<List<Object[]>> invoiceValueData = invoiceDataService.getInvoiceValue(invoiceIds);

        if (invoiceValueData.isPresent()) {
            invoiceValueData.get().forEach(item -> {
                invoiceTotalValueMap.put((Integer) item[0], ((BigDecimal) item[1]).doubleValue());
            });
        }

        return invoiceTotalValueMap;
    }

    public List<Invoice> getInvoiceByPo(String poNumber) throws QQBusinessException {
        List<Invoice> result = null;
        List<com.qqs.posvcs.model.Invoice> invoices = invoiceDataService.getInvoiceByPoNumber(poNumber);

        try {
            if (invoices != null) {
                result = invoiceToAPI.translate(invoices, Invoice.class, false);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    DateUtils<com.qqs.posvcs.model.Invoice> invoiceDateUtils = new DateUtils<>();

    public Invoice saveFileName(Integer invoiceId, String awbFileName) throws QQBusinessException {
        com.qqs.posvcs.api.billing.Invoice savedPoToAPi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        try {
            Optional<com.qqs.posvcs.model.Invoice> po = ds.getInvoiceDS().getEntityById(invoiceId);
            if (po.isPresent()) {
                com.qqs.posvcs.model.Invoice invoiceTodb = po.get();
                invoiceTodb.setModifiedBy(loggedInUser);
                invoiceTodb.setAwbFileName(awbFileName);
                invoiceDateUtils.setTimeStamp(invoiceTodb, com.qqs.posvcs.model.Invoice.class, true);

                com.qqs.posvcs.model.Invoice savedInvoice = ds.getInvoiceDS().saveEntities(invoiceTodb);

                savedPoToAPi = invoiceToAPI.translate(savedInvoice, com.qqs.posvcs.api.billing.Invoice.class, false);
            }

        } catch (Exception e) {
            throw new QQBusinessException("Invoice file save error", e);

        }
        return savedPoToAPi;
    }


}
