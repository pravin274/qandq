package com.qqs.posvcs.service;

import com.qqs.posvcs.api.Places;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;

import static com.qqs.posvcs.service.translate.APITranslator.*;
import static com.qqs.posvcs.service.translate.APITranslator.searchCriteriaToJPA;

@Component
public class PlacesService {
    Logger logger = LoggerFactory.getLogger(PlacesService.class);

    @Resource
    DataService ds;

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    public Collection<Places> getAllPlaces() throws QQBusinessException {
        try {
            Iterable<com.qqs.posvcs.model.Places> places = ds.getPlacesDS().getAllEntities();
            return placesToAPI.translate(places, Places.class, false);
        } catch (Exception e){
            logger.error("Places retrieve error");
        }
        throw new QQBusinessException("Places retrieve failed");
    }

    public Places getPlacesById(Integer id) throws QQBusinessException {
        com.qqs.posvcs.api.Places placesDataToApi = null;

        try {
            placesDataToApi = placesToAPI.translate(ds.getPlacesDS().getPlacesById(id).get(), com.qqs.posvcs.api.Places.class, false);

        } catch (Exception e) {
            logger.error("Error fetching PlacesDetails", e);
            throw new QQBusinessException("No PlacesDetails information found");
        }

        return placesDataToApi;
    }

    public List<Places> searchPlacess(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.posvcs.model.Places>> places = ds.getPlacesDS().searchEntities(conditions);
        if (!places.isPresent())
            throw new QQBusinessException("No Places found for criteria");
        List<Places> result = null;
        try {
            result = placesToAPI.translate(places.get(), Places.class, false);
        } catch (Exception e) {
            logger.error("Error getting Placess", e);
        }
        return result;
    }

    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"code", "description", "type"}));
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, null, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }

    public Places savePlaces(Places placesData) throws QQBusinessException {
        Places placesToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();

        try {
            com.qqs.posvcs.model.Places toSavePlaces =  placesToDB.translate(placesData, com.qqs.posvcs.model.Places.class, true);
            if(toSavePlaces.getId() > 0) {
                new DateUtils<com.qqs.posvcs.model.Places>().setTimeStamp(toSavePlaces, com.qqs.posvcs.model.Places.class, true);
                toSavePlaces.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.posvcs.model.Places>().setTimeStamp(toSavePlaces, com.qqs.posvcs.model.Places.class, false);
                toSavePlaces.setCreatedBy(loggedInUser);
            }
            com.qqs.posvcs.model.Places places = ds.getPlacesDS().savePlaces(toSavePlaces);

            placesToApi = placesToAPI.translate(places , Places.class, true);

        } catch (Exception e ) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving Places");
        }
        return placesToApi;
    }
}
