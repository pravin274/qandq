package com.qqs.posvcs.service;

import com.qqs.posvcs.api.*;
import com.qqs.posvcs.api.billing.*;
import com.qqs.posvcs.api.common.People;
import com.qqs.posvcs.model.PartCommodity;
import com.qqs.posvcs.model.Vendor;
import com.qqs.posvcs.service.startup.ApplicationCodeMap;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.pdf.PDFCreateService;
import com.qqs.qqsoft.utils.CurrencyUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;
import java.lang.Math;

import static com.qqs.posvcs.api.translation.ParentEntityType.VENDOR;
import static com.qqs.posvcs.utils.Constants.*;

@Component
public class InvoiceGenerateHelper {

    @Resource
    DataService ds;

    @Resource
    private ApplicationCodeMap systemCodeMap;

    @Resource
    private POService poService;

    @Resource
    private PeopleService peopleService;

    @Resource
    private AddressService addressService;

    @Resource
    private BankService bankService;

    @Resource
    private PlantService plantService;


    public void generateInvoice(Invoice invoice, ByteArrayOutputStream stream, String invoiceType) throws QQBusinessException {

        Map<String, String> invoicePdfValueMap = new HashMap<>();
        Map<String, Map<String, com.qqs.posvcs.api.common.Codes>> codesMap = systemCodeMap.getCodeMap();

        Optional<Vendor> vendor = ds.getVendorDS().getVendorById(VENDOR_ID);
        String gstinNo = "";
        String ieCode = "";
        String vendorName = "";
        String panNo = "";
        String email = "";
        String phoneNumber = "";
        Integer stateCode = 0;
        Integer districtCode = 0;

        if (vendor.isPresent()) {
            vendorName = vendor.get().getVendorName();
            email = vendor.get().getEmail();
            phoneNumber = vendor.get().getPhoneNumber();
            stateCode = vendor.get().getStateCode();
            districtCode = vendor.get().getDistrictCode();
            panNo = vendor.get().getPanNo();
            gstinNo = vendor.get().getGstinNo();
            ieCode = vendor.get().getIeCode();
        }

        List<Address> vendorAddressList = (List) addressService.getAddressByParentType(VENDOR.getDbCode(), VENDOR_ID);


        vendorAddressList.forEach( address -> {
            address.setCityName(ds.getAddressDS().findCityNameById(address.getCity()).get());
            address.setProvinceName(ds.getAddressDS().findStateNameById(address.getProvince()).get());
            address.setCountryName(ds.getAddressDS().findCountryNameById(address.getCountry()).get());
        });

                Address vendorAddress = new Address();
        String vendorDisplayAddress = "";


        if (vendorAddressList != null && vendorAddressList.size() > 0) {
            vendorAddress = vendorAddressList.get(0);
            StringBuffer vendorAddressSB = new StringBuffer();
            vendorAddressSB.append(vendorAddress.getLineOne() == null ? "" : vendorAddress.getLineOne() + ", ");
            vendorAddressSB.append(vendorAddress.getLineTwo() == null ? "" : vendorAddress.getLineTwo() + ", ");
            vendorAddressSB.append(vendorAddress.getLineThree() == null ? "" : vendorAddress.getLineThree() + ", ");
            vendorAddressSB.append(vendorAddress.getLineFour() == null ? "" : vendorAddress.getLineFour() + ", ");
            vendorAddressSB.append(vendorAddress.getCityName() == null ? "" :  vendorAddress.getCityName());
            vendorAddressSB.append(vendorAddress.getPostalCd() == null ? "" : " - " + vendorAddress.getPostalCd());

            vendorDisplayAddress = vendorAddressSB.toString();
        }
        PurchOrder firstPO = poService.getPurchaseOrderById(invoice.getPurchOrderList().get(0).getId());

        Set<People> peopleList = firstPO.getPeoples();
        People buyer = new People();
        for (People people : peopleList) {
            if (people.getId() == firstPO.getBuyer()) {
                buyer = peopleService.getPeopleById(people.getId());
                break;
            }
        }

        PlantDeliveryTerms plantDeliveryTerms = plantService.getPlantDeliveryTerms(firstPO.getDvryTermsId());
        PlantPaymentTerms plantPaymentTerms = plantService.getPlantPaymentTerms(firstPO.getPymntTermsId());

        String deliveryTerms = "";
        String paymentTerms = "";
        if (plantDeliveryTerms != null) {
            deliveryTerms = codesMap.get("DELIVERY_TERMS").get(plantDeliveryTerms.getDeliveryTerms()).getDescription();
        }

        if(invoice.getPaymentTermsCode().equals("OT")) {
            paymentTerms = invoice.getPaymentTermsText();
        } else {
            paymentTerms = codesMap.get("PAYMENT_TERMS").get(invoice.getPaymentTermsCode()).getDescription();
        }

//        if (plantPaymentTerms != null) {
//            paymentTerms = codesMap.get("PAYMENT_TERMS").get(plantPaymentTerms.getPaymentTerms()).getDescription();
//        }

        String transportCode = "";

        if (!TOOL.equals(invoiceType)) {
            transportCode = codesMap.get("TRANSPORT_MODE").get(invoice.getTransport()).getDescription();
        } else {
            transportCode = "NA";
        }
        String paymentDec = codesMap.get("PAYMENT_DECLARATION").get(invoice.getPaymentDeclaration()).getDescription();
        String declaration = codesMap.get("DECLARATION").get(invoice.getDeclaration()).getDescription();

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
        sdf.setTimeZone(TimeZone.getTimeZone(codesMap.get("APP_TIME_ZONE").get("TZ").getDescription()));
        String invDate = sdf.format(invoice.getInvDate());
        Set<String> poDates = new HashSet<>();
        Set<String> poNumber = new HashSet<>();

        Map<Integer, PoLineItem> poLineItems = new HashMap<>();
        Set<Integer> poLineItemIds = new HashSet<>();
        Map<Integer, InvoiceLineItem> invoiceLineItemMap = new HashMap<>();
        invoice.getInvoiceLineItems().forEach(invLineItem -> {
            poLineItemIds.add(invLineItem.getPoLineId());
            invoiceLineItemMap.put(invLineItem.getId(), invLineItem);
        });

        List<Integer> commodityCodeIds = new ArrayList<>();
        Map<Integer, PurchOrder> poMap = new HashMap<>();
        String currencyCode = "";
        invoice.getPurchOrderList().forEach(item -> {
            poDates.add(sdf.format(item.getPoDate()));
            poNumber.add(item.getPoNumber());

            item.getPoLineItems().forEach(poLineItem -> {
                if (poLineItemIds.contains(poLineItem.getId())) {
                    poLineItems.put(poLineItem.getId(), poLineItem);
                    if (poLineItem.getCommodityCodeId() != null) {
                        commodityCodeIds.add(poLineItem.getCommodityCodeId());
                    }
                    poMap.put(poLineItem.getId(), item);
                }
            });
        });

        Set<String> meisCodes = new HashSet<>();
        String meisCode = "";
        Map<Integer, String> commodityMap = new HashMap<>();
        if (commodityCodeIds.size() > 0) {
            Iterable<PartCommodity> partCommodityList = ds.getPartDS().getAllCommodityById(commodityCodeIds);
            partCommodityList.forEach(item -> {
                meisCodes.add(item.getCommodityCode());
                commodityMap.put(item.getId(), item.getCommodityCode());
            });
            meisCode = String.join(", ", meisCodes);
        }

        //TODO - change to retrieve
        Bank bank = bankService.getBankById(invoice.getBankId());
        String bankName = "";
        String ifscCode = "";
        String swiftCode = "";
        String adCode = "";
        String accountNo = "";

        if (bank != null) {
            bankName = bank.getBankName();
            ifscCode = bank.getIfscCode();
            accountNo = bank.getAccountNumber();
            adCode = bank.getAdCode();
            swiftCode = bank.getSwiftcode();
        }

        Address deliveryAddress = firstPO.getDeliveryAddress();
        Address billingAddress = firstPO.getBillToAddress();

        ///
        List<String> deliveryAddressList = (List) addressService.addressFormatter(deliveryAddress, codesMap);
        List<String> billAddressList = (List) addressService.addressFormatter(billingAddress, codesMap);
        ///

        String buyerEmailAddress = "";

        Set<Email> emails = buyer.getEmails();
        if (emails != null) {
            Optional<Email> buyerEmail = emails.stream().findFirst();
            if (buyerEmail.isPresent()) buyerEmailAddress = buyerEmail.get().getEmailId();
        }

        String buyerFaxNo = "";
        Set<Phone> phones = buyer.getPhones();
        if (phones != null) {
            Optional<Phone> buyerFax = phones.stream().findFirst();
            if (buyerFax.isPresent()) buyerFaxNo = buyerFax.get().getPhoneNo();
        }

        List<Places> places = invoice.getPlacesList();
        Places portLoad = new Places();
        Places portDischarge = new Places();
        Places countryOrgin = new Places();
        Places countryOfFinal = new Places();
        Places supplyPlace = new Places();
        for (Places item : places) {
            if (invoice.getPortDischarge() != null && item.getId() == invoice.getPortDischarge().intValue())
                portDischarge = item;
            if (invoice.getPortLoad() != null && item.getId() == invoice.getPortLoad().intValue()) portLoad = item;
            if (invoice.getCountryOrigin() != null && item.getId() == invoice.getCountryOrigin().intValue())
                countryOrgin = item;
            if (invoice.getCountryOfFinal() != null && item.getId() == invoice.getCountryOfFinal().intValue())
                countryOfFinal = item;
            if (invoice.getSupplyPlace() != null && item.getId() == invoice.getSupplyPlace().intValue())
                supplyPlace = item;
        }

        if (INDIA.equals(countryOfFinal.getDescription())) {
            invoicePdfValueMap.put("invTitle", DOMESTIC_INVOICE_TITLE);
            Plant plant = plantService.getPlantById(invoice.getPlantId());
            invoicePdfValueMap.put("taxGstInNumber", "GSTIN - " + String.valueOf(plant.getTaxId()));
        } else {
            invoicePdfValueMap.put("invTitle", INVOICE_TITLE);
        }
        String address = vendorDisplayAddress +","+ (vendorAddress.getProvinceName() + ", " + vendorAddress.getCountryName());
        String phoneNoAndEmail = "Telephone No " + ":"+ phoneNumber +" " + "E Mail "+ ":" + email;
        invoicePdfValueMap.put("invSubTitle", INVOICE_SUB_TITLE);
        invoicePdfValueMap.put("vendorName", vendorName);
        invoicePdfValueMap.put("address1",address );
        invoicePdfValueMap.put("address2",phoneNoAndEmail); // "TAMIL NADU,  INDIA ");
        invoicePdfValueMap.put("panNo", panNo);
        invoicePdfValueMap.put("gstinNo", gstinNo);
        invoicePdfValueMap.put("stateCode", stateCode.toString());
        invoicePdfValueMap.put("districtCode", districtCode.toString());
        invoicePdfValueMap.put("invoiceSerialNo", invoice.getSerialNo());
        invoicePdfValueMap.put("vendorCode", firstPO.getVendorCode());
        invoicePdfValueMap.put("invDate", invDate);
        invoicePdfValueMap.put("transportMode", transportCode);
        invoicePdfValueMap.put("ieCodeNo", ieCode);
        invoicePdfValueMap.put("placeOfSupply", supplyPlace.getDescription());
        // deliver and bill adress
        int addressLineCount = 1;
        for (String del : deliveryAddressList) {
            invoicePdfValueMap.put("deliveryAddress" + addressLineCount, del);
            addressLineCount++;
        }
        int billAddressLineCount = 1;
        for (String bil : billAddressList) {
            invoicePdfValueMap.put("recipientAddress" + billAddressLineCount, bil);
            billAddressLineCount++;
        }
        invoicePdfValueMap.put("buyerName", buyer.getFirstName() + " " + buyer.getLastName());
        if (invoice.getPurchOrderList().size() > 2) {
            invoicePdfValueMap.put("poNoMulti", String.join(", ", poNumber));
        } else {
            invoicePdfValueMap.put("poNo", String.join(", ", poNumber));
        }
        invoicePdfValueMap.put("poDate", String.join(", ", poDates));
        invoicePdfValueMap.put("eMail", buyerEmailAddress);
        invoicePdfValueMap.put("faxNo", buyerFaxNo);
        if (!TOOL.equals(invoiceType)) {
            invoicePdfValueMap.put("preCarriageBy", codesMap.get("PRE_CARRIAGE").get(invoice.getPreCarriage()).getDescription());
            invoicePdfValueMap.put("placeofReceipt", codesMap.get("PLACE_RECEIPT").get(invoice.getPlaceReceipt()).getDescription());
            invoicePdfValueMap.put("vesselFlight", invoice.getVesselNo());
            invoicePdfValueMap.put("portOfDischarge", portDischarge != null ? portDischarge.getDescription() : "");
            invoicePdfValueMap.put("portOfLoading", portLoad != null ? portLoad.getDescription() : "");
            invoicePdfValueMap.put("meisCode", meisCode);
        } else {
            invoicePdfValueMap.put("preCarriageBy", "NA");
            invoicePdfValueMap.put("placeofReceipt", "NA");
            invoicePdfValueMap.put("vesselFlight", "NA");
            invoicePdfValueMap.put("portOfDischarge", "NA");
            invoicePdfValueMap.put("portOfLoading", "NA");
        }
        invoicePdfValueMap.put("finalDestination", invoice.getFinalDest());
        invoicePdfValueMap.put("countryOfOrigin", countryOrgin.getDescription());
        invoicePdfValueMap.put("countryOfFinal", countryOfFinal.getDescription());
        invoicePdfValueMap.put("termsOfDelivery", deliveryTerms);
        invoicePdfValueMap.put("paymentTerms", paymentTerms);
        invoicePdfValueMap.put("description", invoice.getSplInstruction());
        invoicePdfValueMap.put("paymentDecalaration", paymentDec);
        if (invoice.getSplDeclaration() != null) {
            invoicePdfValueMap.put("splinstruction", REX);
            String rexComment = invoice.getSplDeclaration() + " " + meisCode;
            invoicePdfValueMap.put("splinstructioncomments", rexComment);
        }
        invoicePdfValueMap.put("scheme", invoice.getScheme());

        if (invoice.getSecondSplInstruction() != null) {
            invoicePdfValueMap.put("secondSplInstructionOfDeclaration", invoice.getSecondSplInstruction());
        }

        if (invoice.getSliInstruction() != null) {
            invoicePdfValueMap.put("sliInstruction", invoice.getSliInstruction());
        }

        if (invoice.getPaymentDeclaration().contains("IGST")) {
            invoicePdfValueMap.put("splInstructionOfDeclaration", codesMap.get("SLI_SI").get("SLIIGST").getDescription());
        } else if (invoice.getPaymentDeclaration().contains("LUT")) {
            invoicePdfValueMap.put("splInstructionOfDeclaration", codesMap.get("SLI_SI").get("SLILUT").getDescription());
        }

        invoicePdfValueMap.put("bankName", bankName);
        invoicePdfValueMap.put("ifscCode", ifscCode);
        invoicePdfValueMap.put("accountNo", accountNo);
        invoicePdfValueMap.put("swiftCode", swiftCode);
        invoicePdfValueMap.put("adCode", adCode);
        invoicePdfValueMap.put("declaration", declaration);
        invoicePdfValueMap.put("shippingThrough", invoice.getShippingThrough());

        // Invoice Line Items
        int lineItemCount = 1;
        Double totalQty = 0.0;
        Double totalUnitPrice = 0.0;
        Double grantTotalValue = 0.0;

        for (InvoiceLineItem invoiceLineItem : invoice.getInvoiceLineItems()) {
            PoLineItem poLineItem = poLineItems.get(invoiceLineItem.getPoLineId());
            invoicePdfValueMap.put("poLineNoRow" + lineItemCount, poLineItem.getItem());
            invoicePdfValueMap.put("poNoRow" + lineItemCount, poMap.get(invoiceLineItem.getPoLineId()).getPoNumber());
            invoicePdfValueMap.put("descRow" + lineItemCount, poLineItem.getDescription());

            if (TOOL.equals(invoiceType)) {

                invoicePdfValueMap.put("paymentDescription" + lineItemCount, codesMap.get("TOOL_PAYMENT").get(invoiceLineItem.getToolPaymentDescription()).getDescription());
                invoicePdfValueMap.put("partNoRow" + lineItemCount, poLineItem.getPoLineTool().getToolNo());
            } else {
                invoicePdfValueMap.put("partNoRow" + lineItemCount, poLineItem.getPart().getNumber());
                invoicePdfValueMap.put("hsCodeRow" + lineItemCount, commodityMap.get(poLineItem.getCommodityCodeId()));
            }
            Double qty = invoiceLineItem.getInvoiceQty();
            Double unitPrice = Double.valueOf(poLineItem.getPartPrice());
            Double total = qty * unitPrice;
            totalQty += qty;
            totalUnitPrice += unitPrice;
            grantTotalValue += total;
            if (TOOL.equals(invoiceType)) {
                invoicePdfValueMap.put("qtyRow" + lineItemCount, qty.toString());
            } else {
                invoicePdfValueMap.put("qtyRow" + lineItemCount, String.valueOf((int) Math.round(qty)));
            }
            invoicePdfValueMap.put("unitPriceRow" + lineItemCount, String.format("%.2f", unitPrice));
            invoicePdfValueMap.put("totalValueRow" + lineItemCount, String.format("%.2f", total));
            lineItemCount++;
            currencyCode = poLineItem.getCurrency();

            currencyCode = codesMap.get("CURRENCY").get(currencyCode).getDescription();
        }

        if (TOOL.equals(invoiceType)) {
            invoicePdfValueMap.put("totalQty", totalQty.toString());
        } else {
            invoicePdfValueMap.put("totalQty", String.valueOf((int) Math.round(totalQty)));
        }

        ////// GST CALCULA  //////
        Double grantTotalTAX = 0.0;
        if (INDIA.equals(countryOfFinal.getDescription())) {
            if (invoice.getIgst() != null) {
                Double igst = ((grantTotalValue * invoice.getIgst()) / 100);
                grantTotalTAX = igst;
                invoicePdfValueMap.put("tax1", "IGST -" + invoice.getIgst() + "%");
                invoicePdfValueMap.put("taxValue1", String.valueOf(igst));
            } else {
                if (invoice.getCgst() != null) {
                    Double cgst = ((grantTotalValue * invoice.getCgst()) / 100);
                    grantTotalTAX += cgst;
                    invoicePdfValueMap.put("tax1", "CGST -" + invoice.getCgst() + "%");
                    invoicePdfValueMap.put("taxValue1", String.valueOf(cgst));
                }
                if (invoice.getSgst() != null) {
                    Double sgst = ((grantTotalValue * invoice.getSgst()) / 100);
                    grantTotalTAX += sgst;
                    invoicePdfValueMap.put("tax2", "SGST -" + invoice.getSgst() + "%");
                    invoicePdfValueMap.put("taxValue2", String.valueOf(sgst));
                }
            }
        }

        if (grantTotalTAX != 0.0) {
            grantTotalValue += grantTotalTAX;
            invoicePdfValueMap.put("subTotalValue", String.format("%.2f", grantTotalValue - grantTotalTAX));
        }
        String currencyCodeINR = codesMap.get("CURRENCY").get("INR").getDescription();

        invoicePdfValueMap.put("totalValue", String.format("%.2f", grantTotalValue));
        invoicePdfValueMap.put("valueInWords", currencyCode + " " + CurrencyUtils.convertToWordCurrency(grantTotalValue, currencyCode).toString() + " only)");
        invoicePdfValueMap.put("currency", "(" + currencyCode + ")");
        Double invINRVal = grantTotalValue * invoice.getCurrConvRs();
        Double subtotalTaxableAmt = 0.0;

        if ("Y".equalsIgnoreCase(invoice.getUndertakingLUT())) {

            invoicePdfValueMap.put("lutExport", "true");
            subtotalTaxableAmt = invINRVal;
            invoicePdfValueMap.put("igstValue","NA" );
            invoicePdfValueMap.put("totalIgstInWord","NA");
        } else {

            invoicePdfValueMap.put("payment", "true");
            Double taxAmt = ((invINRVal * GST_RATE) / 100);
            subtotalTaxableAmt = invINRVal + taxAmt;
            invoicePdfValueMap.put("igstValue",String.valueOf(taxAmt) );
            invoicePdfValueMap.put("totalIgstInWord",CurrencyUtils.convertToWordCurrency(taxAmt,currencyCodeINR) + "Only");
            invoicePdfValueMap.put("igstAmount", "Invoice value Rs. " + String.format("%.2f", invINRVal) + " + IGST Rs. " + String.format("%.2f", taxAmt) + " = Total  Rs. " + String.format("%.2f", subtotalTaxableAmt));
        }
        Double roundOff = Math.round(subtotalTaxableAmt) - subtotalTaxableAmt;
        Double totalINRValue =  roundOff + subtotalTaxableAmt ;
        invoicePdfValueMap.put("valueINR",  invINRVal.toString());
        invoicePdfValueMap.put("subTotal",String.valueOf(subtotalTaxableAmt));
        invoicePdfValueMap.put("roundOff",String.format("%.2f", roundOff));
        invoicePdfValueMap.put("totalValueINR",String.valueOf(totalINRValue));
        invoicePdfValueMap.put("exangeRate", String.valueOf(invoice.getCurrConvRs()));
        invoicePdfValueMap.put("igst", String.valueOf(GST_RATE));
        invoicePdfValueMap.put("totalInvoiceValue",CurrencyUtils.convertToWordCurrency(totalINRValue,currencyCodeINR) + "Only");

        int pkgDetailCount = 0;
        //Package Master & Details
        if (!TOOL.equals(invoiceType)) {
            pkgDetailCount = packingList(invoice, stream, invoicePdfValueMap, invoiceLineItemMap, poLineItems, grantTotalValue);
        }

        PDFCreateService service = new PDFCreateService();

        try {
            String templateName = null;
            if (TOOL.equals(invoiceType)) {
                templateName = TOOL_PDF;
            } else {
                if (pkgDetailCount > 5) {
                    templateName = PDF_MULTI_PKG;
                } else {
                    if (GERMANY.equals(countryOfFinal.getDescription())) {
                        templateName = GERMANY_SINGLE;
                    } else if (INDIA.equals(countryOfFinal.getDescription())) {
                        templateName = DOMESTIC_SINGLE;
                    } else {
                        templateName = PDF_SINGLE_PKG;
                    }
                }
            }
            service.getPdfContent(invoicePdfValueMap, stream, templateName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int packingList(Invoice invoice, ByteArrayOutputStream stream, Map<String, String> invoicePdfValueMap,
                           Map<Integer, InvoiceLineItem> invoiceLineItemMap,
                           Map<Integer, PoLineItem> poLineItems, Double grantTotalValue)
            throws QQBusinessException {
        int pkgDetailCount = 1;
        int pkgMasterCount = 1;
        int totalBoxCount = 0;
        int totalBoxQty = 0;
        int totalPkgMasterQty = 0;
        int boxQty = 0;
        BigDecimal totalGrossWt = BigDecimal.valueOf(0.0);
        BigDecimal totalNetWt = BigDecimal.valueOf(0.0);
        BigDecimal grantGrossWt = BigDecimal.valueOf(0.0);

        int boxCount = 0;
        if (invoice.getPkgMasters() != null) {
            boxCount = invoice.getPkgMasters().size();


            List<PkgMaster> groupPkgMaster = new ArrayList<>();
            for (PkgMaster item : invoice.getPkgMasters()) {
                if (!item.getIsDeleted()) {
                    if (groupPkgMaster.size() > 0) {
                        boolean matchFound = false;
                        for (PkgMaster pkgMaster : groupPkgMaster) {
                            if (pkgMaster.isSimilarBox(item)) {
                                pkgMaster.setGroupCount(pkgMaster.getGroupCount() + 1);
                                matchFound = true;
                                break;
                            }
                        }
                        if (!matchFound) {
                            item.setGroupCount(1);
                            groupPkgMaster.add(item);
                        }
                    } else {
                        item.setGroupCount(1);
                        groupPkgMaster.add(item);
                    }
                }
            }

            for (PkgMaster item : groupPkgMaster) {
                if (!item.getIsDeleted()) {
                    String weightUnit = '(' + item.getWeightUnit() + ')';
                    String DimensionUnit = '(' + item.getDimensionUnit() + ')';

                    invoicePdfValueMap.put("weightUnit", weightUnit);
                    invoicePdfValueMap.put("measureUnit", DimensionUnit);
                    boxQty = 0;
                    String boxNo = "";
                    if (item.getGroupCount() > 1) {
                        boxNo = (totalBoxCount + 1) + " to " + (totalBoxCount + item.getGroupCount());
                        boxQty = item.getGroupCount();
                    } else {
                        boxNo = (totalBoxCount + 1) + " of " + boxCount;
                        boxQty = 1;
                    }
                    for (PkgDetail pkgDetail : item.getPkgDetails()) {
                        if (!pkgDetail.getIsDeleted()) {
                            invoicePdfValueMap.put("packListBoxRow" + pkgDetailCount, boxNo);
                            int poLineItemId = invoiceLineItemMap.get(pkgDetail.getInvoiceLineItemId()).getPoLineId();
                            invoicePdfValueMap.put("packListPartRow" + pkgDetailCount, poLineItems.get(poLineItemId).getPart().getNumber());
                            invoicePdfValueMap.put("packListDescRow" + pkgDetailCount, poLineItems.get(poLineItemId).getDescription());
                            invoicePdfValueMap.put("packListQtyRow" + pkgDetailCount, ((Integer) (pkgDetail.getQty() * boxQty)).toString());
                            invoicePdfValueMap.put("packListWeightRow" + pkgDetailCount, String.valueOf(pkgDetail.getWeightPrPiece()));
                            invoicePdfValueMap.put("packListNetWeightRow" + pkgDetailCount, String.valueOf(pkgDetail.getWeightPrPiece().
                                    multiply(new BigDecimal(pkgDetail.getQty() * boxQty))));
                            totalBoxQty += (pkgDetail.getQty() * boxQty);
                            pkgDetailCount++;
                        }
                    }
                    invoicePdfValueMap.put("pkgMasRow" + pkgMasterCount, boxNo);
                    invoicePdfValueMap.put("pkgMasCmsRow" + pkgMasterCount, String.valueOf(item.getLength().intValue()) + " x " + String.valueOf(item.getWidth().intValue()) + " x " + String.valueOf(item.getHeight().intValue()));
                    invoicePdfValueMap.put("pkgMasNoOfBoxesRow" + pkgMasterCount, String.valueOf(boxQty));
                    invoicePdfValueMap.put("pkgMasQtyBoxRow" + pkgMasterCount, item.getTotalQty().toString());
                    invoicePdfValueMap.put("netWtBoxKgsRow" + pkgMasterCount, String.valueOf(item.getNetWeight()));
                    invoicePdfValueMap.put("pkgMasGrossWtRow" + pkgMasterCount, String.valueOf(item.getGrossWeight()));
                    invoicePdfValueMap.put("pkgMasTotalNetRow" + pkgMasterCount, String.valueOf(item.getNetWeight().multiply(new BigDecimal(boxQty))));
                    invoicePdfValueMap.put("pkgMasTotalGrossRow" + pkgMasterCount, String.valueOf(item.getGrossWeight().multiply(new BigDecimal(boxQty))));

                    totalBoxCount = totalBoxCount + boxQty;
                    totalPkgMasterQty += (item.getTotalQty() * boxQty);
                    totalGrossWt = totalGrossWt.add(item.getGrossWeight().multiply(new BigDecimal(boxQty)));
                    totalNetWt = totalNetWt.add(item.getNetWeight().multiply(new BigDecimal(boxQty)));
                    grantGrossWt = grantGrossWt.add(item.getGrossWeight().multiply(new BigDecimal(boxQty)));

                    pkgMasterCount++;
                }
            }

            invoicePdfValueMap.put("packListTotalQty", String.valueOf(totalBoxQty));
            invoicePdfValueMap.put("boxesTotal", String.valueOf(totalBoxCount));
            invoicePdfValueMap.put("qtyBoxNosTotal", String.valueOf(totalPkgMasterQty));
            invoicePdfValueMap.put("grossWtTotal", String.valueOf(totalGrossWt));
            invoicePdfValueMap.put("sliTotalGrossTotal", String.valueOf(Math.round(Double.valueOf(String.valueOf(grantGrossWt)))));
            invoicePdfValueMap.put("sliTotalNetTotal", String.valueOf(Math.round(Double.valueOf(String.valueOf(totalNetWt)))));
            invoicePdfValueMap.put("totalNetTotal", String.valueOf(totalNetWt));
            invoicePdfValueMap.put("totalGrossTotal", String.valueOf(grantGrossWt));

            if (invoice.getSliDocumentsList() != null) {
                invoice.getSliDocumentsList().forEach(item -> {
                    if (!item.getIsDeleted()) invoicePdfValueMap.put(item.getDocument(), "true");
                });
            }
            return pkgDetailCount;


        } else {
            return -1; // negtive val
        }


    }
}
