package com.qqs.posvcs.service;


import com.qqs.qqsoft.utils.SecurityUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
public class DataService {
    @Resource
    private CompanyDataService companyDS;
    @Resource
    private PlantDataService plantDS;
    @Resource
    private AddressDataService addressDS;
    @Resource
    private PhoneDataService phoneDS;
    @Resource
    private EmailDataService emailDS;
    @Resource
    private PurchOrderDataService purchOrderDS;
    @Resource
    private POLineItemDataService poLineItemDS;
    @Resource
    private PartDataService partDS;
    @Resource
    private PeopleDataService peopleDS;
    @Resource
    private PlacesDataService placesDS;
    @Resource
    private InvoiceDataService invoiceDS;
    @Resource
    private InvoiceLineItemDataService invoiceLineItemDS;
    @Resource
    private PkgDataService pkgDataService;
    @Resource
    private VendorDataService vendorDS;
    @Resource
    private AtsDataService atsDS;
    @Resource
    private PackageCheckLisMastertDataService packageCheckLisMastertDataService;
    @Resource
    private NdaDataService ndaDataService;
    @Resource
    private CountriesDataService countriesDataService;
    @Resource
    private StatesDataService statesDataService;
    @Resource
    private CityDataService cityDataService;
    @Resource
    private CurrencyExchangeRateDataService currencyExchangeRateDataService;

    @Resource
    SecurityUtils security;

    public CompanyDataService getCompanyDS() {
        return companyDS;
    }

    public PlantDataService getPlantDS() {
        return plantDS;
    }

    public AddressDataService getAddressDS() {
        return addressDS;
    }

    public PhoneDataService getPhoneDS() {
        return phoneDS;
    }

    public EmailDataService getEmailDS() {
        return emailDS;
    }

    public PurchOrderDataService getPurchOrderDS() {
        return purchOrderDS;
    }

    public POLineItemDataService getPoLineItemDS() {
        return poLineItemDS;
    }

    public PartDataService getPartDS() {
        return partDS;
    }

    public PeopleDataService getPeopleDS() {
        return peopleDS;
    }

    public PlacesDataService getPlacesDS() {
        return placesDS;
    }

    public InvoiceDataService getInvoiceDS() {
        return invoiceDS;
    }

    public InvoiceLineItemDataService getInvoiceLineItemDS() {
        return invoiceLineItemDS;
    }

    public PkgDataService getPkgDataService() {
        return pkgDataService;
    }

    public SecurityUtils getSecurity() {
        return security;
    }

    public VendorDataService getVendorDS() {
        return vendorDS;
    }

    public AtsDataService getAtsDS() {
        return atsDS;
    }

    public PackageCheckLisMastertDataService getPackageCheckListMasterDS() {
        return packageCheckLisMastertDataService;
    }

    public NdaDataService getNdaDS() {
        return ndaDataService;
    }

    public CountriesDataService getCountriesDataService() { return countriesDataService; }

    public StatesDataService getStatesDataService() { return statesDataService; }

    public CityDataService getCityDataService() { return cityDataService; }

    public  CurrencyExchangeRateDataService getCurrencyExchangeRateDataService() { return  currencyExchangeRateDataService; }
}
