package com.qqs.posvcs.service;

import com.qqs.posvcs.api.Countries;
import com.qqs.posvcs.api.Plant;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;

import static com.qqs.posvcs.service.translate.APITranslator.*;

@Component
public class CountriesService {

    Logger logger = LoggerFactory.getLogger(CountriesService.class);

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    @Resource
    DataService ds;

    public Countries saveCountry(Countries countriesData) throws QQBusinessException {
        Countries countriesToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        try {
            com.qqs.posvcs.model.Countries toSaveCountries =  countriesToDB.translate(countriesData, com.qqs.posvcs.model.Countries.class, true);
//            if(toSaveAddresse.getId() > 0) {
//                new DateUtils<com.qqs.posvcs.model.Address>().setTimeStamp(toSaveAddresse, com.qqs.posvcs.model.Address.class, true);
//                toSaveAddresse.setModifiedBy(loggedInUser);
//            } else {
//                new DateUtils<com.qqs.posvcs.model.Address>().setTimeStamp(toSaveAddresse, com.qqs.posvcs.model.Address.class, false);
//                toSaveAddresse.setCreatedBy(loggedInUser);
//            }
            com.qqs.posvcs.model.Countries countries = ds.getCountriesDataService().saveCountry(toSaveCountries);

            countriesToApi = countriesToAPI.translate(countries , Countries.class, true);

        } catch (Exception e ) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving Countries details");
        }
        return countriesToApi;

    }


    public Countries getCountryById(Integer countryId) throws QQBusinessException {
        try {
            Optional<com.qqs.posvcs.model.Countries> country = ds.getCountriesDataService().getCountryById(countryId);
            if (!country.isPresent()) {
                throw new QQBusinessException("No Countries found");
            }
            Countries countriesAPI = countriesToAPI.translate(country.get(), Countries.class, false);
            return countriesAPI;
        } catch (Exception e) {
            logger.error("Countries fetch error", e);
        }
        throw new QQBusinessException("Countries could not be retrieved");
    }



    public List<Countries> getAllCountries() throws QQBusinessException {
        List<Countries> result = new ArrayList<>();
        Iterable<com.qqs.posvcs.model.Countries> countries = ds.getCountriesDataService().getAllCountries();
        countries.forEach(country -> {
            try {
                result.add(countriesToAPI.translate(country, Countries.class, false));
            } catch (Exception e) {
                logger.error("translation exception");
            }
        });
        return result;
    }



    public List<Countries> searchCountries(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createCountrySearchCriteria(params, exactMatch);
        Optional<List<com.qqs.posvcs.model.Countries>> countryList = ds.getCountriesDataService().searchCountries(conditions);
        if (!countryList.isPresent())
            throw new QQBusinessException("No client found for criteria");
        List<Countries> result = null;
        try {
            result = countriesToAPI.translate(countryList.get(), Countries.class, false);
        } catch (Exception e) {
            logger.error("translation exception");
        }
        return result;
    }

    private List<SearchCriteria> createCountrySearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"name", "sortname"}));
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, null, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }



}
