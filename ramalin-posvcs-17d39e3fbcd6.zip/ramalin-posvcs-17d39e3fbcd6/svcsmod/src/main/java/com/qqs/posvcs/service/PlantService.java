package com.qqs.posvcs.service;

import com.qqs.posvcs.api.Company;
import com.qqs.posvcs.api.Plant;
import com.qqs.posvcs.api.translation.ParentEntityType;
import com.qqs.posvcs.model.Address;
import com.qqs.posvcs.model.PlantDeliveryTerms;
import com.qqs.posvcs.model.PlantPaymentTerms;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import com.qqs.qqsoft.QQBusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import javax.annotation.Resource;
import java.util.*;

import static com.qqs.posvcs.api.translation.ParentEntityType.PEOPLE;
import static com.qqs.posvcs.service.translate.APITranslator.*;

@Component
public class PlantService {

    Logger logger = LoggerFactory.getLogger(PlantService.class);

    @Resource
    DataService dataService;

    @Resource
    CompanyService companyService;

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;


    @Resource
    PeopleService peopleService;

    public Plant savePlant(Plant plantData) throws QQBusinessException {
        Plant plantToApi = null;
        Integer loggedInUser = dataService.getSecurity().getLoggedInUser();
        try {
            com.qqs.posvcs.model.Plant toSavePlant =  plantToDB.translate(plantData, com.qqs.posvcs.model.Plant.class, true);
            if(toSavePlant.getId() > 0) {
                new DateUtils<com.qqs.posvcs.model.Plant>().setTimeStamp(toSavePlant, com.qqs.posvcs.model.Plant.class, true);
                toSavePlant.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.posvcs.model.Plant>().setTimeStamp(toSavePlant, com.qqs.posvcs.model.Plant.class, false);
                toSavePlant.setCreatedBy(loggedInUser);
            }
            com.qqs.posvcs.model.Plant plant = dataService.getPlantDS().savePlant(toSavePlant);

            plantToApi = plantToAPI.translate(plant , Plant.class, true);
        } catch (Exception e ) {
            System.out.println(e);
            throw new QQBusinessException("Error while Saving Plant details.");
        }
        return plantToApi;
    }


    public Plant getPlantById(Integer id) throws QQBusinessException {
        Optional<com.qqs.posvcs.model.Plant> plantOpt = dataService.getPlantDS().getPlantById(id);
        if (plantOpt.isPresent()) {
            try {
                Plant plant = plantToAPI.translate(plantOpt.get(), Plant.class, false);
                try {
                    Company company = companyService.getCompanyById(plantOpt.get().getCompanyId ());
                    plant.setCompany(company);
                } catch (Exception e) {
                    logger.error("translation exception - Company");
                }

                try {
                    List<com.qqs.posvcs.api.Address> addresses =
                            addressToAPI.translate(
                                retrieveAddress(plant.getId()), com.qqs.posvcs.api.Address.class, false);
                    addresses.forEach( address -> {
                        address.setCityName(dataService.getAddressDS().findCityNameById(address.getCity()).get());
                        address.setProvinceName(dataService.getAddressDS().findStateNameById(address.getProvince()).get());
                        address.setCountryName(dataService.getAddressDS().findCountryNameById(address.getCountry()).get());
                    });
                plant.setAddresses(addresses);
                } catch (Exception e) {
                    logger.error("translation exception - Address");
                }

                try {
                    Collection<com.qqs.posvcs.api.common.People> peopleList = peopleService.getPeopleByParentType(ParentEntityType.PLANT.getDbCode(), plant.getId());
                    List<Integer> peopleIds = new ArrayList<>();
                    peopleList.forEach( people -> {
                        peopleIds.add(people.getId());
                    });
                    Optional<List<com.qqs.posvcs.model.Phone>> phoneList =  dataService.getPhoneDS().findAllByParentIdInAndParentEntity(peopleIds, PEOPLE.getDbCode());
                    Optional<List<com.qqs.posvcs.model.Email>> emailList = dataService.getEmailDS().findAllByParentIdInAndParentEntity(peopleIds, PEOPLE.getDbCode());
                    Map<Integer, Set<com.qqs.posvcs.api.Phone>> phoneMap = new HashMap<>();
                    Map<Integer, Set<com.qqs.posvcs.api.Email>> emailMap = new HashMap<>();
                    if (phoneList.isPresent()) {
                        List<com.qqs.posvcs.api.Phone> phonesToApi = phoneToAPI.translate(phoneList.get(), com.qqs.posvcs.api.Phone.class , true );
                        phonesToApi.forEach( phone ->  {
                            if (phoneMap.get(phone.getParentId()) == null) {
                                phoneMap.put(phone.getParentId(), new HashSet<>());
                            }
                            phoneMap.get(phone.getParentId()).add(phone);
                        });
                        peopleList.forEach( people -> {
                            if (phoneMap.get(people.getId()) != null) {
                                people.setPhones(phoneMap.get(people.getId()));
                            }
                        });
                    }
                    if (emailList.isPresent()) {
                        List<com.qqs.posvcs.api.Email> emailsToApi = emailToAPI.translate(emailList.get(), com.qqs.posvcs.api.Email.class , true );
                        emailsToApi.forEach( email ->  {
                            if (emailMap.get(email.getParentId()) == null) {
                                emailMap.put(email.getParentId(), new HashSet<>());
                            }
                            emailMap.get(email.getParentId()).add(email);
                        });
                        peopleList.forEach( people -> {
                            if (emailMap.get(people.getId()) != null) {
                                people.setEmails(emailMap.get(people.getId()));
                            }
                        });
                    }
                    plant.setPeople(new ArrayList(peopleList));
                } catch (Exception e) {
                    logger.error("translation exception - People");
                }
                try {
                   Optional<List<PlantDeliveryTerms>> plantDeliveryTerms = dataService.getPlantDS().getPlantDeliveryTermsByPlantId(id);
                   if(plantDeliveryTerms.isPresent()) {
                       plant.setPlantDeliveryTerms(plantDeliveryTermsToAPI.translate(plantDeliveryTerms.get(), com.qqs.posvcs.api.PlantDeliveryTerms.class, false));
                   }
                } catch (Exception e) {
                    logger.error("translation exception - People (DeliveryTerms)");
                }
                try {
                    Optional<List<PlantPaymentTerms>> plantPaymentTerms = dataService.getPlantDS().getPlantPaymentTermsByPlantId(id);
                    if(plantPaymentTerms.isPresent()) {
                        plant.setPlantPaymentTerms(plantPaymentTermsToAPI.translate(plantPaymentTerms.get(), com.qqs.posvcs.api.PlantPaymentTerms.class, false));
                    }
                } catch (Exception e) {
                    logger.error("translation exception - People (DeliveryTerms)");
                }
                return plant;
            } catch (Exception e) {
                logger.error("translation exception - Plant");
            }
        }
        throw new QQBusinessException("No plant information found");
    }

    public List<Plant> getAllPlants() throws QQBusinessException {
        List<Plant> result = new ArrayList<>();
        Iterable<com.qqs.posvcs.model.Plant> plants = dataService.getPlantDS().getAllPlants();
        plants.forEach(p -> {
            try {
                result.add(plantToAPI.translate(p, Plant.class, false));
            } catch (Exception e) {
                logger.error("translation exception");
            }
        });
        return result;
    }


    public List<Plant> searchPlants(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createPlantSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.posvcs.model.Plant>> plantList = dataService.getPlantDS().searchPlant(conditions);
        if (!plantList.isPresent())
            throw new QQBusinessException("No client found for criteria");
        List<Plant> result = null;
        try {
            result = plantToAPI.translate(plantList.get(), Plant.class, false);
        } catch (Exception e) {
            logger.error("translation exception");
        }
        return result;
    }

    private List<Address> retrieveAddress(Integer plantId) {
        return dataService.getAddressDS().findAddressesByPlant(plantId).orElse(Collections.EMPTY_LIST);
    }

    private List<SearchCriteria> createPlantSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"companyId", "plantCode", "description", "vendorCode"}));
        Map<String, String> operators = new HashMap<>(2);
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, operators, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }

    public com.qqs.posvcs.api.PlantDeliveryTerms getPlantDeliveryTerms(Integer id) {
        com.qqs.posvcs.api.PlantDeliveryTerms plantDeliveryTerms = new com.qqs.posvcs.api.PlantDeliveryTerms();
        try {
            plantDeliveryTerms = plantDeliveryTermsToAPI.translate(dataService.getPlantDS().getPlantDeliveryTermsById(id), com.qqs.posvcs.api.PlantDeliveryTerms.class, false);
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return plantDeliveryTerms;
    }

    public com.qqs.posvcs.api.PlantPaymentTerms getPlantPaymentTerms(Integer id) {
        com.qqs.posvcs.api.PlantPaymentTerms plantPaymentTerms = new com.qqs.posvcs.api.PlantPaymentTerms();
        try {
            plantPaymentTerms =  plantPaymentTermsToAPI.translate(dataService.getPlantDS().getPlantPaymentTermsById(id), com.qqs.posvcs.api.PlantPaymentTerms.class, false);
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return plantPaymentTerms;
    }

    public com.qqs.posvcs.api.PlantDeliveryTerms savePlantDeliveryTerms(com.qqs.posvcs.api.PlantDeliveryTerms PlantDeliveryTermsData) throws QQBusinessException {
        com.qqs.posvcs.api.PlantDeliveryTerms plantDeliveryToApi = null;
        Integer loggedInUser = dataService.getSecurity().getLoggedInUser();
        try {
            PlantDeliveryTerms toSavePlantDelivery =  plantDeliveryTermsToDB.translate(PlantDeliveryTermsData, PlantDeliveryTerms.class, true);
            if(toSavePlantDelivery.getId() > 0) {
                new DateUtils<com.qqs.posvcs.model.PlantDeliveryTerms>().setTimeStamp(toSavePlantDelivery, com.qqs.posvcs.model.PlantDeliveryTerms.class, true);
                toSavePlantDelivery.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.posvcs.model.PlantDeliveryTerms>().setTimeStamp(toSavePlantDelivery, com.qqs.posvcs.model.PlantDeliveryTerms.class, false);
                toSavePlantDelivery.setCreatedBy(loggedInUser);
            }
            PlantDeliveryTerms plantDelivery = dataService.getPlantDS().savePlantDeliveryTerms(toSavePlantDelivery);

            plantDeliveryToApi = plantDeliveryTermsToAPI.translate(plantDelivery , com.qqs.posvcs.api.PlantDeliveryTerms.class, true);
        } catch (Exception e ) {
            System.out.println(e);
            throw new QQBusinessException("Error while Saving Delivery Terms");
        }
        return plantDeliveryToApi;
    }

    public com.qqs.posvcs.api.PlantPaymentTerms savePlantPaymentTerms(com.qqs.posvcs.api.PlantPaymentTerms PlantDeliveryTermsData) throws QQBusinessException {
        com.qqs.posvcs.api.PlantPaymentTerms plantPaymentToApi = null;
        Integer loggedInUser = dataService.getSecurity().getLoggedInUser();
        try {
            PlantPaymentTerms toSavePaymentDelivery =  plantPaymentTermsToDB.translate(PlantDeliveryTermsData, PlantPaymentTerms.class, true);
            if(toSavePaymentDelivery.getId() > 0) {
                new DateUtils<com.qqs.posvcs.model.PlantPaymentTerms>().setTimeStamp(toSavePaymentDelivery, com.qqs.posvcs.model.PlantPaymentTerms.class, true);
                toSavePaymentDelivery.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.posvcs.model.PlantPaymentTerms>().setTimeStamp(toSavePaymentDelivery, com.qqs.posvcs.model.PlantPaymentTerms.class, false);
                toSavePaymentDelivery.setCreatedBy(loggedInUser);
            }
            PlantPaymentTerms plantDelivery = dataService.getPlantDS().savePlantPaymentTerms(toSavePaymentDelivery);

            plantPaymentToApi = plantPaymentTermsToAPI.translate(plantDelivery , com.qqs.posvcs.api.PlantPaymentTerms.class, true);
        } catch (Exception e ) {
            System.out.println(e);
            throw new QQBusinessException("Error while Saving Plant Payment Terms");
        }
        return plantPaymentToApi;
    }
}
