package com.qqs.posvcs.service;

import com.qqs.posvcs.api.Company;
import com.qqs.posvcs.api.common.Codes;
import com.qqs.posvcs.api.parts.Part;
import com.qqs.posvcs.model.PackCheckListMaster;
import com.qqs.posvcs.model.PkgCheckList;
import com.qqs.posvcs.service.startup.ApplicationCodeMap;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.mail.MailService;
import com.qqs.qqsoft.pdf.PDFCreateService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.transaction.Transactional;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.qqs.posvcs.service.translate.APITranslator.*;
import static com.qqs.posvcs.utils.Constants.PDF_PCKCHLIST;


@Component
public class PackageCheckListService {

    Logger logger = LoggerFactory.getLogger(PackCheckListMaster.class);

    @Resource
    DataService ds;
    @Resource
    SearchCriteriaUtils searchCriteriaUtils;
    @Resource
    private ApplicationCodeMap systemCodeMap;
    @Resource
    private ApplicationCodeMap codeMap;
    @Resource
    private CompanyService companyService;
    @Resource
    private PartService partService;

    @Value("${app.document.upload.location}")
    private String uploadFolder;

    @Transactional
    public com.qqs.posvcs.api.reports.PackCheckListMaster savePackCheckListMaster(com.qqs.posvcs.api.reports.PackCheckListMaster source) throws QQBusinessException {

        com.qqs.posvcs.api.reports.PackCheckListMaster packToAPI = null;
        List<com.qqs.posvcs.api.billing.PkgCheckList> savedCheckListToAPI = null;

        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        try {
            com.qqs.posvcs.model.PackCheckListMaster packCheckListMaster = PackCheckListMasterToDB.translate(source, com.qqs.posvcs.model.PackCheckListMaster.class, true);
            if(packCheckListMaster.getId() > 0) {
                new DateUtils<com.qqs.posvcs.model.PackCheckListMaster>().setTimeStamp(packCheckListMaster, com.qqs.posvcs.model.PackCheckListMaster.class, true);
                packCheckListMaster.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.posvcs.model.PackCheckListMaster>().setTimeStamp(packCheckListMaster, com.qqs.posvcs.model.PackCheckListMaster.class, false);
                packCheckListMaster.setCreatedBy(loggedInUser);
            }
            // save pkgCheckList
            com.qqs.posvcs.model.PackCheckListMaster saved = ds.getPackageCheckListMasterDS().savePackCheckListMaster(packCheckListMaster);

            packToAPI = PackCheckListMasterToAPI.translate(saved, com.qqs.posvcs.api.reports.PackCheckListMaster.class, true);
            List<com.qqs.posvcs.model.PkgCheckList> pkgCheckList = PkgCheckListToDB.translate(source.getPkgCheckList(), com.qqs.posvcs.model.PkgCheckList.class, true);
            for (com.qqs.posvcs.model.PkgCheckList pkgCheck : pkgCheckList) {
                pkgCheck.setPkgId(packToAPI.getId());
            }
            Iterable<PkgCheckList> savedPkgCheckList = ds.getPackageCheckListMasterDS().saveAllPkgCheckList(pkgCheckList);
            savedCheckListToAPI = PkgCheckListToAPI.translate(savedPkgCheckList, com.qqs.posvcs.api.billing.PkgCheckList.class, true);
            packToAPI.setPkgCheckList(savedCheckListToAPI);
        } catch (Exception e) {
            logger.error("PackCheckListMaster Save error ", e);
            throw new QQBusinessException("PackCheckListMaster  save error", e);
        }
        return packToAPI;
    }

    @Transactional
    public com.qqs.posvcs.api.billing.PkgCheckList savePackageChkList(com.qqs.posvcs.api.billing.PkgCheckList source) throws QQBusinessException {
        com.qqs.posvcs.api.billing.PkgCheckList pckListItem = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        try {
            com.qqs.posvcs.model.PkgCheckList pkgCheckList = PkgCheckListToDB.translate(source, com.qqs.posvcs.model.PkgCheckList.class, true);
            if(pkgCheckList.getId() > 0) {
                new DateUtils<com.qqs.posvcs.model.PkgCheckList>().setTimeStamp(pkgCheckList, com.qqs.posvcs.model.PkgCheckList.class, true);
                pkgCheckList.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.posvcs.model.PkgCheckList>().setTimeStamp(pkgCheckList, com.qqs.posvcs.model.PkgCheckList.class, false);
                pkgCheckList.setCreatedBy(loggedInUser);
            }
            com.qqs.posvcs.model.PkgCheckList savedPkgCheckList = ds.getPackageCheckListMasterDS().savePkgCheckList(pkgCheckList);

            pckListItem = PkgCheckListToAPI.translate(savedPkgCheckList, com.qqs.posvcs.api.billing.PkgCheckList.class, true);
        } catch (
                Exception e) {
            logger.error("PackCheckList Save error ", e);
            throw new QQBusinessException("PackCheckList  save error", e);
        }
        return pckListItem;
    }

    public com.qqs.posvcs.api.reports.PackCheckListMaster getPackageCheckListMasterById(Integer id) throws QQBusinessException {
        com.qqs.posvcs.api.reports.PackCheckListMaster pckToAPI = null;
        List<com.qqs.posvcs.api.billing.PkgCheckList> pkgCheckListAPI = null;

        try {
            com.qqs.posvcs.model.PackCheckListMaster pckMaster = ds.getPackageCheckListMasterDS().getPackCheckListMasterById(id);

            pckToAPI = PackCheckListMasterToAPI.translate(pckMaster, com.qqs.posvcs.api.reports.PackCheckListMaster.class, true);

            List<com.qqs.posvcs.model.PkgCheckList> savedpkgcheList = ds.getPackageCheckListMasterDS().findPkgCheckListByPkg(pckMaster.getId()).get();
            pkgCheckListAPI = PkgCheckListToAPI.translate(savedpkgcheList, com.qqs.posvcs.api.billing.PkgCheckList.class, true);

            Map<String, Codes> pkgChkListBefore = codeMap.getCodeMap().get("PACKING_CHECK_LIST_BFRE");
            Map<String, Codes> pkgChkListAfter = codeMap.getCodeMap().get("PACKING_CHECK_LIST_AFTER");

            //Setting codeDesc & isBeforePacking flag
            pkgCheckListAPI.forEach(item -> {
                if (pkgChkListAfter.get(item.getCode()) != null) {
                    item.setIsBeforePacking(false);
                    item.setCodeDesc(pkgChkListAfter.get(item.getCode()).getDescription());
                } else if (pkgChkListBefore.get(item.getCode()) != null) {
                    item.setIsBeforePacking(true);
                    item.setCodeDesc(pkgChkListBefore.get(item.getCode()).getDescription());
                }
            });
            pckToAPI.setPkgCheckList(pkgCheckListAPI);
        } catch (Exception e) {
            logger.error("PackCheckListMaster Retrive error ", e);
            throw new QQBusinessException("PackCheckListMaster  Retrive error", e);
        }
        return pckToAPI;
    }

    public List<com.qqs.posvcs.api.reports.PackCheckListMaster> searchPackCheckListMaster(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<PackCheckListMaster>> packCheckList = ds.getPackageCheckListMasterDS().searchPackCheckListMaster(conditions);
        if (!packCheckList.isPresent())
            throw new QQBusinessException("No PackCheckListMaster found for criteria");
        List<com.qqs.posvcs.api.reports.PackCheckListMaster> result = null;
        try {
            result = PackCheckListMasterToAPI.translate(packCheckList.get(), com.qqs.posvcs.api.reports.PackCheckListMaster.class, false);
        } catch (Exception e) {
            logger.error("Translation failed", e);
        }
        return result;
    }


    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"companyId", "plantId", "cocNo", "packStartTime", "pclDateTo"}));
        Map<String, String> operators = new HashMap<>(2);
        operators.put("packStartTime", ">");
        if(params.get("pclDateTo") != null && params.get("packStartTime") != null) {
            params.put("packStartTime", params.get("packStartTime") + "||" + params.get("pclDateTo"));
            params.remove("pclDateTo");
            operators.put("packStartTime", "^");
        } else if(params.get("pclDateTo") != null) {
            operators.put("packStartTime", "<");
            params.put("packStartTime", params.get("pclDateTo"));
            params.remove("pclDateTo");
        }
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, operators, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }

    public void generatePackCheckList(Integer pkgId, ByteArrayOutputStream stream) throws QQBusinessException {
        generatePackCheckListHelper(getPackageCheckListMasterById(pkgId), stream);
    }

    public void generatePackCheckListHelper(com.qqs.posvcs.api.reports.PackCheckListMaster packCheckListMaster, ByteArrayOutputStream stream) throws QQBusinessException {


        Map<String, String> pckPdfValueMap = new HashMap<>();
        Map<String, Map<String, com.qqs.posvcs.api.common.Codes>> codesMap = systemCodeMap.getCodeMap();
        // SimpleDateFormat
        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yy");
        format.setTimeZone(TimeZone.getTimeZone(codesMap.get("APP_TIME_ZONE").get("TZ").getDescription()));

        // company Retrive by ID
        Company company = companyService.getCompanyById(packCheckListMaster.getCompanyId());
        String companyName = company.getDescription();

        // part Retrive by ID
        Part part = partService.getPartById(packCheckListMaster.getPartId(), null);
        String partNumberAndRevision = part.getNumber() + " / " + part.getPartRevNo() + "-" + part.getName();

        pckPdfValueMap.put("packStartTime", format.format(packCheckListMaster.getPackStartTime()));
        pckPdfValueMap.put("shift", packCheckListMaster.getShift());
        pckPdfValueMap.put("customer", companyName);
        pckPdfValueMap.put("partNumberName", partNumberAndRevision);
        pckPdfValueMap.put("packBoxSize", codesMap.get("PACK_BOX_SIZE").get(packCheckListMaster.getPackBoxSize()).getDescription());
        pckPdfValueMap.put("vciBagSize", codesMap.get("VCI_BAG_SIZE").get(packCheckListMaster.getVciBagSize()).getDescription());
        pckPdfValueMap.put("silicaWt", packCheckListMaster.getSilicaWt());
        pckPdfValueMap.put("qtyPerBox", packCheckListMaster.getQtyPerBox().toString());
        pckPdfValueMap.put("packingIncharge", packCheckListMaster.getPackingIncharge());

        File fileToBeReaded = new File("./myFileName");

        pckPdfValueMap.put("Image6_af_image", "/Users/dhaarunraja/Downloads/QQ-Logo-01.jpg" );
//       /Users/dhaarunraja/Downloads/QQ-Logo-01.jpg

//        PDImageXObject pdImage = PDImageXObject.createFromFileByContent(atimageFile, doc);
//        contentStream.drawImage(pdImage, 20f, 20f);

        final int[] bpCount = {1};
        final int[] apCount = {1};
        packCheckListMaster.getPkgCheckList().forEach( checkList ->  {
            // Before Packing
            if (checkList.getIsBeforePacking()) {
                String bpDescription = checkList.getCode();
                pckPdfValueMap.put("checkBoxBPDescription" + bpCount[0], codesMap.get("PACKING_CHECK_LIST_BFRE").get(bpDescription).getDescription());
                if( checkList.getIsSelected()) pckPdfValueMap.put("checkBoxBP" + bpCount[0],"true");
                bpCount[0]++;
            } else {  // after packing
                String apDescription = checkList.getCode();;
                pckPdfValueMap.put("checkBoxAPDescription" + apCount[0], codesMap.get("PACKING_CHECK_LIST_AFTER").get(apDescription).getDescription());
                if( checkList.getIsSelected()) pckPdfValueMap.put("checkBoxAP" + apCount[0],"true");
                apCount[0]++;
            }
        });
        try {
            PDFCreateService service = new PDFCreateService();
            String templateName;
            templateName = PDF_PCKCHLIST;
            service.getPdfContent(pckPdfValueMap, stream, templateName);
            MailService.sendEmail(stream);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
