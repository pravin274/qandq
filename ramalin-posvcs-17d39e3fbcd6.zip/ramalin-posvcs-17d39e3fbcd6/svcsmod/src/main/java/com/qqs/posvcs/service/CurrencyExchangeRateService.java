package com.qqs.posvcs.service;

import com.qqs.posvcs.api.Countries;
import com.qqs.posvcs.api.CurrencyExchangeRate;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;

import static com.qqs.posvcs.service.translate.APITranslator.*;

@Component
public class CurrencyExchangeRateService {

    Logger logger = LoggerFactory.getLogger(CurrencyExchangeRateService.class);

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    @Resource
    DataService ds;

    public CurrencyExchangeRate saveCurrencyExchangeRate(CurrencyExchangeRate currencyExchangeRateData) throws QQBusinessException {
        CurrencyExchangeRate currencyExchangeRateToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        try {
            com.qqs.posvcs.model.CurrencyExchangeRate toSaveCurrencyExchangeRateData =  currencyExchangeRateToDB.translate(currencyExchangeRateData, com.qqs.posvcs.model.CurrencyExchangeRate.class, true);
            if(toSaveCurrencyExchangeRateData.getId() > 0) {
                new DateUtils<com.qqs.posvcs.model.CurrencyExchangeRate>().setTimeStamp(toSaveCurrencyExchangeRateData, com.qqs.posvcs.model.CurrencyExchangeRate.class, true);
                toSaveCurrencyExchangeRateData.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.posvcs.model.CurrencyExchangeRate>().setTimeStamp(toSaveCurrencyExchangeRateData, com.qqs.posvcs.model.CurrencyExchangeRate.class, false);
                toSaveCurrencyExchangeRateData.setCreatedBy(loggedInUser);
            }
            com.qqs.posvcs.model.CurrencyExchangeRate currencyExchangeRate = ds.getCurrencyExchangeRateDataService().saveCurrencyExchangeRates(toSaveCurrencyExchangeRateData);

            currencyExchangeRateToApi = currencyExchangeRateToAPI.translate(currencyExchangeRate , CurrencyExchangeRate.class, true);

        } catch (Exception e ) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving currencyExchangeRate details");
        }
        return currencyExchangeRateToApi;

    }


    public CurrencyExchangeRate getCurrencyExchangeRateById(Integer currencyExchangeRateId) throws QQBusinessException {
        try {
            Optional<com.qqs.posvcs.model.CurrencyExchangeRate> currencyExchangeRate = ds.getCurrencyExchangeRateDataService().findCurrencyExchangeRateById(currencyExchangeRateId);
            if (!currencyExchangeRate.isPresent()) {
                throw new QQBusinessException("No CurrencyExchangeRate found");
            }
            CurrencyExchangeRate currencyExchangeRateAPI = currencyExchangeRateToAPI.translate(currencyExchangeRate.get(), CurrencyExchangeRate.class, false);
            return currencyExchangeRateAPI;
        } catch (Exception e) {
            logger.error("CurrencyExchangeRate fetch error", e);
        }
        throw new QQBusinessException("CurrencyExchangeRate could not be retrieved");
    }



    public List<CurrencyExchangeRate> getAllCurrencyExchangeRates() throws QQBusinessException {
        List<CurrencyExchangeRate> result = new ArrayList<>();
        Iterable<com.qqs.posvcs.model.CurrencyExchangeRate> currencyExchangeRates = ds.getCurrencyExchangeRateDataService().getAllCurrencyExchangeRates();
        currencyExchangeRates.forEach(currencyExchangeRate -> {
            try {
                result.add(currencyExchangeRateToAPI.translate(currencyExchangeRate, CurrencyExchangeRate.class, false));
            } catch (Exception e) {
                logger.error("translation exception");
            }
        });
        return result;
    }

    public List<CurrencyExchangeRate> searchCurrencyExchangeRate(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createCurrencyExchangeRateSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.posvcs.model.CurrencyExchangeRate>> currencyExchangeRateList = ds.getCurrencyExchangeRateDataService().searchCurrencyExchangeRates(conditions);
        if (!currencyExchangeRateList.isPresent())
            throw new QQBusinessException("No client found for criteria");
        List<CurrencyExchangeRate> result = null;
        try {
            result = currencyExchangeRateToAPI.translate(currencyExchangeRateList.get(), CurrencyExchangeRate.class, false);
        } catch (Exception e) {
            logger.error("translation exception");
        }
        return result;
    }



    private List<SearchCriteria> createCurrencyExchangeRateSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"currency"}));
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, null, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }

}
