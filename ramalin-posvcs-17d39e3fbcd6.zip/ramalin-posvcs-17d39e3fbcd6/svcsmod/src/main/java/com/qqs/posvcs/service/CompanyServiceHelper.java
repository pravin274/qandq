package com.qqs.posvcs.service;

import com.qqs.posvcs.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import static com.qqs.posvcs.service.translate.APITranslator.*;

@Component
public class CompanyServiceHelper {
    Logger logger = LoggerFactory.getLogger(CompanyServiceHelper.class);
    @Resource
    DataService dataService;

    public com.qqs.posvcs.api.Company fillCompleteCompanyInfo(Company company) {
        com.qqs.posvcs.api.Company result = null;
        try {
            result = companyToAPI.translate(company, com.qqs.posvcs.api.Company.class, false);
            List<com.qqs.posvcs.api.Plant> plants =
                    plantToAPI.translate(
                            retrievePlants(company.getId()), com.qqs.posvcs.api.Plant.class, false);
            List<com.qqs.posvcs.api.Address> addresses =
                    addressToAPI.translate(
                            retrieveAddress(company.getId()), com.qqs.posvcs.api.Address.class, false);
            List<com.qqs.posvcs.api.Phone> phones =
                    phoneToAPI.translate(
                            retrievePhone(company.getId()), com.qqs.posvcs.api.Phone.class, false);
            List<com.qqs.posvcs.api.Email> emails =
                    emailToAPI.translate(
                            retrieveEmail(company.getId()), com.qqs.posvcs.api.Email.class, false);
            result.setPlants(plants);
            result.setAddresses(addresses);
            result.setPhones(phones);
            result.setEmails(emails);
        } catch (Exception e) {
            logger.error("Company populate error", e);
        }
        return result;
    }

    public List<Plant> retrievePlants(Integer companyId) {
        return dataService.getPlantDS().getPlantsByCompany(companyId).orElse(Collections.EMPTY_LIST);
    }

    public List<Address> retrieveAddress(Integer companyId) {
        return dataService.getAddressDS().findAddressesByCompany(companyId).orElse(Collections.EMPTY_LIST);
    }

    public List<Phone> retrievePhone(Integer companyId) {
        return dataService.getPhoneDS().findPhoneByCompany(companyId).orElse(Collections.EMPTY_LIST);
    }

    public List<Email> retrieveEmail(Integer companyId) {
        return dataService.getEmailDS().findEmailByCompany(companyId).orElse(Collections.EMPTY_LIST);
    }

    public List<com.qqs.posvcs.api.Plant> retrieveAllPlants() {
        List<com.qqs.posvcs.api.Plant> result = new ArrayList<>();
        Iterable<Plant> plants = dataService.getPlantDS().getAllPlants();
        plants.forEach(plant -> {
            try {
                result.add(plantToAPI.translate(
                        plant, com.qqs.posvcs.api.Plant.class, false));
            } catch (Exception e) {
                logger.error("Translation error in Plants", e);
            }
        });
        return result;
    }
}
