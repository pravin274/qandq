package com.qqs.posvcs.service;

import com.qqs.posvcs.api.billing.InvoiceStatus;
import com.qqs.posvcs.api.reports.*;
import com.qqs.posvcs.model.InvoiceStatusData;
import com.qqs.posvcs.model.PendingOrderResult;
import com.qqs.posvcs.model.SalesOrderResult;
import com.qqs.posvcs.service.startup.ApplicationCodeMap;
import com.qqs.posvcs.utils.Constants;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.SecurityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static com.qqs.posvcs.service.translate.APITranslator.InvoiceStatusDataToAPI;
import static com.qqs.posvcs.utils.Constants.*;


@Component
public class ReportServiceHelper {
    Logger logger = LoggerFactory.getLogger(ReportServiceHelper.class);

    @Resource
    private ReportDataService reportDataService;

    @Resource
    private InvoiceDataService invoiceDataService;

    @Resource
    private InvoiceLineItemDataService invLineItemDataService;

    @Resource
    private SecurityUtils security;

    @Resource
    private PurchOrderDataService purchOrderDataService;

    @Resource
    private ApplicationCodeMap systemCodeMap;

    public ChartData getOrderReportData(Map<String, String> searchParam) throws QQBusinessException {
        ChartData chartData = new ChartData();
        try {
            if (security.isUserHasElevatedAccess()) {
                Map<String, Map<String, com.qqs.posvcs.api.common.Codes>> codesMap = systemCodeMap.getCodeMap();

                String reportFromDate = searchParam.get("reportFromDate");
                String reportToDate = searchParam.get("reportToDate");
                String selectedItems = searchParam.get("selectedItems");
                String reportType = searchParam.get("reportType");

                String fromDateFormat = "";
                String toDateFormat = "";
                if (reportFromDate.length() > 10) {
                    fromDateFormat = "E MMM dd yyyy hh:mm:ss";
                } else {
                    fromDateFormat = "yyyy-MM-dd";
                }
                if (reportToDate.length() > 10) {
                    toDateFormat = "E MMM dd yyyy hh:mm:ss";
                } else {
                    toDateFormat = "yyyy-MM-dd";
                }

                String fromDate = parseDateString(reportFromDate, fromDateFormat,
                        codesMap.get("APP_TIME_ZONE").get("TZ").getDescription(), "yyyy-MM-dd");
                String toDate = parseDateString(reportToDate, toDateFormat,
                        codesMap.get("APP_TIME_ZONE").get("TZ").getDescription(), "yyyy-MM-dd");

                List<String> idList = new ArrayList<>();
                if (selectedItems != null) {
                    idList = Arrays.asList(selectedItems.split("\\s*(,\\s*)+"));
                }
                Integer idCount = 0;
                if (idList != null) idCount = idList.size();
                Optional<List<Object[]>> reportData;

                if (REPORT_TYPE_CUSTOMER.equals(reportType)) {
                    if (idCount > 0) {
                        reportData = reportDataService.getCustWiseOrderReportData(fromDate, toDate, idList);
                    } else {
                        reportData = reportDataService.getCustWiseOrderReportAllData(fromDate, toDate);
                    }
                } else if (REPORT_TYPE_DOMAIN.equals(reportType)) {
                    if (idCount > 0) {
                        reportData = reportDataService.getDomainWiseOrderReportData(fromDate, toDate, idList);
                    } else {
                        reportData = reportDataService.getDomainWiseOrderReportAllData(fromDate, toDate);
                    }
                } else if (REPORT_TYPE_GEO.equals(reportType)) {
                    if (idCount > 0) {
                        reportData = reportDataService.getGeoWiseOrderReportData(fromDate, toDate, idList);
                    } else {
                        reportData = reportDataService.getGeoWiseOrderReportAllData(fromDate, toDate);
                    }
                } else { // if(REPORT_TYPE_PLANT.equals(reportType)) {
                    if (idCount > 0) {
                        reportData = reportDataService.getPlantWiseOrderReportData(fromDate, toDate, idList);
                    } else {
                        reportData = reportDataService.getPlantWiseOrderReportAllData(fromDate, toDate);
                    }
                }
                if (reportData.isPresent()) {
                    chartData = generateChartData(reportData.get());
                }

            } else {
                throw new QQBusinessException("User not authorised to view this report");
            }
        } catch (Exception e) {
            throw new QQBusinessException("Error fetching report data");
        }
        return chartData;
    }

    public ChartData getSalesReportData(Map<String, String> searchParam) throws QQBusinessException {
        ChartData chartData = new ChartData();
        try {
            if (security.isUserHasElevatedAccess()) {
                Map<String, Map<String, com.qqs.posvcs.api.common.Codes>> codesMap = systemCodeMap.getCodeMap();

                String reportFromDate = searchParam.get("reportFromDate");
                String reportToDate = searchParam.get("reportToDate");
                String selectedItems = searchParam.get("selectedItems");
                String reportType = searchParam.get("reportType");

                String fromDateFormat = "";
                String toDateFormat = "";
                if (reportFromDate.length() > 10) {
                    fromDateFormat = "E MMM dd yyyy hh:mm:ss";
                } else {
                    fromDateFormat = "yyyy-MM-dd";
                }
                if (reportToDate.length() > 10) {
                    toDateFormat = "E MMM dd yyyy hh:mm:ss";
                } else {
                    toDateFormat = "yyyy-MM-dd";
                }
                String fromDate = parseDateString(reportFromDate, fromDateFormat,
                        codesMap.get("APP_TIME_ZONE").get("TZ").getDescription(), "yyyy-MM-dd");
                String toDate = parseDateString(reportToDate, toDateFormat,
                        codesMap.get("APP_TIME_ZONE").get("TZ").getDescription(), "yyyy-MM-dd");


                List<String> idList = new ArrayList<>();
                if (selectedItems != null) {
                    idList = Arrays.asList(selectedItems.split("\\s*(,\\s*)+"));
                }
                Integer idCount = 0;
                if (idList != null) idCount = idList.size();
                Optional<List<Object[]>> reportData;

                if (REPORT_TYPE_CUSTOMER.equals(reportType)) {
                    if (idCount > 0) {
                        reportData = reportDataService.getCustWiseSalesReportData(fromDate, toDate, idList);
                    } else {
                        reportData = reportDataService.getCustWiseSalesReportAllData(fromDate, toDate);
                    }
                } else if (REPORT_TYPE_DOMAIN.equals(reportType)) {
                    if (idCount > 0) {
                        reportData = reportDataService.getDomainWiseSalesReportData(fromDate, toDate, idList);
                    } else {
                        reportData = reportDataService.getDomainWiseSalesReportAllData(fromDate, toDate);
                    }
                } else if (REPORT_TYPE_GEO.equals(reportType)) {//if(REPORT_TYPE_GEO.equals(reportType)) {
                    if (idCount > 0) {
                        reportData = reportDataService.getGeoWiseSalesReportData(fromDate, toDate, idList);
                    } else {
                        reportData = reportDataService.getGeoWiseSalesReportAllData(fromDate, toDate);
                    }
                } else { // if(REPORT_TYPE_PLANT.equals(reportType)) {
                    if (idCount > 0) {
                        reportData = reportDataService.getPlantWiseSalesReportData(fromDate, toDate, idList);
                    } else {
                        reportData = reportDataService.getPlantWiseSalesReportAllData(fromDate, toDate);
                    }
                }
                if (reportData.isPresent()) {
                    chartData = generateChartData(reportData.get());
                }

            } else {
                throw new QQBusinessException("User not authorised to view this report");
            }
        } catch (Exception e) {
            throw new QQBusinessException("Error fetching report data");
        }
        return chartData;
    }

    public List<SalesOrderReportData> getSalesOrderReportData(Map<String, String> searchParam) throws QQBusinessException {
        List<SalesOrderReportData> salesOrderReportData = new ArrayList<>();
        try {
            if (security.isUserHasElevatedAccess()) {
                String reportFromDate = searchParam.get("reportFromDate");
                String reportToDate = searchParam.get("reportToDate");
                String companyId = searchParam.get("companyId");
                String plantId = searchParam.get("plantId");

                List<SalesOrderResult> reportData;
                reportData = reportDataService.getOrderData(reportFromDate, reportToDate);
                List<Integer> poLineItemIds = new ArrayList<>();
                List<String> poNumbers = new ArrayList<>();
                if (reportData != null) {
                    int rowCnt = 1;
                    List<SalesOrderResult> filteredList = reportData;
                    if (companyId != null) {
                        filteredList = filteredList.stream().filter(item -> item.getCompanyId() == Integer.parseInt(companyId)).collect(Collectors.toList());
                    }
                    if (plantId != null) {
                        filteredList = filteredList.stream().filter(item -> item.getPlantId() == Integer.parseInt(plantId)).collect(Collectors.toList());
                    }

                    // filteredList.sort((SalesOrderResult d1, SalesOrderResult d2) -> d1.getPoDate().compareTo(d1.getPoDate()));
                    for (SalesOrderResult item : filteredList) {
                        SalesOrderReportData pData = new SalesOrderReportData();
                        pData.setSerialNo(rowCnt);
                        pData.setId(rowCnt++);
                        pData.setPoLineId(item.getPoLineId());
                        pData.setPoDate(item.getPoDate());
                        pData.setCompanyName(item.getCompanyName());
                        pData.setPlantName(item.getPlantName());
                        pData.setPoNumber(item.getPoNumber());
                        pData.setPoLineItemNo(item.getPoLineItemNo());
                        pData.setPoLineItemType(item.getPoLineItemType());
                        pData.setPartNumber(item.getPartNumber());
                        pData.setPartRevNo(item.getPartRevNo());
                        pData.setPartDesc(item.getPartDesc());
                        pData.setDeliveryDate(item.getDeliveryDate());
                        pData.setPoQty(item.getPoQty());
                        pData.setPartPrice(item.getPartPrice());
//                        pData.setInvoiceNo(item.getInvoiceNo());
//                        pData.setInvoiceDate(item.getInvoiceDate());
                        poLineItemIds.add(item.getPoLineId());
                        poNumbers.add(item.getPoNumber());
                        pData.setDeliveredQty(0);
                        salesOrderReportData.add(pData);
                    }
                    if (poLineItemIds != null && poLineItemIds.size() > 0) {
                        Optional<List<Object[]>> shippedQtyList = invLineItemDataService.getShippedQtyByPoNumbers(poNumbers);
                        if (shippedQtyList.isPresent()) {
                            Map<String, Double> shippedQtyMap = new HashMap<>();
                            Map<String, String> invoiceNoMap = new HashMap<>();
                            Map<String, String> invoiceDateMap = new HashMap<>();

                            shippedQtyList.get().forEach(item -> {
                                StringBuffer sb = new StringBuffer();
                                sb.append(item[0].toString()).append('|').append(item[1].toString()).append('|')
                                        .append(item[2].toString()).append('|').append(item[3].toString());
                                shippedQtyMap.put(sb.toString(), ((BigDecimal) item[4]).doubleValue());
                                invoiceNoMap.put(sb.toString(), item[5].toString());
                                invoiceDateMap.put(sb.toString(), item[6].toString());
                            });
                            salesOrderReportData.forEach(item -> {
                                StringBuffer sb = new StringBuffer();
                                sb.append(item.getPoNumber()).append('|').append(item.getPartNumber()).append('|')
                                        .append(item.getPoLineItemType()).append('|').append(item.getPoLineItemNo());
                                if (shippedQtyMap.get(sb.toString()) != null) {
                                    item.setDeliveredQty(shippedQtyMap.get(sb.toString()));
                                    item.setInvoiceNo(invoiceNoMap.get(sb.toString()));
                                    item.setInvoiceDate(invoiceDateMap.get(sb.toString()));
                                }
                                item.calculateTotalValues();
                            });
                        }
                    }
//                    salesOrderReportData.sort((SalesOrderReportData d1, SalesOrderReportData d2) -> d1.getPoDate().compareTo(d1.getPoDate()));
                }
            } else {
                throw new QQBusinessException("User not authorised to view this report");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new QQBusinessException("Error fetching sales order report data");
        }
        return salesOrderReportData;
    }

    private void generateInvoiceStatus(List<Integer> poLineItemIds, List<SalesOrderReportData> salesOrderReportData) {

    }

    public void generatePendingOrderMail() throws QQBusinessException {
        Map<String, String> searchParam = new HashMap<String, String>();

        searchParam.put("reportFromDate", "2019-04-01");
        searchParam.put("reportToDate", "2020-02-26");
        searchParam.put("pendingQtyFrom", "1");
        searchParam.put("daysLeftFrom", "-1000");
        searchParam.put("daysLeftTo", "14");
        List<PendingOrderData> pendingOrder = getPendingOrderReportData(searchParam);
//        MailService.pendingOrderMail(pendingOrder);
    }


    public List<PendingOrderData> getPendingOrderReportData(Map<String, String> searchParam) throws QQBusinessException {
        List<PendingOrderData> pendingOrderDataList = new ArrayList<>();
        try {
//            if (security.isUserHasElevatedAccess()) {
            String reportFromDate = searchParam.get("reportFromDate");
            String reportToDate = searchParam.get("reportToDate");
            String companyId = searchParam.get("companyId");
            String plantId = searchParam.get("plantId");
            String deliveryFromDate = searchParam.get("deliveryFromDate");
            String deliveryToDate = searchParam.get("deliveryToDate");
            String daysLeftFrom = searchParam.get("daysLeftFrom");
            String daysLeftTo = searchParam.get("daysLeftTo");
            String pendingQtyFrom = searchParam.get("pendingQtyFrom");
            String pendingQtyTo = searchParam.get("pendingQtyTo");

            List<PendingOrderResult> reportData;
            reportData = reportDataService.getPendingOrdersData(reportFromDate, reportToDate);
            List<Integer> poLineItemIds = new ArrayList<>();
            List<String> poNumbers = new ArrayList<>();
            if (reportData != null && reportData.size() > 0) {
                List<PendingOrderResult> filteredList = reportData;
                if (companyId != null) {
                    filteredList = filteredList.stream().filter(item -> item.getCompanyId() == Integer.parseInt(companyId)).collect(Collectors.toList());
                }
                if (plantId != null) {
                    filteredList = filteredList.stream().filter(item -> item.getPlantId() == Integer.parseInt(plantId)).collect(Collectors.toList());
                }
                if (deliveryFromDate != null) {
                    filteredList = filteredList.stream().filter(item -> ((LocalDate.parse(item.getDeliveryDate(),
                            DateTimeFormatter.ofPattern("yyyy-MM-dd"))).plusDays(1).isAfter(LocalDate.parse(
                            deliveryFromDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"))))).collect(Collectors.toList());

                }
                if (deliveryToDate != null) {
                    filteredList = filteredList.stream().filter(item -> ((LocalDate.parse(item.getDeliveryDate(),
                            DateTimeFormatter.ofPattern("yyyy-MM-dd"))).plusDays(-1).isBefore(LocalDate.parse(
                            deliveryToDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"))))).collect(Collectors.toList());
                }
                for (PendingOrderResult item : filteredList) {
                    PendingOrderData pData = new PendingOrderData();
                    pData.setId(item.getId());
                    pData.setCompanyName(item.getCompanyName());
                    pData.setPlantName(item.getPlantName());
                    pData.setPoNumber(item.getPoNumber());
                    pData.setPoRevision(item.getPoRevision());
                    pData.setPoStatus(item.getPoStatus());
                    pData.setPartType(item.getPartType());
                    pData.setPoItem(item.getPoItem());
                    pData.setPoDate(item.getPoDate());
                    pData.setPartNumber(item.getPartNumber());
                    pData.setPartName(item.getPartName());
                    pData.setPartRevNo(item.getPartRevNo());
                    pData.setDeliveryDate(item.getDeliveryDate());
                    pData.setPoQty(item.getPoQty());
                    poLineItemIds.add(item.getId());
                    poNumbers.add(item.getPoNumber());
                    pData.setDeliveredQty(0);
                    pendingOrderDataList.add(pData);
                }
                if (poLineItemIds.size() > 0) {
                    if (daysLeftFrom != null) {
                        pendingOrderDataList = pendingOrderDataList.stream().filter(item -> (item.getDaysLeft() >= (Integer.parseInt(daysLeftFrom)))).collect(Collectors.toList());

                    }
                    if (daysLeftTo != null) {
                        pendingOrderDataList = pendingOrderDataList.stream().filter(item -> (item.getDaysLeft() <= (Integer.parseInt(daysLeftTo)))).collect(Collectors.toList());
                    }

                    Optional<List<Object[]>> shippedQtyList = invLineItemDataService.getShippedQtyByPoNumbers(poNumbers);
                    if (shippedQtyList.isPresent()) {
                        Map<String, Double> shippedQtyMap = new HashMap<>();
                        shippedQtyList.get().forEach(item -> {
                            StringBuffer sb = new StringBuffer();
                            sb.append(item[0].toString()).append('|').append(item[1].toString()).append('|')
                                    .append(item[2].toString()).append('|').append(item[3].toString());
                            shippedQtyMap.put(sb.toString(), ((BigDecimal) item[4]).doubleValue());
                        });
                        pendingOrderDataList.forEach(item -> {
                            StringBuffer sb = new StringBuffer();
                            sb.append(item.getPoNumber()).append('|').append(item.getPartNumber()).append('|')
                                    .append(item.getPartType()).append('|').append(item.getPoItem());
                            if (shippedQtyMap.get(sb.toString()) != null) {
                                item.setDeliveredQty(shippedQtyMap.get(sb.toString()));
                            }
                        });

                        if (pendingQtyFrom != null || pendingQtyTo != null) {
                            pendingOrderDataList = pendingOrderDataList.stream().filter(item ->
                                    (pendingQtyFrom == null || item.getPendingQty() >= (Double.parseDouble(pendingQtyFrom))) &&
                                            (pendingQtyTo == null || item.getPendingQty() <= (Double.parseDouble(pendingQtyTo)))
                            ).collect(Collectors.toList());
                        }
                        int rowCnt = 1;
                        for (PendingOrderData item : pendingOrderDataList) {
                            item.setSerialNo(rowCnt++);
                        }
                    }
                }
            }
//            } else {
//                throw new QQBusinessException("User not authorised to view this report");
//            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new QQBusinessException("Error fetching pending order report data");
        }
        return pendingOrderDataList;
    }

    public List<InvoiceReportData> getInvoiceReportData(Map<String, String> searchParam) throws QQBusinessException {
        List<Integer> invoiceIdList = new ArrayList<>();
        List<Integer> plantIdList = new ArrayList<>();
        List<InvoiceReportData> invoiceReportDataList = new ArrayList<>();
        List<InvoiceReportData> filteredInvoiceList = new ArrayList<>();

        try {
            Map<String, Map<String, com.qqs.posvcs.api.common.Codes>> codesMap = systemCodeMap.getCodeMap();
            String invDate = searchParam.get("reportFromDate");
            String invoiceDateTo = searchParam.get("reportToDate");
            String companyId = searchParam.get("companyId");
            String plantId = searchParam.get("plantId");
            String invoiceId = searchParam.get("invoiceId");
            String invoiceStatus = searchParam.get("invoiceStatus");

            searchParam.remove("reportFromDate");
            searchParam.remove("reportToDate");
            searchParam.remove("companyId");
            searchParam.put("invDate", invDate);
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            dateFormat.setTimeZone(TimeZone.getTimeZone(codesMap.get("APP_TIME_ZONE").get("TZ").getDescription()));

            List<com.qqs.posvcs.model.InvoiceReportData> invoiceList = reportDataService.getInvoiceReportData(invDate, invoiceDateTo);

            if (invoiceList != null && invoiceList.size() > 0) {
                Map<Integer, String> invoiceDateMap = new HashMap<Integer, String>();
                invoiceList.forEach(item -> {
                    InvoiceReportData invoiceReportData = new InvoiceReportData();
                    invoiceReportData.setInvoiceId(item.getInvoiceId());
                    invoiceReportData.setInvoiceNumber(item.getInvoiceNumber());
                    invoiceReportData.setInvoiceDate(item.getInvoiceDate());
                    invoiceReportData.setCompanyName(item.getCompanyName());
                    invoiceReportData.setPlantName(item.getPlantName());
                    invoiceReportData.setCompanyId(item.getCompanyId());
                    invoiceReportData.setPlantId(item.getPlantId());
                    invoiceReportData.setTotalInvoiceValue(item.getTotalInvoiceValue());
                    invoiceDateMap.put(item.getInvoiceId(), item.getInvoiceDate());
                    if (item.getInvoiceStatus() != null) {
                        invoiceReportData.setInvoiceStatus(codesMap.get("INVOICE_STATUS_MAIN").get(item.getInvoiceStatus()).getDescription());
                        invoiceReportData.setInvoiceStatusCode(item.getInvoiceStatus());
                    } else {
                        invoiceReportData.setInvoiceStatus("");
                    }
                    invoiceReportDataList.add(invoiceReportData);
                    invoiceIdList.add(item.getInvoiceId());
                });
                filteredInvoiceList = invoiceReportDataList;
                if (companyId != null) {
                    filteredInvoiceList = invoiceReportDataList.stream().filter(item -> (Integer.parseInt(companyId) == item.getCompanyId())).collect(Collectors.toList());
                }
                if (plantId != null) {
                    filteredInvoiceList = invoiceReportDataList.stream().filter(item -> (Integer.parseInt(plantId) == item.getPlantId())).collect(Collectors.toList());
                }
                if (invoiceStatus != null) {
                    filteredInvoiceList = invoiceReportDataList.stream().filter(item -> (invoiceStatus.equals(item.getInvoiceStatus()))).collect(Collectors.toList());
                }

                List<InvoiceStatusData> invoiceStatusList = invoiceDataService.getInvoiceStatusByInvoiceId(invoiceIdList);
                if (invoiceStatusList != null) {
                    Map<Integer, List<com.qqs.posvcs.api.billing.InvoiceStatus>> invoiceStatusMap = new HashMap<>();
                    List<com.qqs.posvcs.api.billing.InvoiceStatus> invoiceStatusAPI =
                            InvoiceStatusDataToAPI.translate(invoiceStatusList, com.qqs.posvcs.api.billing.InvoiceStatus.class, true);

                    invoiceStatusAPI.forEach(item -> {
                        invoiceStatusMap.computeIfAbsent(item.getInvoiceId(), k -> new ArrayList<>());
                        if (item.getInvoiceStatus() != null && codesMap.get("INV_STATUS_DUE_DATE").get(item.getInvoiceStatus()) != null) {
                            String invoiceStatusDueDate = codesMap.get("INV_STATUS_DUE_DATE").get(item.getInvoiceStatus()).getDescription();
                            String invoiceDate = invoiceDateMap.get(item.getInvoiceId());
                            LocalDate currDate = LocalDate.now();
                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
                            LocalDate invLocalDate = LocalDate.parse(invoiceDate, formatter);
                            invLocalDate = invLocalDate.plusDays(Integer.valueOf(invoiceStatusDueDate));
                            if ((item.getAttribute1() == null || "".equalsIgnoreCase(item.getAttribute1())
                                    || item.getAttribute1().startsWith("Not ") || item.getAttribute1().startsWith("No "))
                                    && (invLocalDate.compareTo(currDate) < 0 && !isInvStatusComplete(item))) {
                                item.setOverDueFlag("True");
                            } else
                                item.setOverDueFlag("False");
                        }
                        invoiceStatusMap.get(item.getInvoiceId()).add(item);
                    });

                    filteredInvoiceList.forEach(item -> {
                        if (invoiceStatusMap.get(item.getInvoiceId()) != null) {
                            Map<String, Map<String, String>> invoiceStatusAttrMap = new HashMap<>();
                            invoiceStatusMap.get(item.getInvoiceId()).forEach(invStatus -> {
                                Map<String, String> invStatusAttr = new HashMap<>();
                                invStatusAttr.put("Attr1", invStatus.getAttribute1());
                                invStatusAttr.put("Attr2", invStatus.getAttribute2());
                                invStatusAttr.put("Attr3", invStatus.getAttribute3());
                                invStatusAttr.put("Attr4", invStatus.getAttribute4());
                                invStatusAttr.put("OverDueFlag", invStatus.getOverDueFlag());
                                invStatusAttr.put("Remarks", invStatus.getRemarks());
                                invoiceStatusAttrMap.put(invStatus.getInvoiceStatus(), invStatusAttr);
                            });
                            item.setInvoiceStatusMap(invoiceStatusAttrMap);
                        }
                    });
                }
            }
        } catch (Exception e) {
            logger.error("Translation error in Invoice save ", e);
        }
        return filteredInvoiceList;
    }

    public List<PoTrackReport> getPoTrackReportData(Map<String, String> searchParam) throws QQBusinessException {
        List<Integer> invoiceIdList = new ArrayList<>();
        List<Integer> plantIdList = new ArrayList<>();
        List<PoTrackReport> poTrackReportDataList = new ArrayList<>();
        List<PoTrackReport> filteredInvoiceList = new ArrayList<>();

        try {
            Map<String, Map<String, com.qqs.posvcs.api.common.Codes>> codesMap = systemCodeMap.getCodeMap();
            String poDate = searchParam.get("reportFromDate");
            String poDateTo = searchParam.get("reportToDate");
            String companyId = searchParam.get("companyId");
            String plantId = searchParam.get("plantId");
            String invoiceId = searchParam.get("invoiceId");
            String invoiceStatus = searchParam.get("invoiceStatus");

            searchParam.remove("reportFromDate");
            searchParam.remove("reportToDate");
            searchParam.remove("companyId");
            searchParam.put("invDate", poDate);
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            dateFormat.setTimeZone(TimeZone.getTimeZone(codesMap.get("APP_TIME_ZONE").get("TZ").getDescription()));

            Map<String, Integer> activePoLineMap = new HashMap<>();
            Optional<List<Object[]>> activePoList = purchOrderDataService.findAllActivePo(poDate, poDateTo);
            activePoList.ifPresent(objects -> objects.forEach(item -> activePoLineMap.put(((String) item[0]), ((BigDecimal) item[1]).intValue())));

            List<com.qqs.posvcs.model.PoTrackReport> poListfromDb = reportDataService.getPoTrackReportData(poDate, poDateTo);
            List<com.qqs.posvcs.model.PoTrackReport> poList = new ArrayList<>();
            poListfromDb.forEach(potrack -> {
                if (!potrack.getPoStatus().equals("REVISED")) {
                    poList.add(potrack);
                } else if (potrack.getPoStatus().equals("REVISED") && potrack.getInvoiceId() != null) {
                    poList.add(potrack);
                }
            });

            Double totalDisplayedQty = 0.0;
            Double poQTy = 0.0;
            String poLineString = "";
            com.qqs.posvcs.model.PoTrackReport prevPO = null;
            if (poList != null && poList.size() > 0) {
                Map<Integer, String> invoiceDateMap = new HashMap<Integer, String>();
                for (com.qqs.posvcs.model.PoTrackReport item : poList) {
                    if (!("".equals(poLineString) || poLineString.equals(item.getPONumber() + "" + item.getItemNumber()))) {
                        if (poQTy > totalDisplayedQty) {
                            poTrackReportDataList.add(addPOTrackReportData(prevPO, poQTy - totalDisplayedQty, true));
                        }
                        totalDisplayedQty = 0.0;
                    }
                    poLineString = item.getPONumber() + "" + item.getItemNumber();
                    prevPO = item;

                    poQTy = activePoLineMap.get(poLineString).doubleValue();
                    if (poQTy > totalDisplayedQty) {
                        poTrackReportDataList.add(addPOTrackReportData(item, poQTy - totalDisplayedQty, false));
                    }
                    if (item.getInvoiceId() != null) {
                        totalDisplayedQty = totalDisplayedQty + Double.parseDouble(item.getInvoiceQuantity());
                        invoiceDateMap.put(item.getInvoiceId(), item.getInvoiceDate());
                        invoiceIdList.add(item.getInvoiceId());
                    } else {
                        totalDisplayedQty = poQTy;
                    }
                }
                if (poQTy > totalDisplayedQty) {
                    poTrackReportDataList.add(addPOTrackReportData(poList.get(poList.size() - 1), poQTy - totalDisplayedQty, true));
                }
                filteredInvoiceList = poTrackReportDataList;
                if (companyId != null) {
                    filteredInvoiceList = poTrackReportDataList.stream().filter(item -> (Integer.parseInt(companyId) == item.getCompanyId())).collect(Collectors.toList());
                }
                if (plantId != null) {
                    filteredInvoiceList = poTrackReportDataList.stream().filter(item -> (Integer.parseInt(plantId) == item.getPlantId())).collect(Collectors.toList());
                }
                if (invoiceStatus != null) {
                    filteredInvoiceList = poTrackReportDataList.stream().filter(item -> (invoiceStatus.equals(item.getInvoiceStatus()))).collect(Collectors.toList());
                }

                List<InvoiceStatusData> invoiceStatusList = invoiceDataService.getInvoiceStatusByInvoiceId(invoiceIdList);
                if (invoiceStatusList != null) {
                    Map<Integer, List<com.qqs.posvcs.api.billing.InvoiceStatus>> invoiceStatusMap = new HashMap<>();
                    List<com.qqs.posvcs.api.billing.InvoiceStatus> invoiceStatusAPI =
                            InvoiceStatusDataToAPI.translate(invoiceStatusList, com.qqs.posvcs.api.billing.InvoiceStatus.class, true);

                    invoiceStatusAPI.forEach(item -> {
                        invoiceStatusMap.computeIfAbsent(item.getInvoiceId(), k -> new ArrayList<>());
                        if (item.getInvoiceStatus() != null && codesMap.get("INV_STATUS_DUE_DATE").get(item.getInvoiceStatus()) != null) {
                            String invoiceStatusDueDate = codesMap.get("INV_STATUS_DUE_DATE").get(item.getInvoiceStatus()).getDescription();
                            String invoiceDate = invoiceDateMap.get(item.getInvoiceId());
                            LocalDate currDate = LocalDate.now();
                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
                            LocalDate invLocalDate = LocalDate.parse(invoiceDate, formatter);
                            invLocalDate = invLocalDate.plusDays(Integer.valueOf(invoiceStatusDueDate));
                            item.setDueDate(invLocalDate.toString());
                            if ((item.getAttribute1() == null || "".equalsIgnoreCase(item.getAttribute1())
                                    || item.getAttribute1().startsWith("Not ") || item.getAttribute1().startsWith("No "))
                                    && (invLocalDate.compareTo(currDate) < 0 && !isInvStatusComplete(item))) {
                                item.setOverDueFlag("True");
                            } else
                                item.setOverDueFlag("False");
                        }
                        invoiceStatusMap.get(item.getInvoiceId()).add(item);
                    });
                    Map prevInvoiceId = new HashMap();
//                    AtomicInteger prevInvoiceId = new AtomicInteger();
                    filteredInvoiceList.forEach(item -> {
                        if (invoiceStatusMap.get(item.getInvoiceId()) != null) {
                            Map<String, Map<String, String>> invoiceStatusAttrMap = new HashMap<>();
                            invoiceStatusMap.get(item.getInvoiceId()).forEach(invStatus -> {
                                Map<String, String> invStatusAttr = new HashMap<>();
                                if (invStatus.getInvoiceStatus().equalsIgnoreCase(INV_STATUS_IGRC)) {
                                    if (prevInvoiceId.containsKey(item.getInvoiceId())) {
                                        invStatusAttr.put("Attr1", "-");
                                    } else {
                                        invStatusAttr.put("Attr1", invStatus.getAttribute1());
                                    }
                                } else {
                                    invStatusAttr.put("Attr1", invStatus.getAttribute1());
                                }

                                if (invStatus.getInvoiceStatus().equalsIgnoreCase(Constants.INV_STATUS_DDB)) {
                                    if (prevInvoiceId.containsKey(item.getInvoiceId())) {
                                        invStatusAttr.put("Attr2", "-");
                                    } else {
                                        invStatusAttr.put("Attr2", invStatus.getAttribute2());
                                    }
                                } else {
                                    invStatusAttr.put("Attr2", invStatus.getAttribute2());
                                }
                                invStatusAttr.put("Attr3", invStatus.getAttribute3());
                                invStatusAttr.put("Attr4", invStatus.getAttribute4());
                                invStatusAttr.put("dueDate", invStatus.getDueDate());
                                invStatusAttr.put("OverDueFlag", invStatus.getOverDueFlag());
                                invStatusAttr.put("Remarks", invStatus.getRemarks());
                                invoiceStatusAttrMap.put(invStatus.getInvoiceStatus(), invStatusAttr);
                            });
                            item.setInvoiceStatusMap(invoiceStatusAttrMap);
                            prevInvoiceId.put(item.getInvoiceId(), "Printed");
//                            prevInvoiceId.set(item.getInvoiceId());
                        }
                    });
                }
            }
        } catch (Exception e) {
            logger.error("Translation error in Invoice save ", e);
        }
        return filteredInvoiceList;
    }

    private PoTrackReport addPOTrackReportData(com.qqs.posvcs.model.PoTrackReport item, Double poQTy, boolean prevFlag) {
        Map<String, Map<String, com.qqs.posvcs.api.common.Codes>> codesMap = systemCodeMap.getCodeMap();

        PoTrackReport poTrackReportData = new PoTrackReport();

        poTrackReportData.setPoNumber(item.getPONumber());
        poTrackReportData.setItemNumber(item.getItemNumber());
        poTrackReportData.setPartType(item.getPartType());
        poTrackReportData.setPoQuantity(poQTy.toString());
        poTrackReportData.setPoDate(item.getPODate());
        poTrackReportData.setPartNumber(item.getPartNumber());
        poTrackReportData.setPartRevisionNumber(item.getPartRevisionNumber());
        poTrackReportData.setDescription(item.getDescription());
        poTrackReportData.setHsCode(item.getHsCode());
        poTrackReportData.setDueDate(item.getDueDate());
        poTrackReportData.setCompanyName(item.getCompanyName());
        poTrackReportData.setPlantName(item.getPlantName());
        poTrackReportData.setCompanyId(item.getCompanyId());
        poTrackReportData.setPlantId(item.getPlantId());
        poTrackReportData.setPoStatus(item.getPoStatus());
        poTrackReportData.setPoRevision(item.getPoRevision());
        poTrackReportData.setPendingQty(poQTy.toString());
        poTrackReportData.setPricePerPart(item.getPricePerPart());

        poTrackReportData.setpOValue(poQTy * item.getPartPrice());
        poTrackReportData.setPendingValue(poQTy * item.getPartPrice());

        System.out.println(item.getInvoiceId() + "  " + item.getCurrency());
        if (item.getCurrency().equals("USD")) {
            poTrackReportData.setpOValueINR(poQTy * item.getPartPrice() * USD_VAL);
            poTrackReportData.setPendingValueINR(poQTy * item.getPartPrice() * USD_VAL);
        } else if (item.getCurrency().equals("EUR")) {
            poTrackReportData.setpOValueINR(poQTy * item.getPartPrice() * EURO_VAL);
            poTrackReportData.setPendingValueINR(poQTy * item.getPartPrice() * EURO_VAL);
        } else {
            poTrackReportData.setpOValueINR(poQTy * item.getPartPrice());
            poTrackReportData.setPendingValueINR(poQTy * item.getPartPrice());
        }

        if (item.getInvoiceId() != null && !prevFlag) {
            poTrackReportData.setInvoiceId(item.getInvoiceId());
            poTrackReportData.setInvoiceNumber(item.getInvoiceNumber());
            poTrackReportData.setInvoiceDate(item.getInvoiceDate());
            poTrackReportData.setTotalInvoiceValue(item.getTotalInvoiceValue());
            poTrackReportData.setInvoiceQuantity(item.getInvoiceQuantity());
            poTrackReportData.setPoQuantity(item.getInvoiceQuantity());
            poTrackReportData.setPendingQty("0");
            poTrackReportData.setTotalInvoiceValueINR(item.getTotalInvoiceValueINR());


            poTrackReportData.setpOValue(item.getTotalInvoiceValue());
            poTrackReportData.setPendingValue(0.0);
            poTrackReportData.setPendingValueINR(0.0);
            if (item.getCurrency().equals("INR")) {
                poTrackReportData.setpOValueINR(item.getTotalInvoiceValue());
            } else {
                poTrackReportData.setpOValueINR(item.getTotalInvoiceValueINR());
            }

        }
        if (item.getInvoiceStatus() != null && !prevFlag) {
            poTrackReportData.setInvoiceStatus(codesMap.get("INVOICE_STATUS_MAIN").get(item.getInvoiceStatus()).getDescription());
            poTrackReportData.setInvoiceStatusCode(item.getInvoiceStatus());
        } else {
            poTrackReportData.setInvoiceStatus("");
        }

        return poTrackReportData;
    }

    private Boolean isInvStatusComplete(InvoiceStatus invStatus) {
        Map<String, String> attrValMap = new HashMap<>();
        attrValMap.put(invStatus.getInvoiceStatus() + "ATTR1", invStatus.getAttribute1());
        attrValMap.put(invStatus.getInvoiceStatus() + "ATTR2", invStatus.getAttribute2());
        attrValMap.put(invStatus.getInvoiceStatus() + "ATTR3", invStatus.getAttribute3());
        attrValMap.put(invStatus.getInvoiceStatus() + "ATTR4", invStatus.getAttribute4());

        for (Map.Entry attrMap : attrValMap.entrySet()) {
            if (INVOICE_STATUS_COMPLETE.get(attrMap.getKey()) != null) {
                if ("NA".equalsIgnoreCase((String) attrMap.getValue())
                        || INVOICE_STATUS_COMPLETE.get(attrMap.getKey()).equalsIgnoreCase((String) attrMap.getValue())) {
                    return true;
                } else {
                    return false;
                }
            }
        }
        return true;
    }

    private ChartData generateChartData(List<Object[]> data) throws QQBusinessException {
        ChartData chartData = new ChartData();
        List<ChartDataSet> dataSets = new ArrayList<ChartDataSet>();
        Map<String, Map<String, String>> formattedData = new LinkedHashMap<String, Map<String, String>>();
        Set<String> xCoordinates = new TreeSet<>();

        data.forEach(item -> {
            String label = item[0].toString();
            String xCoordinate = item[1].toString();
            String orgin = item[2].toString();
            xCoordinates.add(xCoordinate);

            if (formattedData.get(label) == null) {
                formattedData.put(label, new LinkedHashMap<String, String>());
            }
            formattedData.get(label).put(xCoordinate, orgin);
        });

        Set<String> filledXCoordinates = fillXCoordinates(xCoordinates);
        formattedData.forEach((k, v) -> {
            ChartDataSet chartDataSet = new ChartDataSet();
            chartDataSet.setLabel(k);
            chartDataSet.setData(new ArrayList<>());
            filledXCoordinates.forEach(item -> {
                if (v.get(item) == null) {
                    chartDataSet.getData().add("0");
                } else {
                    chartDataSet.getData().add(v.get(item));
                }
            });
            dataSets.add(chartDataSet);
        });

        chartData.setLabels(filledXCoordinates);
        chartData.setDataSets(dataSets);
        return chartData;
    }

    private String parseDateString(String dateVal, String format, String timeZone, String outPutFormat) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);

        String formattedDateVal = "";
        if (timeZone != null && !("".equals(timeZone))) {
            sdf.setTimeZone(TimeZone.getTimeZone(timeZone));
        }
        Date formattedDate = null;

        try {
            if (dateVal != null) {
                formattedDate = sdf.parse(dateVal);
                sdf = new SimpleDateFormat(outPutFormat);
                formattedDateVal = sdf.format(formattedDate);
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return formattedDateVal;
    }

    private Set<String> fillXCoordinates(Set<String> xCordinates) {
        String fromDateVal = ((TreeSet<String>) xCordinates).first();
        String toDateVal = ((TreeSet<String>) xCordinates).last();
        Set<String> filledVal = new TreeSet<String>();

        DateTimeFormatter formatter;

        if (fromDateVal.length() > 8) { // coordinate values as dates
            formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate beginLocalDate = LocalDate.parse(fromDateVal, formatter);
            LocalDate finishLocalDate = LocalDate.parse(toDateVal, formatter);

            while (beginLocalDate.compareTo(finishLocalDate) <= 0) {
                String date = beginLocalDate.format(formatter);
                filledVal.add(date);
                beginLocalDate = beginLocalDate.plusDays(1);
            }
        } else {
            formatter = DateTimeFormatter.ofPattern("yyyy-MM");
            YearMonth beginLocalDate = YearMonth.parse(fromDateVal, formatter);
            YearMonth finishLocalDate = YearMonth.parse(toDateVal, formatter);

            while (beginLocalDate.compareTo(finishLocalDate) <= 0) {
                String date = beginLocalDate.format(formatter);
                filledVal.add(date);
                beginLocalDate = beginLocalDate.plusMonths(1);
            }
        }

        return filledVal;
    }
}
