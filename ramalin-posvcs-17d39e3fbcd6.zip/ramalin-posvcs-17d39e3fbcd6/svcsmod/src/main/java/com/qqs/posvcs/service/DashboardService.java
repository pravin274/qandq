package com.qqs.posvcs.service;

import com.qqs.posvcs.api.DashboardDetails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import javax.annotation.Resource;


@Component
public class DashboardService {

    Logger logger = LoggerFactory.getLogger(DashboardService.class);

    @Resource
    POService poService;

    @Resource
    PartService partService;


    public DashboardDetails getDashboardDetails() {
        DashboardDetails dashboardDetails = new DashboardDetails();

        dashboardDetails.setPoCount(poService.getTotalPOCount());
        dashboardDetails.setPartCount(partService.getTotalPartsCount());
        dashboardDetails.setParentPartCount(partService.getTotalParentPartsCount());

        return dashboardDetails;
    }
}
