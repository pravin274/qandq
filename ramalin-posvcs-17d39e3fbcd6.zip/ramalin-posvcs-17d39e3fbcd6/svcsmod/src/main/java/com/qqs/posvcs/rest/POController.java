package com.qqs.posvcs.rest;

import com.qqs.posvcs.api.PurchOrder;
import com.qqs.posvcs.service.POService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/po")
public class POController {

    @Resource
    POService service;

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_PO_READ', 'ROLE_PO_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/byId", produces = "application/json")
    public ResponseEntity<PurchOrder> getPurchaseOrderById(@RequestParam Integer id,
                                                           HttpServletRequest request) throws QQBusinessException {
        PurchOrder po = service.getPurchaseOrderById(id);
        ResponseEntity<PurchOrder> result = new ResponseEntity(po, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_PO_READ', 'ROLE_PO_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/form/search", produces = "application/json")
    public ResponseEntity<List<PurchOrder>> searchClient(@RequestParam Map<String, String> searchParam,
                                                         @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                      HttpServletRequest request) throws QQBusinessException {
        List<PurchOrder> formList = service.searchPurchaseOrders(searchParam, exactMatch.orElse(false));
        ResponseEntity<List<PurchOrder>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_PO_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/save", produces = "application/json")
    public ResponseEntity<PurchOrder> savePurchOrder(@RequestBody PurchOrder form) throws QQBusinessException {
        PurchOrder saved = service.savePurchaseOrder(form);
        ResponseEntity<PurchOrder> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_PO_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/update", produces = "application/json")
    public ResponseEntity<PurchOrder> updatePurchOrder(@RequestBody PurchOrder form) throws QQBusinessException {
        PurchOrder saved = service.updatePurchaseOrder(form);
        ResponseEntity<PurchOrder> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_PO_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/saveFileName", produces = "application/json")
    public ResponseEntity<PurchOrder> saveFileName(@RequestParam Integer poId, String poFileName) throws QQBusinessException {
        PurchOrder saved = service.saveFileName(poId, poFileName);
        ResponseEntity<PurchOrder> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }
}
