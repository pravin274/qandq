package com.qqs.posvcs.service.helper;

import com.qqs.invsvcs.api.InvProductDetails;
import com.qqs.posvcs.api.common.Codes;
import com.qqs.posvcs.model.*;
import com.qqs.posvcs.service.InvProductDetailService;
import com.qqs.posvcs.service.PartDataService;
import com.qqs.posvcs.service.startup.ApplicationCodeMap;
import com.qqs.posvcs.utils.Constants;
import com.qqs.qqsoft.utils.ApiUtils;
import com.qqs.qqsoft.utils.SecurityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

@Component
public class PartServiceHelper {
    Logger logger = LoggerFactory.getLogger(PartServiceHelper.class);
    private static final String STAGE = "PART_STAGE";
    @Resource
    private PartDataService partDataService;
    @Resource
    private InvProductDetailService invProductDetailService;
    @Resource
    private SecurityUtils security;

    public com.qqs.posvcs.api.parts.Part fillPartDetails(Part partFromDb, HttpServletRequest request) {
        com.qqs.posvcs.api.parts.Part part = null;
        try {
            part = new ApiUtils<Part, com.qqs.posvcs.api.parts.Part>().translate(partFromDb, com.qqs.posvcs.api.parts.Part.class, false);

            Optional<List<PartChronology>> chronology = partDataService.getChronologyByPart(partFromDb.getId());
            if (chronology.isPresent()) {
                List<com.qqs.posvcs.api.parts.PartChronology> chronologyApi =
                        new ApiUtils<PartChronology, com.qqs.posvcs.api.parts.PartChronology>()
                                .translate(chronology.get(), com.qqs.posvcs.api.parts.PartChronology.class, false);
                part.setChronologies(chronologyApi);
            }

            Optional<List<PartDomain>> domain = partDataService.getDomainByPart(partFromDb.getId());
            if (domain.isPresent()) {
                List<com.qqs.posvcs.api.parts.PartDomain> domainApi =
                        new ApiUtils<PartDomain, com.qqs.posvcs.api.parts.PartDomain>()
                                .translate(domain.get(), com.qqs.posvcs.api.parts.PartDomain.class, false);
                part.setDomains(domainApi);
            }

            Optional<List<PartCommodity>> commodity = partDataService.getCommodityByPart(partFromDb.getId());
            if (commodity.isPresent()) {
                List<com.qqs.posvcs.api.parts.PartCommodity> commodityApi =
                        new ApiUtils<PartCommodity, com.qqs.posvcs.api.parts.PartCommodity>()
                                .translate(commodity.get(), com.qqs.posvcs.api.parts.PartCommodity.class, false);
                part.setCommodities(commodityApi);
            }

            Optional<List<PartImage>> image = partDataService.getImageByPart(partFromDb.getId());
            if (image.isPresent()) {
                List<com.qqs.posvcs.api.parts.PartImage> imageApi =
                        new ApiUtils<PartImage, com.qqs.posvcs.api.parts.PartImage>()
                                .translate(image.get(), com.qqs.posvcs.api.parts.PartImage.class, false);
                part.setImages(imageApi);
            }

            if (security.isUserHasElevatedAccess()) {
                Optional<List<PartPrice>> price = partDataService.getPriceByPart(partFromDb.getId());
                if (price.isPresent()) {
                    List<com.qqs.posvcs.api.parts.PartPrice> priceApi =
                            new ApiUtils<PartPrice, com.qqs.posvcs.api.parts.PartPrice>()
                                    .translate(price.get(), com.qqs.posvcs.api.parts.PartPrice.class, false);
                    part.setPrices(priceApi);
                }
            }
            
            Optional<List<PartStandard>> standard = partDataService.getStandardByPart(partFromDb.getId());
            if (standard.isPresent()) {
                List<com.qqs.posvcs.api.parts.PartStandard> standardApi =
                        new ApiUtils<PartStandard, com.qqs.posvcs.api.parts.PartStandard>()
                                .translate(standard.get(), com.qqs.posvcs.api.parts.PartStandard.class, false);
                part.setStandard(standardApi);
            }
            Optional<List<PartCustomerRequirement>> partCustomerRequirement = partDataService.getPartCustomerRequirementByPart(partFromDb.getId());
            if (partCustomerRequirement.isPresent()) {
                List<com.qqs.posvcs.api.parts.PartCustomerRequirement> customerRequirementApi =
                        new ApiUtils<PartCustomerRequirement, com.qqs.posvcs.api.parts.PartCustomerRequirement>()
                                .translate(partCustomerRequirement.get(), com.qqs.posvcs.api.parts.PartCustomerRequirement.class, false);
                part.setCustomerRequirement(customerRequirementApi);
            }
            Optional<List<PartRevisionAmendment>> partRevisionAmendment = partDataService.getPartRevisionAmendmentByPart(partFromDb.getId());
            if (partRevisionAmendment.isPresent()) {
                List<com.qqs.posvcs.api.parts.PartRevisionAmendment> revisionAmendment =
                        new ApiUtils<PartRevisionAmendment, com.qqs.posvcs.api.parts.PartRevisionAmendment>()
                                .translate(partRevisionAmendment.get(), com.qqs.posvcs.api.parts.PartRevisionAmendment.class, false);
                part.setRevisionAmendment(revisionAmendment);
            }

            if(request != null) {
                part.setInvProductDetails(invProductDetailService.getInvProductDetails(part.getId(),
                        Constants.PRODUCT_TYPE_MAP.get("part"), request));
            } else {
                part.setInvProductDetails(new InvProductDetails());
            }



        } catch (Exception e) {
            logger.error("Part translation error", e);
        }
        return part;
    }

    public Map<Integer, List<com.qqs.posvcs.model.PartPrice>> getPartPriceDetails(List<Integer> partIds) {
        Map<Integer, List<com.qqs.posvcs.model.PartPrice>> priceMap = new HashMap<>();
        if (security.isUserHasElevatedAccess()) {
            Optional<List<com.qqs.posvcs.model.PartPrice>> priceList = partDataService.getPriceByPartIds(partIds);
            if(priceList.isPresent()) {
                for (com.qqs.posvcs.model.PartPrice price : priceList.get()) {
                    if (priceMap.get(price.getPartId()) == null) {
                        priceMap.put(price.getPartId(), new ArrayList());
                    }
                    priceMap.get(price.getPartId()).add(price);
                }
            }
        }
        return priceMap;
    }

}
