package com.qqs.posvcs.service;

import com.qqs.posvcs.api.reports.*;
import com.qqs.qqsoft.QQBusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;


@Component
public class ReportService {

    Logger logger = LoggerFactory.getLogger(ReportService.class);

    @Resource
    private ReportServiceHelper helper;

    public ChartData getOrderReportData(Map<String, String> searchParam) throws QQBusinessException {
        return helper.getOrderReportData(searchParam);
    }

    public ChartData getSalesReportData(Map<String, String> searchParam) throws QQBusinessException {
        return helper.getSalesReportData(searchParam);
    }

    public List<SalesOrderReportData> getSalesOrderReportData(Map<String, String> searchParam) throws QQBusinessException {
        return helper.getSalesOrderReportData(searchParam);
    }

    public List<PendingOrderData> getPendingOrderReportData(Map<String, String> searchParam) throws QQBusinessException {
        return helper.getPendingOrderReportData(searchParam);
    }

    public List<InvoiceReportData> getInvoiceReportData(Map<String, String> searchParam) throws QQBusinessException {
        return helper.getInvoiceReportData(searchParam);
    }

    public List<PoTrackReport> getpoTrackData(Map<String, String> searchParam) throws QQBusinessException {
        return helper.getPoTrackReportData(searchParam);
    }
}
