package com.qqs.posvcs.service;

import com.qqs.posvcs.api.Company;
import com.qqs.posvcs.api.PoLineItem;
import com.qqs.posvcs.api.PurchOrder;
import com.qqs.posvcs.api.parts.Part;
import com.qqs.posvcs.model.Ats;
import com.qqs.posvcs.model.AtsContentSheet;
import com.qqs.posvcs.service.startup.ApplicationCodeMap;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.pdf.PDFCreateService;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.transaction.Transactional;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.qqs.posvcs.service.translate.APITranslator.*;
import static com.qqs.posvcs.utils.Constants.*;


@Component
public class AtsService {

    Logger logger = LoggerFactory.getLogger(Ats.class);



    @Resource
    DataService ds;
    @Resource
    SearchCriteriaUtils searchCriteriaUtils;
    @Resource
    private ApplicationCodeMap systemCodeMap;
    @Resource
    private POService poService;
    @Resource
    private PartService partService;
    @Resource
    private CompanyService companyService;
    //TODO : Rama - Get user details from common service
//    @Resource
//    private UserServiceImpl userServiceImpl;
    @Value("${app.document.upload.location}")
    private String uploadFolder;





    @Transactional
    public com.qqs.posvcs.api.reports.Ats saveAts(com.qqs.posvcs.api.reports.Ats source) throws QQBusinessException {
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();

        com.qqs.posvcs.api.reports.Ats atsToAPI = null;
        List<com.qqs.posvcs.api.reports.AtsContentSheet> atsContentSheetToAPI = null;

        try {
            com.qqs.posvcs.model.Ats ats = AtsToDB.translate(source, com.qqs.posvcs.model.Ats.class, true);
            if(ats.getId() > 0) {
                new DateUtils<Ats>().setTimeStamp(ats, com.qqs.posvcs.model.Ats.class, true);
                ats.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<Ats>().setTimeStamp(ats, com.qqs.posvcs.model.Ats.class, false);
                ats.setCreatedBy(loggedInUser);
            }

            com.qqs.posvcs.model.Ats toSaveAts = ds.getAtsDS().saveAts(ats);
            atsToAPI = AtsToAPI.translate(toSaveAts, com.qqs.posvcs.api.reports.Ats.class, true);

            List<com.qqs.posvcs.model.AtsContentSheet> atsContentSheetList = AtsContentSheetListToDB.translate(source.getAtsContentSheet(), com.qqs.posvcs.model.AtsContentSheet.class, true);
            for (com.qqs.posvcs.model.AtsContentSheet atsContentSheet : atsContentSheetList) {
                atsContentSheet.setAtsId(atsToAPI.getId());
            }

            Iterable<AtsContentSheet> savedAtsContentSheet = ds.getAtsDS().saveAllAtsContentSheetList(atsContentSheetList);
            atsContentSheetToAPI = AtsContentSheetListToAPI.translate(savedAtsContentSheet, com.qqs.posvcs.api.reports.AtsContentSheet.class, true);

            atsToAPI.setAtsContentSheet(atsContentSheetToAPI);

        } catch (Exception e) {
            logger.error("Ats Save error", e);
            throw new QQBusinessException("Ats  save error", e);
        }
        return atsToAPI;
    }

    public com.qqs.posvcs.api.reports.Ats getAtsSearchById(Integer id) throws QQBusinessException {
        com.qqs.posvcs.api.reports.Ats atsToAPI = null;
        List<com.qqs.posvcs.api.reports.AtsContentSheet> ContentSheetToAPI = null;
        try {
            com.qqs.posvcs.model.Ats saved = ds.getAtsDS().getAtsByAtsId(id);

            atsToAPI = AtsToAPI.translate(saved, com.qqs.posvcs.api.reports.Ats.class, true);

            com.qqs.posvcs.api.PurchOrder po = poService.getPurchaseOrderById(atsToAPI.getPoId());

            try {
                Iterable<AtsContentSheet> atsContentSheetData = ds.getAtsDS().findAtsContentSheetByAts(atsToAPI.getId()).get();
                if (atsContentSheetData != null) {
                    ContentSheetToAPI = AtsContentSheetListToAPI.translate(atsContentSheetData, com.qqs.posvcs.api.reports.AtsContentSheet.class, true);
                    atsToAPI.setAtsContentSheet(ContentSheetToAPI);
                }
            } catch (Exception e)  {
                logger.error("Retrive Ats Content Sheet Error");
            }
            atsToAPI.setPurchOrder(po);
        } catch (Exception e) {
            logger.error("Ats Retrive by id error ", e);
            throw new QQBusinessException("Ats  Retrive by id error", e);
        }
        return atsToAPI;
    }

    public List<com.qqs.posvcs.api.reports.Ats> searchAllAts(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<Ats>> ats = ds.getAtsDS().searchAllAts(conditions);
        if (!ats.isPresent())
            throw new QQBusinessException("No Ats found for criteria");
        List<com.qqs.posvcs.api.reports.Ats> atsList = null;
        try {
            atsList = AtsToAPI.translate(ats.get(), com.qqs.posvcs.api.reports.Ats.class, false);
            for (com.qqs.posvcs.api.reports.Ats resultval : atsList) {
                try {
                    com.qqs.posvcs.api.PurchOrder po = poService.getPurchaseOrderById(resultval.getPoId());
                    resultval.setPurchOrder(po);
                } catch (Exception e) {
                    logger.error("Ats search translation error", e);
                }
            }
        } catch (Exception e) {
            logger.error("Translation failed", e);
        }
        return atsList;
    }

    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"poId", "partId", "cocNo", "atsDate", "atsDateTo"}));
        Map<String, String> operators = new HashMap<>(2);
        operators.put("atsDate", ">");
        if(params.get("atsDateTo") != null && params.get("atsDate") != null) {
            params.put("atsDate", params.get("atsDate") + "||" + params.get("atsDateTo"));
            params.remove("atsDateTo");
            operators.put("atsDate", "^");
        } else if(params.get("atsDateTo") != null) {
            operators.put("atsDate", "<");
            params.put("atsDate", params.get("atsDateTo"));
            params.remove("atsDateTo");
        }
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, operators, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }

    @Transactional
    public com.qqs.posvcs.api.reports.AtsContentSheet saveAtsContent(com.qqs.posvcs.api.reports.AtsContentSheet source) throws QQBusinessException {

        com.qqs.posvcs.api.reports.AtsContentSheet atsContentData = null;

        try {
            com.qqs.posvcs.model.AtsContentSheet ats = AtsContentSheetListToDB.translate(source, com.qqs.posvcs.model.AtsContentSheet.class, true);
//            new DateUtils<AtsContentSheet>().setTimeStamp(ats, com.qqs.posvcs.model.AtsContentSheet.class, false);
//            ats.setCreatedBy(loggedInUser);
//            ats.setModifiedBy(loggedInUser);

            com.qqs.posvcs.model.AtsContentSheet ataContentData = ds.getAtsDS().saveAtsContetnt(ats);

            atsContentData = AtsContentSheetListToAPI.translate(ataContentData, com.qqs.posvcs.api.reports.AtsContentSheet.class, true);

        } catch (Exception e) {
            logger.error("save Ats Content error ", e);
            throw new QQBusinessException("save Ats Content error", e);
        }

        return atsContentData;
    }

    public void generateAts(Integer atsId, ByteArrayOutputStream stream) throws QQBusinessException {
        generateAtsHelper(getAtsSearchById(atsId), stream);
    }


    public void generateAtsHelper(com.qqs.posvcs.api.reports.Ats ats, ByteArrayOutputStream stream) throws QQBusinessException {

        Map<String, String> atsPdfValueMap = new HashMap<>();
        Map<String, Map<String, com.qqs.posvcs.api.common.Codes>> codesMap = systemCodeMap.getCodeMap();
        // SimpleDateFormat
        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yy");
        format.setTimeZone(TimeZone.getTimeZone(codesMap.get("APP_TIME_ZONE").get("TZ").getDescription()));

        // po Retrive by ID
        PurchOrder poData = poService.getPurchaseOrderById(ats.getPoId());

        String lineItemNumber = "";
        for (PoLineItem lineItem : poData.getPoLineItems()) {
            Integer partId = lineItem.getPartId();
            if (partId.equals(ats.getPartId())) {
                lineItemNumber = lineItem.getItem();
            }
        }
        String poNumberPoDate = poData.getPoNumber() + '/' + lineItemNumber + ' ' + format.format(poData.getPoDate());
        String poNumberLineItem = poData.getPoNumber() + '/' + lineItemNumber;

        // part Retrive by ID
        Part part = partService.getPartById(ats.getPartId(), null);
        String partNumberAndRevision = part.getNumber() + " / " + part.getPartRevNo();
        String drawNumberAndRevision = part.getDrawingNo() + " / " + part.getDrawingRevNo();
        String partDescription = part.getName();
        String partMaterialSpec = part.getMaterialSpec();

        // company Retrive by ID
        String materialGrade = ats.getMaterialSpec();
        Company company = companyService.getCompanyById(poData.getCompanyId());
        String companyName = company.getDescription();

        /* TODO : See above to retrieve user from commons
        // user Details Retrive by ID
        User approvedByUser = userServiceImpl.getUserById(ats.getApprovedBy());
        String approvedBy = approvedByUser.getFirstName() + ' ' + approvedByUser.getLastName();

        User preparedByUser = userServiceImpl.getUserById(ats.getPreparedBy());
        String preparedBy = preparedByUser.getFirstName() + ' ' + preparedByUser.getLastName();
         */

        String cocDescription = "";
        // Coc Long Text
        String cocHTLongDescription = "This is certifying that the components listed above meets to purchase order \n" +
                poNumberLineItem + " Drawing number: " + drawNumberAndRevision + ", Part Number: " + partNumberAndRevision +
                " and Heat Treatment specification " + ats.getHeatTreatmentSpec() + ".\n";

        String cocLongDescription = "This is certifying that the components listed above meets to purchase order \n" +
                poNumberLineItem + " Drawing number: " + drawNumberAndRevision + ", Part Number: " + partNumberAndRevision +
                " and Material specification " + materialGrade + ".\n";
      // for cross head
        String cocLongDescriptionForCH = "This above part number confirms to the respective specifications as listed below \n" +
                "1) Marking on the parts confirms to specifications " + materialGrade + ", Drawing No: "+drawNumberAndRevision+ " And Part report\n" +
                "2) Visual Examination on Parts confirm to specification "+ ats.getHeatTreatmentSpec()  + "\n" +
                "3) Dimensional Verification on individual part confirming to component drawing\n" +
                "4) Crosshead & Trunnion Bolting torque confirm to part report\n";

        if ("P537405".equals(part.getNumber())) {
            cocDescription = cocLongDescriptionForCH;
        } else {
            cocDescription = cocLongDescription;

        }
        // ATS_CONTETNT SHEET
        final int[] contentCount = {1};
        ats.getAtsContentSheet().forEach(contentSheet -> {
            Integer intInstance = new Integer(contentCount[0]);
            String numberAsString = intInstance.toString();
            atsPdfValueMap.put("slno" + contentCount[0], numberAsString);
            String contentCode = contentSheet.getContentCode();
            atsPdfValueMap.put("content" + contentCount[0], codesMap.get("ATS_CONTENT_SHEET").get(contentCode).getDescription());
            contentCount[0]++;
        });


        // Assign the pdf value
        atsPdfValueMap.put("partNumberAndRevision", partNumberAndRevision);
        atsPdfValueMap.put("companyName", companyName);
        atsPdfValueMap.put("drawNumberAndRevision", drawNumberAndRevision);
        atsPdfValueMap.put("atsQty", ats.getAtsQty().toString());
        atsPdfValueMap.put("cocNumberAndDate", ats.getCocNo() + "/" + format.format(ats.getCocDate()));
        atsPdfValueMap.put("description", partDescription);
        atsPdfValueMap.put("materialGrade", partMaterialSpec);
        atsPdfValueMap.put("cocLongDescription", cocDescription);

        atsPdfValueMap.put("cocHTLongDescription", cocHTLongDescription);
        String specCode = ats.getHardnessSpec();
        atsPdfValueMap.put("hardnessSpec", codesMap.get("HARDNESS_SPEC").get(specCode).getDescription());
        atsPdfValueMap.put("heatTreatMentSpec", ats.getHeatTreatmentSpec());
        atsPdfValueMap.put("hardnessActual", ats.getHardnessActualLower() + " - " + ats.getHardnessActualHigher() + "  " + HARDNESS_SPEC_UNIT);
        //atsPdfValueMap.put("approvedBy", approvedBy); TODO : RAMA
        atsPdfValueMap.put("materialSpec", ats.getMaterialSpec());
        atsPdfValueMap.put("date", format.format(ats.getAtsDate()));
        atsPdfValueMap.put("heatCode", ats.getHeatCode());
        //atsPdfValueMap.put("preparedBy", preparedBy); TODO : RAMA
        atsPdfValueMap.put("poNumberAndDate", poNumberPoDate);
//        atsPdfValueMap.put("approvedByDesgination", "( " + approvedByDesgination + " )");
//        atsPdfValueMap.put("preparedByDesgination", "( " + preparedByDesgination + " )");


        try {
//            PDFCreateService service = new PDFCreateService();
            String templateName;
            templateName = PDF_ATS;

//            service.getPdfContent(atsPdfValueMap, stream, templateName);
            mergeAts(atsPdfValueMap, stream, templateName, ats.getAtsContentSheet());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void mergeAts(Map<String, String> params, OutputStream stream, String pdfSource, List<com.qqs.posvcs.api.reports.AtsContentSheet> contetntSheet ) throws IOException {

        org.springframework.core.io.Resource resource = new ClassPathResource(pdfSource);
        PDDocument mergedDoc = new PDDocument();

        try (InputStream inputStream = resource.getInputStream() ) {  // our temp
            PDDocument pdfDocument = PDDocument.load(inputStream);
            PDFCreateService service = new PDFCreateService();
            service.setFields(params, pdfDocument);

            contetntSheet.forEach( singleContentSheet -> {
                if (singleContentSheet.getFileName() != null) {
                    String fileFolder = uploadFileFolder.get("atsContentSheet");
                    ApplicationContext appContext =
                            new ClassPathXmlApplicationContext(new String[] {});
                    org.springframework.core.io.Resource resourceFile = appContext.getResource("file:" + uploadFolder + fileFolder + '/'  + singleContentSheet.getFileName()); // new ClassPathResource("file:" + uploadFolder + fileFolder + '/'  + fileName);
                    try {
                        PDDocument attachPdf = PDDocument.load(resourceFile.getInputStream());
                        for( int pageCnt = 0; pageCnt < attachPdf.getNumberOfPages(); pageCnt++) {
                            mergedDoc.addPage(attachPdf.getPage(pageCnt));
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    if("CNS".equals(singleContentSheet.getContentCode())){
                        mergedDoc.addPage(pdfDocument.getPage(0));
                    } else if("COG".equals(singleContentSheet.getContentCode())){
                        mergedDoc.addPage(pdfDocument.getPage(1));
                    } else if("CHT".equals(singleContentSheet.getContentCode())){
                        mergedDoc.addPage(pdfDocument.getPage(2));
                    }
                }
            });
//            mergedDoc.getDocumentCatalog().getAcroForm().flatten();
            mergedDoc.save(stream);
            mergedDoc.close();
        }

    }


}
