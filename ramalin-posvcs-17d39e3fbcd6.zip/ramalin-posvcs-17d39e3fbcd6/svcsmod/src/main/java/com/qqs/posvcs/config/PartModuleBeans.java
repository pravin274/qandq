package com.qqs.posvcs.config;

import com.qqs.posvcs.api.parts.*;
import com.qqs.posvcs.service.PartDataService;
import com.qqs.posvcs.service.PartSubService;
import com.qqs.qqsoft.utils.SecurityUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.sql.Timestamp;
import java.util.List;

@Configuration
public class PartModuleBeans {

    @Bean(name = "partChronologySubService")
    PartSubService<com.qqs.posvcs.model.PartChronology, PartChronology> partChronologyService(
            PartDataService partDataService, SecurityUtils security) {
        PartSubService<com.qqs.posvcs.model.PartChronology, PartChronology> subService =
                new PartSubService<com.qqs.posvcs.model.PartChronology, PartChronology>(security) {
                    @Override
                    protected void setAuditHistory(com.qqs.posvcs.model.PartChronology part, Integer loggedInUser, Timestamp currentDate) {
                        if (part.getId() > 0) {
                            part.setModifiedBy(loggedInUser);
                            part.setModifiedDt(currentDate);
                        } else {
                            part.setCreatedBy(loggedInUser);
                            part.setCreatedDt(currentDate);
                        }
                    }

                    @Override
                    protected Iterable<com.qqs.posvcs.model.PartChronology> saveEntries(List<com.qqs.posvcs.model.PartChronology> toSave) {
                        return partDataService.saveChronology(toSave);
                    }
                };
        return subService;
    }

    @Bean(name = "partCommoditySubService")
    PartSubService<com.qqs.posvcs.model.PartCommodity, PartCommodity> partCommodityService(
            PartDataService partDataService, SecurityUtils security) {
        PartSubService<com.qqs.posvcs.model.PartCommodity, PartCommodity> subService =
                new PartSubService<com.qqs.posvcs.model.PartCommodity, PartCommodity>(security) {
                    @Override
                    protected void setAuditHistory(com.qqs.posvcs.model.PartCommodity part, Integer loggedInUser, Timestamp currentDate) {
                        if (part.getId() > 0) {
                            part.setModifiedBy(loggedInUser);
                            part.setModifiedDt(currentDate);
                        } else {
                            part.setCreatedBy(loggedInUser);
                            part.setCreatedDt(currentDate);
                        }
                    }

                    @Override
                    protected Iterable<com.qqs.posvcs.model.PartCommodity> saveEntries(List<com.qqs.posvcs.model.PartCommodity> toSave) {
                        return partDataService.saveCommodity(toSave);
                    }
                };
        return subService;
    }

    @Bean(name = "partDomainSubService")
    PartSubService<com.qqs.posvcs.model.PartDomain, PartDomain> partDomainService(
            PartDataService partDataService, SecurityUtils security) {
        PartSubService<com.qqs.posvcs.model.PartDomain, PartDomain> subService =
                new PartSubService<com.qqs.posvcs.model.PartDomain, PartDomain>(security) {
                    @Override
                    protected void setAuditHistory(com.qqs.posvcs.model.PartDomain part,
                                                   Integer loggedInUser, Timestamp currentDate) {
                        if (part.getId() > 0) {
                            part.setModifiedBy(loggedInUser);
                            part.setModifiedDt(currentDate);
                        } else {
                            part.setCreatedBy(loggedInUser);
                            part.setCreatedDt(currentDate);
                        }
                    }

                    @Override
                    protected Iterable<com.qqs.posvcs.model.PartDomain> saveEntries(List<com.qqs.posvcs.model.PartDomain> toSave) {
                        return partDataService.saveDomain(toSave);
                    }
                };
        return subService;
    }

    @Bean(name = "partPriceSubService")
    PartSubService<com.qqs.posvcs.model.PartPrice, PartPrice> partPriceService(
            PartDataService partDataService, SecurityUtils security) {
        PartSubService<com.qqs.posvcs.model.PartPrice, PartPrice> subService =
                new PartSubService<com.qqs.posvcs.model.PartPrice, PartPrice>(security) {
                    @Override
                    protected void setAuditHistory(com.qqs.posvcs.model.PartPrice part,
                                                   Integer loggedInUser, Timestamp currentDate) {
                        if (part.getId() > 0) {
                            part.setModifiedBy(loggedInUser);
                            part.setModifiedDt(currentDate);
                        } else {
                            part.setCreatedBy(loggedInUser);
                            part.setCreatedDt(currentDate);
                        }
                    }

                    @Override
                    protected Iterable<com.qqs.posvcs.model.PartPrice> saveEntries(List<com.qqs.posvcs.model.PartPrice> toSave) {
                        return partDataService.savePrice(toSave);
                    }
                };
        return subService;
    }

    @Bean(name = "partRelationxRefSubService")
    PartSubService<com.qqs.posvcs.model.PartRelationxRef, PartRelationxRef> partRelationxRefService(
            PartDataService partDataService, SecurityUtils security) {
        PartSubService<com.qqs.posvcs.model.PartRelationxRef, PartRelationxRef> subService =
                new PartSubService<com.qqs.posvcs.model.PartRelationxRef, PartRelationxRef>(security) {

                    @Override
                    protected void setAuditHistory(com.qqs.posvcs.model.PartRelationxRef part,
                                                   Integer loggedInUser, Timestamp currentDate) {
                        if (part.getId() > 0) {
                            part.setModifiedBy(loggedInUser);
                            part.setModifiedDt(currentDate);
                        } else {
                            part.setCreatedBy(loggedInUser);
                            part.setCreatedDt(currentDate);
                        }
                    }

                    @Override
                    protected Iterable<com.qqs.posvcs.model.PartRelationxRef> saveEntries(List<com.qqs.posvcs.model.PartRelationxRef> toSave) {
                        return partDataService.saveChildParts(toSave);
                    }
                };
        return subService;
    }

    @Bean(name = "partStandardSubService")
    PartSubService<com.qqs.posvcs.model.PartStandard, PartStandard> partStandardSubService(
            PartDataService partDataService, SecurityUtils security) {
        PartSubService<com.qqs.posvcs.model.PartStandard, PartStandard> subService =
                new PartSubService<com.qqs.posvcs.model.PartStandard, PartStandard>(security) {

                    @Override
                    protected void setAuditHistory(com.qqs.posvcs.model.PartStandard part,
                                                   Integer loggedInUser, Timestamp currentDate) {
                        if (part.getId() > 0) {
                            part.setModifiedBy(loggedInUser);
                            part.setModifiedDt(currentDate);
                        } else {
                            part.setCreatedBy(loggedInUser);
                            part.setCreatedDt(currentDate);
                        }
                    }

                    @Override
                    protected Iterable<com.qqs.posvcs.model.PartStandard> saveEntries(List<com.qqs.posvcs.model.PartStandard> toSave) {
                        return partDataService.saveStandards(toSave);
                    }
                };
        return subService;
    }

    @Bean(name = "partCustomerRequirementSubService")
    PartSubService<com.qqs.posvcs.model.PartCustomerRequirement, PartCustomerRequirement> partCustomerRequirementSubService(
            PartDataService partDataService, SecurityUtils security) {
        PartSubService<com.qqs.posvcs.model.PartCustomerRequirement, PartCustomerRequirement> subService =
                new PartSubService<com.qqs.posvcs.model.PartCustomerRequirement, PartCustomerRequirement>(security) {

                    @Override
                    protected void setAuditHistory(com.qqs.posvcs.model.PartCustomerRequirement part,
                                                   Integer loggedInUser, Timestamp currentDate) {
                        if (part.getId() > 0) {
                            part.setModifiedBy(loggedInUser);
                            part.setModifiedDt(currentDate);
                        } else {
                            part.setCreatedBy(loggedInUser);
                            part.setCreatedDt(currentDate);
                        }
                    }

                    @Override
                    protected Iterable<com.qqs.posvcs.model.PartCustomerRequirement> saveEntries(List<com.qqs.posvcs.model.PartCustomerRequirement> toSave) {
                        return partDataService.saveCustomerRequirement(toSave);
                    }
                };
        return subService;
    }

    @Bean(name = "partRevisionAmendmentSubService")
    PartSubService<com.qqs.posvcs.model.PartRevisionAmendment, PartRevisionAmendment> partRevisionAmendmentSubService(
            PartDataService partDataService, SecurityUtils security) {
        PartSubService<com.qqs.posvcs.model.PartRevisionAmendment, PartRevisionAmendment> subService =
                new PartSubService<com.qqs.posvcs.model.PartRevisionAmendment, PartRevisionAmendment>(security) {

                    @Override
                    protected void setAuditHistory(com.qqs.posvcs.model.PartRevisionAmendment part,
                                                   Integer loggedInUser, Timestamp currentDate) {
                        if (part.getId() > 0) {
                            part.setModifiedBy(loggedInUser);
                            part.setModifiedDt(currentDate);
                        } else {
                            part.setCreatedBy(loggedInUser);
                            part.setCreatedDt(currentDate);
                        }
                    }

                    @Override
                    protected Iterable<com.qqs.posvcs.model.PartRevisionAmendment> saveEntries(List<com.qqs.posvcs.model.PartRevisionAmendment> toSave) {
                        return partDataService.saveRevisionAmendment(toSave);
                    }
                };
        return subService;
    }

    @Bean(name = "partImageSubService")
    PartSubService<com.qqs.posvcs.model.PartImage, PartImage> partImageSubService(
            PartDataService partDataService, SecurityUtils security) {
        PartSubService<com.qqs.posvcs.model.PartImage, PartImage> subService =
                new PartSubService<com.qqs.posvcs.model.PartImage, PartImage>(security) {

                    @Override
                    protected void setAuditHistory(com.qqs.posvcs.model.PartImage part,
                                                   Integer loggedInUser, Timestamp currentDate) {
                        if (part.getId() > 0) {
                            part.setModifiedBy(loggedInUser);
                            part.setModifiedDt(currentDate);
                        } else {
                            part.setCreatedBy(loggedInUser);
                            part.setCreatedDt(currentDate);
                        }
                    }

                    @Override
                    protected Iterable<com.qqs.posvcs.model.PartImage> saveEntries(List<com.qqs.posvcs.model.PartImage> toSave) {
                        return partDataService.savePartImage(toSave);
                    }
                };
        return subService;
    }
}
