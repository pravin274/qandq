package com.qqs.posvcs.service;

import com.qqs.qqsoft.BarCode.BarCodeGenerateService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


@Component
public class BarCodeService {

    Logger logger = LoggerFactory.getLogger(BankService.class);

    public String generateBarCode(com.qqs.posvcs.api.Barcode barCodeForm) {

        Integer fromNumber = barCodeForm.getFromNumber();
        Integer toNumber = barCodeForm.getToNumber();

        for (Integer index = fromNumber; index <= toNumber; index++) {
            BarCodeGenerateService.generateBarcode(barCodeForm.getSeriesNo() + "-" + index.toString() );
//            System.out.println(index);
        }


        return "Success Generate Barcode";
    }
}
