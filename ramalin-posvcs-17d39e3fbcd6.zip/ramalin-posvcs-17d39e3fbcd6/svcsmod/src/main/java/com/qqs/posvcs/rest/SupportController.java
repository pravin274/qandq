package com.qqs.posvcs.rest;

import com.qqs.posvcs.api.*;
import com.qqs.posvcs.api.common.Codes;
import com.qqs.posvcs.api.common.People;
import com.qqs.posvcs.api.translation.ParentEntityType;
import com.qqs.posvcs.service.*;
import com.qqs.posvcs.service.startup.ApplicationCodeMap;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.CurrencyUtils;
import com.qqs.qqsoft.utils.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

import static com.qqs.posvcs.utils.Constants.*;


@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/support")
public class SupportController {

    @Resource
    private ApplicationCodeMap codeMap;

    @Resource
    private PeopleService peopleService;

    @Resource
    private PlacesService placesService;

    @Resource
    private AddressService addressService;

    @Resource
    private DashboardService dashboardService;

    @Resource
    private BarCodeService barCodeService;

    @Value("${app.document.upload.location}")
    private String uploadFolder;

    // PICKLIST
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_ALL_WRITE','ROLE_MASTER_READ','ROLE_MASTER_WRITE', 'ROLE_PART_READ', 'ROLE_PLAN_READ'," +
            "'ROLE_WORK_READ', 'ROLE_WORK_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/picklist", produces = "application/json")
    public ResponseEntity<Map<String, Map<String, Codes>>> getPickList(HttpServletRequest request) throws QQBusinessException {
        ResponseEntity<Map<String, Map<String, Codes>>> result = new ResponseEntity(codeMap.getPickListMap(), HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    @RequestMapping(method = RequestMethod.GET, value = "/picklist/refresh", produces = "application/json")
    public ResponseEntity<String> refreshPicklist(HttpServletRequest request) throws QQBusinessException {
        codeMap.fillCodeData();
        ResponseEntity<String> result = new ResponseEntity("Refresh Successful", HttpStatus.OK);
        return result;
    }

    // PEOPLE
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/people", produces = "application/json")
    public ResponseEntity<Collection<People>> getPeopleByParentType(HttpServletRequest request,
                                                                    @RequestParam Integer parentId, @RequestParam String parentType) throws QQBusinessException {
        Collection<People> people = peopleService.getPeopleByParentType(parentType, parentId);
        ResponseEntity<Collection<People>> result = new ResponseEntity(people, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/people/byId", produces = "application/json")
    public ResponseEntity<Collection<People>> getPeopleById(HttpServletRequest request,
                                                            @RequestParam Integer id) throws QQBusinessException {
        People people = peopleService.getPeopleById(id);
        ResponseEntity<Collection<People>> result = new ResponseEntity(people, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/people/byCompany", produces = "application/json")
    public ResponseEntity<Collection<People>> getPeopleByCompany(HttpServletRequest request, @RequestParam Integer companyId) throws QQBusinessException {
        Collection<People> people = peopleService.getPeopleByCompany(companyId);
        ResponseEntity<Collection<People>> result = new ResponseEntity(people, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/people/byPlant", produces = "application/json")
    public ResponseEntity<Collection<People>> getPeopleByPlant(HttpServletRequest request, @RequestParam Integer plantId) throws QQBusinessException {
        Collection<People> people = peopleService.getPeopleByParentType(ParentEntityType.PLANT.getDbCode(), plantId);
        ResponseEntity<Collection<People>> result = new ResponseEntity(people, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/people/save", produces = "application/json")
    public ResponseEntity<People> savePeople(@RequestBody com.qqs.posvcs.api.common.People form) throws QQBusinessException {
        com.qqs.posvcs.api.common.People saved = peopleService.savePeople(form);
        ResponseEntity<People> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }


    // ADDRESS
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/address", produces = "application/json")
    public ResponseEntity<Collection<Address>> getAddressByParent(HttpServletRequest request,
                                                                  @RequestParam Integer parentId, @RequestParam String parentType) throws QQBusinessException {
        if (ParentEntityType.getEntityType(parentType) == null) {
            throw new QQBusinessException("Invalid type");
        }
        Collection<Address> address = addressService.getAddressByParentType(parentType, parentId);
        ResponseEntity<Collection<Address>> result = new ResponseEntity(address, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/address/save", produces = "application/json")
    public ResponseEntity<Address> saveAddress(@RequestBody com.qqs.posvcs.api.Address form) throws QQBusinessException {
        com.qqs.posvcs.api.Address saved = addressService.saveAddress(form);
        ResponseEntity<Address> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }


    // PLACES
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/places", produces = "application/json")
    public ResponseEntity<Collection<Places>> getAllPlaces(HttpServletRequest request) throws QQBusinessException {
        Collection<Places> places = placesService.getAllPlaces();
        ResponseEntity<Collection<Places>> result = new ResponseEntity(places, HttpStatus.OK);
        return result;
    }

    // CONVERSION AMOUT
    @RequestMapping(method = RequestMethod.GET, value = "/convertword", produces = "application/json")
    public ResponseEntity<String> getAddressByParent(HttpServletRequest request,
                                                     @RequestParam Integer amount) throws QQBusinessException {
        ResponseEntity<String> result = new ResponseEntity(CurrencyUtils.convertToWordCurrency(amount), HttpStatus.OK);
        return result;
    }

    //// ///// ////// File and document upload
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_WRITE','ROLE_MASTER_WRITE')")
    @RequestMapping(value = "/upload", method = RequestMethod.POST, consumes = {"multipart/form-data"})
    @ResponseBody
    public ResponseEntity<String> uploadFiles(@RequestParam("file") MultipartFile file, @RequestParam("documentType") String documentType,
                                              HttpServletRequest httpRequest, HttpServletResponse httpResponse) throws Exception {
        String result = "";
        String fileFolder = uploadFileFolder.get(documentType);
        if (!file.isEmpty()) {
            try {
                FileUtils fileUtils = new FileUtils();
                result = fileUtils.uploadFile(file, "", uploadFolder + fileFolder);
            } catch (Exception e) {
                result = "Error occurred";
            }
        } else {
            result = "File was empty";
        }
        ResponseEntity<String> resultOut = new ResponseEntity(result, HttpStatus.OK);
        return resultOut;
    }

    // DOWNLOAD
    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    @RequestMapping(method = RequestMethod.GET, value = "/downloadFile", produces = {"multipart/form-data"})
    public ResponseEntity<org.springframework.core.io.Resource> generateFile(@RequestParam String fileName, String documentType,
                                                                             HttpServletRequest request,
                                                                             HttpServletResponse response) throws QQBusinessException {
        String fileFolder = uploadFileFolder.get(documentType);
        ApplicationContext appContext =
                new ClassPathXmlApplicationContext(new String[]{});
        org.springframework.core.io.Resource resource = appContext.getResource("file:" + uploadFolder + fileFolder + '/' + fileName); // new ClassPathResource("file:" + uploadFolder + fileFolder + '/'  + fileName);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=img.docx");
        ResponseEntity<org.springframework.core.io.Resource> result = ResponseEntity
                .ok()
                .headers(httpHeaders)
                .body(resource);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_DASHBOARD', 'ROLE_ALL_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/dashboardData", produces = "application/json")
    public ResponseEntity<DashboardDetails> getDashboardData(HttpServletRequest request) throws QQBusinessException {
        DashboardDetails dashboardDetails = dashboardService.getDashboardDetails();
        ResponseEntity<DashboardDetails> result = new ResponseEntity(dashboardDetails, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_ALL_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/generateBarcode", produces = "application/json")
    public ResponseEntity<String> generateBarCode(@RequestBody Barcode form) throws QQBusinessException {
        String saved = barCodeService.generateBarCode(form);
        ResponseEntity<String> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

}
