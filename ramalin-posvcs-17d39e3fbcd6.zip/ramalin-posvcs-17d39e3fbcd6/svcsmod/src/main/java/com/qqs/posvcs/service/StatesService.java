package com.qqs.posvcs.service;

import com.qqs.posvcs.api.States;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;

import static com.qqs.posvcs.service.translate.APITranslator.*;

@Component
public class StatesService {

    Logger logger = LoggerFactory.getLogger(StatesService.class);

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    @Resource
    DataService ds;

    public States saveState(States statesData) throws QQBusinessException {
        States statesToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        try {
            com.qqs.posvcs.model.States toSaveStates =  statesToDB.translate(statesData, com.qqs.posvcs.model.States.class, true);
//            if(toSaveAddresse.getId() > 0) {
//                new DateUtils<com.qqs.posvcs.model.Address>().setTimeStamp(toSaveAddresse, com.qqs.posvcs.model.Address.class, true);
//                toSaveAddresse.setModifiedBy(loggedInUser);
//            } else {
//                new DateUtils<com.qqs.posvcs.model.Address>().setTimeStamp(toSaveAddresse, com.qqs.posvcs.model.Address.class, false);
//                toSaveAddresse.setCreatedBy(loggedInUser);
//            }
            com.qqs.posvcs.model.States states = ds.getStatesDataService().saveState(toSaveStates);

            statesToApi = statesToAPI.translate(states , States.class, true);

        } catch (Exception e ) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving States details");
        }
        return statesToApi;

    }


    public States getStateById(Integer stateId) throws QQBusinessException {
        try {
            Optional<com.qqs.posvcs.model.States> state = ds.getStatesDataService().getStateById(stateId);
            if (!state.isPresent()) {
                throw new QQBusinessException("No States found");
            }
            States statesAPI = statesToAPI.translate(state.get(), States.class, false);
            return statesAPI;
        } catch (Exception e) {
            logger.error("States fetch error", e);
        }
        throw new QQBusinessException("States could not be retrieved");
    }

    public List<States> getAllStatesByCountryId(Integer countryId) {
        return ds.getStatesDataService().findStatesByCountryId(countryId).orElse(Collections.EMPTY_LIST);
    }


    public List<States> getAllStates() throws QQBusinessException {
        List<States> result = new ArrayList<>();
        Iterable<com.qqs.posvcs.model.States> states = ds.getStatesDataService().getAllStates();
        states.forEach(state -> {
            try {
                result.add(statesToAPI.translate(state, States.class, false));
            } catch (Exception e) {
                logger.error("translation exception");
            }
        });
        return result;
    }

    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"name"}));
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, null, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }



}
