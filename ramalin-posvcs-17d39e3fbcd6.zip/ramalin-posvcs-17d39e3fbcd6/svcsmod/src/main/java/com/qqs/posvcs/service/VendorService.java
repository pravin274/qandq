package com.qqs.posvcs.service;

import com.qqs.posvcs.api.Vendor;
import com.qqs.posvcs.api.translation.ParentEntityType;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;

import static com.qqs.posvcs.api.translation.ParentEntityType.PEOPLE;
import static com.qqs.posvcs.service.translate.APITranslator.*;

@Component
public class VendorService {

    Logger logger = LoggerFactory.getLogger(VendorService.class);

    @Resource
    DataService ds;
    @Resource
    VendorDataService vendorDataService;

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    @Resource
    PeopleService peopleService;

    public Vendor saveVendor(Vendor vendorData) throws QQBusinessException {
        Vendor vendorToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();

        try {
            com.qqs.posvcs.model.Vendor toSaveVendor =  vendorToDB.translate(vendorData, com.qqs.posvcs.model.Vendor.class, true);
            if(toSaveVendor.getId() > 0) {
                new DateUtils<com.qqs.posvcs.model.Vendor>().setTimeStamp(toSaveVendor, com.qqs.posvcs.model.Vendor.class, true);
                toSaveVendor.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.posvcs.model.Vendor>().setTimeStamp(toSaveVendor, com.qqs.posvcs.model.Vendor.class, false);
                toSaveVendor.setCreatedBy(loggedInUser);
            }
            com.qqs.posvcs.model.Vendor vendor = vendorDataService.saveVendor(toSaveVendor);

            vendorToApi = vendorToAPI.translate(vendor , Vendor.class, true);

        } catch (Exception e ) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving Vendor");
        }

        return vendorToApi;

    }

    public Vendor getVendorById(Integer id) throws QQBusinessException {
        Vendor vendorToApi = null;
        try {
            Optional<com.qqs.posvcs.model.Vendor> vendor = vendorDataService.getVendorById(id);
            if (vendor.isPresent()) {
                vendorToApi =  vendorToAPI.translate(vendor.get(), Vendor.class, true);
            }
        } catch (Exception e) {
            throw new QQBusinessException("Error while fetching Vendor");
        }
        try {
            Collection<com.qqs.posvcs.api.common.People> peopleList = peopleService.getPeopleByParentType(ParentEntityType.VENDOR.getDbCode(), id);
            List<Integer> peopleIds = new ArrayList<>();
            peopleList.forEach( people -> {
                peopleIds.add(people.getId());
            });
            Optional<List<com.qqs.posvcs.model.Phone>> phoneList =  ds.getPhoneDS().findAllByParentIdInAndParentEntity(peopleIds, PEOPLE.getDbCode());
            Optional<List<com.qqs.posvcs.model.Email>> emailList = ds.getEmailDS().findAllByParentIdInAndParentEntity(peopleIds, PEOPLE.getDbCode());
            Map<Integer, Set<com.qqs.posvcs.api.Phone>> phoneMap = new HashMap<>();
            Map<Integer, Set<com.qqs.posvcs.api.Email>> emailMap = new HashMap<>();
            if (phoneList.isPresent()) {
                List<com.qqs.posvcs.api.Phone> phonesToApi = phoneToAPI.translate(phoneList.get(), com.qqs.posvcs.api.Phone.class , true );
                phonesToApi.forEach( phone ->  {
                    if (phoneMap.get(phone.getParentId()) == null) {
                        phoneMap.put(phone.getParentId(), new HashSet<>());
                    }
                    phoneMap.get(phone.getParentId()).add(phone);
                });
                peopleList.forEach( people -> {
                    if (phoneMap.get(people.getId()) != null) {
                        people.setPhones(phoneMap.get(people.getId()));
                    }
                });
            }
            if (emailList.isPresent()) {
                List<com.qqs.posvcs.api.Email> emailsToApi = emailToAPI.translate(emailList.get(), com.qqs.posvcs.api.Email.class , true );
                emailsToApi.forEach( email ->  {
                    if (emailMap.get(email.getParentId()) == null) {
                        emailMap.put(email.getParentId(), new HashSet<>());
                    }
                    emailMap.get(email.getParentId()).add(email);
                });
                peopleList.forEach( people -> {
                    if (emailMap.get(people.getId()) != null) {
                        people.setEmails(emailMap.get(people.getId()));
                    }
                });
            }
            vendorToApi.setPeople(new ArrayList(peopleList));
        } catch (Exception e) {
            logger.error("translation exception - People");
        }
        return vendorToApi;
    }

    public List<Vendor> searchVendor(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.posvcs.model.Vendor>> vendorList = vendorDataService.searchClient(conditions);
        if (!vendorList.isPresent())
            throw new QQBusinessException("No Vendor details found for criteria vendor search");
        List<Vendor> result = null;
        try {
            result = vendorToAPI.translate(vendorList.get(), Vendor.class, false);
        } catch (Exception e) {
            logger.error("Error getting Vendor", e);
        }

        return result;
    }

    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"vendorName", "gstinNo", "panNo", "ieCode"}));
        Map<String, String> operators = new HashMap<>(2);
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, operators, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }
}




