package com.qqs.posvcs.service.helper;

import com.qqs.posvcs.model.*;
import com.qqs.posvcs.service.DataService;
import com.qqs.posvcs.service.PlantService;
import com.qqs.posvcs.service.startup.ApplicationCodeMap;
import com.qqs.qqsoft.utils.ApiUtils;
import com.qqs.qqsoft.QQBusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;

import static com.qqs.posvcs.service.translate.APITranslator.*;

@Component
public class POServiceHelper {
    Logger logger = LoggerFactory.getLogger(POServiceHelper.class);

    @Resource
    DataService ds;

    @Resource
    private PlantService plantService;

    @Resource
    private ApplicationCodeMap systemCodeMap;

    public com.qqs.posvcs.api.PurchOrder fillPODetails(PurchOrder po) throws QQBusinessException {
        try {
            //Retrieve lineItems for PO
            Iterable<PoLineItem> lineItems = ds.getPoLineItemDS().getPOLineItemByPOId(po.getId());
            com.qqs.posvcs.api.PurchOrder poAPI = poToAPI.translate(po, com.qqs.posvcs.api.PurchOrder.class, false);

            Map<String, Map<String, com.qqs.posvcs.api.common.Codes>> codesMap = systemCodeMap.getCodeMap();
            com.qqs.posvcs.api.PlantDeliveryTerms plantDeliveryTerms =  plantService.getPlantDeliveryTerms(poAPI.getDvryTermsId());
            com.qqs.posvcs.api.PlantPaymentTerms plantPaymentTerms =  plantService.getPlantPaymentTerms(poAPI.getPymntTermsId());
            String deliveryTerms = "";
            String paymentTerms = "";
            if(plantDeliveryTerms != null) {
                deliveryTerms = codesMap.get("DELIVERY_TERMS").get(plantDeliveryTerms.getDeliveryTerms()).getDescription();
            }
            if(plantPaymentTerms != null) {
                paymentTerms = codesMap.get("PAYMENT_TERMS").get(plantPaymentTerms.getPaymentTerms()).getDescription();
            }
            poAPI.setDvryTerms(deliveryTerms);
            poAPI.setPymntTerms(paymentTerms);

            List<PoLineItem> lines = new ArrayList<>();
            List<Integer> poLineItemIds = new ArrayList<>();

            lineItems.forEach(item -> {
                if (!item.getIsDeleted()){
                    lines.add(item);
                    poLineItemIds.add(item.getId());
                }
            });      
             System.out.println(lines);
            List<com.qqs.posvcs.api.PoLineItem> lineItemsAPI = lineItemToAPI.translate(
                    lines, com.qqs.posvcs.api.PoLineItem.class, false
            );

            //Getting shipped qty. Shipped qty is calculated based on PoNumber, PartType, PartNumber, Item (POLineItem).

            Optional<List<Object[]>> shippingAttrList = ds.getPoLineItemDS().getShippingAttr(poLineItemIds);
            if(shippingAttrList.isPresent()) {
                Map<Integer, String> shippingAttrMap = new HashMap<>();
                shippingAttrList.get().forEach(item -> {
                    StringBuffer sb = new StringBuffer();
                    sb.append(item[1].toString()).append('|').append(item[2].toString()).append('|')
                            .append(item[3].toString()).append('|').append(item[4].toString());
                    shippingAttrMap.put(((Integer) item[0]), sb.toString());
                });

                Optional<List<Object[]>> shippedQtyList = ds.getInvoiceLineItemDS().getShippedQtyByPOLineItems(poLineItemIds, 0);

                if (shippedQtyList.isPresent()) {
                    Map<String, Double> shippedQtyMap = new HashMap<>();
                    shippedQtyList.get().forEach(item -> {
                        StringBuffer sb = new StringBuffer();
                        sb.append(item[0].toString()).append('|').append(item[1].toString()).append('|')
                                .append(item[2].toString()).append('|').append(item[3].toString());
                        shippedQtyMap.put(sb.toString(), (((BigDecimal) item[4]).doubleValue()));
                    });
                    lineItemsAPI.forEach(item -> {
                        if (shippingAttrMap.get(item.getId()) != null &&
                                shippedQtyMap.get(shippingAttrMap.get(item.getId())) != null) {
                            item.setShippedQty(shippedQtyMap.get(shippingAttrMap.get(item.getId())));
                        } else {
                            item.setShippedQty(0.0);
                        }
                    });
                }
            }

            poAPI.setPoLineItems(new HashSet<>(lineItemsAPI));

            //Fill Address
            List<Integer> addressIds = Arrays.asList(po.getBillToAddrId(), po.getDvryAddrId());
            Iterable<Address> addresses = ds.getAddressDS().findAddressByIds(addressIds);
            List<com.qqs.posvcs.api.Address> addressList = addressToAPI.translate(addresses, com.qqs.posvcs.api.Address.class, false);
            addressList.forEach( address -> {
                address.setCityName(ds.getAddressDS().findCityNameById(address.getCity()).get());
                address.setProvinceName(ds.getAddressDS().findStateNameById(address.getProvince()).get());
                address.setCountryName(ds.getAddressDS().findCountryNameById(address.getCountry()).get());
            });
            Map<Integer, com.qqs.posvcs.api.Address> addressMap = new HashMap<>();
            addressList.forEach(address -> {
                addressMap.put(address.getId(), address);
            });
            poAPI.setBillToAddress(addressMap.get(po.getBillToAddrId()));
            poAPI.setDeliveryAddress(addressMap.get(po.getDvryAddrId()));

            //Fill company and plant info
            Company company = ds.getCompanyDS().getCompanyById(po.getCompanyId()).get();
            com.qqs.posvcs.api.Company companyAPI = companyToAPI.translate(company, com.qqs.posvcs.api.Company.class, false);
            poAPI.setCompany(companyAPI);
            //TODO - Decide which level of plant is required at the frontend
            Plant plant = ds.getPlantDS().getPlantById(po.getPlantId()).get();
            com.qqs.posvcs.api.Plant plantAPI = plantToAPI.translate(plant, com.qqs.posvcs.api.Plant.class, false);
            plantAPI.setCompany(companyAPI);
            poAPI.setPlant(plantAPI);
            fillToolDetails(poAPI);
            fillPartDetails(poAPI);
            fillPeopleDetails(poAPI);
            return poAPI;
        } catch (Exception e) {
            throw new QQBusinessException("", e);
        }
    }

    public void fillPeopleDetails(com.qqs.posvcs.api.PurchOrder po) {
        try {
            List<Integer> peopleIds = new ArrayList<>();
            peopleIds.add(po.getBuyer());
            peopleIds.add(po.getQqRespPerson());
            Iterable<People> fromDB = ds.getPeopleDS().findAllPeopleById(peopleIds);
            po.setPeoples(new HashSet<>(peopleToAPI.translate(fromDB, com.qqs.posvcs.api.common.People.class, false)));
        } catch (Exception e) {
            logger.error("Exception adding People", e);
        }
    }

    public void fillPartDetails(com.qqs.posvcs.api.PurchOrder po) {
        try {
            List<Integer> partIds = new ArrayList<>();
            po.getPoLineItems().stream().filter(item -> item.getPartId() > 0).forEach(item -> partIds.add(item.getPartId()));
            Iterable<Part> parts = ds.getPartDS().getAllPartsById(partIds);
            List<com.qqs.posvcs.api.parts.Part> partListAPI = partsToAPI.translate(
                    parts, com.qqs.posvcs.api.parts.Part.class, false);

            for (com.qqs.posvcs.api.parts.Part part : partListAPI) {
                Optional<List<com.qqs.posvcs.model.PartPrice>> priceList = ds.getPartDS().getPriceByPart(part.getId());
                try {
                    part.setPrices(partPriceToAPI.translate(priceList.get(),com.qqs.posvcs.api.parts.PartPrice.class,false ));
                } catch (Exception e) {
                    logger.error("Part Price translation error", e);
                }
            }

            for (com.qqs.posvcs.api.parts.Part part : partListAPI) {
                Optional<List<PartCommodity>> commodity = ds.getPartDS().getCommodityByPart(part.getId());
                if (commodity.isPresent()) {
                    try {
                        List<com.qqs.posvcs.api.parts.PartCommodity> commodityApi =
                                new ApiUtils<PartCommodity, com.qqs.posvcs.api.parts.PartCommodity>()
                                        .translate(commodity.get(), com.qqs.posvcs.api.parts.PartCommodity.class, false);
                        part.setCommodities(commodityApi);
                    } catch (Exception e) {
                        logger.error("Part Commodity translation error", e);
                    }
                }
            }

            Map<Integer, com.qqs.posvcs.api.parts.Part> partMap = new HashMap<>();
            partListAPI.forEach(p -> partMap.put(p.getId(), p));
            po.getPoLineItems().stream().filter(item -> item.getPartId() > 0).forEach(i -> i.setPart(partMap.get(i.getPartId())));
        } catch (Exception e) {
            logger.error("Exception translating PO ", e);
        }
    }

    public void fillToolDetails(com.qqs.posvcs.api.PurchOrder po) {
        try {
            Map<Integer, com.qqs.posvcs.api.PoLineTool> toolMap = new HashMap<>();
            List<Integer> poLineToolIds = new ArrayList<>();
            po.getPoLineItems().forEach(item -> poLineToolIds.add(item.getPoLineToolId()));
            Iterable<PoLineTool> poLineTools = ds.getPoLineItemDS().getAllPoLineToolsById(poLineToolIds);

            List<com.qqs.posvcs.api.PoLineTool> poLineToolAPI = poLineToolToAPI.translate(poLineTools, com.qqs.posvcs.api.PoLineTool.class, false);
            poLineToolAPI.forEach(lineTool -> toolMap.put(lineTool.getId(), lineTool));
            po.getPoLineItems().forEach(lineItem -> {
                if (toolMap.get(lineItem.getPoLineToolId()) != null)
                    lineItem.setPoLineTool(toolMap.get(lineItem.getPoLineToolId()));
            });
        } catch (Exception e) {
            logger.error("Exception translating PO Line Item Tool ", e);
        }
    }
}
