package com.qqs.posvcs.rest;

import com.qqs.posvcs.api.Countries;
import com.qqs.posvcs.api.Plant;
import com.qqs.posvcs.api.States;
import com.qqs.posvcs.api.Cities;
import com.qqs.posvcs.service.CitiesService;
import com.qqs.posvcs.service.CountriesService;
import com.qqs.posvcs.service.StatesService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/countries")
public class CountriesController {

    @Resource
    CountriesService countriesService;

    @Resource
    StatesService statesService;

    @Resource
    CitiesService citiesService;

    // Countries

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/save", produces = "application/json")
    public ResponseEntity<Countries> saveCountry(@RequestBody com.qqs.posvcs.api.Countries form) throws QQBusinessException {
        com.qqs.posvcs.api.Countries saved = countriesService.saveCountry(form);
        ResponseEntity<Countries> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_COMPANY_READ', 'ROLE_ALL_READ','ROLE_COMPANY_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/allCountries", produces = "application/json")
    public ResponseEntity<List<Countries>> getAllCountries(HttpServletRequest request) throws QQBusinessException {
        List<Countries> formList = countriesService.getAllCountries();
        ResponseEntity<List<Countries>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ','ROLE_MASTER_WRITE')")
     @RequestMapping(method = RequestMethod.GET, value = "/country/byId", produces = "application/json")
    public ResponseEntity<Collection<Countries>> getCountryById(HttpServletRequest request,
                                                            @RequestParam Integer id) throws QQBusinessException {
        Countries country = countriesService.getCountryById(id);
        ResponseEntity<Collection<Countries>> result = new ResponseEntity(country, HttpStatus.OK);
        return result;
    }


    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_COMPANY_READ', 'ROLE_ALL_READ','ROLE_COMPANY_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/form/searchCountries", produces = "application/json")
    public ResponseEntity<List<Countries>> searchCountries(@RequestParam Map<String, String> searchParam,
                                                    @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                    HttpServletRequest request) throws QQBusinessException {
        List<Countries> formList = countriesService.searchCountries(searchParam, exactMatch.orElse(false));
        ResponseEntity<List<Countries>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }


    // State

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/state/save", produces = "application/json")
    public ResponseEntity<States> saveState(@RequestBody com.qqs.posvcs.api.States form) throws QQBusinessException {
        com.qqs.posvcs.api.States saved = statesService.saveState(form);
        ResponseEntity<States> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_COMPANY_READ', 'ROLE_ALL_READ','ROLE_COMPANY_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/allStates", produces = "application/json")
    public ResponseEntity<List<States>> getAllStates(HttpServletRequest request) throws QQBusinessException {
        List<States> formList = statesService.getAllStates();
        ResponseEntity<List<States>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_COMPANY_READ', 'ROLE_ALL_READ','ROLE_COMPANY_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/allStates/byCountryId", produces = "application/json")
    public ResponseEntity<List<States>> getAllStatesByCountryId(HttpServletRequest request,
                                                                @RequestParam Integer countryId) throws QQBusinessException {
        List<States> formList = statesService.getAllStatesByCountryId(countryId);
        ResponseEntity<List<States>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/state/byId", produces = "application/json")
    public ResponseEntity<Collection<States>> getStateById(HttpServletRequest request,
                                                                  @RequestParam Integer id) throws QQBusinessException {
        States state = statesService.getStateById(id);
        ResponseEntity<Collection<States>> result = new ResponseEntity(state, HttpStatus.OK);
        return result;
    }

    // City

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/city/save", produces = "application/json")
    public ResponseEntity<Cities> saveCity(@RequestBody com.qqs.posvcs.api.Cities form) throws QQBusinessException {
        com.qqs.posvcs.api.Cities saved = citiesService.saveCity(form);
        ResponseEntity<Cities> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_COMPANY_READ', 'ROLE_ALL_READ','ROLE_COMPANY_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/allCities/byStateId", produces = "application/json")
    public ResponseEntity<List<Cities>> getAllCitiesByStateId(HttpServletRequest request,
                                                                @RequestParam Integer stateId) throws QQBusinessException {
        List<Cities> formList = citiesService.getAllCitiesByStateId(stateId);
        ResponseEntity<List<Cities>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_COMPANY_READ', 'ROLE_ALL_READ','ROLE_COMPANY_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/allCities", produces = "application/json")
    public ResponseEntity<List<Cities>> getAllCities(HttpServletRequest request) throws QQBusinessException {
        List<Cities> formList = citiesService.getAllCities();
        ResponseEntity<List<Cities>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/city/byId", produces = "application/json")
    public ResponseEntity<Collection<Cities>> getCityById(HttpServletRequest request,
                                                           @RequestParam Integer id) throws QQBusinessException {
        Cities city = citiesService.getCityById(id);
        ResponseEntity<Collection<Cities>> result = new ResponseEntity(city, HttpStatus.OK);
        return result;
    }
}
