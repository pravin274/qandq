package com.qqs.posvcs.service;

import com.qqs.invsvcs.api.InvProductDetails;
import com.qqs.invsvcs.api.SupplierPurchaseOrder;
import com.qqs.posvcs.api.PurchOrder;
import com.qqs.posvcs.utils.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Component
public class InvProductDetailService {

    private static Logger log = LoggerFactory.getLogger(InvProductDetailService.class);

    @Value("${app.invsvcs.url}")
    private String invsvcsURL;

    public InvProductDetails getInvProductDetails(Integer productId, String productType, HttpServletRequest request) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders requestHeaders = new HttpHeaders();

        StringBuffer url = new StringBuffer(invsvcsURL);
        url.append(Constants.INV_SERVICE_MAP.get("byId")).append("productId=").append(productId).append("&productType=").append(productType);

        requestHeaders.add("Authorization", request.getHeader("Authorization"));
        requestHeaders.add("Content-Type", "application/json; charset=UTF-8");

        HttpEntity requestEntity = new HttpEntity(null, requestHeaders);
        ResponseEntity response = restTemplate.exchange(url.toString(),
                HttpMethod.GET, requestEntity, new ParameterizedTypeReference<InvProductDetails>(){});
        InvProductDetails invProductDetails = (InvProductDetails) response.getBody();

        return invProductDetails;
    }

    public InvProductDetails saveInvProductDetails(InvProductDetails invProductDetails, HttpServletRequest request) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders requestHeaders = new HttpHeaders();

        requestHeaders.add("Authorization", request.getHeader("Authorization"));
        requestHeaders.add("Content-Type", "application/json; charset=UTF-8");

        HttpEntity requestEntity = new HttpEntity(invProductDetails, requestHeaders);
        ResponseEntity response = restTemplate.exchange(invsvcsURL + Constants.INV_SERVICE_MAP.get("save"),
                HttpMethod.POST, requestEntity, new ParameterizedTypeReference<InvProductDetails>(){});
        InvProductDetails invProductDetailsSaved = (InvProductDetails) response.getBody();

        return invProductDetailsSaved;
    }

}
