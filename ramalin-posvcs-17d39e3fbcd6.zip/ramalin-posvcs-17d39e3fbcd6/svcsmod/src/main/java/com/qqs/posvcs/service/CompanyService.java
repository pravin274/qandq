package com.qqs.posvcs.service;

import com.qqs.posvcs.api.Company;
import com.qqs.posvcs.model.Ats;
import com.qqs.qqsoft.utils.ApiUtils;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import com.qqs.qqsoft.QQBusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;

import static com.qqs.posvcs.service.translate.APITranslator.companyToAPI;
import static com.qqs.posvcs.service.translate.APITranslator.companyToDB;
import static com.qqs.posvcs.service.translate.APITranslator.searchCriteriaToJPA;

@Component
public class CompanyService {

    Logger logger = LoggerFactory.getLogger(CompanyService.class);

    @Resource
    DataService ds;
    @Resource
    CompanyDataService companyDataService;

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    @Resource
    CompanyServiceHelper helper;

    public Company saveCompany(Company companyData) throws QQBusinessException {
        Company companyToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();

        try {
            com.qqs.posvcs.model.Company toSaveCompany =  companyToDB.translate(companyData, com.qqs.posvcs.model.Company.class, true);
            if(toSaveCompany.getId() > 0) {
                new DateUtils<com.qqs.posvcs.model.Company>().setTimeStamp(toSaveCompany, com.qqs.posvcs.model.Company.class, true);
                toSaveCompany.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.posvcs.model.Company>().setTimeStamp(toSaveCompany, com.qqs.posvcs.model.Company.class, false);
                toSaveCompany.setCreatedBy(loggedInUser);
            }
            com.qqs.posvcs.model.Company company = companyDataService.saveCompany(toSaveCompany);

            companyToApi = companyToAPI.translate(company , Company.class, true);

        } catch (Exception e ) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving Company");
        }
        return companyToApi;

    }

    public Company getCompanyById(Integer id) throws QQBusinessException {
        Optional<com.qqs.posvcs.model.Company> company = companyDataService.getCompanyById(id);
        if (company.isPresent()) {
            return helper.fillCompleteCompanyInfo(company.get());
        }
        throw new QQBusinessException("No company information found");
    }

    public List<Company> searchClients(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.posvcs.model.Company>> clientList = companyDataService.searchClient(conditions);
        if (!clientList.isPresent())
            throw new QQBusinessException("No client found for criteria company search");
        List<Company> result = new ArrayList<>(clientList.get().size());

        for (com.qqs.posvcs.model.Company c : clientList.get()) {
            Company form = helper.fillCompleteCompanyInfo(c);
            result.add(form);
        }
        return result;
    }

    public List<Company> getAllClients() throws QQBusinessException {
        Iterable<com.qqs.posvcs.model.Company> clientList = companyDataService.getAllCompany();
        List<Company> result = new ArrayList<>();
        for (com.qqs.posvcs.model.Company c : clientList) {
            Company company = null;
            try {
                company = new ApiUtils<com.qqs.posvcs.model.Company, Company>().translate(c, Company.class, false);
            } catch (Exception e) {
                logger.error("Company translation error", e);
            }
            result.add(company);
        }
        return result;
    }

    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"name"}));
        Map<String, String> operators = new HashMap<>(2);
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, operators, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }
}
