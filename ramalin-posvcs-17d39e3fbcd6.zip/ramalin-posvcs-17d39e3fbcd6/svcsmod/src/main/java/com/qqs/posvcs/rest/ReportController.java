package com.qqs.posvcs.rest;

import com.qqs.posvcs.api.reports.*;
import com.qqs.posvcs.service.ReportService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/report")
public class ReportController {

    @Resource
    private ReportService service;

    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    @RequestMapping(method = RequestMethod.GET, value = "/salesReport", produces = "application/json")
    public ResponseEntity<ChartData> getSalesReportData(@RequestParam Map<String, String> searchParam,
                                                        @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                        HttpServletRequest request) throws QQBusinessException {
        ChartData chartData = service.getSalesReportData(searchParam);
        ResponseEntity<ChartData> result = new ResponseEntity(chartData, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    @RequestMapping(method = RequestMethod.GET, value = "/orderReport", produces = "application/json")
    public ResponseEntity<ChartData> getOrderReportData(@RequestParam Map<String, String> searchParam,
                                                        @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                        HttpServletRequest request) throws QQBusinessException {
        ChartData chartData = service.getOrderReportData(searchParam);
        ResponseEntity<ChartData> result = new ResponseEntity(chartData, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    @RequestMapping(method = RequestMethod.GET, value = "/salesOrderReport", produces = "application/json")
    public ResponseEntity<SalesOrderReportData> getSalesOrderReportData(@RequestParam Map<String, String> searchParam,
                                                                          @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                                          HttpServletRequest request) throws QQBusinessException {
        List<SalesOrderReportData> salesOrderReportDataData = service.getSalesOrderReportData(searchParam);
        ResponseEntity<SalesOrderReportData> result = new ResponseEntity(salesOrderReportDataData, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_INVOICE_READ', 'ROLE_PENDING_READ')")
    @RequestMapping(method = RequestMethod.GET, value = "/pendingOrderReport", produces = "application/json")
    public ResponseEntity<List<PendingOrderData>> getPendingOrderReportData(@RequestParam Map<String, String> searchParam,
                                                                        @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                                        HttpServletRequest request) throws QQBusinessException {
        List<PendingOrderData> pendingOrderDataList = service.getPendingOrderReportData(searchParam);
        ResponseEntity<List<PendingOrderData>> result = new ResponseEntity(pendingOrderDataList, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    @RequestMapping(method = RequestMethod.GET, value = "/invoiceReport", produces = "application/json")
    public ResponseEntity<List<InvoiceReportData>> getInvoiceReportData(@RequestParam Map<String, String> searchParam,
                                                                        @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                                        HttpServletRequest request) throws QQBusinessException {
        List<InvoiceReportData> invoiceReportList = service.getInvoiceReportData(searchParam);
        ResponseEntity<List<InvoiceReportData>> result = new ResponseEntity(invoiceReportList, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    @RequestMapping(method = RequestMethod.GET, value = "/poTrackReport", produces = "application/json")
    public ResponseEntity<List<PoTrackReport>> getpoTrackData(@RequestParam Map<String, String> searchParam,
                                                              @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                              HttpServletRequest request) throws QQBusinessException {
        List<PoTrackReport> invoiceReportList = service.getpoTrackData(searchParam);
        ResponseEntity<List<PoTrackReport>> result = new ResponseEntity(invoiceReportList, HttpStatus.OK);
        return result;
    }
}
