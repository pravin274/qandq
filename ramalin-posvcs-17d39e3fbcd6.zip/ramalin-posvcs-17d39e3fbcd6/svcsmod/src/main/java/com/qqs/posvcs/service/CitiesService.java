package com.qqs.posvcs.service;

import com.qqs.posvcs.api.Cities;
import com.qqs.posvcs.api.States;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;

import static com.qqs.posvcs.service.translate.APITranslator.*;

@Component
public class CitiesService {

    Logger logger = LoggerFactory.getLogger(CitiesService.class);

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    @Resource
    DataService ds;

    public Cities saveCity(Cities citiesData) throws QQBusinessException {
        Cities citiesToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        try {
            com.qqs.posvcs.model.Cities toSaveCities =  citiesToDB.translate(citiesData, com.qqs.posvcs.model.Cities.class, true);
//            if(toSaveAddresse.getId() > 0) {
//                new DateUtils<com.qqs.posvcs.model.Address>().setTimeStamp(toSaveAddresse, com.qqs.posvcs.model.Address.class, true);
//                toSaveAddresse.setModifiedBy(loggedInUser);
//            } else {
//                new DateUtils<com.qqs.posvcs.model.Address>().setTimeStamp(toSaveAddresse, com.qqs.posvcs.model.Address.class, false);
//                toSaveAddresse.setCreatedBy(loggedInUser);
//            }
            com.qqs.posvcs.model.Cities cities = ds.getCityDataService().saveCities(toSaveCities);

            citiesToApi = citiesToAPI.translate(cities , Cities.class, true);

        } catch (Exception e ) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving Cities details");
        }
        return citiesToApi;

    }


    public Cities getCityById(Integer cityId) throws QQBusinessException {
        try {
            Optional<com.qqs.posvcs.model.Cities> city = ds.getCityDataService().findCityById(cityId);
            if (!city.isPresent()) {
                throw new QQBusinessException("No States found");
            }
            Cities statesAPI = citiesToAPI.translate(city.get(), Cities.class, false);
            return statesAPI;
        } catch (Exception e) {
            logger.error("Cities fetch error", e);
        }
        throw new QQBusinessException("States could not be retrieved");
    }



    public List<Cities> getAllCities() throws QQBusinessException {
        List<Cities> result = new ArrayList<>();
        Iterable<com.qqs.posvcs.model.Cities> cities = ds.getCityDataService().getAllCities();
        cities.forEach(city -> {
            try {
                result.add(citiesToAPI.translate(city, Cities.class, false));
            } catch (Exception e) {
                logger.error("translation exception");
            }
        });
        return result;
    }

    public List<Cities> getAllCitiesByStateId(Integer stateId) {
        return ds.getCityDataService().findCitiesByStateId(stateId).orElse(Collections.EMPTY_LIST);
    }

    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"name"}));
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, null, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }



}
