package com.qqs.posvcs.rest;


import com.qqs.posvcs.api.billing.PkgCheckList;
import com.qqs.posvcs.api.reports.PackCheckListMaster;
import com.qqs.posvcs.service.PackageCheckListService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.qqs.posvcs.utils.Constants.uploadFileFolder;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/pckList")
public class PackCheckListController {

    @Resource
    private com.qqs.posvcs.service.PackageCheckListService PackageCheckListService;

    @Value("${app.document.upload.location}")
    private String uploadFolder;

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_PKGCHK_WRITE', 'ROLE_ALL_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "pckchklistMaster/save", produces = "application/json")
    public ResponseEntity<PackCheckListMaster> savePackageCheckListMaster(@RequestBody com.qqs.posvcs.api.reports.PackCheckListMaster form) throws QQBusinessException {
        com.qqs.posvcs.api.reports.PackCheckListMaster saved = PackageCheckListService.savePackCheckListMaster(form);
        ResponseEntity<PackCheckListMaster> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_PKGCHK_WRITE', 'ROLE_ALL_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "pckchklist/save", produces = "application/json")
    public ResponseEntity<PkgCheckList> savePackageChkList(@RequestBody PkgCheckList form) throws QQBusinessException {

        PkgCheckList saved = PackageCheckListService.savePackageChkList(form);
        ResponseEntity<PkgCheckList> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_ALL_WRITE','ROLE_PKGCHK_WRITE','ROLE_PKGCHK_READ')")
    @RequestMapping(method = RequestMethod.GET, value = "/pckchklistMaster/byId", produces = "application/json")
    public ResponseEntity<PackCheckListMaster> getPackageCheckListMasterById(@RequestParam Integer id,
                                                                             HttpServletRequest request) throws QQBusinessException {
        PackCheckListMaster ats = PackageCheckListService.getPackageCheckListMasterById(id);
        ResponseEntity<PackCheckListMaster> result = new ResponseEntity(ats, HttpStatus.OK);
        return result;
    }


    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_ALL_WRITE','ROLE_PKGCHK_READ','ROLE_PKGCHK_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "packChckListMaster/form/search", produces = "application/json")
    public ResponseEntity<List<PackCheckListMaster>> searchPackCheckListMaster(@RequestParam Map<String, String> searchParam,
                                                                               @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                                               HttpServletRequest request) throws QQBusinessException {
        List<PackCheckListMaster> formList = PackageCheckListService.searchPackCheckListMaster(searchParam, exactMatch.orElse(false));
        ResponseEntity<List<PackCheckListMaster>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_ALL_WRITE','ROLE_PKGCHK_WRITE','ROLE_PKGCHK_READ')")
    @RequestMapping(method = RequestMethod.GET, value =  "/generatePcl", produces="application/pdf")
    public ResponseEntity<org.springframework.core.io.Resource> generatePackCheckList(@RequestParam Integer pckId, HttpServletRequest request,
                                                                                      HttpServletResponse response) throws QQBusinessException {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        PackageCheckListService.generatePackCheckList(pckId, stream);
        org.springframework.core.io.Resource file = new ByteArrayResource(stream.toByteArray());
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.put(HttpHeaders.CONTENT_DISPOSITION, Collections.singletonList("attachment; filename=filledapp.pdf"));
        httpHeaders.put(HttpHeaders.CONTENT_TYPE, Collections.singletonList("application/pdf"));
        ResponseEntity<org.springframework.core.io.Resource> result = ResponseEntity
                .ok()
                .headers(httpHeaders)
                .body(file);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_ALL_WRITE','ROLE_PKGCHK_WRITE','ROLE_PKGCHK_READ')")
    @RequestMapping(method = RequestMethod.GET, value =  "/downLoadPckFile", produces={"multipart/form-data"})
    public ResponseEntity<org.springframework.core.io.Resource> generateFile(@RequestParam String fileName, String documentType,
                                                                             HttpServletRequest request,
                                                                             HttpServletResponse response) throws QQBusinessException {
        ResponseEntity<org.springframework.core.io.Resource> result = null;
        if ("PkgCheckList".equals(documentType)) { // To Avoid Downloading from other folders
            String fileFolder = uploadFileFolder.get(documentType);
            ApplicationContext appContext =
                    new ClassPathXmlApplicationContext(new String[] {});
            org.springframework.core.io.Resource resource = appContext.getResource("file:" + uploadFolder + fileFolder + '/'  + fileName); // new ClassPathResource("file:" + uploadFolder + fileFolder + '/'  + fileName);
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=img.docx");
            result = ResponseEntity
                    .ok()
                    .headers(httpHeaders)
                    .body(resource);
        }
        return result;

    }

}
