package com.qqs.posvcs.service;

import com.qqs.posvcs.api.Address;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;

import static com.qqs.posvcs.api.translation.ParentEntityType.COMPANY;
import static com.qqs.posvcs.api.translation.ParentEntityType.PLANT;
import static com.qqs.posvcs.service.translate.APITranslator.addressToAPI;
import static com.qqs.posvcs.service.translate.APITranslator.addressToDB;

@Component
public class AddressService {
    Logger logger = LoggerFactory.getLogger(AddressService.class);

    @Resource
    DataService ds;

    public Address saveAddress(Address addressData) throws QQBusinessException {
        Address addressToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        try {
            com.qqs.posvcs.model.Address toSaveAddresse = addressToDB.translate(addressData, com.qqs.posvcs.model.Address.class, true);
            if (toSaveAddresse.getId() > 0) {
                new DateUtils<com.qqs.posvcs.model.Address>().setTimeStamp(toSaveAddresse, com.qqs.posvcs.model.Address.class, true);
                toSaveAddresse.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.posvcs.model.Address>().setTimeStamp(toSaveAddresse, com.qqs.posvcs.model.Address.class, false);
                toSaveAddresse.setCreatedBy(loggedInUser);
            }
            com.qqs.posvcs.model.Address address = ds.getAddressDS().saveAddress(toSaveAddresse);

            addressToApi = addressToAPI.translate(address, Address.class, true);

        } catch (Exception e) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving Address details");
        }
        return addressToApi;

    }

    public Address getAddressById(Integer addressId) throws QQBusinessException {
        try {
            Optional<com.qqs.posvcs.model.Address> address = ds.getAddressDS().getAddressById(addressId);
            if (!address.isPresent()) {
                throw new QQBusinessException("No address found");
            }
            Address addressAPI = addressToAPI.translate(address.get(), Address.class, false);
            return addressAPI;
        } catch (Exception e) {
            logger.error("Address fetch error", e);
        }
        throw new QQBusinessException("Address could not be retrieved");
    }

    public Collection<Address> getAddressByCompany(Integer companyId) throws QQBusinessException {
        return getAddressByParentType(COMPANY.getDbCode(), companyId);
    }

    public Collection<Address> getAddressByPlant(Integer companyId) throws QQBusinessException {
        return getAddressByParentType(PLANT.getDbCode(), companyId);
    }

    public Collection<Address> getAddressByParentType(String parentType, Integer parentId) throws QQBusinessException {
        Optional<List<com.qqs.posvcs.model.Address>> addresses = ds.getAddressDS().findAddressesForParentType(parentType, parentId);
        if (!addresses.isPresent()) {
            throw new QQBusinessException("No addresses found");
        }
        try {
            return addressToAPI.translate(addresses.get(), Address.class, false);
        } catch (Exception e) {
            logger.error("Translation error in  Address", e);
        }
        return null;
    }

    public List<String> addressFormatter(Address address, Map<String, Map<String, com.qqs.posvcs.api.common.Codes>> codesMap) throws QQBusinessException {
        List<String> formattedAddress = new ArrayList<>();
        String LineOne = "";
        String LineTwo = "";
        String LineThree = "";
        String State = "";
        String Country = "";

        LineOne = address.getLineOne();
        LineTwo = address.getLineTwo();
        LineThree = address.getLineThree();

        State = address.getCityName() + ' ' + address.getProvinceName() + ' ' + address.getPostalCd();
        Country = address.getCountryName();
        if (!"".equals(LineOne)) {
            formattedAddress.add(LineOne);
        }
        if (!"".equals(LineTwo)) {
            formattedAddress.add(LineTwo);
        }
        if (!"".equals(LineThree)) {
            formattedAddress.add(LineThree);
        }
        formattedAddress.add(State);
        formattedAddress.add(Country);
        return formattedAddress;
    }


}
