package com.qqs.posvcs.service;

import com.qqs.qqsoft.utils.ApiUtils;

import com.qqs.qqsoft.utils.SecurityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.util.List;

public abstract class PartSubService<D, A> {

    Logger logger = LoggerFactory.getLogger(PartSubService.class);

    SecurityUtils security;

    public PartSubService(SecurityUtils security) {
        this.security = security;
    }

    public List<A> savePartSubsidiary(List<A> subsidiary,
                                      ApiUtils dbTranslator, ApiUtils apiTranslator,
                                      Class<D> dbClass, Class<A> apiClass) {
        List<D> toSave = null;
        List<A> savedAPI = null;
        Integer loggedInUser = security.getLoggedInUser();
        Timestamp currentDate = new Timestamp(System.currentTimeMillis());
        try {
            toSave = dbTranslator.translate(subsidiary, dbClass, true);
            toSave.forEach(part -> {
                this.setAuditHistory(part, loggedInUser, currentDate);
            });
            Iterable<D> saved = saveEntries(toSave);
            savedAPI = apiTranslator.translate(saved, apiClass, false);
        } catch (Exception e) {
            logger.error("Translation error in part sub save ", e);
        }
        return savedAPI;
    }

    protected void setAuditHistory(D part, Integer loggedInUser, Timestamp currentDate){
        // Override in subclass for audit
    }

    protected abstract Iterable<D> saveEntries(List<D> toSave);

}
