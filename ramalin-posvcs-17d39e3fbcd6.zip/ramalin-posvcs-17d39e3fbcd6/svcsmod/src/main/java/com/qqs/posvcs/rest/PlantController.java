package com.qqs.posvcs.rest;

import com.qqs.posvcs.api.Plant;
import com.qqs.posvcs.api.PlantDeliveryTerms;
import com.qqs.posvcs.api.PlantPaymentTerms;
import com.qqs.posvcs.service.PlantService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/plant")
public class PlantController {

    @Resource
    PlantService service;

    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    @RequestMapping(method = RequestMethod.POST, value = "/save", produces = "application/json")
    public ResponseEntity<Plant> saveCompany(@RequestBody com.qqs.posvcs.api.Plant form) throws QQBusinessException {
        com.qqs.posvcs.api.Plant saved = service.savePlant(form);
        ResponseEntity<Plant> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_COMPANY_READ', 'ROLE_ALL_READ','ROLE_COMPANY_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/byId", produces = "application/json")
    public ResponseEntity<Plant> getPlantById(@RequestParam Integer id,
                                                  HttpServletRequest request) throws QQBusinessException {
        Plant plant = service.getPlantById(id);
        ResponseEntity<Plant> result = new ResponseEntity(plant, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_COMPANY_READ', 'ROLE_ALL_READ','ROLE_COMPANY_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/all", produces = "application/json")
    public ResponseEntity<List<Plant>> getAllPlantInfo(HttpServletRequest request) throws QQBusinessException {
        List<Plant> formList = service.getAllPlants();
        ResponseEntity<List<Plant>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_COMPANY_READ', 'ROLE_ALL_READ','ROLE_COMPANY_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/form/search", produces = "application/json")
    public ResponseEntity<List<Plant>> searchPlants(@RequestParam Map<String, String> searchParam,
                                                    @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                    HttpServletRequest request) throws QQBusinessException {
        List<Plant> formList = service.searchPlants(searchParam, exactMatch.orElse(false));
        ResponseEntity<List<Plant>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_COMPANY_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/saveDeliveryTerms", produces = "application/json")
    public ResponseEntity<PlantDeliveryTerms> savePlantDeliveryTerms(@RequestBody com.qqs.posvcs.api.PlantDeliveryTerms form) throws QQBusinessException {
        com.qqs.posvcs.api.PlantDeliveryTerms saved = service.savePlantDeliveryTerms(form);
        ResponseEntity<PlantDeliveryTerms> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    @RequestMapping(method = RequestMethod.POST, value = "/savePaymentTerms", produces = "application/json")
    public ResponseEntity<PlantPaymentTerms> savePlantPaymentTerms(@RequestBody com.qqs.posvcs.api.PlantPaymentTerms form) throws QQBusinessException {
        com.qqs.posvcs.api.PlantPaymentTerms saved = service.savePlantPaymentTerms(form);
        ResponseEntity<PlantPaymentTerms> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

}
