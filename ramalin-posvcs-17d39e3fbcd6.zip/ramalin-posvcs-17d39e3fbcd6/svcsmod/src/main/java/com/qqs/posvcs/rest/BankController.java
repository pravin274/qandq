package com.qqs.posvcs.rest;

import com.qqs.posvcs.api.billing.Bank;
import com.qqs.posvcs.service.BankService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/bank")
public class BankController {

    @Resource
    BankService bankService;

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_BANK_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/save", produces = "application/json")
    public ResponseEntity<Bank> saveBank(@RequestBody Bank form) throws QQBusinessException {
        Bank saved = bankService.saveBank(form);
        ResponseEntity<Bank> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_BANK_READ','ROLE_BANK_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/byId", produces = "application/json")
    public ResponseEntity<Bank> getBankById(@RequestParam Integer id,
                                                  HttpServletRequest request) throws QQBusinessException {
        Bank bank = bankService.getBankById(id);
        ResponseEntity<Bank> result = new ResponseEntity(bank, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_BANK_READ','ROLE_BANK_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/form/search", produces = "application/json")
    public ResponseEntity<List<Bank>> searchBank(@RequestParam Map<String, String> searchParam,
                                                      @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                      HttpServletRequest request) throws QQBusinessException {
        List<Bank> formList = bankService.searchBanks(searchParam, exactMatch.orElse(false));
        ResponseEntity<List<Bank>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }
}
