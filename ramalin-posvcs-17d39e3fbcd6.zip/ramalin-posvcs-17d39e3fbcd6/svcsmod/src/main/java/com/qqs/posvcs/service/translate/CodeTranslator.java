package com.qqs.posvcs.service.translate;

public interface CodeTranslator<T> {
    T translate(String code);
}
