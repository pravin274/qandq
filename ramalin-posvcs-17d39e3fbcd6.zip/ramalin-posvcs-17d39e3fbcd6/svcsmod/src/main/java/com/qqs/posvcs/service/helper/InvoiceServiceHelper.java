package com.qqs.posvcs.service.helper;

import com.google.common.collect.Iterables;
import com.qqs.posvcs.model.*;
import com.qqs.posvcs.service.DataService;
import com.qqs.posvcs.service.POService;
import com.qqs.posvcs.service.startup.ApplicationCodeMap;
import com.qqs.qqsoft.utils.ApiUtils;
import com.qqs.qqsoft.utils.SecurityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;

import static com.qqs.posvcs.service.translate.APITranslator.*;

@Component
public class InvoiceServiceHelper {

    @Resource
    DataService ds;
    @Resource
    private POService poService;

    @Resource
    private ApplicationCodeMap systemCodeMap;
    @Resource
    private SecurityUtils security;

    Logger logger = LoggerFactory.getLogger(InvoiceServiceHelper.class);

    public com.qqs.posvcs.api.billing.Invoice fillAdditionalDetails(Invoice invoice) {
        com.qqs.posvcs.api.billing.Invoice result = null;
        try {
            result = invoiceToAPI.translate(invoice, com.qqs.posvcs.api.billing.Invoice.class, false);
            // List<Integer> addressIds = Arrays.asList(new Integer[]{invoice.getDlvryAddr(), invoice.getReceiptAddr()});
            // Iterable<Address> addresses = ds.getAddressDS().findAddressByIds(addressIds);
            // List<com.qqs.posvcs.api.Address> addressList = addressToAPI.translate(addresses, com.qqs.posvcs.api.Address.class, false);
            // result.setAddressList(addressList);
            Optional<List<Integer>> poIds = ds.getInvoiceDS().getPOIdByInvoiceId(invoice.getId());
            List<com.qqs.posvcs.api.PurchOrder> poList = new ArrayList<>();
            if(poIds.isPresent()) {
                poIds.get().forEach(poId -> {
                        try {
                            poList.add(poService.getPurchaseOrderById(poId));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                });
                    result.setPurchOrderList(poList);
            }

            Optional<Plant> plant = ds.getPlantDS().getPlantById(invoice.getPlantId());
            if (plant.isPresent()) {
                result.setPlant(plantToAPI.translate(plant.get(), com.qqs.posvcs.api.Plant.class, false));
            }
            List<Integer> placeIds = new ArrayList<Integer>(Arrays.asList(new Integer[]{invoice.getPortLoad(), invoice.getPortDischarge(),
                    invoice.getCountryOrigin(), invoice.getCountryOfFinal(), invoice.getSupplyPlace()}));

            if (placeIds.size() > 0) {
                Iterables.removeIf(placeIds, x -> x == null);
                Iterable<Places> places = ds.getPlacesDS().getAllEntityById(placeIds);
                List<com.qqs.posvcs.api.Places> placesList = placesToAPI.translate(places, com.qqs.posvcs.api.Places.class, false);
                result.setPlacesList(placesList);
            }

            //Retrieve lineItems for Invoice
            Iterable<InvoiceLineItem> invoiceLineItems = ds.getInvoiceLineItemDS().getAllInvoiceLineItemByInvoiceId(invoice.getId());
            List<com.qqs.posvcs.api.billing.InvoiceLineItem> invoiceLineItemAPI = invoiceLineToAPI.translate(invoiceLineItems,com.qqs.posvcs.api.billing.InvoiceLineItem.class, false);

            //Retrieve shipped Quantity for all LineItems
            List<Integer> poLineItemIds = new ArrayList<>();
            invoiceLineItems.forEach(item -> {
                poLineItemIds.add(item.getPoLineId());
            });

            invoiceLineItemAPI.forEach(item -> { //setting default value as 0.0 for shippedQty
                item.setShippedQty(0.0);
            });

            Optional<List<Object[]>> shippingAttrList = ds.getPoLineItemDS().getShippingAttr(poLineItemIds);
            if(shippingAttrList.isPresent()) {
                Map<Integer, String> shippingAttrMap = new HashMap<>();
                shippingAttrList.get().forEach(item -> {
                    StringBuffer sb = new StringBuffer();
                    sb.append(item[1].toString()).append('|').append(item[2].toString()).append('|')
                            .append(item[3].toString()).append('|').append(item[4].toString());
                    shippingAttrMap.put(((Integer) item[0]), sb.toString());
                });

                Optional<List<Object[]>> shippedQtyList = ds.getInvoiceLineItemDS().getShippedQtyByPOLineItems(poLineItemIds, invoice.getId());

                if (shippedQtyList.isPresent()) {
                    Map<String, Double> shippedQtyMap = new HashMap<>();
                    shippedQtyList.get().forEach(item -> {
                        StringBuffer sb = new StringBuffer();
                        sb.append(item[0].toString()).append('|').append(item[1].toString()).append('|')
                                .append(item[2].toString()).append('|').append(item[3].toString());
                        shippedQtyMap.put(sb.toString(), (((BigDecimal) item[4]).doubleValue()));
                    });
                    invoiceLineItemAPI.forEach(item -> {
                        if (shippingAttrMap.get(item.getPoLineId()) != null &&
                                shippedQtyMap.get(shippingAttrMap.get(item.getPoLineId())) != null) {
                            item.setShippedQty(shippedQtyMap.get(shippingAttrMap.get(item.getPoLineId())));
                        } else {
                            item.setShippedQty(0.0);
                        }
                    });
                }
            }

            result.setInvoiceLineItems(invoiceLineItemAPI);

            //Retrieve SLIDocuments for Invoice
            Optional<List<SLIDocuments>> sliDocuments = ds.getInvoiceDS().getSLIDocumentsByInvoiceId(invoice.getId());
            if(sliDocuments.isPresent()) {
                List<com.qqs.posvcs.api.billing.SLIDocuments> sliDocumentsAPI = sliDocumentsToAPI.translate(sliDocuments.get(), com.qqs.posvcs.api.billing.SLIDocuments.class, false);
                result.setSliDocumentsList(sliDocumentsAPI);
            }

            //Retrieve InvoiceStatus for Invoice
            Optional<List<InvoiceStatus>> invoiceStatus = ds.getInvoiceDS().getInvoiceStatusByInvoiceId(invoice.getId());
            if(invoiceStatus.isPresent()) {
                List<com.qqs.posvcs.api.billing.InvoiceStatus> InvoiceStatusAPI = InvoiceStatusToAPI.translate(invoiceStatus.get(), com.qqs.posvcs.api.billing.InvoiceStatus.class, false);
                result.setInvoiceStatusList(InvoiceStatusAPI);
            }

            fillPkgDetails(result);

        } catch (Exception e) {
            logger.error("Invoice retrieve error", e);
        }
        return result;
    }


    public void fillPkgDetails(com.qqs.posvcs.api.billing.Invoice invoice) {
        try {
            Optional<List<PkgMaster>> pkgMasters =  ds.getPkgDataService().findPkgByInvoice(invoice.getId());

            if(pkgMasters.isPresent()) {

                List<com.qqs.posvcs.api.billing.PkgMaster> returnVal = convertToAPI(pkgMasters);

                List<com.qqs.posvcs.api.billing.PkgMaster> PkgMasterlines = new ArrayList<>();
                returnVal.forEach(item -> {
                    if (!item.getIsDeleted()) {
                        PkgMasterlines.add(item);
                    }
                });
//                List<com.qqs.posvcs.api.billing.PkgMaster> PkgMasterVal = convertToAPI(PkgMasterlines);

                List<Integer> invoiceLineItemIds = new ArrayList<Integer>();
                Map<Integer, List<com.qqs.posvcs.api.billing.PkgDetail>> pkgDetailMap = new HashMap<>();
                invoice.getInvoiceLineItems().forEach(lineItem -> {
                    invoiceLineItemIds.add(lineItem.getId());
                });
                Optional<List<PkgDetail>> pkgDetails = ds.getPkgDataService().findPkgDetailByInvoiceLineItemIds(invoiceLineItemIds);
                if(pkgDetails.isPresent()) {
                    List<com.qqs.posvcs.api.billing.PkgDetail> pkgDetailAPI = pkgDetailToAPI.translate(pkgDetails.get(), com.qqs.posvcs.api.billing.PkgDetail.class, false);
                    pkgDetailAPI.forEach(item -> {
                        if (pkgDetailMap.get(item.getPkgId()) == null) {
                            pkgDetailMap.put(item.getPkgId(), new ArrayList());
                        }
                        pkgDetailMap.get(item.getPkgId()).add(item);
                    });

                    for (com.qqs.posvcs.api.billing.PkgMaster pkgMaster : PkgMasterlines) {
                        try {
                            pkgMaster.setPkgDetails(pkgDetailMap.get(pkgMaster.getId()));
                            pkgMaster.getPkgDetails().forEach(item -> {
                                item.setPkgNo(pkgMaster.getPkgNo());
                            });
                        } catch (Exception e) {
                            logger.error("Invoice PkgMaster translation error", e);
                        }
                    }
                    invoice.setPkgMasters(PkgMasterlines);
                }
            }
        } catch (Exception e) {
            logger.error("Invoice PkgMaster translation error", e);
        }
    }

    private List<com.qqs.posvcs.api.billing.PkgMaster> convertToAPI(Optional<List<PkgMaster>> pkgMasterList) {
        List<com.qqs.posvcs.api.billing.PkgMaster> result = null;
        if (pkgMasterList.isPresent()) {
            try {
                result = new ApiUtils<PkgMaster, com.qqs.posvcs.api.billing.PkgMaster>().translate(pkgMasterList.get(), com.qqs.posvcs.api.billing.PkgMaster.class, false);
            } catch (Exception e) {
                logger.error("PkgMaster translation error", e);
            }
        }
        return result;
    }

}
