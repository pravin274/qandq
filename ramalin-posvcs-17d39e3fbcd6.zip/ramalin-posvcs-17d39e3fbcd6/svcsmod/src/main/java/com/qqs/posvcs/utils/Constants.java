package com.qqs.posvcs.utils;

import com.google.common.collect.ImmutableMap;

import java.util.*;

public final class Constants {


    private Constants() {
        // restrict instantiation
    }

    public static final int VENDOR_ID = 1;
    public static final String INVOICE_TITLE = "EXPORT INVOICE";
    public static final String DOMESTIC_INVOICE_TITLE = "INVOICE";
    public static final String INVOICE_SUB_TITLE = "( Rule 46 of Invoice rules of CGST/SGST/IGST Rules 2017 )";
    // public static final String PDF_FILE_LOCATION = "src/main/resources/";
    public static final String PDF_SINGLE_PKG = "InvWithSinglePkgListNew.pdf";
    public static final String PDF_MULTI_PKG = "InvWithMultiPkgList.pdf";
    public static final String GERMANY_SINGLE = "germanyInvoice.pdf";
    public static final String DOMESTIC_SINGLE = "domesticInvoice.pdf";
    public static final String TOOL_PDF= "toolInvoice.pdf";
    public static final String PDF_PO_QQ = "QQPoFormat.pdf";

    public static final int GST_RATE = 18;
    public static final String PAYMENT_TERMS_SUFFIX = " Days NET";
    public static final String REPORT_TYPE_CUSTOMER = "CUST";
    public static final String REPORT_TYPE_DOMAIN = "DOM";
    public static final String REPORT_TYPE_GEO = "GEO";
    public static final String REPORT_TYPE_PLANT = "PLT";
    public static final String GERMANY = "GERMANY";
    public static final String INDIA = "INDIA";

    public static final String TOOL = "TOOL";
    public static final String REX = "REX DECLARATION";

    public static final String TOOLINVOICE = "TOOL";
    public static final String NONTOOLINVOICE = "NONTOOL";

    // LineItem Current status
    public static final String CS_TYPEPO = "PO";
    public static final String CS_TYPEINVOICE = "INVOICE";
    public static final String CS_ACTIVE = "ACTIVE";
    public static final String CS_INACTIVE = "INACTIVE";

    //
    public static final Integer USD_VAL = 71;
    public static final Integer EURO_VAL = 81;



    public static final List<String> NA_DOM_INV = new ArrayList<>(Arrays.asList("IGRC", "DDB", "SBR", "FIRC", "EDPMS", "MEIS"));



    public static final Map<String, String> uploadFileFolder = new HashMap<>();
    static {
        uploadFileFolder.put("standard", "standards");
        uploadFileFolder.put("partDrawing", "partDrawing");
        uploadFileFolder.put("atsContentSheet", "atsContentSheet");
        uploadFileFolder.put("PkgCheckList", "PkgCheckList");
        uploadFileFolder.put("purchaseOrder", "purchaseOrder");
        uploadFileFolder.put("awbInvoice", "awbInvoice");
    }

    public static final String PO_STATUS_REVISIED= "REVISED";
    public static final String PO_STATUS_ACTIVE = "ACTIVE";

    public static final String PDF_ATS = "ATSFORM.pdf";
    public static final String PDF_PCKCHLIST = "PCKLISTPDF.pdf";


    public static final String PDF_NDA = "NdaForm.pdf"; // want to add file

    public static final String HARDNESS_SPEC_UNIT = "BHN";

    public static final Map<String, String> INVOICE_STATUS_COMPLETE = new HashMap<>();
    static {
        INVOICE_STATUS_COMPLETE.put("AWBBLATTR2", "Yes");
        INVOICE_STATUS_COMPLETE.put("INVCUATTR2", "Sent");
        INVOICE_STATUS_COMPLETE.put("PRATTR3", "Received");
        INVOICE_STATUS_COMPLETE.put("IGRCATTR3", "Received");
        INVOICE_STATUS_COMPLETE.put("DDBATTR3", "Received");
        INVOICE_STATUS_COMPLETE.put("SBRATTR4", "Yes");
        INVOICE_STATUS_COMPLETE.put("FIRCATTR3", "Received");
        INVOICE_STATUS_COMPLETE.put("EDPMSATTR1", "Updated");
        INVOICE_STATUS_COMPLETE.put("MEISATTR2", "Received");
    }
    public static final String INV_STATUS_DDB = "DDB";
    public static final String INV_STATUS_IGRC = "IGRC";

    public static final Map<String, String> INV_SERVICE_MAP = ImmutableMap.of("byId", "invPD/search/byProductIdType?",
            "save", "invPD/save");

    public static final Map<String, String> INV_PO_SERVICE_MAP = ImmutableMap.of("byId", "supplierpurchase/search/byId?",
            "save", "invPD/save");

    public static final Map<String, String> PRODUCT_TYPE_MAP = ImmutableMap.of("part", "part", "tool", "tool",
            "inserts", "inserts", "holder", "holder", "product", "product");

    public static final String SCHEDULE_URL = "/schedule/bySchFromDate?schFromDate=";

    public static final String JOB_TYPE_BO = "BO";

}
