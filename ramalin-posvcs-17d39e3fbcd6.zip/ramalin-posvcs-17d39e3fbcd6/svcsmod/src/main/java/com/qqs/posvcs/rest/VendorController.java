package com.qqs.posvcs.rest;

import com.qqs.posvcs.api.Vendor;
import com.qqs.posvcs.service.VendorService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/vendor")
public class VendorController {

    @Resource
    VendorService vendorService;

    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    @RequestMapping(method = RequestMethod.POST, value = "/save", produces = "application/json")
    public ResponseEntity<Vendor> saveVendor(@RequestBody Vendor form) throws QQBusinessException {
        Vendor saved = vendorService.saveVendor(form);
        ResponseEntity<Vendor> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/byId", produces = "application/json")
    public ResponseEntity<Vendor> getVendorById(@RequestParam Integer id,
                                                  HttpServletRequest request) throws QQBusinessException {
        Vendor vendor = vendorService.getVendorById(id);
        ResponseEntity<Vendor> result = new ResponseEntity(vendor, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/form/search", produces = "application/json")
    public ResponseEntity<List<Vendor>> searchVendor(@RequestParam Map<String, String> searchParam,
                                                      @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                      HttpServletRequest request) throws QQBusinessException {
        List<Vendor> formList = vendorService.searchVendor(searchParam, exactMatch.orElse(false));
        ResponseEntity<List<Vendor>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }
}
