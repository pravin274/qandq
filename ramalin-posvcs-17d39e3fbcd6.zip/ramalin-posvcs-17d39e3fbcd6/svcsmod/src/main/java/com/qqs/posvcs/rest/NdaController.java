package com.qqs.posvcs.rest;

import com.qqs.posvcs.api.reports.NdaForm;
import com.qqs.posvcs.service.NdaService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/nda")
public class NdaController {

    @Resource
    private NdaService ndaService;

    @Value("${app.document.upload.location}")
    private String uploadFolder;

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_NDA_WRITE', 'ROLE_ALL_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "nda/save", produces = "application/json")
    public ResponseEntity<NdaForm> saveNda(@RequestBody com.qqs.posvcs.api.reports.NdaForm form) throws QQBusinessException {
        com.qqs.posvcs.api.reports.NdaForm saved = ndaService.saveNdaForm(form);
        ResponseEntity<NdaForm> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }


    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_ALL_WRITE','ROLE_NDA_WRITE','ROLE_NDA_READ')")
    @RequestMapping(method = RequestMethod.GET, value = "/nda/Search/byId", produces = "application/json")
    public ResponseEntity<NdaForm> getNdaById(@RequestParam Integer id,
                                                    HttpServletRequest request) throws QQBusinessException {
        NdaForm nda = ndaService.getNdaById(id);
        ResponseEntity<NdaForm> result = new ResponseEntity(nda, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_ALL_WRITE','ROLE_NDA_WRITE','ROLE_NDA_READ')")
    @RequestMapping(method = RequestMethod.GET, value = "nda/form/search", produces = "application/json")
    public ResponseEntity<List<NdaForm>> searchNdaForm(@RequestParam Map<String, String> searchParam,
                                                       @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                       HttpServletRequest request) throws QQBusinessException {
        List<NdaForm> formList = ndaService.searchNdaForm(searchParam, exactMatch.orElse(false));
        ResponseEntity<List<NdaForm>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_ALL_WRITE','ROLE_NDA_WRITE','ROLE_NDA_READ')")
    @RequestMapping(method = RequestMethod.GET, value =  "/generateNda", produces="application/pdf")
    public ResponseEntity<org.springframework.core.io.Resource> generatenNdaForm(@RequestParam Integer ndaId, HttpServletRequest request,
                                                                                 HttpServletResponse response) throws QQBusinessException {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        ndaService.generatenNdaForm(ndaId, stream);

        org.springframework.core.io.Resource file = new ByteArrayResource(stream.toByteArray());
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.put(HttpHeaders.CONTENT_DISPOSITION, Collections.singletonList("attachment; filename=filledapp.pdf"));
        httpHeaders.put(HttpHeaders.CONTENT_TYPE, Collections.singletonList("application/pdf"));
        ResponseEntity<org.springframework.core.io.Resource> result = ResponseEntity
                .ok()
                .headers(httpHeaders)
                .body(file);
        return result;
    }

}
