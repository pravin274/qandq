package com.qqs.posvcs.service;

import com.qqs.posvcs.api.billing.Bank;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import com.qqs.qqsoft.QQBusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;

import static com.qqs.posvcs.service.translate.APITranslator.*;

@Component
public class BankService {

    Logger logger = LoggerFactory.getLogger(BankService.class);

    @Resource
    BankDataService bankDataService;

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    @Resource
    DataService ds;

    public Bank getBankById(Integer id) throws QQBusinessException {
        try {
            Optional<com.qqs.posvcs.model.Bank> bank = bankDataService.getEntityById(id);
            if (bank.isPresent()) {
                return fillBankDetails(bank.get());
            }
        } catch (Exception e) {
            logger.error("Error fetching BankDetails", e);
        }
        throw new QQBusinessException("No BankDetails information found");
    }

    public List<Bank> searchBanks(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.posvcs.model.Bank>> bank = bankDataService.searchEntities(conditions);
        if (!bank.isPresent())
            throw new QQBusinessException("No Bank found for criteria");
        List<Bank> result = null;
        try {
            result = bankToAPI.translate(bank.get(), Bank.class, false);
        } catch (Exception e) {
            logger.error("Error getting Banks", e);
        }
        return result;
    }

    public com.qqs.posvcs.api.billing.Bank fillBankDetails(com.qqs.posvcs.model.Bank bank) {
        com.qqs.posvcs.api.billing.Bank bankDataToApi = null;
        try {
            bankDataToApi = bankToAPI.translate(bank, com.qqs.posvcs.api.billing.Bank.class, false);
        } catch (Exception e) {
            logger.error("Bank retrieve error", e);
        }
        return bankDataToApi;
    }


    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"bankName", "accountNumber", "ifscCode", "swiftcode", "adCode"}));
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, null, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }

    public Bank saveBank(Bank bankData) throws QQBusinessException {
        Bank bankToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();

        try {
            com.qqs.posvcs.model.Bank toSaveBank =  bankToDB.translate(bankData, com.qqs.posvcs.model.Bank.class, true);
            if(toSaveBank.getId() > 0) {
                new DateUtils<com.qqs.posvcs.model.Bank>().setTimeStamp(toSaveBank, com.qqs.posvcs.model.Bank.class, true);
                toSaveBank.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.posvcs.model.Bank>().setTimeStamp(toSaveBank, com.qqs.posvcs.model.Bank.class, false);
                toSaveBank.setCreatedBy(loggedInUser);
            }
            com.qqs.posvcs.model.Bank bank = bankDataService.saveBank(toSaveBank);

            bankToApi = bankToAPI.translate(bank , Bank.class, true);

        } catch (Exception e ) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving Bank");
        }
        return bankToApi;
    }
}
