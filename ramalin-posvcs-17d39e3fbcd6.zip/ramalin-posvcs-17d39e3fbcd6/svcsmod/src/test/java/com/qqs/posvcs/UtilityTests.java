package com.qqs.posvcs;

import com.qqs.qqsoft.utils.CurrencyUtils;
import org.junit.Test;

public class UtilityTests {

    @Test
    public void testCurrencyToWords(){
        String value = CurrencyUtils.convertToWordCurrency(177035, "");
        System.out.println(value);
    }
}
