package com.qqs.posvcs;

import com.qqs.posvcs.model.PurchOrder;
import com.qqs.qqsoft.utils.ApiUtils;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.pdf.PDFCreateService;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

public class TestDateUtils {
    @Test
    public void testTimeStamp() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        DateUtils<PurchOrder> dateUtils = new DateUtils<>();
        PurchOrder po = new PurchOrder();
        dateUtils.setTimeStamp(po, PurchOrder.class);
        System.out.println(po.getModifiedDt() + "   " + po.getCreatedDt());
    }

    @Test
    public void testCopyObject() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        PurchOrder po = new PurchOrder();
        po.setDvryTermsId(1);
        DateUtils<PurchOrder> dateUtils = new DateUtils<>();
        dateUtils.setTimeStamp(po, PurchOrder.class);
        PurchOrder poCopy = new ApiUtils<PurchOrder, PurchOrder>().translate(po, PurchOrder.class, false);
        System.out.println(po);
        System.out.println(poCopy);
        Assert.assertEquals(po.getDvryTermsId(), poCopy.getDvryTermsId());
        Assert.assertNull(poCopy.getCreatedDt());
        Assert.assertNull(poCopy.getModifiedDt());
    }

    @Test
    public void testCreatePDF(){
        PDFCreateService service = new PDFCreateService();
        Map<String, String> parameters = new HashMap<>(5);
        parameters.put("FixedRateyrs", "random");
        parameters.put("AmortizationYrs", "random");
        parameters = getData();
        try {
            service.fillFormLocal(parameters);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Map<String, String> getData(){

        Map<String, String> parameters = new HashMap<>(15);
        parameters.put("name.officer","Rama Sudalayandi" );
        parameters.put("number.officer","4332" );
        parameters.put("phone.applicant","111111111" );
        parameters.put("phone.officer","8569245643" );
        parameters.put("branchnumber","ST001" );
        parameters.put("name.store","TD Mt. Laurel" );
        parameters.put("Reftypecheckbox","true" );
        parameters.put("HQ.checkbox","1" );

        parameters.put("genexpensecheckbox","true" );
        parameters.put("startupcheckbox","true" );
        parameters.put("workcapcheckbox","true" );
        parameters.put("otherchkbox","true" );
        parameters.put("modificationofexistingcheckbox","true" );
        parameters.put("businessimprovecheckbox","true" );
        parameters.put("reficheckbox","true" );
        parameters.put("workingcapitaldesc","Working Capital" );
        parameters.put("businesspurposeotherdesc","Other desc" );

        parameters.put("purchasebusinesscheckbox","true" );
        parameters.put("purchaserealestatecheckbox","true" );
        parameters.put("vehiclecheckbox","true" );
        parameters.put("modificationcheckbox","true" );

        parameters.put("purchaseprice","500000" );
        parameters.put("downpayment","50000" );
        parameters.put("purchasevehicledesc","Purchase Vehicle" );
        parameters.put("purchequipdesc","Equipment" );
        parameters.put("accountnumber.existingbankloan","L23454" );
        parameters.put("loanchange.request","No request" );

        parameters.put("LOCtypecheckbox","true" );
        parameters.put("LOC1typecheckbox","true" );
        parameters.put("LOC2typecheckbox","true" );

        parameters.put("cmmlremtgcheckbox","true" );
        parameters.put("FixedRateyrs","20" );
        parameters.put("AmortizationYrs","20" );
        parameters.put("amount.commlREmortgage","55000" );

        parameters.put("expressleasecheckbox","true" );
        parameters.put("ExpressLeaseYearList","4" );
        parameters.put("amountexpresslease","20000" );

        parameters.put("termloancheckbox","true" );
        parameters.put("TermLoanYearList","5" );
        parameters.put("amounttermloan","20000" );

        parameters.put("timenotecheckbox","true" );
        parameters.put("amounttimenote","40000" );

        parameters.put("LOCcheckbox","true" );
        parameters.put("amountLOC","33000" );
        parameters.put("letterofcreditcheckbox","true" );
        parameters.put("amountletterofcredit","56000" );
        parameters.put("achcheckbox","true" );
        parameters.put("amount.ACHdebit","200" );
        parameters.put("amount.ACHcredit","300" );
        parameters.put("pftcheckbox","true" );
        parameters.put("PFTYearList","40000" );
        parameters.put("amount.PFT","2000" );

        parameters.put("name.applicant","Rama Sudalayandi" );
        parameters.put("phone.business","8567348888" );
        parameters.put("phone.applicant","8567347777" );

        parameters.put("accountnumberauto","TD1234" );
        parameters.put("businessname","Temp Corporation" );
        parameters.put("primarycontactname","Gopinath Vendarasi" );
        parameters.put("dbaname","Temp LLC" );
        parameters.put("emailaddress","temp@gmail.com" );
        parameters.put("taxid","23-456765" );
        parameters.put("phone.business","8568457777" );
        parameters.put("address.street","23 Church Road" );
        parameters.put("owncheckbox","true" );
        parameters.put("city.legal","Maple Shade" );
        parameters.put("state.legal","NJ" );
        parameters.put("zip.legal","08057" );
        parameters.put("address.mailing","24 Church" );
        parameters.put("city.mailing","Mt Laurel" );
        parameters.put("state.mailing","NJ" );
        parameters.put("zip.mailing","08054" );


        parameters.put("businesstypecheckbox","4" );
        parameters.put("businesstypeotherdesc","Testing description" );
        parameters.put("natureofbusiness","None" );
        parameters.put("businessnaturecheckbox","5" );
        parameters.put("businessnatureotherdesc","true" );
        parameters.put("Month.Start","07" );
        parameters.put("Year.Start","17" );
        parameters.put("state.incorporation","NJ" );
        parameters.put("BusinessNetIncome","200000" );
        parameters.put("TDBusCheckingTotalBalance","10000" );
        parameters.put("CheckingBalanceTransfer","650000" );
        parameters.put("CompanyGrossAnnualRevenue","300000" );
        parameters.put("tax.datemonth","08" );
        parameters.put("tax.dateday","31" );
        parameters.put("tax.dateyear","2017" );
        parameters.put("employees.after","Testing" );
        parameters.put("listofaffiliatedcompanies","None so far" );

        return parameters;
    }
}
