package com.qqs.qqsvcs.api.lists;

import java.util.Arrays;
import java.util.List;

public enum ProcessList implements ListItem {
    TURN("Turning", ""),
    CAST("Casting", "");

    private String description;
    private String otherInfo;

    ProcessList(String description, String otherInfo) {
        this.description = description;
        this.otherInfo = otherInfo;
    }

    public String getDescription() {
        return description;
    }

    public String getOtherInfo() {
        return otherInfo;
    }

    public List<ListItem> getValues() {
        List<ListItem> result = Arrays.asList(values());
        return result;
    }

    public String getName() {
        return name();
    }
}
