package com.qqs.posvcs.api.billing;

import com.qqs.posvcs.api.Address;
import com.qqs.posvcs.api.Places;
import com.qqs.posvcs.api.Plant;
import com.qqs.posvcs.api.PurchOrder;

import java.sql.Timestamp;
import java.util.List;

public class Invoice {
    private int id;
    private String serialNo;
    private int plantId;
    private Timestamp invDate;
    private String transport;
    private String invoiceType;
    private Timestamp supplyTime;
    private Integer supplyPlace;
    private String preCarriage;
    private String placeReceipt;
    private String vesselNo;
    private Integer portLoad;
    private Integer portDischarge;
    private String finalDest;
    private Integer countryOrigin;
    private Integer countryOfFinal;
    private String splInstruction;
    private String scheme;
    private String secondSplInstruction;
    private String sliInstruction;
    private String declaration;
    private String paymentDeclaration;


    private String paymentTermsCode;
    private String paymentTermsText;
    private String shippingThrough;
    private int bankId;
    private Integer signatory;
    private Double currConvRs;
    private String undertakingLUT;
    private List<InvoiceLineItem> invoiceLineItems;
    private List<PkgMaster> pkgMasters;
    private List<PkgDetail> pkgDetails;
    private List<SLIDocuments> sliDocumentsList;
    private String invoiceStatus;
    private List<InvoiceStatus> invoiceStatusList;
    private Plant plant;
    private List<PurchOrder> purchOrderList;
    private List<Address> addressList;
    private List<Places> placesList;
    private String splDeclaration;
    private Double igst;
    private Double cgst;
    private Double sgst;
    private String awbFileName;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public int getPlantId() {
        return plantId;
    }

    public void setPlantId(int plantId) {
        this.plantId = plantId;
    }

    public String getInvoiceType() {
        return invoiceType;
    }

    public void setInvoiceType(String invoiceType) {
        this.invoiceType = invoiceType;
    }

    public Timestamp getInvDate() {
        return invDate;
    }

    public void setInvDate(Timestamp invDate) {
        this.invDate = invDate;
    }

    public String getTransport() {
        return transport;
    }

    public void setTransport(String transport) {
        this.transport = transport;
    }

    public Timestamp getSupplyTime() {
        return supplyTime;
    }

    public void setSupplyTime(Timestamp supplyTime) {
        this.supplyTime = supplyTime;
    }

    public Integer getSupplyPlace() {
        return supplyPlace;
    }

    public void setSupplyPlace(Integer supplyPlace) {
        this.supplyPlace = supplyPlace;
    }

    public String getPreCarriage() {
        return preCarriage;
    }

    public void setPreCarriage(String preCarriage) {
        this.preCarriage = preCarriage;
    }

    public String getPlaceReceipt() {
        return placeReceipt;
    }

    public void setPlaceReceipt(String placeReceipt) {
        this.placeReceipt = placeReceipt;
    }

    public String getVesselNo() {
        return vesselNo;
    }

    public void setVesselNo(String vesselNo) {
        this.vesselNo = vesselNo;
    }

    public String getSecondSplInstruction() {
        return secondSplInstruction;
    }

    public void setSecondSplInstruction(String secondSplInstruction) {
        this.secondSplInstruction = secondSplInstruction;
    }

    public String getSliInstruction() {
        return sliInstruction;
    }

    public void setSliInstruction(String sliInstruction) {
        this.sliInstruction = sliInstruction;
    }

    public Integer getPortLoad() {
        return portLoad;
    }

    public void setPortLoad(Integer portLoad) {
        this.portLoad = portLoad;
    }

    public Integer getPortDischarge() {
        return portDischarge;
    }

    public void setPortDischarge(Integer portDischarge) {
        this.portDischarge = portDischarge;
    }

    public String getFinalDest() {
        return finalDest;
    }

    public void setFinalDest(String finalDest) {
        this.finalDest = finalDest;
    }

    public Integer getCountryOrigin() {
        return countryOrigin;
    }

    public void setCountryOrigin(Integer countryOrigin) {
        this.countryOrigin = countryOrigin;
    }
    public Integer getCountryOfFinal() {
        return countryOfFinal;
    }

    public void setCountryOfFinal(Integer countryOfFinal) {
        this.countryOfFinal = countryOfFinal;
    }

    public String getSplInstruction() {
        return splInstruction;
    }

    public void setSplInstruction(String splInstruction) {
        this.splInstruction = splInstruction;
    }

    public String getScheme() {
        return scheme;
    }

    public void setScheme(String scheme) {
        this.scheme = scheme;
    }

    public String getDeclaration() {
        return declaration;
    }

    public void setDeclaration(String declaration) {
        this.declaration = declaration;
    }

    public String getPaymentDeclaration() {
        return paymentDeclaration;
    }

    public void setPaymentDeclaration(String paymentDeclaration) {
        this.paymentDeclaration = paymentDeclaration;
    }


    public String getPaymentTermsCode() {
        return paymentTermsCode;
    }

    public void setPaymentTermsCode(String paymentTermsCode) {
        this.paymentTermsCode = paymentTermsCode;
    }

    public String getPaymentTermsText() {
        return paymentTermsText;
    }

    public void setPaymentTermsText(String paymentTermsText) {
        this.paymentTermsText = paymentTermsText;
    }

    public int getBankId() {
        return bankId;
    }

    public void setBankId(int bankId) {
        this.bankId = bankId;
    }

    public Integer getSignatory() {
        return signatory;
    }

    public void setSignatory(Integer signatory) {
        this.signatory = signatory;
    }

    public Double getCurrConvRs() { return currConvRs; }

    public void setCurrConvRs(Double currConvRs) { this.currConvRs = currConvRs; }

    public String getUndertakingLUT() { return undertakingLUT; }

    public void setUndertakingLUT(String undertakingLUT) { this.undertakingLUT = undertakingLUT; }

    public List<InvoiceLineItem> getInvoiceLineItems() { return invoiceLineItems; }

    public void setInvoiceLineItems(List<InvoiceLineItem> invoiceLineItems) { this.invoiceLineItems = invoiceLineItems; }

    public List<PkgMaster> getPkgMasters() {
        return pkgMasters;
    }

    public void setPkgMasters(List<PkgMaster> pkgMasters) {
        this.pkgMasters = pkgMasters;
    }


    public List<PkgDetail> getPkgDetails() {
        return pkgDetails;
    }

    public void setPkgDetails(List<PkgDetail> pkgDetails) {
        this.pkgDetails = pkgDetails;
    }

    public List<SLIDocuments> getSliDocumentsList() { return sliDocumentsList; }

    public void setSliDocumentsList(List<SLIDocuments> sliDocumentsList) { this.sliDocumentsList = sliDocumentsList; }

    public String getInvoiceStatus() {
        return invoiceStatus;
    }

    public void setInvoiceStatus(String invoiceStatus) {
        this.invoiceStatus = invoiceStatus;
    }

    public List<InvoiceStatus> getInvoiceStatusList() {
        return invoiceStatusList;
    }

    public void setInvoiceStatusList(List<InvoiceStatus> invoiceStatusList) {
        this.invoiceStatusList = invoiceStatusList;
    }

    public String getShippingThrough() {
        return shippingThrough;
    }

    public void setShippingThrough(String shippingThrough) {
        this.shippingThrough = shippingThrough;
    }

    public Plant getPlant() {
        return plant;
    }

    public void setPlant(Plant plant) {
        this.plant = plant;
    }

    public List<PurchOrder> getPurchOrderList() {
        return purchOrderList;
    }

    public void setPurchOrderList(List<PurchOrder> purchOrderList) {
        this.purchOrderList = purchOrderList;
    }

    public List<Address> getAddressList() {
        return addressList;
    }

    public void setAddressList(List<Address> addressList) {
        this.addressList = addressList;
    }

    public List<Places> getPlacesList() {
        return placesList;
    }

    public void setPlacesList(List<Places> placesList) {
        this.placesList = placesList;
    }

    public String getSplDeclaration() {
        return splDeclaration;
    }

    public void setSplDeclaration(String splDeclaration) {
        this.splDeclaration = splDeclaration;
    }

    public Double getIgst() {
        return igst;
    }

    public void setIgst(Double igst) {
        this.igst = igst;
    }

    public Double getCgst() {
        return cgst;
    }

    public void setCgst(Double cgst) {
        this.cgst = cgst;
    }

    public Double getSgst() {
        return sgst;
    }

    public void setSgst(Double sgst) {
        this.sgst = sgst;
    }

    public String getAwbFileName() {
        return awbFileName;
    }

    public void setAwbFileName(String awbFileName) {
        this.awbFileName = awbFileName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Invoice invoice = (Invoice) o;

        if (id != invoice.id) return false;
        if (plantId != invoice.plantId) return false;
        if (serialNo != null ? !serialNo.equals(invoice.serialNo) : invoice.serialNo != null) return false;
        if (invDate != null ? !invDate.equals(invoice.invDate) : invoice.invDate != null) return false;
        if (transport != null ? !transport.equals(invoice.transport) : invoice.transport != null) return false;
        if (invoiceType != null ? !invoiceType.equals(invoice.invoiceType) : invoice.invoiceType != null) return false;

        if (supplyTime != null ? !supplyTime.equals(invoice.supplyTime) : invoice.supplyTime != null) return false;
        if (supplyPlace != null ? !supplyPlace.equals(invoice.supplyPlace) : invoice.supplyPlace != null) return false;
        if (preCarriage != null ? !preCarriage.equals(invoice.preCarriage) : invoice.preCarriage != null) return false;
        if (placeReceipt != null ? !placeReceipt.equals(invoice.placeReceipt) : invoice.placeReceipt != null)
            return false;
        if (vesselNo != null ? !vesselNo.equals(invoice.vesselNo) : invoice.vesselNo != null) return false;
        if (portLoad != null ? !portLoad.equals(invoice.portLoad) : invoice.portLoad != null) return false;
        if (shippingThrough != null ? !shippingThrough.equals(invoice.shippingThrough) : invoice.shippingThrough != null) return false;
        if (portDischarge != null ? !portDischarge.equals(invoice.portDischarge) : invoice.portDischarge != null)
            return false;
        if (finalDest != null ? !finalDest.equals(invoice.finalDest) : invoice.finalDest != null) return false;
        if (countryOrigin != null ? !countryOrigin.equals(invoice.countryOrigin) : invoice.countryOrigin != null)
            return false;
        if (countryOfFinal != null ? !countryOfFinal.equals(invoice.countryOfFinal) : invoice.countryOfFinal != null)
            return false;
        if (splInstruction != null ? !splInstruction.equals(invoice.splInstruction) : invoice.splInstruction != null)
            return false;
        if (scheme != null ? !scheme.equals(invoice.scheme) : invoice.scheme != null)
            return false;
        if (splDeclaration != null ? !splDeclaration.equals(invoice.splDeclaration) : invoice.splDeclaration != null) return false;
        if (declaration != null ? !declaration.equals(invoice.declaration) : invoice.declaration != null) return false;
        if (paymentDeclaration != null ? !paymentDeclaration.equals(invoice.paymentDeclaration) : invoice.paymentDeclaration != null) return false;
        if (paymentTermsCode != null ? !paymentTermsCode.equals(invoice.paymentTermsCode) : invoice.paymentTermsCode != null) return false;
        if (paymentTermsText != null ? !paymentTermsText.equals(invoice.paymentTermsText) : invoice.paymentTermsText != null) return false;
        if (secondSplInstruction != null ? !secondSplInstruction.equals(invoice.secondSplInstruction) : invoice.secondSplInstruction != null) return false;
        if (sliInstruction != null ? !sliInstruction.equals(invoice.sliInstruction) : invoice.sliInstruction != null) return false;
        if (bankId != invoice.bankId) return false;
        if (signatory != null ? !signatory.equals(invoice.signatory) : invoice.signatory != null) return false;
        if (currConvRs != null ? !currConvRs.equals(invoice.currConvRs) : invoice.currConvRs != null) return false;
        if (undertakingLUT != null ? !undertakingLUT.equals(invoice.undertakingLUT) : invoice.undertakingLUT != null) return false;
        if (invoiceLineItems != null ? !invoiceLineItems.equals(invoice.invoiceLineItems) : invoice.invoiceLineItems != null) return false;
        if (pkgMasters != null ? !pkgMasters.equals(invoice.pkgMasters) : invoice.pkgMasters != null) return false;
        if (sliDocumentsList != null ? !sliDocumentsList.equals(invoice.sliDocumentsList) : invoice.sliDocumentsList != null) return false;
        if (invoiceStatus != null ? !invoiceStatus.equals(invoice.invoiceStatus) : invoice.invoiceStatus != null) return false;
        if (igst != invoice.igst) return false;
        if (cgst != invoice.cgst) return false;
        if (sgst != invoice.sgst) return false;
        if (awbFileName != null ? !awbFileName.equals(invoice.awbFileName) : invoice.awbFileName != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (serialNo != null ? serialNo.hashCode() : 0);
        result = 31 * result + plantId;
        result = 31 * result + (invDate != null ? invDate.hashCode() : 0);
        result = 31 * result + (transport != null ? transport.hashCode() : 0);
        result = 31 * result + (invoiceType != null ? invoiceType.hashCode() : 0);
        result = 31 * result + (supplyTime != null ? supplyTime.hashCode() : 0);
        result = 31 * result + (supplyPlace != null ? supplyPlace.hashCode() : 0);
        result = 31 * result + (preCarriage != null ? preCarriage.hashCode() : 0);
        result = 31 * result + (placeReceipt != null ? placeReceipt.hashCode() : 0);
        result = 31 * result + (vesselNo != null ? vesselNo.hashCode() : 0);
        result = 31 * result + (portLoad != null ? portLoad.hashCode() : 0);
        result = 31 * result + (portDischarge != null ? portDischarge.hashCode() : 0);
        result = 31 * result + (shippingThrough != null ? shippingThrough.hashCode() : 0);
        result = 31 * result + (finalDest != null ? finalDest.hashCode() : 0);
        result = 31 * result + (countryOrigin != null ? countryOrigin.hashCode() : 0);
        result = 31 * result + (countryOfFinal != null ? countryOfFinal.hashCode() : 0);
        result = 31 * result + (splInstruction != null ? splInstruction.hashCode() : 0);
        result = 31 * result + (scheme != null ? scheme.hashCode() : 0);
        result = 31 * result + (declaration != null ? declaration.hashCode() : 0);
        result = 31 * result + (paymentDeclaration != null ? paymentDeclaration.hashCode() : 0);
        result = 31 * result + (paymentTermsCode != null ? paymentTermsCode.hashCode() : 0);
        result = 31 * result + (paymentTermsText != null ? paymentTermsText.hashCode() : 0);
        result = 31 * result + (secondSplInstruction != null ? secondSplInstruction.hashCode() : 0);
        result = 31 * result + (sliInstruction != null ? sliInstruction.hashCode() : 0);
        result = 31 * result + (splDeclaration != null ? splDeclaration.hashCode() : 0);
        result = 31 * result + bankId;
        result = 31 * result + (signatory != null ? signatory.hashCode() : 0);
        result = 31 * result + (currConvRs != null ? currConvRs.hashCode() : 0);
        result = 31 * result + (undertakingLUT != null ? undertakingLUT.hashCode() : 0);
        result = 31 * result + (invoiceLineItems != null ? invoiceLineItems.hashCode() : 0);
        result = 31 * result + (pkgMasters != null ? pkgMasters.hashCode() : 0);
        result = 31 * result + (sliDocumentsList != null ? sliDocumentsList.hashCode() : 0);
        result = 31 * result + (invoiceStatus!= null ? invoiceStatus.hashCode() : 0);
        result = 31 * result + (igst != null ? igst.hashCode() : 0);
        result = 31 * result + (cgst != null ? cgst.hashCode() : 0);
        result = 31 * result + (sgst != null ? sgst.hashCode() : 0);
        result = 31 * result + (awbFileName != null ? awbFileName.hashCode() : 0);


        return result;
    }
}
