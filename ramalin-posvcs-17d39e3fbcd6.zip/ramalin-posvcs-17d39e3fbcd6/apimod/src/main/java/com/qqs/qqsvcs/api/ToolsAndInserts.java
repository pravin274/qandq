package com.qqs.qqsvcs.api;

public class ToolsAndInserts {
    private Integer toolLayoutDetailId;
    private String toolName;
    private String insertName;

    public Integer getToolLayoutDetailId() {
        return toolLayoutDetailId;
    }

    public void setToolLayoutDetailId(Integer toolLayoutDetailId) {
        this.toolLayoutDetailId = toolLayoutDetailId;
    }

    public String getToolName() {
        return toolName;
    }

    public void setToolName(String toolName) {
        this.toolName = toolName;
    }

    public String getInsertName() {
        return insertName;
    }

    public void setInsertName(String insertName) {
        this.insertName = insertName;
    }


}
