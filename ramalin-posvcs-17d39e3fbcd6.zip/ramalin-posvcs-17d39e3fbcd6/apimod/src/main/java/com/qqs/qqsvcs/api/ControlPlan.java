package com.qqs.qqsvcs.api;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Set;


public class ControlPlan {

    private int id;
    private Integer partId;
    private Integer customerId;
    private String controlPlanCategory;
    private String controlPlanNo;
    private Date revisionDate;
    private String revisionNumber;
    private Date originDate;
    private Integer preparedBy;
    private Date preparedDate;
    private Integer approvedBy;
    private Date approvedDate;
    private List<Process> process;
    private Set<ControlPlanItem> controlPlanItems;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getPartId() {
        return partId;
    }

    public void setPartId(Integer partId) {
        this.partId = partId;
    }


    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public String getControlPlanCategory() {
        return controlPlanCategory;
    }

    public void setControlPlanCategory(String controlPlanCategory) {
        this.controlPlanCategory = controlPlanCategory;
    }

    public String getControlPlanNo() {
        return controlPlanNo;
    }

    public void setControlPlanNo(String controlPlanNo) {
        this.controlPlanNo = controlPlanNo;
    }

    public Date getRevisionDate() {
        return revisionDate;
    }

    public void setRevisionDate(Date revisionDate) {
        this.revisionDate = revisionDate;
    }

    public String getRevisionNumber() {
        return revisionNumber;
    }

    public void setRevisionNumber(String revisionNumber) {
        this.revisionNumber = revisionNumber;
    }

    public Date getOriginDate() {
        return originDate;
    }

    public void setOriginDate(Date originDate) {
        this.originDate = originDate;
    }

    public Date getPreparedDate() {
        return preparedDate;
    }

    public void setPreparedDate(Date preparedDate) {
        this.preparedDate = preparedDate;
    }

    public Integer getPreparedBy() {
        return preparedBy;
    }

    public void setPreparedBy(Integer preparedBy) {
        this.preparedBy = preparedBy;
    }

    public Integer getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(Integer approvedBy) {
        this.approvedBy = approvedBy;
    }

    public Date getApprovedDate() {
        return approvedDate;
    }

    public void setApprovedDate(Date approvedDate) {
        this.approvedDate = approvedDate;
    }

    public List<Process> getProcess() {
        return process;
    }

    public void setProcess(List<Process> process) {
        this.process = process;
    }

    public Set<ControlPlanItem> getControlPlanItems() {
        return controlPlanItems;
    }

    public void setControlPlanItems(Set<ControlPlanItem> controlPlanItems) {
        this.controlPlanItems = controlPlanItems;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ControlPlan)) return false;
        ControlPlan that = (ControlPlan) o;
        return getId() == that.getId() &&
                getPartId().equals(that.getPartId()) &&
                getCustomerId().equals(that.getCustomerId()) &&
                getControlPlanCategory().equals(that.getControlPlanCategory()) &&
                getControlPlanNo().equals(that.getControlPlanNo()) &&
                getRevisionDate().equals(that.getRevisionDate()) &&
                getRevisionNumber().equals(that.getRevisionNumber()) &&
                getOriginDate().equals(that.getOriginDate()) &&
                getPreparedBy().equals(that.getPreparedBy()) &&
                getPreparedDate().equals(that.getPreparedDate()) &&
                getApprovedBy().equals(that.getApprovedBy()) &&
                getApprovedDate().equals(that.getApprovedDate()) &&
                getProcess().equals(that.getProcess()) &&
                getControlPlanItems().equals(that.getControlPlanItems());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getPartId(), getCustomerId(), getControlPlanCategory(), getControlPlanNo(), getRevisionDate(), getRevisionNumber(), getOriginDate(), getPreparedBy(), getPreparedDate(), getApprovedBy(), getApprovedDate(), getProcess(), getControlPlanItems());
    }

    @Override
    public String toString() {
        return "ControlPlan{" +
                "id=" + id +
                ", partId=" + partId +
                ", customerId=" + customerId +
                ", controlPlanCategory='" + controlPlanCategory + '\'' +
                ", controlPlanNo='" + controlPlanNo + '\'' +
                ", revisionDate=" + revisionDate +
                ", revisionNumber='" + revisionNumber + '\'' +
                ", originDate=" + originDate +
                ", preparedBy=" + preparedBy +
                ", preparedDate=" + preparedDate +
                ", approvedBy=" + approvedBy +
                ", approvedDate=" + approvedDate +
                ", process=" + process +
                ", controlPlanItems=" + controlPlanItems +
                '}';
    }
}
