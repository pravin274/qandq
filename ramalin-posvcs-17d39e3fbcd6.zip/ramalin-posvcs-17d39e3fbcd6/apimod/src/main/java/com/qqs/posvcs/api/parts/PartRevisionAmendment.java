package com.qqs.posvcs.api.parts;


import java.sql.Timestamp;

public class PartRevisionAmendment {
    private int id;
    private int partId;
    private String revisionNumber;
    private String revisionDescription;
    private Timestamp revisionDate;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPartId() {
        return partId;
    }

    public void setPartId(int partId) {
        this.partId = partId;
    }

    public String getRevisionNumber() {
        return revisionNumber;
    }

    public void setRevisionNumber(String revisionNumber) {
        this.revisionNumber = revisionNumber;
    }

    public String getRevisionDescription() { 
        return revisionDescription;
    }

    public void setRevisionDescription(String revisionDescription) {
        this.revisionDescription = revisionDescription;
    }

    public Timestamp getRevisionDate() { 
        return revisionDate;
    }

    public void setRevisionDate(Timestamp revisionDate) {
        this.revisionDate = revisionDate;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("PartRevisionAmendment{");
        sb.append("id=").append(id);
        sb.append(", partId=").append(partId);
        sb.append(", revisionNumber='").append(revisionNumber);
        sb.append(", revisionDescription=").append(revisionDescription);
        sb.append(", revisionDate=").append(revisionDate);
        sb.append('}');
        return sb.toString();
    }
}
