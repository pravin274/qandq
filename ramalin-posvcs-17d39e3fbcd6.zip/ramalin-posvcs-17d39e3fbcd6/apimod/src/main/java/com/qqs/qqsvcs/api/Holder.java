package com.qqs.qqsvcs.api;

import com.qqs.invsvcs.api.InvProductDetails;

public class Holder {
    private int id;
    private String name;
    private String type;
    private String modelNo;
    private String make;
    private String colletUpperDia;
    private String colletLowerDia;
    private InvProductDetails invProductDetails;

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public String getType() { return type; }

    public void setType(String type) { this.type = type; }

    public String getModelNo() { return modelNo; }

    public void setModelNo(String modelNo) { this.modelNo = modelNo; }

    public String getMake() { return make; }

    public void setMake(String make) { this.make = make; }

    public String getColletLowerDia() { return colletLowerDia; }

    public void setColletLowerDia(String colletLowerDia) { this.colletLowerDia = colletLowerDia; }

    public String getColletUpperDia() { return colletLowerDia; }

    public void setColletUpperDia(String colletUpperDia) { this.colletUpperDia = colletUpperDia; }

    public InvProductDetails getInvProductDetails() {
        return invProductDetails;
    }

    public void setInvProductDetails(InvProductDetails invProductDetails) {
        this.invProductDetails = invProductDetails;
    }

    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        if (!super.equals(object)) return false;

        Holder that = (Holder) object;

        if (id != that.id) return false;
        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        if (type != null ? !type.equals(that.type) : that.type != null) return false;
        if (modelNo != null ? !modelNo.equals(that.modelNo) : that.modelNo != null) return false;
        if (make != null ? !make.equals(that.make) : that.make != null) return false;
        if (colletUpperDia != null ? !colletUpperDia.equals(that.colletUpperDia) : that.colletUpperDia != null) return false;
        if (colletLowerDia != null ? !colletLowerDia.equals(that.colletLowerDia) : that.colletLowerDia!= null) return false;
        if (invProductDetails != null ? !invProductDetails.equals(that.invProductDetails) : that.invProductDetails != null) return false;

        return true;
    }

    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + id;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (type != null ? type.hashCode() : 0);
        result = 31 * result + (modelNo != null ? modelNo.hashCode() : 0);
        result = 31 * result + (make != null ? make.hashCode() : 0);
        result = 31 * result + (colletLowerDia != null ? colletLowerDia.hashCode() : 0);
        result = 31 * result + (colletUpperDia != null ? colletUpperDia.hashCode() : 0);
        result = 31 * result + (invProductDetails != null ? invProductDetails.hashCode() : 0);
        return result;
    }
}
