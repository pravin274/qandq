package com.qqs.qqsvcs.api;

import java.util.Map;
import java.util.Set;

public class ResultCollection<K, T> {
    private Set<T> resultSet;
    private Map<K, T> resultMap;

    public Set<T> getResultSet() {
        return resultSet;
    }

    public void setResultSet(Set<T> resultSet) {
        this.resultSet = resultSet;
    }

    public Map<K, T> getResultMap() {
        return resultMap;
    }

    public void setResultMap(Map<K, T> resultMap) {
        this.resultMap = resultMap;
    }
}
