package com.qqs.posvcs.api.reports;

import com.qqs.posvcs.api.PurchOrder;
import com.qqs.posvcs.api.billing.PkgCheckList;
import com.qqs.posvcs.api.parts.Part;

import java.sql.Timestamp;
import java.util.List;
import java.util.Set;

public class PackCheckListMaster {
    private int id;
    private Integer invoiceId;
    private Integer partId;
    private Integer plantId;
    private Integer companyId;
    private String boxNumber;
    private Timestamp packStartTime;
    private Timestamp packEndTime;
    private String shift;
    private String packBoxSize;
    private String vciBagSize;
    private String silicaWt;
    private Integer qtyPerBox;
    private String packingIncharge;
    private List<PkgCheckList> pkgCheckList;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Integer invoiceId) {
        this.invoiceId = invoiceId;
    }

    public Integer getPartId() {
        return partId;
    }

    public void setPartId(Integer partId) {
        this.partId = partId;
    }

    public Integer getPlantId() {
        return plantId;
    }

    public void setPlantId(Integer plantId) {
        this.plantId = plantId;
    }

    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    public String getBoxNumber() {
        return boxNumber;
    }

    public void setBoxNumber(String boxNumber) {
        this.boxNumber = boxNumber;
    }

    public Timestamp getPackStartTime() {
        return packStartTime;
    }

    public void setPackStartTime(Timestamp packStartTime) {
        this.packStartTime = packStartTime;
    }

    public Timestamp getPackEndTime() {
        return packEndTime;
    }

    public void setPackEndTime(Timestamp packEndTime) {
        this.packEndTime = packEndTime;
    }

    public String getShift() {
        return shift;
    }

    public void setShift(String shift) {
        this.shift = shift;
    }

    public String getPackBoxSize() {
        return packBoxSize;
    }

    public void setPackBoxSize(String packBoxSize) {
        this.packBoxSize = packBoxSize;
    }

    public String getVciBagSize() {
        return vciBagSize;
    }

    public void setVciBagSize(String vciBagSize) {
        this.vciBagSize = vciBagSize;
    }

    public String getSilicaWt() {
        return silicaWt;
    }

    public void setSilicaWt(String silicaWt) {
        this.silicaWt = silicaWt;
    }

    public Integer getQtyPerBox() {
        return qtyPerBox;
    }

    public void setQtyPerBox(Integer qtyPerBox) {
        this.qtyPerBox = qtyPerBox;
    }

    public String getPackingIncharge() {
        return packingIncharge;
    }

    public void setPackingIncharge(String packingIncharge) {
        this.packingIncharge = packingIncharge;
    }

    public List<PkgCheckList> getPkgCheckList() {
        return pkgCheckList;
    }

    public void setPkgCheckList(List<PkgCheckList> pkgCheckList) {
        this.pkgCheckList = pkgCheckList;
    }

}
