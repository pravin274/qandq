package com.qqs.qqsvcs.api.lists;

import java.util.List;

public interface ListItem {
    String getDescription();

    String getOtherInfo();

    List<ListItem> getValues();

    String getName();
}
