package com.qqs.qqsvcs.api;

import java.util.Objects;

public class ControlMethod {
    private int id;
    private String controlMethodName;
    private String description;
    private String fileName;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getControlMethodName() {
        return controlMethodName;
    }

    public void setControlMethodName(String controlMethodName) {
        this.controlMethodName = controlMethodName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ControlMethod)) return false;
        ControlMethod that = (ControlMethod) o;
        return getId() == that.getId() &&
                getControlMethodName().equals(that.getControlMethodName()) &&
                getDescription().equals(that.getDescription()) &&
                getFileName().equals(that.getFileName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getControlMethodName(), getDescription(), getFileName());
    }

    @Override
    public String toString() {
        return "ControlMethod{" +
                "id=" + id +
                ", controlMethodName='" + controlMethodName + '\'' +
                ", description='" + description + '\'' +
                ", fileName='" + fileName + '\'' +
                '}';
    }
}
