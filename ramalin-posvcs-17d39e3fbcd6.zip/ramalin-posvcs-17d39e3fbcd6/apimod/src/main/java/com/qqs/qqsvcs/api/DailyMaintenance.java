package com.qqs.qqsvcs.api;

import java.util.Objects;

public class DailyMaintenance {
    private int id;
    private String machineType;
    private String validationType;

    private String description;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMachineType() {
        return machineType;
    }

    public void setMachineType(String machineType) {
        this.machineType = machineType;
    }

    public String getValidationType() {
        return validationType;
    }

    public void setValidationType(String validationType) {
        this.validationType = validationType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DailyMaintenance dailyMaintenance = (DailyMaintenance) o;

        if (id != dailyMaintenance.id) return false;
        if (!Objects.equals(machineType, dailyMaintenance.machineType)) return false;
        if (!Objects.equals(validationType, dailyMaintenance.validationType)) return false;
        if (!Objects.equals(description, dailyMaintenance.description)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (machineType != null ? machineType.hashCode() : 0);
        result = 31 * result + (validationType != null ? validationType.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);

        return result;
    }

}
