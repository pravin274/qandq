package com.qqs.invsvcs.api;

import java.util.Objects;

public class InventoryStockDetailReport {

    private Integer inwardQty;
    private Integer openingStock;
    private Integer totalConsumption;
    private String productType;
    private String productName;
    private Integer productId;
    private Integer closingStock;


    public Integer getInwardQty() {
        return inwardQty;
    }

    public void setInwardQty(Integer inwardQty) {
        this.inwardQty = inwardQty;
    }

    public Integer getOpeningStock() {
        return openingStock;
    }

    public void setOpeningStock(Integer openingStock) {
        this.openingStock = openingStock;
    }

    public Integer getTotalConsumption() {
        return totalConsumption;
    }

    public void setTotalConsumption(Integer totalConsumption) {
        this.totalConsumption = totalConsumption;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getClosingStock() {
        return closingStock;
    }

    public void setClosingStock(Integer closingStock) {
        this.closingStock = closingStock;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof InventoryStockDetailReport)) return false;
        InventoryStockDetailReport that = (InventoryStockDetailReport) o;
        return Objects.equals(getInwardQty(), that.getInwardQty()) &&
                Objects.equals(getOpeningStock(), that.getOpeningStock()) &&
                Objects.equals(getTotalConsumption(), that.getTotalConsumption()) &&
                Objects.equals(getProductType(), that.getProductType()) &&
                Objects.equals(getProductName(), that.getProductName()) &&
                Objects.equals(getProductId(), that.getProductId()) &&
                Objects.equals(getClosingStock(), that.getClosingStock());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getInwardQty(), getOpeningStock(), getTotalConsumption(), getProductType(), getProductName(), getProductId(), getClosingStock());
    }
}
