package com.qqs.qqsvcs.api;

import java.sql.Timestamp;
import java.util.List;

public class ToolLayoutDetail {
    private int id;
    private int toolLayoutId;
    private int toolId;
    private int insertId;
    private int holderId;
    private String serialNo;
    private String operationName;
    private Integer spindleSpeed;
    private Double feed;
    private Double gaugeLength;
    private Integer life;
    private String toolNo;
    private String offsetNo;
    private Double fluteLength;
    private Double workingLength;

    private Tool tool;
    private Holder holder;
    private Insert insert;
    private List<String> printNos;

    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public int getToolLayoutId() { return toolLayoutId; }

    public void setToolLayoutId(int toolLayoutId) { this.toolLayoutId = toolLayoutId; }

    public int getToolId() { return toolId; }

    public void setToolId(int toolId) { this.toolId = toolId; }

    public int getInsertId() { return insertId; }

    public void setInsertId(int insertId) { this.insertId = insertId; }

    public int getHolderId() { return holderId; }

    public void setHolderId(int holderId) { this.holderId = holderId; }

    public String getSerialNo() { return serialNo; }

    public void setSerialNo(String serialNo) { this.serialNo = serialNo; }

    public String getOperationName() { return operationName; }

    public void setOperationName(String operationName) { this.operationName = operationName; }

    public Integer getSpindleSpeed() { return spindleSpeed; }

    public void setSpindleSpeed(Integer spindleSpeed) { this.spindleSpeed = spindleSpeed; }

    public Double getFeed() { return feed; }

    public void setFeed(Double feed) { this.feed = feed; }

    public Double getGaugeLength() { return gaugeLength; }

    public void setGaugeLength(Double gaugeLength) { this.gaugeLength = gaugeLength; }

    public Integer getLife() { return life; }

    public void setLife(Integer life) { this.life = life; }

    public String getToolNo() { return toolNo; }

    public void setToolNo(String toolNo) { this.toolNo = toolNo; }

    public String getOffsetNo() { return offsetNo; }

    public void setOffsetNo(String offsetNo) { this.offsetNo = offsetNo; }

    public Tool getTool() { return tool; }

    public void setTool(Tool tool) { this.tool = tool; }

    public Holder getHolder() { return holder; }

    public void setHolder(Holder holder) { this.holder = holder; }

    public Double getFluteLength() {
        return fluteLength;
    }

    public void setFluteLength(Double fluteLength) {
        this.fluteLength = fluteLength;
    }

    public Double getWorkingLength() {
        return workingLength;
    }

    public void setWorkingLength(Double workingLength) {
        this.workingLength = workingLength;
    }

    public Insert getInsert() { return insert; }

    public void setInsert(Insert insert) { this.insert = insert; }

    public List<String> getPrintNos() { return printNos; }

    public void setPrintNos(List<String> printNos) { this.printNos = printNos; }

    public Integer getCreatedBy() { return createdBy; }

    public void setCreatedBy(Integer createdBy) { this.createdBy = createdBy; }

    public Timestamp getCreatedDt() { return createdDt; }

    public void setCreatedDt(Timestamp createdDt) { this.createdDt = createdDt; }

    public Integer getModifiedBy() { return modifiedBy; }

    public void setModifiedBy(Integer modifiedBy) { this.modifiedBy = modifiedBy; }

    public Timestamp getModifiedDt() { return modifiedDt; }

    public void setModifiedDt(Timestamp modifiedDt) { this.modifiedDt = modifiedDt; }


    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        if (!super.equals(object)) return false;

        ToolLayoutDetail that = (ToolLayoutDetail) object;

        if (id != that.id) return false;
        if (toolLayoutId != that.toolLayoutId) return false;
        if (toolId != that.toolId) return false;
        if (holderId != that.holderId) return false;
        if (insertId != that.insertId) return false;

        if (serialNo != null ? !serialNo.equals(that.serialNo) : that.serialNo != null) return false;
        if (operationName != null ? !operationName.equals(that.operationName) : that.operationName != null) return false;
        if (spindleSpeed != null ? !spindleSpeed.equals(that.spindleSpeed) : that.spindleSpeed != null) return false;
        if (feed != null ? !feed.equals(that.feed) : that.feed != null) return false;
        if (gaugeLength != null ? !gaugeLength.equals(that.gaugeLength) : that.gaugeLength != null) return false;
        if (fluteLength != null ? !fluteLength.equals(that.fluteLength) : that.fluteLength != null) return false;
        if (workingLength != null ? !workingLength.equals(that.workingLength) : that.workingLength != null) return false;

        if (life != null ? !life.equals(that.life) : that.life != null) return false;
        if (toolNo != null ? !toolNo.equals(that.toolNo) : that.toolNo != null) return false;
        if (offsetNo != null ? !offsetNo.equals(that.offsetNo) : that.offsetNo != null) return false;
        if (tool != null ? !tool.equals(that.tool) : that.tool != null) return false;
        if (holder != null ? !holder.equals(that.holder) : that.holder != null) return false;
        if (insert != null ? !insert.equals(that.insert) : that.insert != null) return false;
        if (printNos != null ? !printNos.equals(that.printNos) : that.printNos != null) return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (createdDt != null ? !createdDt.equals(that.createdDt) : that.createdDt != null) return false;
        if (modifiedBy != null ? !modifiedBy.equals(that.modifiedBy) : that.modifiedBy != null) return false;
        if (modifiedDt != null ? !modifiedDt.equals(that.modifiedDt) : that.modifiedDt != null) return false;

        return true;
    }

    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + id;
        result = 31 * result + toolLayoutId;
        result = 31 * result + toolId;
        result = 31 * result + insertId;
        result = 31 * result + holderId;

        result = 31 * result + (serialNo != null ? serialNo.hashCode() : 0);
        result = 31 * result + (operationName != null ? operationName.hashCode() : 0);
        result = 31 * result + (spindleSpeed != null ? spindleSpeed.hashCode() : 0);
        result = 31 * result + (feed != null ? feed.hashCode() : 0);
        result = 31 * result + (gaugeLength != null ? gaugeLength.hashCode() : 0);
        result = 31 * result + (life != null ? life.hashCode() : 0);

        result = 31 * result + (fluteLength != null ? fluteLength.hashCode() : 0);
        result = 31 * result + (workingLength != null ? workingLength.hashCode() : 0);

        result = 31 * result + (toolNo != null ? toolNo.hashCode() : 0);
        result = 31 * result + (offsetNo != null ? offsetNo.hashCode() : 0);
        result = 31 * result + (tool != null ? tool.hashCode() : 0);
        result = 31 * result + (holder != null ? holder.hashCode() : 0);
        result = 31 * result + (insert != null ? insert.hashCode() : 0);
        result = 31 * result + (printNos != null ? printNos.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDt != null ? createdDt.hashCode() : 0);
        result = 31 * result + (modifiedBy != null ? modifiedBy.hashCode() : 0);
        result = 31 * result + (modifiedDt != null ? modifiedDt.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Tool{");
        sb.append("id=").append(id);
        sb.append("toolLayoutId=").append(toolLayoutId);
        sb.append("toolId=").append(toolId);
        sb.append("insertId=").append(insertId);
        sb.append("holderId=").append(holderId);

        sb.append(", serialNo=").append(serialNo);
        sb.append(", operationName='").append(operationName).append('\'');
        sb.append(", spindleSpeed='").append(spindleSpeed).append('\'');
        sb.append(", feed='").append(feed).append('\'');
        sb.append(", gaugeLength='").append(gaugeLength).append('\'');

        sb.append(", fluteLength='").append(fluteLength).append('\'');
        sb.append(", workingLength='").append(workingLength).append('\'');

        sb.append(", life='").append(life).append('\'');
        sb.append(", toolNo='").append(toolNo).append('\'');
        sb.append(", offsetNo='").append(offsetNo).append('\'');
        sb.append(", tool=").append(tool.toString());
        sb.append(", holder=").append(holder.toString());
        sb.append(", insert=").append(insert.toString());
        sb.append(", printNos=").append(printNos.toString());
        sb.append(", createdBy=").append(createdBy);
        sb.append(", createdDt=").append(createdDt);
        sb.append(", modifiedBy=").append(modifiedBy);
        sb.append(", modifiedDt=").append(modifiedDt);
        sb.append('}');
        return sb.toString();
    }
}
