package com.qqs.posvcs.api.reports;

import java.sql.Timestamp;
import java.util.Date;

public class NdaForm {


    private int id;
    private String companyName;
    private Date ndaDate;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String state;
    private String pin;
    private String country;
    private String gstNo;
    private String contactNO;
    private String suppRepName;
    private String supprepTitle;
    private String qqRep;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Date getNdaDate() {
        return ndaDate;
    }

    public void setNdaDate(Date ndaDate) {
        this.ndaDate = ndaDate;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getGstNo() {
        return gstNo;
    }

    public void setGstNo(String gstNo) {
        this.gstNo = gstNo;
    }

    public String getContactNO() {
        return contactNO;
    }

    public void setContactNO(String contactNO) {
        this.contactNO = contactNO;
    }

    public String getSuppRepName() {
        return suppRepName;
    }

    public void setSuppRepName(String suppRepName) {
        this.suppRepName = suppRepName;
    }

    public String getSupprepTitle() {
        return supprepTitle;
    }

    public void setSupprepTitle(String supprepTitle) {
        this.supprepTitle = supprepTitle;
    }

    public String getQqRep() {
        return qqRep;
    }

    public void setQqRep(String qqRep) {
        this.qqRep = qqRep;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        NdaForm that = (NdaForm) o;

        if (id != that.id) return false;
        if (companyName != null ? !companyName.equals(that.companyName) : that.companyName != null) return false;
        if (ndaDate != null ? !ndaDate.equals(that.ndaDate) : that.ndaDate != null) return false;
        if (addressLine1 != null ? !addressLine1.equals(that.addressLine1) : that.addressLine1 != null) return false;
        if (addressLine2 != null ? !addressLine2.equals(that.addressLine2) : that.addressLine2 != null) return false;
        if (city != null ? !city.equals(that.city) : that.city != null) return false;
        if (state != null ? !state.equals(that.state) : that.state != null) return false;
        if (pin != null ? !pin.equals(that.pin) : that.pin != null) return false;
        if (country != null ? !country.equals(that.country) : that.country != null) return false;
        if (gstNo != null ? !gstNo.equals(that.gstNo) : that.gstNo != null) return false;
        if (contactNO != null ? !contactNO.equals(that.contactNO) : that.contactNO != null) return false;
        if (suppRepName != null ? !suppRepName.equals(that.suppRepName) : that.suppRepName != null) return false;
        if (supprepTitle != null ? !supprepTitle.equals(that.supprepTitle) : that.supprepTitle != null) return false;
        if (qqRep != null ? !qqRep.equals(that.qqRep) : that.qqRep != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (companyName != null ? companyName.hashCode() : 0);
        result = 31 * result + (ndaDate != null ? ndaDate.hashCode() : 0);
        result = 31 * result + (addressLine1 != null ? addressLine1.hashCode() : 0);
        result = 31 * result + (addressLine2 != null ? addressLine2.hashCode() : 0);
        result = 31 * result + (city != null ? city.hashCode() : 0);
        result = 31 * result + (state != null ? state.hashCode() : 0);
        result = 31 * result + (pin != null ? pin.hashCode() : 0);
        result = 31 * result + (country != null ? country.hashCode() : 0);
        result = 31 * result + (gstNo != null ? gstNo.hashCode() : 0);
        result = 31 * result + (contactNO != null ? contactNO.hashCode() : 0);
        result = 31 * result + (suppRepName != null ? suppRepName.hashCode() : 0);
        result = 31 * result + (supprepTitle != null ? supprepTitle.hashCode() : 0);
        result = 31 * result + (qqRep != null ? qqRep.hashCode() : 0);
        return result;
    }
}
