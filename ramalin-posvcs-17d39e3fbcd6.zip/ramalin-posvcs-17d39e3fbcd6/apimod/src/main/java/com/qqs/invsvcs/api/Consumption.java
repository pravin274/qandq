package com.qqs.invsvcs.api;


import java.sql.Timestamp;
import java.util.Date;
import java.util.Objects;

public class Consumption {
    private int id;
    private Date consumptionDate;
    private Integer productId;
    private Integer categoryId;
    private String productType;
    private Integer brandId;
    private Double quantity;
    private Integer consumedBy;
    private Integer partId;
    private Product product;
    private ProductBrand brand;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getConsumptionDate() {
        return consumptionDate;
    }

    public void setConsumptionDate(Date consumptionDate) {
        this.consumptionDate = consumptionDate;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public Integer getBrandId() {
        return brandId;
    }

    public void setBrandId(Integer brandId) {
        this.brandId = brandId;
    }

    public Double getQuantity() {
        return quantity;
    }

    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    public Integer getConsumedBy() {
        return consumedBy;
    }

    public void setConsumedBy(Integer consumedBy) {
        this.consumedBy = consumedBy;
    }

    public Integer getPartId() {
        return partId;
    }

    public void setPartId(Integer partId) {
        this.partId = partId;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public ProductBrand getBrand() {
        return brand;
    }

    public void setBrand(ProductBrand brand) {
        this.brand = brand;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Consumption consumption = (Consumption) o;

        if (id != consumption.id) return false;
        if (!Objects.equals(consumptionDate, consumption.consumptionDate)) return false;
        if (!Objects.equals(productId, consumption.productId)) return false;
        if (!Objects.equals(categoryId, consumption.categoryId)) return false;
        if (!Objects.equals(productType, consumption.productType)) return false;
        if (!Objects.equals(brandId, consumption.brandId)) return false;
        if (!Objects.equals(quantity, consumption.quantity)) return false;
        if (!Objects.equals(consumedBy, consumption.consumedBy)) return false;
        if (!Objects.equals(partId, (consumption.partId))) return false;
        if (!Objects.equals(product, (consumption.product))) return false;
        if (!Objects.equals(brand, (consumption.brand))) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (consumptionDate != null ? consumptionDate.hashCode() : 0);
        result = 31 * result + (productId != null ? productId.hashCode() : 0);
        result = 31 * result + (categoryId != null ? categoryId.hashCode() : 0);
        result = 31 * result + (productType != null ? productType.hashCode() : 0);
        result = 31 * result + (brandId != null ? brandId.hashCode() : 0);
        result = 31 * result + (quantity != null ? quantity.hashCode() : 0);
        result = 31 * result + (consumedBy != null ? consumedBy.hashCode() : 0);
        result = 31 * result + (partId != null ? partId.hashCode() : 0);
        result = 31 * result + (product != null ? product.hashCode() : 0);
        result = 31 * result + (brand != null ? brand.hashCode() : 0);

        return result;
    }
}


