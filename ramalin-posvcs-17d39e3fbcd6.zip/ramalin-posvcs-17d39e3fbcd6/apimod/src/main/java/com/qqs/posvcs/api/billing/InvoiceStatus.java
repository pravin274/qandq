package com.qqs.posvcs.api.billing;

import java.sql.Timestamp;
import java.util.Objects;

public class InvoiceStatus {
    private int id;
    private Integer invoiceId;
    private String invoiceStatus;
    private Timestamp statusDate;
    private String attribute1;
    private String attribute2;
    private String attribute3;
    private String attribute4;
    private String dueDate;
    private String remarks;
    private String overDueFlag;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Integer invoiceId) {
        this.invoiceId = invoiceId;
    }

    public String getInvoiceStatus() {
        return invoiceStatus;
    }

    public void setInvoiceStatus(String invoiceStatus) {
        this.invoiceStatus = invoiceStatus;
    }

    public Timestamp getStatusDate() {
        return statusDate;
    }

    public void setStatusDate(Timestamp statusDate) {
        this.statusDate = statusDate;
    }

    public String getAttribute1() {
        return attribute1;
    }

    public void setAttribute1(String attribute1) {
        this.attribute1 = attribute1;
    }

    public String getAttribute2() {
        return attribute2;
    }

    public void setAttribute2(String attribute2) {
        this.attribute2 = attribute2;
    }

    public String getAttribute3() {
        return attribute3;
    }

    public void setAttribute3(String attribute3) {
        this.attribute3 = attribute3;
    }

    public String getAttribute4() {
        return attribute4;
    }

    public void setAttribute4(String attribute4) {
        this.attribute4 = attribute4;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getOverDueFlag() {
        return overDueFlag;
    }

    public void setOverDueFlag(String overDueFlag) {
        this.overDueFlag = overDueFlag;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof InvoiceStatus)) return false;
        InvoiceStatus that = (InvoiceStatus) o;
        return getId() == that.getId() &&
                getInvoiceId().equals(that.getInvoiceId()) &&
                getInvoiceStatus().equals(that.getInvoiceStatus()) &&
                getStatusDate().equals(that.getStatusDate()) && 
                getOverDueFlag().equals(that.getOverDueFlag()) && 
                Objects.equals(getRemarks(), that.getRemarks());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(),
                getInvoiceId(), getInvoiceStatus(), getStatusDate(), getOverDueFlag(), getRemarks());
    }
}
