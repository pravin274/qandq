package com.qqs.qqsvcs.api;

import java.util.Date;

public class RejectionAssign {
    private int id;
    private Integer taskId;
    private Integer responsibilityPersonId;
    private String rootCause;
    private String systemStatus;
    private Date targetDate;
    private Date dateOfAssigning;
    private String rootCauseDescription;
    private String reason;
    private String correctiveAction;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getTaskId() {
        return taskId;
    }

    public void setTaskId(Integer taskId) {
        this.taskId = taskId;
    }

    public Integer getResponsibilityPersonId() {
        return responsibilityPersonId;
    }

    public void setResponsibilityPersonId(Integer resposibilityPersonId) {
        this.responsibilityPersonId = resposibilityPersonId;
    }

    public String getRootCause() {
        return rootCause;
    }

    public void setRootCause(String rootCause) {
        this.rootCause = rootCause;
    }

    public String getSystemStatus() {
        return systemStatus;
    }

    public void setSystemStatus(String systemStatus) {
        this.systemStatus = systemStatus;
    }

    public Date getTargetDate() {
        return targetDate;
    }

    public void setTargetDate(Date targetDate) {
        this.targetDate = targetDate;
    }

    public Date getDateOfAssigning() {
        return dateOfAssigning;
    }

    public void setDateOfAssigning(Date dateOfAssigning) {
        this.dateOfAssigning = dateOfAssigning;
    }

    public String getRootCauseDescription() {
        return rootCauseDescription;
    }

    public void setRootCauseDescription(String rootCauseDescription) {
        this.rootCauseDescription = rootCauseDescription;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getCorrectiveAction() {
        return correctiveAction;
    }

    public void setCorrectiveAction(String correctiveAction) {
        this.correctiveAction = correctiveAction;
    }
}
