package com.qqs.posvcs.api;

public class PoLineTool {
    private int id;
    private String description;
    private Integer price;
    private String toolNo;
    private String revNo;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public String getToolNo() {
        return toolNo;
    }

    public void setToolNo(String toolNo) {
        this.toolNo = toolNo;
    }

    public String getRevNo() { return revNo; }

    public void setRevNo(String revNo) { this.revNo = revNo; }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("PoLineTool{");
        sb.append("id=").append(id);
        sb.append(", description=").append(description);
        sb.append(", price=").append(price);
        sb.append(", toolNo=").append(toolNo);
        sb.append(", revNo=").append(revNo);
        sb.append('}');
        return sb.toString();
    }

}
