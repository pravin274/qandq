package com.qqs.qqsvcs.api;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class ToolLayout {
    private int id;
    private int processId;

    private String programNo;
    private String layoutNo;
    private String revNo;
    private Date revDate;
    private Integer preparedBy;
    private Date preparedDate;
    private Integer approvedBy;
    private Date approvedDate;
    private List<ToolLayoutDetail> toolLayoutDetailList;
    private Process process;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public int getProcessId() { return processId; }

    public void setProcessId(int processId) { this.processId = processId; }

    public Process getProcess() { return process; }

    public void setProcess(Process process) { this.process = process; }

    public String getProgramNo() { return programNo; }

    public void setProgramNo(String programNo) { this.programNo = programNo; }

    public String getLayoutNo() { return layoutNo; }

    public void setLayoutNo(String layoutNo) { this.layoutNo = layoutNo; }

    public String getRevNo() { return revNo; }

    public void setRevNo(String revNo) { this.revNo = revNo; }

    public Date getRevDate() { return revDate; }

    public void setRevDate(Date revDate) { this.revDate = revDate; }

    public Integer getPreparedBy() { return preparedBy; }

    public void setPreparedBy(Integer preparedBy) { this.preparedBy = preparedBy; }

    public Date getPreparedDate() { return preparedDate; }

    public void setPreparedDate(Date preparedDate) { this.preparedDate = preparedDate; }

    public Integer getApprovedBy() { return approvedBy; }

    public void setApprovedBy(Integer approvedBy) { this.approvedBy = approvedBy; }

    public Date getApprovedDate() { return approvedDate; }

    public void setApprovedDate(Date approvedDate) { this.approvedDate = approvedDate; }

    public List<ToolLayoutDetail> getToolLayoutDetailList() { return toolLayoutDetailList; }

    public void setToolLayoutDetailList(List<ToolLayoutDetail> toolLayoutDetailList) {
        this.toolLayoutDetailList = toolLayoutDetailList;
    }

    public Integer getCreatedBy() { return createdBy; }

    public void setCreatedBy(Integer createdBy) { this.createdBy = createdBy; }

    public Timestamp getCreatedDt() { return createdDt; }

    public void setCreatedDt(Timestamp createdDt) { this.createdDt = createdDt; }

    public Integer getModifiedBy() { return modifiedBy; }

    public void setModifiedBy(Integer modifiedBy) { this.modifiedBy = modifiedBy; }

    public Timestamp getModifiedDt() { return modifiedDt; }

    public void setModifiedDt(Timestamp modifiedDt) { this.modifiedDt = modifiedDt; }

    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        if (!super.equals(object)) return false;

        ToolLayout that = (ToolLayout) object;

        if (id != that.id) return false;
        if (processId != that.processId) return false;

        if (programNo != null ? !programNo.equals(that.programNo) : that.programNo != null) return false;
        if (layoutNo != null ? !layoutNo.equals(that.layoutNo) : that.layoutNo != null) return false;
        if (revNo != null ? !revNo.equals(that.revNo) : that.revNo != null) return false;
        if (revDate != null ? !revDate.equals(that.revDate) : that.revDate != null) return false;
        if (preparedBy != null ? !preparedBy.equals(that.preparedBy) : that.preparedBy != null) return false;
        if (preparedDate != null ? !preparedDate.equals(that.preparedDate) : that.preparedDate != null) return false;
        if (approvedBy != null ? !approvedBy.equals(that.approvedBy) : that.approvedBy != null) return false;
        if (approvedDate != null ? !approvedDate.equals(that.approvedDate) : that.approvedDate != null) return false;
        if (toolLayoutDetailList != null ? !toolLayoutDetailList.equals(that.toolLayoutDetailList) :
                that.toolLayoutDetailList != null) return false;
        if (process != null ? !process.equals(that.process) : that.process != null) return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (createdDt != null ? !createdDt.equals(that.createdDt) : that.createdDt != null) return false;
        if (modifiedBy != null ? !modifiedBy.equals(that.modifiedBy) : that.modifiedBy != null) return false;
        if (modifiedDt != null ? !modifiedDt.equals(that.modifiedDt) : that.modifiedDt != null) return false;

        return true;
    }

    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + id;
        result = 31 * result + processId;

        result = 31 * result + (programNo != null ? programNo.hashCode() : 0);
        result = 31 * result + (layoutNo != null ? layoutNo.hashCode() : 0);
        result = 31 * result + (revNo != null ? revNo.hashCode() : 0);
        result = 31 * result + (revDate != null ? revDate.hashCode() : 0);
        result = 31 * result + (preparedBy != null ? preparedBy.hashCode() : 0);
        result = 31 * result + (preparedDate != null ? preparedDate.hashCode() : 0);
        result = 31 * result + (approvedBy != null ? approvedBy.hashCode() : 0);
        result = 31 * result + (approvedDate != null ? approvedDate.hashCode() : 0);
        result = 31 * result + (toolLayoutDetailList != null ? toolLayoutDetailList.hashCode() : 0);
        result = 31 * result + (process != null ? process.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDt != null ? createdDt.hashCode() : 0);
        result = 31 * result + (modifiedBy != null ? modifiedBy.hashCode() : 0);
        result = 31 * result + (modifiedDt != null ? modifiedDt.hashCode() : 0);
        return result;
    }
}
