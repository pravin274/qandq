package com.qqs.posvcs.api.reports;

import java.sql.Date;

public class SalesOrderReportData {
    private int id;

    private int serialNo;
    private String poDate;
    private String poNumber;
    private String companyName;
    private String plantName;
    private String deliveryDate;
    private int poQty;
    private Double totalOrderValue;

    private int poLineId;
    private String poLineItemNo;
    private String poLineItemType;

    private String partDesc;
    private String partNumber;
    private String partRevNo;
    private String hsCode;
    private double partPrice;

    private double deliveredQty;
    private Double totalDeliveredValue;
    private double pendingQty;
    private Double totalPendingValue;
    private int daysLeft;

    private String invoiceNo;
    private String awbBill;
    private String invoiceDate;
    private Date invoiceToCompAccountsDate;
    private Date paymentDueDate;
    private String paymentStatus;
    private Date paymentDate;
    private String paymentLink;
    private Double igstValue;
    private Date igstPaymentDate;
    private Double dbkValue;
    private String ddbStatus;
    private Date ddbReceivedDate;
    private String shippingBill;
    private String shippedPort;
    private String fircStatus;
    private String ebrcStatus;
    private String meisStatus;

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public String getPoDate() { return poDate; }

    public void setPoDate(String poDate) { this.poDate = poDate; }

    public String getPoNumber() {
        return poNumber;
    }

    public void setPoNumber(String poNumber) {
        this.poNumber = poNumber;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }
    public String getPartRevNo() {
        return partRevNo;
    }

    public void setPartRevNo(String partRevNo) {
        this.partRevNo = partRevNo;
    }

    public String getDeliveryDate() { return deliveryDate; }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }
    public int getPoQty() { return poQty; }

    public void setPoQty(int poQty) { this.poQty = poQty; }

    public double getDeliveredQty() { return deliveredQty; }

    public void setDeliveredQty(double deliveredQty) { this.deliveredQty = deliveredQty; }

    public double getPendingQty() { return pendingQty; }

    public void setPendingQty(double pendingQty) {
        this.pendingQty = pendingQty;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getPlantName() {
        return plantName;
    }

    public void setPlantName(String plantName) {
        this.plantName = plantName;
    }

    public int getDaysLeft() {
        return daysLeft;
    }

    public void setDaysLeft(int daysLeft) {
        this.daysLeft = daysLeft;
    }

    public int getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(int serialNo) {
        this.serialNo = serialNo;
    }

    public String getPoLineItemNo() {
        return poLineItemNo;
    }

    public void setPoLineItemNo(String poLineItemNo) {
        this.poLineItemNo = poLineItemNo;
    }

    public String getPoLineItemType() {
        return poLineItemType;
    }

    public void setPoLineItemType(String poLineItemType) {
        this.poLineItemType = poLineItemType;
    }

    public String getPartDesc() {
        return partDesc;
    }

    public double getPartPrice() { return partPrice; }

    public void setPartPrice(double partPrice) { this.partPrice = partPrice; }

    public void setPartDesc(String partDesc) {
        this.partDesc = partDesc;
    }

    public String getHsCode() {
        return hsCode;
    }

    public void setHsCode(String hsCode) {
        this.hsCode = hsCode;
    }

    public String getInvoiceNo() {
        return invoiceNo;
    }

    public void setInvoiceNo(String invoiceNo) {
        this.invoiceNo = invoiceNo;
    }

    public String getAwbBill() {
        return awbBill;
    }

    public void setAwbBill(String awbBill) {
        this.awbBill = awbBill;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public Date getInvoiceToCompAccountsDate() {
        return invoiceToCompAccountsDate;
    }

    public void setInvoiceToCompAccountsDate(Date invoiceToCompAccountsDate) {
        this.invoiceToCompAccountsDate = invoiceToCompAccountsDate;
    }

    public Date getPaymentDueDate() {
        return paymentDueDate;
    }

    public void setPaymentDueDate(Date paymentDueDate) {
        this.paymentDueDate = paymentDueDate;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getPaymentLink() {
        return paymentLink;
    }

    public void setPaymentLink(String paymentLink) {
        this.paymentLink = paymentLink;
    }

    public Double getIgstValue() {
        return igstValue;
    }

    public void setIgstValue(Double igstValue) { this.igstValue = igstValue; }

    public Date getIgstPaymentDate() { return igstPaymentDate; }

    public void setIgstPaymentDate(Date igstPaymentDate) { this.igstPaymentDate = igstPaymentDate; }

    public Double getDbkValue() { return dbkValue; }

    public void setDbkValue(Double dbkValue) { this.dbkValue = dbkValue; }

    public String getDdbStatus() { return ddbStatus; }

    public void setDdbStatus(String ddbStatus) { this.ddbStatus = ddbStatus; }

    public Date getDdbReceivedDate() { return ddbReceivedDate; }

    public void setDdbReceivedDate(Date ddbReceivedDate) { this.ddbReceivedDate = ddbReceivedDate; }

    public String getShippingBill() { return shippingBill; }

    public void setShippingBill(String shippingBill) { this.shippingBill = shippingBill; }

    public String getShippedPort() { return shippedPort; }

    public void setShippedPort(String shippedPort) { this.shippedPort = shippedPort; }

    public String getFircStatus() { return fircStatus; }

    public void setFircStatus(String fircStatus) { this.fircStatus = fircStatus; }

    public String getEbrcStatus() { return ebrcStatus; }

    public void setEbrcStatus(String ebrcStatus) { this.ebrcStatus = ebrcStatus; }

    public String getMeisStatus() { return meisStatus; }

    public void setMeisStatus(String meisStatus) { this.meisStatus = meisStatus; }

    public Double getTotalOrderValue() { return totalOrderValue; }

    public void setTotalOrderValue(Double totalOrderValue) { this.totalOrderValue = totalOrderValue; }

    public Double getTotalDeliveredValue() { return totalDeliveredValue; }

    public void setTotalDeliveredValue(Double totalDeliveredValue) { this.totalDeliveredValue = totalDeliveredValue; }

    public Double getTotalPendingValue() { return totalPendingValue; }

    public void setTotalPendingValue(Double totalPendingValue) { this.totalPendingValue = totalPendingValue; }

    public int getPoLineId() { return poLineId; }

    public void setPoLineId(int poLineId) { this.poLineId = poLineId; }

    public void calculateTotalValues() {
        pendingQty = poQty - deliveredQty;
        totalOrderValue = (poQty * partPrice);
        totalDeliveredValue = (deliveredQty * partPrice);
        totalPendingValue = (pendingQty * partPrice);
    }
}
