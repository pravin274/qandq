package com.qqs.posvcs.api.reports;

import java.util.List;
import java.util.Map;

public class PendingOrderReport {
    private List<PendingOrderData> pendingOrderData;
    private Map<String, String> summaryText;

    public List<PendingOrderData> getPendingOrderData() {
        return pendingOrderData;
    }

    public void setPendingOrderData(List<PendingOrderData> pendingOrderData) {
        this.pendingOrderData = pendingOrderData;
    }

    public Map<String, String> getSummaryText() {
        return summaryText;
    }

    public void setSummaryText(Map<String, String> summaryText) {
        this.summaryText = summaryText;
    }
}
