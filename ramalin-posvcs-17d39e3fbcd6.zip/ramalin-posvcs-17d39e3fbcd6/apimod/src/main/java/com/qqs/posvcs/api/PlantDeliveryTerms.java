package com.qqs.posvcs.api;

import java.sql.Timestamp;

public class PlantDeliveryTerms {
    private int id;
    private int plantId;
    private String deliveryTerms;
    private Timestamp effectiveDt;
    private Timestamp expiryDt;

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public int getPlantId() { return plantId; }

    public void setPlantId(int plantId) { this.plantId = plantId; }

    public String getDeliveryTerms() { return deliveryTerms; }

    public void setDeliveryTerms(String deliveryTerms) { this.deliveryTerms = deliveryTerms; }

    public Timestamp getEffectiveDt() { return effectiveDt; }

    public void setEffectiveDt(Timestamp effectiveDt) { this.effectiveDt = effectiveDt; }

    public Timestamp getExpiryDt() { return expiryDt; }

    public void setExpiryDt(Timestamp expiryDt) { this.expiryDt = expiryDt; }


    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Plant{");
        sb.append("id=").append(id);
        sb.append(", plantId='").append(plantId).append('\'');
        sb.append(", deliveryTerms='").append(deliveryTerms).append('\'');
        sb.append(", effectiveDt=").append(effectiveDt).append('\'');
        sb.append(", expiryDt=").append(expiryDt).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
