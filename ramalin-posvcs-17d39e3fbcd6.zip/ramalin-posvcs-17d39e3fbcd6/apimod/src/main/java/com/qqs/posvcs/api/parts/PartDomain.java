package com.qqs.posvcs.api.parts;


import java.sql.Timestamp;

public class PartDomain {
    private int id;
    private int partId;
    private String domain;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPartId() {
        return partId;
    }

    public void setPartId(int partId) {
        this.partId = partId;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("PartDomain{");
        sb.append("id=").append(id);
        sb.append(", partId=").append(partId);
        sb.append(", domain='").append(domain).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
