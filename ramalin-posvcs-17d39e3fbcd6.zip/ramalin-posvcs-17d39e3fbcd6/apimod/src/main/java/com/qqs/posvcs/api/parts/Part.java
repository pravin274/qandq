package com.qqs.posvcs.api.parts;


import com.qqs.invsvcs.api.InvProductDetails;

import java.sql.Timestamp;
import java.util.List;

public class Part {
    private int id;
    private String name;
    private Integer companyId;
    private String number;
    private String partRevNo;
    private Timestamp partRevDt;
    private Integer partRevOrder;
    private String drawingNo;
    private String drawingRevNo;
    private Timestamp drawingRevDt;
    private String qqsCode;
    private String qqsRevNo;
    private Timestamp qqsRevDt;
    private String projectName;
    private String category;
    private String materialSpec;
    private Double castingWt;
    private String castingWtUnit;
    private Integer rfqVolume;
    private Integer mbq;
    private String uom;
    private String resourceInd;
    private String jobType;
    private Integer qty;
    private List<PartChronology> chronologies;
    private List<PartDomain> domains;
    private List<PartCommodity> commodities;
    private List<PartImage> images;
    private List<PartPrice> prices;
    private List<Part> revisions;
    private List<PartStandard> standard;
    private List<PartCustomerRequirement> customerRequirement;
    private List<PartRevisionAmendment> revisionAmendment;
    private InvProductDetails invProductDetails;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getPartRevNo() {
        return partRevNo;
    }

    public void setPartRevNo(String partRevNo) {
        this.partRevNo = partRevNo;
    }

    public Timestamp getPartRevDt() {
        return partRevDt;
    }

    public void setPartRevDt(Timestamp partRevDt) {
        this.partRevDt = partRevDt;
    }

    public Integer getPartRevOrder() {
        return partRevOrder;
    }

    public void setPartRevOrder(Integer partRevOrder) {
        this.partRevOrder = partRevOrder;
    }

    public String getDrawingNo() {
        return drawingNo;
    }

    public void setDrawingNo(String drawingNo) {
        this.drawingNo = drawingNo;
    }

    public String getDrawingRevNo() {
        return drawingRevNo;
    }

    public void setDrawingRevNo(String drawingRevNo) {
        this.drawingRevNo = drawingRevNo;
    }

    public Timestamp getDrawingRevDt() {
        return drawingRevDt;
    }

    public void setDrawingRevDt(Timestamp drawingRevDt) {
        this.drawingRevDt = drawingRevDt;
    }

    public String getQqsCode() {
        return qqsCode;
    }

    public void setQqsCode(String qqsCode) {
        this.qqsCode = qqsCode;
    }

    public String getQqsRevNo() {
        return qqsRevNo;
    }

    public void setQqsRevNo(String qqsRevNo) {
        this.qqsRevNo = qqsRevNo;
    }

    public Timestamp getQqsRevDt() {
        return qqsRevDt;
    }

    public void setQqsRevDt(Timestamp qqsRevDt) {
        this.qqsRevDt = qqsRevDt;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getMaterialSpec() {
        return materialSpec;
    }

    public void setMaterialSpec(String materialSpec) {
        this.materialSpec = materialSpec;
    }

    public Double getCastingWt() {
        return castingWt;
    }

    public void setCastingWt(Double castingWt) {
        this.castingWt = castingWt;
    }

    public String getCastingWtUnit() {
        return castingWtUnit;
    }

    public void setCastingWtUnit(String castingWtUnit) {
        this.castingWtUnit = castingWtUnit;
    }

    public Integer getRfqVolume() {
        return rfqVolume;
    }

    public void setRfqVolume(Integer rfqVolume) {
        this.rfqVolume = rfqVolume;
    }

    public Integer getMbq() {
        return mbq;
    }

    public void setMbq(Integer mbq) {
        this.mbq = mbq;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    public String getResourceInd() {
        return resourceInd;
    }

    public void setResourceInd(String resourceInd) {
        this.resourceInd = resourceInd;
    }

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public Integer getQty() {
        return qty;
    }

    public void setQty(Integer qty) {
        this.qty = qty;
    }

    public List<PartChronology> getChronologies() {
        return chronologies;
    }

    public void setChronologies(List<PartChronology> chronologies) {
        this.chronologies = chronologies;
    }

    public List<PartDomain> getDomains() {
        return domains;
    }

    public void setDomains(List<PartDomain> domains) {
        this.domains = domains;
    }

    public List<PartCommodity> getCommodities() { return commodities; }

    public void setCommodities(List<PartCommodity> commodities) { this.commodities = commodities; }

    public List<PartImage> getImages() {
        return images;
    }

    public void setImages(List<PartImage> images) {
        this.images = images;
    }

    public List<PartPrice> getPrices() {
        return prices;
    }

    public void setPrices(List<PartPrice> prices) {
        this.prices = prices;
    }

    public List<Part> getRevisions() {
        return revisions;
    }

    public void setRevisions(List<Part> revisions) {
        this.revisions = revisions;
    }


    public List<PartStandard> getStandard() {
        return standard;
    }

    public void setStandard(List<PartStandard> standard) {
        this.standard = standard;
    }

    public List<PartCustomerRequirement> getCustomerRequirement() {
        return customerRequirement;
    }

    public void setCustomerRequirement(List<PartCustomerRequirement> customerRequirement) {
        this.customerRequirement = customerRequirement;
    }

    public List<PartRevisionAmendment> getRevisionAmendment() {
        return revisionAmendment;
    }

    public void setRevisionAmendment(List<PartRevisionAmendment> revisionAmendment) {
        this.revisionAmendment = revisionAmendment;
    }

    public InvProductDetails getInvProductDetails() {
        return invProductDetails;
    }

    public void setInvProductDetails(InvProductDetails invProductDetails) {
        this.invProductDetails = invProductDetails;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Part{");
        sb.append("id=").append(id);
        sb.append(", name=").append(name).append('\'');
        sb.append(",companyId=").append(companyId).append('\'');
        sb.append(", number='").append(number).append('\'');
        sb.append(", partRevNo='").append(partRevNo).append('\'');
        sb.append(", partRevDt=").append(partRevDt);
        sb.append(", partRevOrder=").append(partRevOrder);
        sb.append(", drawingNo='").append(drawingNo).append('\'');
        sb.append(", drawingRevNo='").append(drawingRevNo).append('\'');
        sb.append(", drawingRevDt=").append(drawingRevDt);
        sb.append(", qqsCode='").append(qqsCode).append('\'');
        sb.append(", qqsRevNo='").append(qqsRevNo).append('\'');
        sb.append(", qqsRevDt=").append(qqsRevDt);
        sb.append(", projectName='").append(projectName).append('\'');
        sb.append(", category='").append(category).append('\'');
        sb.append(", materialSpec='").append(materialSpec).append('\'');
        sb.append(", castingWt=").append(castingWt);
        sb.append(", castingWtUnit='").append(castingWtUnit).append('\'');
        sb.append(", rfqVolume=").append(rfqVolume);
        sb.append(", mbq=").append(mbq);
        sb.append(", uom='").append(uom).append('\'');
        sb.append(", resourceInd='").append(resourceInd).append('\'');
        sb.append(", jobType='").append(jobType).append('\'');
        sb.append(", qty='").append(qty).append('\'');
        sb.append(", chronologies=").append(chronologies);
        sb.append(", domains=").append(domains);
        sb.append(", commodities=").append(commodities);
        sb.append(", images=").append(images);
        sb.append(", prices=").append(prices);
        sb.append(", revisions=").append(revisions);
        sb.append(", standard=").append(standard);
        sb.append(", customerRequirement=").append(customerRequirement);
        sb.append(", revisionAmendment=").append(revisionAmendment);
        sb.append(", invProductDetails=").append(invProductDetails);
        sb.append('}');
        return sb.toString();
    }
}
