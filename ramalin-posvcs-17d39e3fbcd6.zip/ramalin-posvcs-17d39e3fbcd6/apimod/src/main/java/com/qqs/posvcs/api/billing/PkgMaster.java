package com.qqs.posvcs.api.billing;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class PkgMaster {
    private int id;
    private Integer pkgNo;
    private String shipId;
    private String pkgType;
    private Integer totalQty;
    private BigDecimal netWeight;
    private BigDecimal grossWeight;
    private String weightUnit;
    private BigDecimal height;
    private BigDecimal length;
    private BigDecimal width;
    private String dimensionUnit;
    private List<PkgDetail> pkgDetails;
    private Boolean isDeleted;
    private Integer groupCount;
    private Integer boxCount;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getPkgNo() {
        return pkgNo;
    }

    public void setPkgNo(Integer pkgNo) {
        this.pkgNo = pkgNo;
    }

    public String getShipId() {
        return shipId;
    }

    public void setShipId(String shipId) {
        this.shipId = shipId;
    }

    public String getPkgType() {
        return pkgType;
    }

    public void setPkgType(String pkgType) {
        this.pkgType = pkgType;
    }

    public Integer getTotalQty() {
        return totalQty;
    }

    public void setTotalQty(Integer totalQty) {
        this.totalQty = totalQty;
    }

    public BigDecimal getNetWeight() {
        return netWeight;
    }

    public void setNetWeight(BigDecimal netWeight) {
        this.netWeight = netWeight;
    }

    public BigDecimal getGrossWeight() {
        return grossWeight;
    }

    public void setGrossWeight(BigDecimal grossWeight) {
        this.grossWeight = grossWeight;
    }

    public String getWeightUnit() {
        return weightUnit;
    }

    public void setWeightUnit(String weightUnit) {
        this.weightUnit = weightUnit;
    }

    public BigDecimal getHeight() {
        return height;
    }

    public void setHeight(BigDecimal height) {
        this.height = height;
    }

    public BigDecimal getLength() {
        return length;
    }

    public void setLength(BigDecimal length) {
        this.length = length;
    }

    public BigDecimal getWidth() {
        return width;
    }

    public void setWidth(BigDecimal width) {
        this.width = width;
    }

    public String getDimensionUnit() {
        return dimensionUnit;
    }

    public void setDimensionUnit(String dimensionUnit) {
        this.dimensionUnit = dimensionUnit;
    }

    public List<PkgDetail> getPkgDetails() { return pkgDetails; }

    public void setPkgDetails(List<PkgDetail> pkgDetails) { this.pkgDetails = pkgDetails; }

    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        if(isDeleted == null) {
            this.isDeleted = false;
        } else {
            this.isDeleted = isDeleted;
        }
    }

    public Integer getGroupCount() {
        if(groupCount == null) return 0;
        return groupCount;
    }

    public void setGroupCount(Integer groupCount) { this.groupCount = groupCount; }


    public Boolean getDeleted() {
        return isDeleted;
    }

    public void setDeleted(Boolean deleted) {
        isDeleted = deleted;
    }

    public Integer getBoxCount() {
        return boxCount;
    }

    public void setBoxCount(Integer boxCount) {
        this.boxCount = boxCount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PkgMaster pkgMaster = (PkgMaster) o;

        if (id != pkgMaster.id) return false;
        if (pkgNo != null ? !pkgNo.equals(pkgMaster.pkgNo) : pkgMaster.pkgNo != null) return false;
        if (shipId != null ? !shipId.equals(pkgMaster.shipId) : pkgMaster.shipId != null) return false;
        if (pkgType != null ? !pkgType.equals(pkgMaster.pkgType) : pkgMaster.pkgType != null) return false;
        if (totalQty != null ? !totalQty.equals(pkgMaster.totalQty) : pkgMaster.totalQty != null) return false;
        if (netWeight != null ? !netWeight.equals(pkgMaster.netWeight) : pkgMaster.netWeight != null) return false;
        if (grossWeight != null ? !grossWeight.equals(pkgMaster.grossWeight) : pkgMaster.grossWeight != null)
            return false;
        if (weightUnit != null ? !weightUnit.equals(pkgMaster.weightUnit) : pkgMaster.weightUnit != null) return false;
        if (height != null ? !height.equals(pkgMaster.height) : pkgMaster.height != null) return false;
        if (length != null ? !length.equals(pkgMaster.length) : pkgMaster.length != null) return false;
        if (width != null ? !width.equals(pkgMaster.width) : pkgMaster.width != null) return false;
        if (dimensionUnit != null ? !dimensionUnit.equals(pkgMaster.dimensionUnit) : pkgMaster.dimensionUnit != null)
            return false;
        if (pkgDetails != null ? !pkgDetails.equals(pkgMaster.pkgDetails) : pkgMaster.pkgDetails != null) return false;
        if (isDeleted != null ? !isDeleted.equals(pkgMaster.isDeleted) : pkgMaster.isDeleted != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (pkgNo != null ? pkgNo.hashCode() : 0);
        result = 31 * result + (shipId != null ? shipId.hashCode() : 0);
        result = 31 * result + (pkgType != null ? pkgType.hashCode() : 0);
        result = 31 * result + (totalQty != null ? totalQty.hashCode() : 0);
        result = 31 * result + (netWeight != null ? netWeight.hashCode() : 0);
        result = 31 * result + (grossWeight != null ? grossWeight.hashCode() : 0);
        result = 31 * result + (weightUnit != null ? weightUnit.hashCode() : 0);
        result = 31 * result + (height != null ? height.hashCode() : 0);
        result = 31 * result + (length != null ? length.hashCode() : 0);
        result = 31 * result + (width != null ? width.hashCode() : 0);
        result = 31 * result + (dimensionUnit != null ? dimensionUnit.hashCode() : 0);
        result = 31 * result + (pkgDetails != null ? pkgDetails.hashCode() : 0);
        result = 31 * result + (isDeleted != null ? isDeleted.hashCode() : 0);
        return result;
    }

    public boolean isSimilarBox(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PkgMaster pkgMaster = (PkgMaster) o;

        if (pkgType != null ? !pkgType.equals(pkgMaster.pkgType) : pkgMaster.pkgType != null) return false;
        if (totalQty != null ? !totalQty.equals(pkgMaster.totalQty) : pkgMaster.totalQty != null) return false;
        if (netWeight != null ? !netWeight.equals(pkgMaster.netWeight) : pkgMaster.netWeight != null) return false;
        if (grossWeight != null ? !grossWeight.equals(pkgMaster.grossWeight) : pkgMaster.grossWeight != null)
            return false;
        if (weightUnit != null ? !weightUnit.equals(pkgMaster.weightUnit) : pkgMaster.weightUnit != null) return false;
        if (height != null ? !height.equals(pkgMaster.height) : pkgMaster.height != null) return false;
        if (length != null ? !length.equals(pkgMaster.length) : pkgMaster.length != null) return false;
        if (width != null ? !width.equals(pkgMaster.width) : pkgMaster.width != null) return false;
        if (dimensionUnit != null ? !dimensionUnit.equals(pkgMaster.dimensionUnit) : pkgMaster.dimensionUnit != null)
            return false;

        List<PkgDetail> pkgDetailList = pkgDetails.stream()                // convert list to stream
                .filter(item -> !item.getIsDeleted())
                .collect(Collectors.toList());

        List<PkgDetail> oPkgDetailList = pkgMaster.pkgDetails.stream()                // convert list to stream
                .filter(item -> !item.getIsDeleted())
                .collect(Collectors.toList());

        if(pkgDetailList.size() != oPkgDetailList.size()) return false;

        List<PkgDetail> filteredList = new ArrayList<>();
        pkgDetailList.forEach(pkgD ->
        oPkgDetailList.stream()
                .filter(pkgD1 -> pkgD.getInvoiceLineItemId().equals(pkgD1.getInvoiceLineItemId()) &&
                        pkgD.getQty().equals(pkgD1.getQty()) && pkgD.getWeightPrPiece().equals(pkgD1.getWeightPrPiece()))
                .forEach(filteredList::add));
        if(filteredList.size() != pkgDetailList.size()) return  false;

        return true;
    }

}
