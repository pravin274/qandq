package com.qqs.posvcs.api.parts;


import java.sql.Timestamp;

public class PartCustomerRequirement {
    private int id;
    private int partId;
    private String noteNumber;
    private String customerRequirement;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPartId() {
        return partId;
    }

    public void setPartId(int partId) {
        this.partId = partId;
    }

    public String getNoteNumber() {
        return noteNumber;
    }

    public void setNoteNumber(String noteNumber) {
        this.noteNumber = noteNumber;
    }

    public String getCustomerRequirement() { 
        return customerRequirement;
    }

    public void setCustomerRequirement(String customerRequirement) {
        this.customerRequirement = customerRequirement;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("PartCustomerRequirement{");
        sb.append("id=").append(id);
        sb.append(", partId=").append(partId);
        sb.append(", noteNumber='").append(noteNumber).append('\'');
        sb.append(", customerRequirement=").append(customerRequirement);
        sb.append('}');
        return sb.toString();
    }
}
