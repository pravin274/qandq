package com.qqs.qqsvcs.api;

import java.util.Collection;

public class ControlPlanCollection {
    private Collection<ControlPlan> controlPlans;

    public Collection<ControlPlan> getControlPlans() {
        return controlPlans;
    }

    public void setControlPlans(Collection<ControlPlan> controlPlans) {
        this.controlPlans = controlPlans;
    }
}
