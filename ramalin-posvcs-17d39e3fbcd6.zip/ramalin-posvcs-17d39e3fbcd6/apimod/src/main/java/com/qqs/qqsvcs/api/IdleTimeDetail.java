package com.qqs.qqsvcs.api;

import java.util.Objects;

public class IdleTimeDetail {

    private int id;
    private Integer idleTimeId;
    private Integer idleTimeInMins;
    private String reason;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getIdleTimeId() {
        return idleTimeId;
    }

    public void setIdleTimeId(Integer idleTimeId) {
        this.idleTimeId = idleTimeId;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Integer getIdleTimeInMins() { return idleTimeInMins; }

    public void setIdleTimeInMins(Integer idleTimeInMins) { this.idleTimeInMins = idleTimeInMins; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof IdleTimeDetail)) return false;
        IdleTimeDetail that = (IdleTimeDetail) o;
        return id == that.id &&
                idleTimeId.equals(that.idleTimeId) &&
                Objects.equals(idleTimeInMins, that.idleTimeInMins) &&
                reason.equals(that.reason);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, idleTimeId, idleTimeInMins, reason);
    }

    @Override
    public String toString() {
        return "IdleTimeDetail{" +
                "id=" + id +
                ", idleTimeId=" + idleTimeId +
                ", idleTimeInMins=" + idleTimeInMins +
                ", reason='" + reason + '\'' +
                '}';
    }
}
