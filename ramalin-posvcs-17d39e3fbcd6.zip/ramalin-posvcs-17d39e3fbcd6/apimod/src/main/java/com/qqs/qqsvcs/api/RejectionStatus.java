package com.qqs.qqsvcs.api;

import java.util.Date;

public class RejectionStatus {

    private Integer id;
    private Integer rejectionAssignId;
    private String rejectionStatus;
    private String actionTaken;
    private Date closedDate;
    private String remarks;
    private String activeStatus;
    private RejectionAssign rejectionAssign;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRejectionStatus() {
        return rejectionStatus;
    }

    public void setRejectionStatus(String rejectionStatus) {
        this.rejectionStatus = rejectionStatus;
    }

    public String getActionTaken() {
        return actionTaken;
    }

    public void setActionTaken(String actionTaken) {
        this.actionTaken = actionTaken;
    }

    public Date getClosedDate() {
        return closedDate;
    }

    public void setClosedDate(Date closedDate) {
        this.closedDate = closedDate;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Integer getRejectionAssignId() {
        return rejectionAssignId;
    }

    public void setRejectionAssignId(Integer rejectionAssignId) {
        this.rejectionAssignId = rejectionAssignId;
    }

    public String getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(String activeStatus) {
        this.activeStatus = activeStatus;
    }

    public RejectionAssign getRejectionAssign() {
        return rejectionAssign;
    }

    public void setRejectionAssign(RejectionAssign rejectionAssign) {
        this.rejectionAssign = rejectionAssign;
    }
}
