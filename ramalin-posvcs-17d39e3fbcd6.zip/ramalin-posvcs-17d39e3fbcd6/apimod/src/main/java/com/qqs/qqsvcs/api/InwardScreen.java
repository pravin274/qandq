package com.qqs.qqsvcs.api;

import java.util.Date;


public class InwardScreen {
    private int id;
    private Integer partId;
    private Integer customerId;
    private String poNumber;
    private String dcNumber;
    private String qtyOfPiece;
    private Date dateReceived;

    
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public Integer getPartId() {
			return partId;
		}
		public void setPartId(Integer partId) {
			this.partId = partId;
		}
		public Integer getCustomerId() {
			return customerId;
		}
		public void setCustomerId(Integer customerId) {
			this.customerId = customerId;
		}
		public String getPoNumber() {
			return poNumber;
		}
		public void setPoNumber(String poNumber) {
			this.poNumber = poNumber;
		}
		public String getDcNumber() {
			return dcNumber;
		}
		public void setDcNumber(String dcNumber) {
			this.dcNumber = dcNumber;
		}
		public String getQtyOfPiece() {
			return qtyOfPiece;
		}
		public void setQtyOfPiece(String qtyOfPiece) {
			this.qtyOfPiece = qtyOfPiece;
		}
		public Date getDateReceived() {
			return dateReceived;
		}
		public void setDateReceived(Date dateReceived) {
			this.dateReceived = dateReceived;
		}

}
