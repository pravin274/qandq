package com.qqs.posvcs.api;

import java.sql.Timestamp;

public class Phone {
    private int id;
    private Integer parentId;
    private String parentEntity;
    private String type;
    private String phoneNo;
    private String extension;;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public String getParentEntity() {
        return parentEntity;
    }

    public void setParentEntity(String parentEntity) {
        this.parentEntity = parentEntity;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Phone{");
        sb.append("id=").append(id);
        sb.append(", parentId=").append(parentId);
        sb.append(", parentEntity='").append(parentEntity).append('\'');
        sb.append(", type='").append(type).append('\'');
        sb.append(", phoneNo='").append(phoneNo).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
