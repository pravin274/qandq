package com.qqs.qqsvcs.api;


import java.sql.Timestamp;
import java.util.Date;
import java.util.Objects;

public class Schedule {
    private int id;
    private Integer partId;
    private Date schFromDate;
    private Date schToDate;
    private Integer plannedQuantity;
    private String jobType;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getPartId() { return partId; }

    public void setPartId(Integer partId) { this.partId = partId; }

    public Date getSchFromDate() {
        return schFromDate;
    }

    public void setSchFromDate(Date schFromDate) {
        this.schFromDate = schFromDate;
    }

    public Date getSchToDate() {
        return schToDate;
    }

    public void setSchToDate(Date schToDate) {
        this.schToDate = schToDate;
    }

    public Integer getPlannedQuantity() { return plannedQuantity; }

    public void setPlannedQuantity(Integer plannedQuantity) { this.plannedQuantity = plannedQuantity; }

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Schedule schedule = (Schedule) o;

        if (id != schedule.id) return false;
        if (!Objects.equals(partId, schedule.partId)) return false;
        if (!Objects.equals(schFromDate, schedule.schFromDate)) return false;
        if (!Objects.equals(schToDate, schedule.schToDate)) return false;
        if (!Objects.equals(plannedQuantity, schedule.plannedQuantity)) return false;
        if (!Objects.equals(jobType, schedule.jobType)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (partId != null ? partId.hashCode() : 0);
        result = 31 * result + (schFromDate != null ? schFromDate.hashCode() : 0);
        result = 31 * result + (schToDate != null ? schToDate.hashCode() : 0);
        result = 31 * result + (plannedQuantity != null ? plannedQuantity.hashCode() : 0);
        result = 31 * result + (jobType != null ? jobType.hashCode() : 0);
        return result;
    }
}


