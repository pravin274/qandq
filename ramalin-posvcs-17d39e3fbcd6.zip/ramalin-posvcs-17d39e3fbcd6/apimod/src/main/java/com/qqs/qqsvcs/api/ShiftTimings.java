package com.qqs.qqsvcs.api;

import java.sql.Time;
import java.sql.Timestamp;
import java.util.Objects;

public class ShiftTimings {
    private int id;
    private int shiftId;
    private Time fromTime;
    private Time toTime;
    private Timestamp effectiveFrom;
    private Timestamp effectiveTo;

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public int getShiftId() { return shiftId; }

    public void setShiftId(int shiftId) { this.shiftId = shiftId; }

    public Time getFromTime() { return fromTime; }

    public void setFromTime(Time fromTime) { this.fromTime = fromTime; }

    public Time getToTime() { return toTime; }

    public void setToTime(Time toTime) { this.toTime = toTime; }

    public Timestamp getEffectiveFrom() { return effectiveFrom; }

    public void setEffectiveFrom(Timestamp effectiveFrom) { this.effectiveFrom = effectiveFrom; }

    public Timestamp getEffectiveTo() { return effectiveTo; }

    public void setEffectiveTo(Timestamp effectiveTo) { this.effectiveTo = effectiveTo; }

    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        if (!super.equals(object)) return false;

        ShiftTimings that = (ShiftTimings) object;

        if (id != that.id) return false;
        if (shiftId != that.shiftId) return false;
        if (!Objects.equals(fromTime, that.fromTime)) return false;
        if (!Objects.equals(toTime, that.toTime)) return false;
        if (!Objects.equals(effectiveFrom, that.effectiveFrom)) return false;
        if (!Objects.equals(effectiveTo, that.effectiveTo)) return false;

        return true;
    }

    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + id;
        result = 31 * result + shiftId;
        result = 31 * result + (fromTime != null ? fromTime.hashCode() : 0);
        result = 31 * result + (toTime != null ? toTime.hashCode() : 0);
        result = 31 * result + (effectiveTo != null ? effectiveTo.hashCode() : 0);
        result = 31 * result + (effectiveFrom != null ? effectiveFrom.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("ShitTimings{");
        sb.append("id=").append(id);
        sb.append(", shiftId='").append(shiftId).append('\'');
        sb.append(", fromTime='").append(fromTime).append('\'');
        sb.append(", toTime='").append(toTime).append('\'');
        sb.append(", effectiveFrom='").append(effectiveFrom).append('\'');
        sb.append(", effectiveTo='").append(effectiveTo).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
