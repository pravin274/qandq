package com.qqs.invsvcs.api;

import java.util.Map;
import java.util.Objects;

public class StockStatusDetails {

    private Integer productId;
    private String productType;
    private String productName;
    private Integer availableStock;
    private Map<String, Integer> processStageStock;

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Integer getAvailableStock() {
        return availableStock;
    }

    public void setAvailableStock(Integer availableStock) {
        this.availableStock = availableStock;
    }

    public Map<String, Integer> getProcessStageStock() {
        return processStageStock;
    }

    public void setProcessStageStock(Map<String, Integer> processStageStock) {
        this.processStageStock = processStageStock;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof StockStatusDetails)) return false;
        StockStatusDetails that = (StockStatusDetails) o;
        return Objects.equals(getProductId(), that.getProductId()) &&
                Objects.equals(getProductType(), that.getProductType()) &&
                Objects.equals(getProductName(), that.getProductName()) &&
                Objects.equals(getAvailableStock(), that.getAvailableStock()) &&
                Objects.equals(getProcessStageStock(), that.getProcessStageStock());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getProductId(), getProductType(), getProductName(), getAvailableStock(), getProcessStageStock());
    }
}
