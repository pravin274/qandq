package com.qqs.posvcs.api.reports;

public class AtsContentSheet {
    private int id;
    private Integer atsId;
    private String contentCode;
    private String description;
    private String fileName;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getAtsId() {
        return atsId;
    }

    public void setAtsId(Integer atsId) {
        this.atsId = atsId;
    }

    public String getContentCode() {
        return contentCode;
    }

    public void setContentCode(String contentCode) {
        this.contentCode = contentCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AtsContentSheet atsContentSheet = (AtsContentSheet) o;

        if (contentCode != null ? !contentCode.equals(atsContentSheet.contentCode) : atsContentSheet.contentCode != null) return false;
        if (description != null ? !description.equals(atsContentSheet.description) : atsContentSheet.description != null) return false;
        if (fileName != null ? !fileName.equals(atsContentSheet.fileName) : atsContentSheet.fileName != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (contentCode != null ? contentCode.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (fileName != null ? fileName.hashCode() : 0);

        return result;
    }
}
