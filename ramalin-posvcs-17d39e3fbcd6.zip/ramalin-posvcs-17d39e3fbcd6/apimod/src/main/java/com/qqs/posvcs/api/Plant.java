package com.qqs.posvcs.api;

import com.qqs.posvcs.api.common.People;

import java.util.Collection;
import java.util.List;

public class Plant {
    private int id;
    private int companyId;
    private Company company;
    private String plantCode;
    private String description;
    private String vendorCode;
    private String domesticInd;
    private String currency;
    private String dutyStruct;
    private String taxId;
    private List<Address> addresses;
    private List<People> people;
    private List<PlantDeliveryTerms> plantDeliveryTerms;
    private List<PlantPaymentTerms> plantPaymentTerms;
    private Collection<Email> emails;
    private Collection<Phone> phones;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCompanyId() {
        return companyId;
    }

    public void setCompanyId(int companyId) {
        this.companyId = companyId;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public String getPlantCode() {
        return plantCode;
    }

    public void setPlantCode(String plantCode) {
        this.plantCode = plantCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getVendorCode() {
        return vendorCode;
    }

    public void setVendorCode(String vendorCode) {
        this.vendorCode = vendorCode;
    }

    public String getDomesticInd() {
        return domesticInd;
    }

    public void setDomesticInd(String domesticInd) {
        this.domesticInd = domesticInd;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getDutyStruct() {
        return dutyStruct;
    }

    public void setDutyStruct(String dutyStruct) {
        this.dutyStruct = dutyStruct;
    }

    public String getTaxId() {
        return taxId;
    }

    public void setTaxId(String taxId) {
        this.taxId = taxId;
    }

    public List<PlantDeliveryTerms> getPlantDeliveryTerms() { return plantDeliveryTerms; }

    public void setPlantDeliveryTerms(List<PlantDeliveryTerms> plantDeliveryTerms) { this.plantDeliveryTerms = plantDeliveryTerms; }

    public List<PlantPaymentTerms> getPlantPaymentTerms() { return plantPaymentTerms; }

    public void setPlantPaymentTerms(List<PlantPaymentTerms> plantPaymentTerms) { this.plantPaymentTerms = plantPaymentTerms; }

    public Collection<Email> getEmails() { return emails; }

    public void setEmails(Collection<Email> emails) { this.emails = emails; }

    public Collection<Phone> getPhones() { return phones; }

    public void setPhones(Collection<Phone> phones) { this.phones = phones; }

    public List<Address> getAddresses() {
        return addresses;
    }

    public void setAddresses(List<Address> addresses) {
        this.addresses = addresses;
    }

    public List<People> getPeople() {
        return people;
    }

    public void setPeople(List<People> people) {
        this.people = people;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Plant{");
        sb.append("id=").append(id);
        sb.append(", company=").append(company);
        sb.append(", plantCode='").append(plantCode).append('\'');
        sb.append(", desc='").append(description).append('\'');
        sb.append(", vendorCode='").append(vendorCode).append('\'');
        sb.append(", domesticInd='").append(domesticInd).append('\'');
        sb.append(", currency='").append(currency).append('\'');
        sb.append(", plantDeliveryTerms='").append(plantDeliveryTerms).append('\'');
        sb.append(", plantPaymentTerms='").append(plantPaymentTerms).append('\'');
        sb.append(", dutyStruct='").append(dutyStruct).append('\'');
        sb.append(", taxId='").append(taxId).append('\'');
        sb.append(", addresses=").append(addresses);
        sb.append('}');
        return sb.toString();
    }
}
