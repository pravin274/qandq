package com.qqs.qqsvcs.api;

import java.sql.Timestamp;

public class ToolXHolder {
    private int id;
    private int toolId;
    private int holderId;

    private Tool tool;
    private Holder holder;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public int getToolId() { return toolId; }

    public void setToolId(int toolId) { this.toolId = toolId; }

    public int getHolderId() { return holderId; }

    public void setHolderId(int holderId) { this.holderId = holderId; }

    public Tool getTool() { return tool; }

    public void setTool(Tool tool) { this.tool = tool; }

    public Holder getHolder() { return holder; }

    public void setHolder(Holder holder) { this.holder = holder; }

    public Integer getCreatedBy() { return createdBy; }

    public void setCreatedBy(Integer createdBy) { this.createdBy = createdBy; }

    public Timestamp getCreatedDt() { return createdDt; }

    public void setCreatedDt(Timestamp createdDt) { this.createdDt = createdDt; }

    public Integer getModifiedBy() { return modifiedBy; }

    public void setModifiedBy(Integer modifiedBy) { this.modifiedBy = modifiedBy; }

    public Timestamp getModifiedDt() { return modifiedDt; }

    public void setModifiedDt(Timestamp modifiedDt) { this.modifiedDt = modifiedDt; }


    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        if (!super.equals(object)) return false;

        ToolXHolder that = (ToolXHolder) object;

        if (id != that.id) return false;
        if (toolId != that.toolId) return false;
        if (holderId != that.holderId) return false;
        if (tool != null ? !tool.equals(that.tool) : that.tool != null) return false;
        if (holder != null ? !holder.equals(that.holder) : that.holder != null) return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (createdDt != null ? !createdDt.equals(that.createdDt) : that.createdDt != null) return false;
        if (modifiedBy != null ? !modifiedBy.equals(that.modifiedBy) : that.modifiedBy != null) return false;
        if (modifiedDt != null ? !modifiedDt.equals(that.modifiedDt) : that.modifiedDt != null) return false;

        return true;
    }

    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + id;
        result = 31 * result + holderId;
        result = 31 * result + toolId;
        result = 31 * result + (tool != null ? tool.hashCode() : 0);
        result = 31 * result + (holder != null ? holder.hashCode() : 0);
        result = 31 * result + (createdDt != null ? createdDt.hashCode() : 0);
        result = 31 * result + (modifiedDt != null ? modifiedDt.hashCode() : 0);
        return result;
    }
}
