package com.qqs.qqsvcs.api.reports;

import java.util.Objects;

public class ToolChangeReportData{

    String machineName;
    String part;
    String partSerialNo;
    String tool;
    String insertName;
    String holder;
    String reason;
    String operatorName;
    String time;
	String shift;

    public String getMachineName() {
		return machineName;
	}
	public void setMachineName(String machineName) {
		this.machineName = machineName;
	}
	public String getPart() {
		return part;
	}
	public void setPart(String part) {
		this.part = part;
	}
	public String getPartSerialNo() {
		return partSerialNo;
	}
	public void setPartSerialNo(String partSerialNo) {
		this.partSerialNo = partSerialNo;
	}
	public String getTool() {
		return tool;
	}
	public void setTool(String tool) {
		this.tool = tool;
	}
	public String getInsertName() {
		return insertName;
	}

	public void setInsertName(String insertName) {
		this.insertName = insertName;
	}
	public String getHolder() {
		return holder;
	}
	public void setHolder(String holder) {
		this.holder = holder;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getOperatorName() {
		return operatorName;
	}
	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getShift() {
		return shift;
	}
	public void setShift(String shift) {
		this.shift = shift;
	}


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ToolChangeReportData toolChangeReportData = (ToolChangeReportData) o;

        if (!Objects.equals(machineName, toolChangeReportData.machineName)) return false;
        if (!Objects.equals(part, toolChangeReportData.part)) return false;
        if (!Objects.equals(partSerialNo, toolChangeReportData.partSerialNo)) return false;        
        if (!Objects.equals(tool, toolChangeReportData.tool)) return false;
        if (!Objects.equals(insertName, toolChangeReportData.insertName)) return false;
        if (!Objects.equals(holder, toolChangeReportData.holder)) return false;
        if (!Objects.equals(reason, toolChangeReportData.reason)) return false;
        if (!Objects.equals(operatorName, toolChangeReportData.operatorName)) return false;
        if (!Objects.equals(time, toolChangeReportData.time)) return false;
		if (!Objects.equals(shift, toolChangeReportData.shift)) return false;

		return true;
    }

     @Override
    public int hashCode() {
        int result = (machineName != null ? machineName.hashCode() : 0);
        result = 31 * result + (part != null ? part.hashCode() : 0);
        result = 31 * result + (partSerialNo != null ? partSerialNo.hashCode() : 0);
        result = 31 * result + (tool != null ? tool.hashCode() : 0);
        result = 31 * result + (insertName != null ? insertName.hashCode() : 0);
        result = 31 * result + (holder != null ? holder.hashCode() : 0);
        result = 31 * result + (reason != null ? reason.hashCode() : 0);
        result = 31 * result + (operatorName != null ? operatorName.hashCode() : 0);
        result = 31 * result + (time != null ? time.hashCode() : 0);
		 result = 31 * result + (shift != null ? shift.hashCode() : 0);


		 return result;
    }
    

}
