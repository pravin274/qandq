package com.qqs.posvcs.api.parts;


import java.sql.Timestamp;

public class Standard {
    private int id;
    private String standardNumber;
    private String specType;
    private String standardDescription;
    private String revisionNumber;
    private String standardLink;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStandardNumber() {
        return standardNumber;
    }

    public void setStandardNumber(String standardNumber) {
        this.standardNumber = standardNumber;
    }

    public String getSpecType() {
        return specType;
    }

    public void setSpecType(String specType) {
        this.specType = specType;
    }

    public String getStandardDescription() {
        return standardDescription;
    }

    public void setStandardDescription(String standardDescription) {
        this.standardDescription = standardDescription;
    }
 
    public String getStandardLink() { 
        return standardLink;
    }

    public void setStandardLink(String standardLink) {
        this.standardLink = standardLink;
    }
    public String getRevisionNumber() { 
        return revisionNumber;
    }

    public void setRevisionNumber(String revisionNumber) {
        this.revisionNumber = revisionNumber;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Standard{");
        sb.append("id=").append(id);
        sb.append(", standardNumber='").append(standardNumber).append('\'');
        sb.append(", standardDescription=").append(standardDescription);
        sb.append(", revisionNumber=").append(revisionNumber);
        sb.append(", standardLink=").append(standardLink);
        sb.append('}');
        return sb.toString();
    }
}
