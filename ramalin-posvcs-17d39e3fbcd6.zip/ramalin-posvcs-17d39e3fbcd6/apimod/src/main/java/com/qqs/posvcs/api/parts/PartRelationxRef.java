package com.qqs.posvcs.api.parts;

public class PartRelationxRef {
    private int id;
    private int parentId;
    private int childId;
    private Integer qty;
    private Part childPart;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getParentId() { return parentId; }

    public void setParentId(int parentId) { this.parentId = parentId; }

    public int getChildId() { return childId; }

    public void setChildId(int childId) { this.childId = childId; }

    public Integer getQty() {
        return qty;
    }

    public void setQty(Integer qty) {
        this.qty = qty;
    }

    public Part getChildPart() { return childPart; }

    public void setChildPart(Part childPart) { this.childPart = childPart; }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("PartRelationxRef{");
        sb.append("id=").append(id);
        sb.append(", parentId=").append(parentId);
        sb.append(", childId=").append(childId);
        sb.append(", qty=").append(qty);
        sb.append(", childPart=").append(childPart.toString());
        sb.append('}');
        return sb.toString();
    }
}
