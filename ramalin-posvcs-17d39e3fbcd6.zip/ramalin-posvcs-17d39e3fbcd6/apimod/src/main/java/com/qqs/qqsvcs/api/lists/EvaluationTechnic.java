package com.qqs.qqsvcs.api.lists;

import java.util.Arrays;
import java.util.List;

public enum EvaluationTechnic implements ListItem{
    CMM ("CMM", ""),
    VERNIER ("Digital Vernier Caliper", "");

    private String description;
    private String otherInfo;

    EvaluationTechnic(String description, String otherInfo) {
        this.description = description;
        this.otherInfo = otherInfo;
    }

    public String getDescription() {
        return description;
    }

    public String getOtherInfo() {
        return otherInfo;
    }

    public List<ListItem> getValues() {
        List<ListItem> result = Arrays.asList(values());
        return result;
    }

    public String getName() {
        return name();
    }
}
