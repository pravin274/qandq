package com.qqs.qqsvcs.api;

import java.io.Serializable;
import java.sql.Timestamp;

public class ControlTaskValidation implements Serializable {
    private int id;
    private Integer controlTaskId;
    private Integer controlItemId;
    private String actualValue;
    private ControlPlanItem controlPlanItem;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getControlTaskId() {
        return controlTaskId;
    }

    public void setControlTaskId(Integer controlTaskId) {
        this.controlTaskId = controlTaskId;
    }

    public Integer getControlItemId() {
        return controlItemId;
    }

    public void setControlItemId(Integer controlItemId) {
        this.controlItemId = controlItemId;
    }

    public ControlPlanItem getControlPlanItem() { return controlPlanItem; }

    public void setControlPlanItem(ControlPlanItem controlPlanItem) { this.controlPlanItem = controlPlanItem; }

    public String getActualValue() {
        return actualValue;
    }

    public void setActualValue(String actualValue) {
        this.actualValue = actualValue;
    }

    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("ControlTaskValidation{");
        sb.append("id=").append(id);
        sb.append(", controlTaskId=").append(controlTaskId);
        sb.append(", controlItemId=").append(controlItemId);
        sb.append(", actualValue='").append(actualValue).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
