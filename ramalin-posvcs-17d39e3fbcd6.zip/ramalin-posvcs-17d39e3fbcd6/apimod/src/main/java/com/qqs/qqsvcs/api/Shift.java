package com.qqs.qqsvcs.api;

import java.util.List;
import java.util.Objects;

public class Shift {
    private int id;
    private String shiftCode;
    private String shiftName;
    private List<ShiftTimings> shiftTimingsList;

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public String getShiftCode() { return shiftCode; }

    public void setShiftCode(String shiftCode) { this.shiftCode = shiftCode; }

    public String getShiftName() { return shiftName; }

    public void setShiftName(String shiftName) { this.shiftName = shiftName; }

    public List<ShiftTimings> getShiftTimingsList() { return shiftTimingsList; }

    public void setShiftTimingsList(List<ShiftTimings> shiftTimingsList) { this.shiftTimingsList = shiftTimingsList; }

    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        if (!super.equals(object)) return false;

        Shift that = (Shift) object;

        if (id != that.id) return false;
        if (!Objects.equals(shiftCode, that.shiftCode)) return false;
        if (!Objects.equals(shiftName, that.shiftName)) return false;
        if (!Objects.equals(shiftTimingsList, that.shiftTimingsList)) return false;
        return true;
    }

    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + id;
        result = 31 * result + (shiftName != null ? shiftName.hashCode() : 0);
        result = 31 * result + (shiftCode != null ? shiftCode.hashCode() : 0);
        result = 31 * result + (shiftTimingsList != null ? shiftTimingsList.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Shift{");
        sb.append("id=").append(id);
        sb.append(", shiftCode='").append(shiftCode).append('\'');
        sb.append(", shiftName='").append(shiftName).append('\'');
        sb.append(", shiftTimingsList='").append(shiftTimingsList).append('\'');
        sb.append('}');
        return sb.toString();
    }

}
