package com.qqs.qqsvcs.api;

import java.sql.Timestamp;
import java.util.Objects;
import java.util.Set;

public class ControlTask {
    private int id;
    private Integer controlProcessId;
    private Integer controlPlanId;
    private Integer machineId;
    private Integer runningNumber;
    private Integer otherFrequency;
    private String heatNo;
    private Integer partSerialNo;
    private String heatNoSerialNo;
    private String processStatus;
    private String partStatus;
    private String taskType;
    private String rejectionSingleWord;
    private String reason;
    private String processNo;
    private Integer toolLayoutId;
    private Integer operatorId;
    private Timestamp operateDt;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;
    private Set<ControlTaskValidation> taskValidations;
    private Set<ToolChange> toolChanges;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getMachineId() {
        return machineId;
    }

    public void setMachineId(Integer machineId) {
        this.machineId = machineId;
    }

    public Integer getRunningNumber() {
        return runningNumber;
    }

    public void setRunningNumber(Integer runningNumber) {
        this.runningNumber = runningNumber;
    }

    public Integer getOtherFrequency() { return otherFrequency; }

    public void setOtherFrequency(Integer otherFrequency) { this.otherFrequency = otherFrequency; }

    public String getHeatNo() { return heatNo; }

    public void setHeatNo(String heatNo) {
        this.heatNo = heatNo;
        populateHeatNoSerialNo();
    }

    public Integer getPartSerialNo() {
        return partSerialNo;
    }

    public void setPartSerialNo(Integer partSerialNo) {
        this.partSerialNo = partSerialNo;
        populateHeatNoSerialNo();
    }

    public String getHeatNoSerialNo() { return heatNoSerialNo; }

    public void setHeatNoSerialNo(String heatNoSerialNo) { this.heatNoSerialNo = heatNoSerialNo; }

    public String getPartStatus() {
        return partStatus;
    }

    public void setPartStatus(String partStatus) {
        this.partStatus = partStatus;
    }

    public String getRejectionSingleWord() {
        return rejectionSingleWord;
    }

    public void setRejectionSingleWord(String rejectionSingleWord) {
        this.rejectionSingleWord = rejectionSingleWord;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Set<ControlTaskValidation> getTaskValidations() {
        return taskValidations;
    }

    public void setTaskValidations(Set<ControlTaskValidation> taskValidations) {
        this.taskValidations = taskValidations;
    }

    public String getProcessStatus() {
        return processStatus;
    }

    public void setProcessStatus(String processStatus) {
        this.processStatus = processStatus;
    }

    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType;
    }

    public Integer getControlProcessId() {
        return controlProcessId;
    }

    public void setControlProcessId(Integer controlProcessId) {
        this.controlProcessId = controlProcessId;
    }

    public Integer getControlPlanId() {
        return controlPlanId;
    }

    public void setControlPlanId(Integer controlPlanId) {
        this.controlPlanId = controlPlanId;
    }

    public String getProcessNo() {
        return processNo;
    }

    public void setProcessNo(String processNo) {
        this.processNo = processNo;
    }

    public Integer getToolLayoutId() {
        return toolLayoutId;
    }

    public void setToolLayoutId(Integer toolLayoutId) {
        this.toolLayoutId = toolLayoutId;
    }

    public Set<ToolChange> getToolChanges() { return toolChanges; }

    public void setToolChanges(Set<ToolChange> toolChanges) { this.toolChanges = toolChanges; }

    public Integer getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(Integer operatorId) {
        this.operatorId = operatorId;
    }

    public Timestamp getOperateDt() {
        return operateDt;
    }

    public void setOperateDt(Timestamp operateDt) {
        this.operateDt = operateDt;
    }

    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    private void populateHeatNoSerialNo() {
        this.heatNoSerialNo = this.heatNo + '-' + this.partSerialNo;
    }

    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        if (!super.equals(object)) return false;

        ControlTask that = (ControlTask) object;

        if (id != that.id) return false;
        if (controlProcessId != that.controlProcessId) return false;

        if (!Objects.equals(machineId, that.machineId)) return false;
        if (!Objects.equals(runningNumber, that.runningNumber)) return false;
        if (!Objects.equals(otherFrequency, that.otherFrequency)) return false;
        if (!Objects.equals(heatNo, that.heatNo)) return false;
        if (!Objects.equals(heatNoSerialNo, that.heatNoSerialNo)) return false;
        if (!Objects.equals(partSerialNo, that.partSerialNo)) return false;
        if (!Objects.equals(partStatus, that.partStatus)) return false;
        if (!Objects.equals(reason, that.reason)) return false;
        if (!Objects.equals(createdBy, that.createdBy)) return false;
        if (!Objects.equals(createdDt, that.createdDt)) return false;
        if (!Objects.equals(modifiedBy, that.modifiedBy)) return false;
        if (!Objects.equals(modifiedDt, that.modifiedDt)) return false;

        return true;
    }

    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + id;

        result = 31 * result + (controlProcessId != null ? controlProcessId.hashCode() : 0);
        result = 31 * result + (machineId != null ? machineId.hashCode() : 0);
        result = 31 * result + (runningNumber != null ? runningNumber.hashCode() : 0);
        result = 31 * result + (otherFrequency != null ? otherFrequency.hashCode() : 0);
        result = 31 * result + (heatNo != null ? heatNo.hashCode() : 0);
        result = 31 * result + (heatNoSerialNo != null ? heatNoSerialNo.hashCode() : 0);
        result = 31 * result + (partSerialNo != null ? partSerialNo.hashCode() : 0);
        result = 31 * result + (partStatus != null ? partStatus.hashCode() : 0);
        result = 31 * result + (reason != null ? reason.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDt != null ? createdDt.hashCode() : 0);
        result = 31 * result + (modifiedBy != null ? modifiedBy.hashCode() : 0);
        result = 31 * result + (modifiedDt != null ? modifiedDt.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("ControlTask{");
        sb.append("id=").append(id);
        sb.append(", machineId=").append(machineId);
        sb.append(", runningNumber=").append(runningNumber);
        sb.append(", otherFrequency=").append(otherFrequency);
        sb.append(", heatNo='").append(heatNo).append('\'');
        sb.append(", heatNoSerialNo='").append(heatNoSerialNo).append('\'');
        sb.append(", partSerialNo='").append(partSerialNo).append('\'');
        sb.append(", partStatus=").append(partStatus);
        sb.append(", reason='").append(reason).append('\'');
        sb.append(", createdBy=").append(createdBy);
        sb.append(", createdDt=").append(createdDt);
        sb.append(", modifiedBy=").append(modifiedBy);
        sb.append(", modifiedDt=").append(modifiedDt);
        sb.append('}');
        return sb.toString();
    }
}
