package com.qqs.invsvcs.api;

import java.sql.Timestamp;
import java.util.Objects;

public class SupplierXProduct {
    private int id;
    private Integer productId;
    private Integer supplierId;
    private Integer brandId;
    private Double cost;
    private Double mbq;
    private Integer leadTimeInDays;
    private Timestamp effectiveFrom;
    private Timestamp effectiveTo;
    private Product product;
    private ProductBrand brand;
    private String ispreferred;
    private String productType;
    private Integer prefpercent;
    private String productName;
    private InvProductDetails invProductDetails;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(Integer supplierId) {
        this.supplierId = supplierId;
    }

    public Integer getBrandId() {
        return brandId;
    }

    public void setBrandId(Integer brandId) {
        this.brandId = brandId;
    }

    public Double getCost() {
        return cost;
    }

    public void setCost(Double cost) {
        this.cost = cost;
    }

    public Double getMbq() {
        return mbq;
    }

    public void setMbq(Double mbq) {
        this.mbq = mbq;
    }

    public Integer getLeadTimeInDays() {
        return leadTimeInDays;
    }

    public void setLeadTimeInDays(Integer leadTimeInDays) {
        this.leadTimeInDays = leadTimeInDays;
    }

    public Timestamp getEffectiveFrom() {
        return effectiveFrom;
    }

    public void setEffectiveFrom(Timestamp effectiveFrom) {
        this.effectiveFrom = effectiveFrom;
    }

    public Timestamp getEffectiveTo() {
        return effectiveTo;
    }

    public void setEffectiveTo(Timestamp effectiveTo) {
        this.effectiveTo = effectiveTo;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public ProductBrand getBrand() {
        return brand;
    }

    public void setBrand(ProductBrand brand) {
        this.brand = brand;
    }

    public String getIspreferred() {
        return ispreferred;
    }

    public void setIspreferred(String ispreferred) {
        this.ispreferred = ispreferred;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public Integer getPrefpercent() {
        return prefpercent;
    }

    public void setPrefpercent(Integer prefpercent) {
        this.prefpercent = prefpercent;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public InvProductDetails getInvProductDetails() {
        return invProductDetails;
    }

    public void setInvProductDetails(InvProductDetails invProductDetails) {
        this.invProductDetails = invProductDetails;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SupplierXProduct)) return false;
        SupplierXProduct that = (SupplierXProduct) o;
        return getId() == that.getId() &&
                Objects.equals(getProductId(), that.getProductId()) &&
                Objects.equals(getSupplierId(), that.getSupplierId()) &&
                Objects.equals(getBrandId(), that.getBrandId()) &&
                Objects.equals(getCost(), that.getCost()) &&
                Objects.equals(getMbq(), that.getMbq()) &&
                Objects.equals(getLeadTimeInDays(), that.getLeadTimeInDays()) &&
                Objects.equals(getEffectiveFrom(), that.getEffectiveFrom()) &&
                Objects.equals(getEffectiveTo(), that.getEffectiveTo()) &&
                Objects.equals(getProduct(), that.getProduct()) &&
                Objects.equals(getBrand(), that.getBrand()) &&
                Objects.equals(getIspreferred(), that.getIspreferred()) &&
                Objects.equals(getProductType(), that.getProductType()) &&
                Objects.equals(getPrefpercent(), that.getPrefpercent()) &&
                Objects.equals(getProductName(), that.getProductName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getProductId(), getSupplierId(), getBrandId(), getCost(), getMbq(), getLeadTimeInDays(), getEffectiveFrom(), getEffectiveTo(), getProduct(), getBrand(), getIspreferred(), getProductType(), getPrefpercent(), getProductName());
    }
}
