package com.qqs.invsvcs.api;

import com.qqs.posvcs.api.Address;
import com.qqs.posvcs.api.Email;
import com.qqs.posvcs.api.Phone;
import com.qqs.posvcs.api.common.People;

import java.util.Collection;
import java.util.List;
import java.util.Objects;

public class Supplier {
    private int id;
    private String name;
    private Boolean status;
    private String gstNo;
    private String paymentTerm;
    private String splInstruction;
    private String note;
    private String vendorCode;
    private List<SupplierXProduct> supplierXProduct;
    private List<People> people;
    private Collection<Email> emails;
    private Collection<Phone> phones;
    private List<Address> addresses;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public Boolean getStatus() { return status; }

    public void setStatus(Boolean status) { this.status = status; }

    public String getGstNo() {
        return gstNo;
    }

    public void setGstNo(String gstNo) {
        this.gstNo = gstNo;
    }


    public String getPaymentTerm() {
        return paymentTerm;
    }

    public void setPaymentTerm(String paymentTerm) {
        this.paymentTerm = paymentTerm;
    }

    public String getSplInstruction() {
        return splInstruction;
    }

    public void setSplInstruction(String splInstruction) {
        this.splInstruction = splInstruction;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getVendorCode() {
        return vendorCode;
    }

    public void setVendorCode(String vendorCode) {
        this.vendorCode = vendorCode;
    }


    public List<SupplierXProduct> getSupplierXProduct() {
        return supplierXProduct;
    }

    public void setSupplierXProduct(List<SupplierXProduct> supplierXProduct) {
        this.supplierXProduct = supplierXProduct;
    }

    public Collection<Email> getEmails() { return emails; }

    public void setEmails(Collection<Email> emails) { this.emails = emails; }

    public Collection<Phone> getPhones() { return phones; }

    public void setPhones(Collection<Phone> phones) { this.phones = phones; }

    public List<People> getPeople() {
        return people;
    }

    public void setPeople(List<People> people) {
        this.people = people;
    }

    public List<Address> getAddresses() {
        return addresses;
    }

    public void setAddresses(List<Address> addresses) {
        this.addresses = addresses;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Supplier)) return false;
        Supplier supplier = (Supplier) o;
        return getId() == supplier.getId() &&
                Objects.equals(getName(), supplier.getName()) &&
                Objects.equals(getStatus(), supplier.getStatus()) &&
                Objects.equals(getGstNo(), supplier.getGstNo()) &&
                Objects.equals(getPaymentTerm(), supplier.getPaymentTerm()) &&
                Objects.equals(getSplInstruction(), supplier.getSplInstruction()) &&
                Objects.equals(getNote(), supplier.getNote()) &&
                Objects.equals(getVendorCode(), supplier.getVendorCode()) &&
                Objects.equals(getSupplierXProduct(), supplier.getSupplierXProduct()) &&
                Objects.equals(getPeople(), supplier.getPeople()) &&
                Objects.equals(getEmails(), supplier.getEmails()) &&
                Objects.equals(getPhones(), supplier.getPhones()) &&
                Objects.equals(getAddresses(), supplier.getAddresses());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getName(), getStatus(), getGstNo(), getPaymentTerm(), getSupplierXProduct(), getSplInstruction(),
                getNote(), getVendorCode(), getPeople(), getEmails(), getPhones(), getAddresses());
    }
}
