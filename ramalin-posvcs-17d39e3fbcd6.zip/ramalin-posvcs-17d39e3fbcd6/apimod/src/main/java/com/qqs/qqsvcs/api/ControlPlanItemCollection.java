package com.qqs.qqsvcs.api;

import java.util.Collection;

public class ControlPlanItemCollection {
    private Collection<ControlPlanItem> controlPlanItems;

    public Collection<ControlPlanItem> getControlPlanItems() {
        return controlPlanItems;
    }

    public void setControlPlanItems(Collection<ControlPlanItem> controlPlanItems) {
        this.controlPlanItems = controlPlanItems;
    }
}
