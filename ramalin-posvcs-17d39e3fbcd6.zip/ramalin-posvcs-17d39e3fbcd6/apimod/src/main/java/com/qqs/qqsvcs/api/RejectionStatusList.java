package com.qqs.qqsvcs.api;

import java.util.Date;

public class RejectionStatusList {
    private Integer id;
    private Integer rejectionAssignId;
    private String rejectionStatus;
    private String actionTaken;
    private Date closedDate;
    private String remark;
    private String activeStatus;
    private Integer responsibilityPersonId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getRejectionAssignId() {
        return rejectionAssignId;
    }

    public void setRejectionAssignId(Integer rejectionAssignId) {
        this.rejectionAssignId = rejectionAssignId;
    }

    public String getRejectionStatus() {
        return rejectionStatus;
    }

    public void setRejectionStatus(String rejectionStatus) {
        this.rejectionStatus = rejectionStatus;
    }

    public String getActionTaken() {
        return actionTaken;
    }

    public void setActionTaken(String actionTaken) {
        this.actionTaken = actionTaken;
    }

    public Date getClosedDate() {
        return closedDate;
    }

    public void setClosedDate(Date closedDate) {
        this.closedDate = closedDate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(String activeStatus) {
        this.activeStatus = activeStatus;
    }

    public Integer getResponsibilityPersonId() {
        return responsibilityPersonId;
    }

    public void setResponsibilityPersonId(Integer responsibilityPersonId) {
        this.responsibilityPersonId = responsibilityPersonId;
    }
}
