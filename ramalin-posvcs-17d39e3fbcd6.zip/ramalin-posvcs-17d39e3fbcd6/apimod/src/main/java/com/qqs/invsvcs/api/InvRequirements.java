package com.qqs.invsvcs.api;

import java.sql.Timestamp;
import java.util.Objects;

public class InvRequirements {
    private int id;
    private Integer productId;
    private String productType;
    private String productTypeDesc;
    private Timestamp reqFrom;
    private Timestamp reqTo;
    private Double reqQuantity;
    private Double unUsedQuantity;
    private Double avlQuantity;
    private Double reservedQuantity;
    private Double netReqQuantity;
    private String productName;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) { this.productType = productType; }

    public String getProductTypeDesc() { return productTypeDesc; }

    public void setProductTypeDesc(String productTypeDesc) { this.productTypeDesc = productTypeDesc; }

    public Timestamp getReqFrom() {
        return reqFrom;
    }

    public void setReqFrom(Timestamp reqFrom) {
        this.reqFrom = reqFrom;
    }

    public Timestamp getReqTo() {
        return reqTo;
    }

    public void setReqTo(Timestamp reqTo) {
        this.reqTo = reqTo;
    }

    public Double getReqQuantity() {
        return reqQuantity;
    }

    public void setReqQuantity(Double reqQuantity) {
        this.reqQuantity = reqQuantity;
    }

    public Double getUnUsedQuantity() {
        return unUsedQuantity;
    }

    public void setUnUsedQuantity(Double unUsedQuantity) {
        this.unUsedQuantity = unUsedQuantity;
    }

    public String getProductName() { return productName; }

    public void setProductName(String productName) { this.productName = productName; }

    public Double getAvlQuantity() { return avlQuantity; }

    public void setAvlQuantity(Double avlQuantity) { this.avlQuantity = avlQuantity; }

    public Double getReservedQuantity() { return reservedQuantity; }

    public void setReservedQuantity(Double reservedQuantity) { this.reservedQuantity = reservedQuantity; }

    public Double getNetReqQuantity() { return netReqQuantity; }

    public void setNetReqQuantity(Double netReqQuantity) { this.netReqQuantity = netReqQuantity; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InvRequirements product = (InvRequirements) o;
        return id == product.id &&
                productId == product.productId &&
                productType.equals(product.productType) &&
                productTypeDesc.equals(product.productTypeDesc) &&
                productName.equals(product.productName) &&
                reqFrom.equals(product.reqFrom) &&
                reqTo.equals(product.reqTo) &&
                reqQuantity.equals(product.reqQuantity) &&
                avlQuantity.equals(product.avlQuantity) &&
                reservedQuantity.equals(product.reservedQuantity) &&
                netReqQuantity.equals(product.netReqQuantity) &&
                unUsedQuantity.equals(product.unUsedQuantity);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, productId, productType, productTypeDesc, productName, reqFrom, reqTo, reqQuantity,
                avlQuantity, reservedQuantity, netReqQuantity, unUsedQuantity);
    }
}
