package com.qqs.invsvcs.api;

import java.util.Map;
import java.util.Objects;

public class PandLReportData {

    private String headsCatDesc;
    private String headsCat;
    private String heads;
    private String headsDesc;
    private String rowDisplayFormat;
    private Map<String, Double> monthPandLData;
    private Map<String, Integer> monthPercentData;

    public String getHeadsCatDesc() { return headsCatDesc; }

    public void setHeadsCatDesc(String headsCatDesc) { this.headsCatDesc = headsCatDesc; }

    public String getHeadsCat() { return headsCat; }

    public void setHeadsCat(String headsCat) { this.headsCat = headsCat; }

    public String getHeads() { return heads; }

    public void setHeads(String heads) { this.heads = heads; }

    public String getHeadsDesc() { return headsDesc; }

    public void setHeadsDesc(String headsDesc) { this.headsDesc = headsDesc; }

    public Map<String, Double> getMonthPandLData() { return monthPandLData; }

    public void setMonthPandLData(Map<String, Double> monthPandLData) { this.monthPandLData = monthPandLData; }

    public Map<String, Integer> getMonthPercentData() { return monthPercentData; }

    public void setMonthPercentData(Map<String, Integer> monthPercentData) { this.monthPercentData = monthPercentData; }

    public String getRowDisplayFormat() { return rowDisplayFormat; }

    public void setRowDisplayFormat(String rowDisplayFormat) { this.rowDisplayFormat = rowDisplayFormat; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PandLReportData)) return false;
        PandLReportData that = (PandLReportData) o;
        return Objects.equals(headsCatDesc, that.headsCatDesc) &&
                Objects.equals(headsCat, that.headsCat) &&
                Objects.equals(heads, that.heads) &&
                Objects.equals(headsDesc, that.headsDesc) &&
                Objects.equals(rowDisplayFormat, that.rowDisplayFormat) &&
                Objects.equals(monthPandLData, that.monthPandLData) &&
                Objects.equals(monthPercentData, that.monthPercentData);
    }

    @Override
    public int hashCode() {
        return Objects.hash(heads, headsCatDesc, headsCat, headsDesc, rowDisplayFormat, monthPercentData, monthPandLData);
    }

    @Override
    public String toString() {
        return "PandLReportData{" +
                ", headsCatDesc='" + headsCatDesc + '\'' +
                ", headsCat='" + headsCat + '\'' +
                ", heads='" + heads + '\'' +
                ", headsDesc='" + headsDesc + '\'' +
                ", headsDesc='" + rowDisplayFormat + '\'' +
                ", monthPandLData=" + monthPandLData.toString() +
                ", monthPercentData=" + monthPercentData.toString() +
                '}';
    }
}
