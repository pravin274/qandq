package com.qqs.qqsvcs.api;

import java.util.Objects;

public class Process {
    private int id;
    private Integer controlPlanId;
    private String processNumber;
    private String processName;
    private String processType;
    private Integer processOrder;
    private String machineType;
    private String reactionPlan;
    private String description;
    private String isFirstProcess;
    private Integer completionPercent;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getControlPlanId() {
        return controlPlanId;
    }

    public void setControlPlanId(Integer controlPlanId) {
        this.controlPlanId = controlPlanId;
    }

    public String getProcessNumber() {
        return processNumber;
    }

    public void setProcessNumber(String processNumber) {
        this.processNumber = processNumber;
    }

    public String getProcessName() {
        return processName;
    }

    public void setProcessName(String processName) {
        this.processName = processName;
    }

    public String getProcessType() {
        return processType;
    }

    public void setProcessType(String processType) {
        this.processType = processType;
    }

    public String getMachineType() {
        return machineType;
    }

    public void setMachineType(String machineType) {
        this.machineType = machineType;
    }

    public String getReactionPlan() {
        return reactionPlan;
    }

    public void setReactionPlan(String reactionPlan) {
        this.reactionPlan = reactionPlan;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getProcessOrder() { return processOrder; }

    public void setProcessOrder(Integer processOrder) { this.processOrder = processOrder; }

    public String getIsFirstProcess() {
        return isFirstProcess;
    }

    public void setIsFirstProcess(String isFirstProcess) {
        this.isFirstProcess = isFirstProcess;
    }

    public Integer getCompletionPercent() { return completionPercent; }

    public void setCompletionPercent(Integer completionPercent) { this.completionPercent = completionPercent; }

    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        if (!super.equals(object)) return false;

        Process that = (Process) object;

        if (id != that.id) return false;
        if (!Objects.equals(controlPlanId, that.controlPlanId)) return false;
        if (!Objects.equals(processNumber, that.processNumber)) return false;
        if (!Objects.equals(description, that.description)) return false;
        if (!Objects.equals(processName, that.processName)) return false;
        if (!Objects.equals(processOrder, that.processOrder)) return false;
        if (!Objects.equals(machineType, that.machineType)) return false;
        if (!Objects.equals(reactionPlan, that.reactionPlan)) return false;
        if (!Objects.equals(isFirstProcess, that.isFirstProcess)) return false;
        if (!Objects.equals(completionPercent, that.completionPercent)) return false;

        return true;
    }

    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + id;
        result = 31 * result + (controlPlanId != null ? controlPlanId.hashCode() : 0);
        result = 31 * result + (processNumber != null ? processNumber.hashCode() : 0);
        result = 31 * result + (processName != null ? processName.hashCode() : 0);
        result = 31 * result + (processOrder != null ? processOrder.hashCode() : 0);
        result = 31 * result + (machineType != null ? machineType.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (reactionPlan != null ? reactionPlan.hashCode() : 0);
        result = 31 * result + (isFirstProcess != null ? isFirstProcess.hashCode() : 0);
        result = 31 * result + (completionPercent != null ? completionPercent.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Process{");
        sb.append("id=").append(id);
        sb.append("controlPlanId=").append(controlPlanId);
        sb.append(", processNumber='").append(processNumber).append('\'');
        sb.append(", processName='").append(processName).append('\'');
        sb.append(", processOrder='").append(processOrder).append('\'');
        sb.append(", machineType='").append(machineType).append('\'');
        sb.append(", description='").append(description).append('\'');
        sb.append(", reactionPlan='").append(reactionPlan).append('\'');
        sb.append(", completionPercent='").append(completionPercent).append('\'');
        sb.append('}');
        return sb.toString();
    }
}

