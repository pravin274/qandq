package com.qqs.posvcs.api.parts;


import java.sql.Timestamp;

public class PartStandard {
    private int id;
    private int partId;
    private String standardNumber;
    private String standardDescription;
    private String standardSpecificDescription;
    private String revisionNumber;
    private String standardLink;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPartId() {
        return partId;
    }

    public void setPartId(int partId) {
        this.partId = partId;
    }

    public String getStandardNumber() {
        return standardNumber;
    }

    public void setStandardNumber(String standardNumber) {
        this.standardNumber = standardNumber;
    }

    public String getStandardDescription() { 
        return standardDescription;
    }

    public void setStandardDescription(String standardDescription) {
        this.standardDescription = standardDescription;
    }
    public String getStandardSpecificDescription() { 
        return standardSpecificDescription;
    }

    public void setStandardSpecificDescription(String standardSpecificDescription) {
        this.standardSpecificDescription = standardSpecificDescription;
    }
    public String getStandardLink() { 
        return standardLink;
    }

    public void setStandardLink(String standardLink) {
        this.standardLink = standardLink;
    }
    public String getRevisionNumber() { 
        return revisionNumber;
    }

    public void setRevisionNumber(String revisionNumber) {
        this.revisionNumber = revisionNumber;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("PartStandard{");
        sb.append("id=").append(id);
        sb.append(", partId=").append(partId);
        sb.append(", standardNumber='").append(standardNumber).append('\'');
        sb.append(", standardDescription=").append(standardDescription);
        sb.append(", standardSpecificDescription=").append(standardSpecificDescription);
        sb.append(", revisionNumber=").append(revisionNumber);
        sb.append(", standardLink=").append(standardLink);
        sb.append('}');
        return sb.toString();
    }
}
