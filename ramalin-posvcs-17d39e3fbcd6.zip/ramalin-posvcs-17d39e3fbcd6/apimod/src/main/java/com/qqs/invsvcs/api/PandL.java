package com.qqs.invsvcs.api;

import java.sql.Date;
import java.util.Objects;

public class PandL {
    private int id;
    private Integer headsId;
    private String amount;
    private String remarks;
    private Date fromDate;
    private Date toDate;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getHeadsId() {
        return headsId;
    }

    public void setHeadsId(Integer headsId) {
        this.headsId = headsId;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PandL pandL = (PandL) o;

        if (id != pandL.id) return false;
        if (!Objects.equals(headsId, pandL.headsId)) return false;
        if (!Objects.equals(amount, pandL.amount)) return false;
        if (!Objects.equals(remarks, pandL.remarks)) return false;
        if (!Objects.equals(fromDate, pandL.fromDate)) return false;
        if (!Objects.equals(toDate, pandL.toDate)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (headsId != null ? headsId.hashCode() : 0);
        result = 31 * result + (amount != null ? amount.hashCode() : 0);
        result = 31 * result + (remarks != null ? remarks.hashCode() : 0);
        result = 31 * result + (fromDate != null ? fromDate.hashCode() : 0);
        result = 31 * result + (toDate != null ? toDate.hashCode() : 0);
        return result;
    }


}
