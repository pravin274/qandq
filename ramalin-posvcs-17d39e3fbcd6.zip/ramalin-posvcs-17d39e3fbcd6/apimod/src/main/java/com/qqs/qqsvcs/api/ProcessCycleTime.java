package com.qqs.qqsvcs.api;

import java.util.Objects;

public class ProcessCycleTime {
    private int id;
    private Integer processId;
    private Integer machineId;
    private Integer cycleTimeMins;
    private Integer handleTimeMins;
    private Machine machine;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getProcessId() {
        return processId;
    }

    public void setProcessId(Integer processId) {
        this.processId = processId;
    }

    public Integer getMachineId() {
        return machineId;
    }

    public void setMachineId(Integer machineId) {
        this.machineId = machineId;
    }

    public Integer getCycleTimeMins() {
        return cycleTimeMins;
    }

    public void setCycleTimeMins(Integer cycleTimeMins) {
        this.cycleTimeMins = cycleTimeMins;
    }

   public Integer getHandleTimeMins() {
        return handleTimeMins;
    }

    public void setHandleTimeMins(Integer handleTimeMins) {
        this.handleTimeMins = handleTimeMins;
    }

    public Machine getMachine() {
        return machine;
    }

    public void setMachine(Machine machine) {
        this.machine = machine;
    }

    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        if (!super.equals(object)) return false;

        ProcessCycleTime that = (ProcessCycleTime) object;

        if (id != that.id) return false;
        if (!Objects.equals(processId, that.processId)) return false;
        if (!Objects.equals(machineId, that.machineId)) return false;
        if (!Objects.equals(cycleTimeMins, that.cycleTimeMins)) return false;
        if (!Objects.equals(handleTimeMins, that.handleTimeMins)) return false;


        return true;
    }

    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + id;
        result = 31 * result + (processId != null ? processId.hashCode() : 0);
        result = 31 * result + (machineId != null ? machineId.hashCode() : 0);
        result = 31 * result + (cycleTimeMins != null ? cycleTimeMins.hashCode() : 0);
        result = 31 * result + (handleTimeMins != null ? handleTimeMins.hashCode() : 0);

        return result;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Process{");
        sb.append("id=").append(id);
        sb.append("processId=").append(processId);
        sb.append(", machineId='").append(machineId).append('\'');
        sb.append(", cycleTimeMins='").append(cycleTimeMins).append('\'');
         sb.append(", handleTimeMins='").append(handleTimeMins).append('\'');

        sb.append('}');
        return sb.toString();
    }
}

