package com.qqs.invsvcs.api;

import java.util.Objects;

public class SupplierPoLineItem {
    private int id;
    private Integer poId;
    private Integer supplierXProductId;
    private Double quantity;
    private Double receivedQuantity;
    private Double cost;
    private String item;
    private String itemStatus;
    private SupplierXProduct supplierXProduct;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getPoId() {
        return poId;
    }

    public void setPoId(Integer poId) {
        this.poId = poId;
    }

    public Integer getSupplierXProductId() {
        return supplierXProductId;
    }

    public void setSupplierXProductId(Integer supplierXProductId) {
        this.supplierXProductId = supplierXProductId;
    }

    public Double getQuantity() {
        return quantity;
    }

    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    public Double getReceivedQuantity() { return receivedQuantity; }

    public void setReceivedQuantity(Double receivedQuantity) { this.receivedQuantity = receivedQuantity; }

    public Double getCost() {
        return cost;
    }

    public void setCost(Double cost) {
        this.cost = cost;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getItemStatus() {
        return itemStatus;
    }

    public void setItemStatus(String itemStatus) {
        this.itemStatus = itemStatus;
    }

    public SupplierXProduct getSupplierXProduct() {
        return supplierXProduct;
    }

    public void setSupplierXProduct(SupplierXProduct supplierXProduct) {
        this.supplierXProduct = supplierXProduct;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SupplierPoLineItem)) return false;
        SupplierPoLineItem that = (SupplierPoLineItem) o;
        return getId() == that.getId() &&
                Objects.equals(getPoId(), that.getPoId()) &&
                Objects.equals(getSupplierXProductId(), that.getSupplierXProductId()) &&
                Objects.equals(getQuantity(), that.getQuantity()) &&
                Objects.equals(getReceivedQuantity(), that.getReceivedQuantity()) &&
                Objects.equals(getCost(), that.getCost()) &&
                Objects.equals(getItem(), that.getItem()) &&
                Objects.equals(getItemStatus(), that.getItemStatus()) &&
                Objects.equals(getSupplierXProduct(), that.getSupplierXProduct());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getPoId(), getSupplierXProductId(), getQuantity(), getReceivedQuantity(), getCost(), getItem(), getItemStatus(), getSupplierXProduct());
    }
}
