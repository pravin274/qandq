package com.qqs.invsvcs.api;

import java.util.List;
import java.util.Objects;

public class PandLReport {

    private List<String> monthList;
    private List<PandLReportData> pandLReportData;

    public List<String> getMonthList() {
        return monthList;
    }

    public void setMonthList(List<String> monthList) {
        this.monthList = monthList;
    }

    public List<PandLReportData> getPandLReportData() {
        return pandLReportData;
    }

    public void setPandLReportData(List<PandLReportData> pandLReportData) {
        this.pandLReportData = pandLReportData;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PandLReport)) return false;
        PandLReport that = (PandLReport) o;
        return Objects.equals(monthList, that.monthList) &&
                Objects.equals(pandLReportData, that.pandLReportData);
    }

    @Override
    public int hashCode() {
        return Objects.hash(monthList, pandLReportData);
    }

    @Override
    public String toString() {
        return "PandLReport{" +
                "monthList=" + monthList +
                ", pandLReportData=" + pandLReportData +
                '}';
    }
}
