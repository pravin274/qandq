package com.qqs.invsvcs.api;

import java.util.Objects;

public class InvProductDetails {
    private int id;
    private Integer productId;
    private String productType;
    private Double msl;
    private Double openingStock;
    private Double availableStock;
    private Double safetyStock;
    private String safetyStockUnit;
    private String jobType;
    private String cgst;
    private String sgst;
    private String igst;
    private String dailyRequirementQty;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public Double getMsl() {
        return msl;
    }

    public void setMsl(Double msl) {
        this.msl = msl;
    }

    public Double getOpeningStock() {
        return openingStock;
    }

    public void setOpeningStock(Double openingStock) {
        this.openingStock = openingStock;
    }

    public Double getAvailableStock() {
        return availableStock;
    }

    public void setAvailableStock(Double availableStock) {
        this.availableStock = availableStock;
    }

    public Double getSafetyStock() {
        return safetyStock;
    }

    public void setSafetyStock(Double safetyStock) {
        this.safetyStock = safetyStock;
    }

    public String getSafetyStockUnit() {
        return safetyStockUnit;
    }

    public void setSafetyStockUnit(String safetyStockUnit) {
        this.safetyStockUnit = safetyStockUnit;
    }

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public String getCgst() {
        return cgst;
    }

    public void setCgst(String cgst) {
        this.cgst = cgst;
    }

    public String getSgst() {
        return sgst;
    }

    public void setSgst(String sgst) {
        this.sgst = sgst;
    }

    public String getIgst() {
        return igst;
    }

    public void setIgst(String igst) {
        this.igst = igst;
    }

    public String getDailyRequirementQty() {
        return dailyRequirementQty;
    }

    public void setDailyRequirementQty(String dailyRequirementQty) {
        this.dailyRequirementQty = dailyRequirementQty;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InvProductDetails product = (InvProductDetails) o;
        return id == product.id &&
                productId == product.productId &&
                productType.equals(product.productType) &&
                msl.equals(product.msl) &&
                openingStock.equals(product.openingStock) &&
                availableStock.equals(product.availableStock) &&
                safetyStock.equals(product.safetyStock) &&
                safetyStockUnit.equals(product.safetyStockUnit) &&
                jobType.equals(product.jobType) &&
                cgst.equals(product.cgst) &&
                sgst.equals(product.sgst) &&
                igst.equals(product.igst) &&
                dailyRequirementQty.equals(product.dailyRequirementQty);

    }

    @Override
    public int hashCode() {
        return Objects.hash(id, productId, productType, msl, openingStock, availableStock,
                safetyStock, safetyStockUnit, jobType, cgst, sgst, igst, dailyRequirementQty );
    }
}
