package com.qqs.posvcs.api;

import com.qqs.posvcs.api.common.People;

import java.sql.Timestamp;
import java.util.Set;

public class PurchOrder {
    private int id;
    private Integer companyId;
    private Company company;
    private Integer plantId;
    private Plant plant;
    private String poNumber;
    private Timestamp poDate;
    private String department;
    private Integer buyer;
    private Integer qqRespPerson;
    private String vendorCode;
    private Integer dvryAddrId;
    private Address deliveryAddress;
    private Integer dvryTermsId;
    private Integer pymntTermsId;
    private String dvryTerms;
    private String pymntTerms;
    private Integer billToAddrId;
    private Address billToAddress;
    private String poRevision;
    private String poStatus;
    private String poFileName;
    private Set<PoLineItem> poLineItems;
    private Set<People> peoples;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    public Integer getPlantId() {
        return plantId;
    }

    public void setPlantId(Integer plantId) {
        this.plantId = plantId;
    }

    public Plant getPlant() {
        return plant;
    }

    public void setPlant(Plant plant) {
        this.plant = plant;
    }

    public String getPoNumber() {
        return poNumber;
    }

    public void setPoNumber(String poNumber) {
        this.poNumber = poNumber;
    }

    public Timestamp getPoDate() {
        return poDate;
    }

    public void setPoDate(Timestamp poDate) {
        this.poDate = poDate;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public Integer getBuyer() {
        return buyer;
    }

    public void setBuyer(Integer buyer) {
        this.buyer = buyer;
    }

    public Integer getQqRespPerson() {
        return qqRespPerson;
    }

    public void setQqRespPerson(Integer qqRespPerson) {
        this.qqRespPerson = qqRespPerson;
    }

    public String getVendorCode() {
        return vendorCode;
    }

    public void setVendorCode(String vendorCode) {
        this.vendorCode = vendorCode;
    }

    public Integer getDvryAddrId() {
        return dvryAddrId;
    }

    public void setDvryAddrId(Integer dvryAddrId) {
        this.dvryAddrId = dvryAddrId;
    }

    public Integer getDvryTermsId() {
        return dvryTermsId;
    }

    public void setDvryTermsId(Integer dvryTermsId) {
        this.dvryTermsId = dvryTermsId;
    }

    public Integer getPymntTermsId() {
        return pymntTermsId;
    }

    public void setPymntTermsId(Integer pymntTermsId) {
        this.pymntTermsId = pymntTermsId;
    }

    public String getDvryTerms() {
        return dvryTerms;
    }

    public void setDvryTerms(String dvryTerms) {
        this.dvryTerms = dvryTerms;
    }

    public String getPymntTerms() {
        return pymntTerms;
    }

    public void setPymntTerms(String pymntTerms) {
        this.pymntTerms = pymntTerms;
    }

    public String getPoStatus() {
        return poStatus;
    }

    public void setPoStatus(String poStatus) {
        this.poStatus = poStatus;
    }

    public Integer getBillToAddrId() {
        return billToAddrId;
    }

    public void setBillToAddrId(Integer billToAddrId) {
        this.billToAddrId = billToAddrId;
    }

    public Set<PoLineItem> getPoLineItems() {
        return poLineItems;
    }

    public void setPoLineItems(Set<PoLineItem> poLineItems) {
        this.poLineItems = poLineItems;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public Address getDeliveryAddress() {
        return deliveryAddress;
    }

    public void setDeliveryAddress(Address deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }

    public Address getBillToAddress() {
        return billToAddress;
    }

    public void setBillToAddress(Address billToAddress) {
        this.billToAddress = billToAddress;
    }

    public Set<People> getPeoples() {
        return peoples;
    }

    public void setPeoples(Set<People> peoples) {
        this.peoples = peoples;
    }

    public String getPoFileName() {
        return poFileName;
    }

    public void setPoFileName(String poFileName) {
        this.poFileName = poFileName;
    }

    public String getPoRevision() {
        return poRevision;
    }

    public void setPoRevision(String poRevision) {
        this.poRevision = poRevision;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("PurchOrder{");
        sb.append("id=").append(id);
        sb.append(", companyId=").append(companyId);
        sb.append(", plantId=").append(plantId);
        sb.append(", poNumber='").append(poNumber).append('\'');
        sb.append(", poDate=").append(poDate);
        sb.append(", department='").append(department).append('\'');
        sb.append(", buyer=").append(buyer);
        sb.append(", qqRespPerson=").append(qqRespPerson);
        sb.append(", vendorCode=").append(vendorCode);
        sb.append(", dvryAddrId=").append(dvryAddrId);
        sb.append(", dvryTermsId='").append(dvryTermsId).append('\'');
        sb.append(", dvryTerms='").append(dvryTerms).append('\'');
        sb.append(", pymntTermsId='").append(pymntTermsId).append('\'');
        sb.append(", pymntTerms='").append(pymntTerms).append('\'');
        sb.append(", billToAddrId=").append(billToAddrId);
        sb.append(", poRevision").append(poRevision);
        sb.append(", poFileName").append(poFileName);
        sb.append(", poLineItems=").append(poLineItems);
        sb.append('}');
        return sb.toString();
    }
}
