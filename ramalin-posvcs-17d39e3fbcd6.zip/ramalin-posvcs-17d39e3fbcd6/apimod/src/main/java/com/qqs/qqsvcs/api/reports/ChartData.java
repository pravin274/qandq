package com.qqs.qqsvcs.api.reports;

import java.util.List;
import java.util.Objects;
import java.util.Set;

public class ChartData {
    private Set<String> labels;
    private List<ChartDataSet> dataSets;
    private List<String> limits;
    private List<String> limitCaptions;
    private Double yAxisMin;
    private Double yAxisMax;


    public Set<String> getLabels() {
        return labels;
    }

    public void setLabels(Set<String> labels) {
        this.labels = labels;
    }

    public List<ChartDataSet> getDataSets() {
        return dataSets;
    }

    public void setDataSets(List<ChartDataSet> dataSets) {
        this.dataSets = dataSets;
    }

    public List<String> getLimits() { return limits; }

    public void setLimits(List<String> limits) { this.limits = limits; }

    public Double getyAxisMin() { return yAxisMin; }

    public void setyAxisMin(Double yAxisMin) { this.yAxisMin = yAxisMin; }

    public Double getyAxisMax() { return yAxisMax; }

    public void setyAxisMax(Double yAxisMax) { this.yAxisMax = yAxisMax; }

    public List<String> getLimitCaptions() { return limitCaptions; }

    public void setLimitCaptions(List<String> limitCaptions) { this.limitCaptions = limitCaptions; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ChartData chartData = (ChartData) o;

        if (!Objects.equals(labels, chartData.labels)) return false;
        if (!Objects.equals(dataSets, chartData.dataSets)) return false;
        if (!Objects.equals(limits, chartData.limits)) return false;
        if (!Objects.equals(limitCaptions, chartData.limitCaptions)) return false;
        if (!Objects.equals(yAxisMax, chartData.yAxisMax)) return false;
        if (!Objects.equals(yAxisMin, chartData.yAxisMin)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (labels != null ? labels.hashCode() : 0);
        result = 31 * result + (dataSets != null ? dataSets.hashCode() : 0);
        result = 31 * result + (limits != null ? limits.hashCode() : 0);
        result = 31 * result + (limitCaptions != null ? limitCaptions.hashCode() : 0);
        result = 31 * result + (yAxisMin != null ? yAxisMin.hashCode() : 0);
        result = 31 * result + (yAxisMax != null ? yAxisMax.hashCode() : 0);

        return result;
    }
}

