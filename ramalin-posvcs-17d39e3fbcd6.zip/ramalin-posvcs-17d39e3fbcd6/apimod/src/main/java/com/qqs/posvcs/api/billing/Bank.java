package com.qqs.posvcs.api.billing;

public class Bank {
    private int id;
    private String bankName;
    private String accountNumber;
    private String ifscCode;
    private String swiftcode;
    private String adCode;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getIfscCode() {
        return ifscCode;
    }

    public void setIfscCode(String ifscCode) {
        this.ifscCode = ifscCode;
    }

    public String getSwiftcode() {
        return swiftcode;
    }

    public void setSwiftcode(String swiftcode) {
        this.swiftcode = swiftcode;
    }

    public String getAdCode() {
        return adCode;
    }

    public void setAdCode(String adCode) {
        this.adCode = adCode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Bank Bank = (Bank) o;

        if (id != Bank.id) return false;

        if (bankName != null ? !bankName.equals(Bank.bankName) : Bank.bankName != null) return false;
        if (accountNumber != null ? !accountNumber.equals(Bank.accountNumber) : Bank.accountNumber != null) return false;
        if (ifscCode != null ? !ifscCode.equals(Bank.ifscCode) : Bank.ifscCode != null)
            return false;
        if (swiftcode != null ? !swiftcode.equals(Bank.swiftcode) : Bank.swiftcode != null) return false;
        if (adCode != null ? !adCode.equals(Bank.adCode) : Bank.adCode != null) return false;


        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (bankName != null ? bankName.hashCode() : 0);
        result = 31 * result + (accountNumber != null ? accountNumber.hashCode() : 0);
        result = 31 * result + (ifscCode != null ? ifscCode.hashCode() : 0);
        result = 31 * result + (swiftcode != null ? swiftcode.hashCode() : 0);
        result = 31 * result + (adCode != null ? adCode.hashCode() : 0);

        return result;
    }
}

