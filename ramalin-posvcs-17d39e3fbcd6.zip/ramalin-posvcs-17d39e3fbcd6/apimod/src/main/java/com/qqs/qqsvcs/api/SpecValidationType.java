package com.qqs.qqsvcs.api;

import org.apache.commons.lang3.StringUtils;

public enum SpecValidationType {
    LENGTH, WEIGHT, VOLUME, TEMP, DEGREE;

    public static SpecValidationType getTypeFromDesc(String desc) {
        for (SpecValidationType result : SpecValidationType.values()) {
            if (StringUtils.equalsIgnoreCase(result.name(), desc)) {
                return result;
            }
        }
        return SpecValidationType.LENGTH;
    }
}
