package com.qqs.posvcs.api.reports;

import com.qqs.posvcs.api.Plant;
import com.qqs.posvcs.api.PurchOrder;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class Ats {

    private int id;
    private Integer poId;
    private Integer partId;
    private Integer invoiceId;
    private Integer poLineId;
    private Integer atsQty;
    private String boxNumber;
    private String heatCode;
    private String hardnessSpec;
    private String hardnessActualLower;
    private String hardnessActualHigher;
    private String materialSpec;
    private Date processDate;
    private Plant plant;
    private String cocNo;
    private Date cocDate;
    private String cocHeatNo;
    private String heatTreatmentSpec;
    private Date atsDate;
    private Integer approvedBy;
    private Integer preparedBy;
    private List<AtsContentSheet> atsContentSheet;
    private PurchOrder purchOrder;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getPoId() {
        return poId;
    }

    public void setPoId(Integer poId) {
        this.poId = poId;
    }

    public Integer getPartId() {
        return partId;
    }

    public void setPartId(Integer partId) {
        this.partId = partId;
    }

    public Integer getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Integer invoiceId) {
        this.invoiceId = invoiceId;
    }

    public Integer getPoLineId() {
        return poLineId;
    }

    public void setPoLineId(Integer poLineId) {
        this.poLineId = poLineId;
    }

    public String getBoxNumber() {
        return boxNumber;
    }

    public void setBoxNumber(String boxNumber) {
        this.boxNumber = boxNumber;
    }

    public Integer getAtsQty() {
        return atsQty;
    }

    public void setAtsQty(Integer atsQty) {
        this.atsQty = atsQty;
    }

    public String getHeatCode() {
        return heatCode;
    }
    public PurchOrder getPurchOrder() {
        return purchOrder;
    }

    public void setPurchOrder(PurchOrder purchOrder) {
        this.purchOrder = purchOrder;
    }

    public void setHeatCode(String heatCode) {
        this.heatCode = heatCode;
    }

    public String getHardnessSpec() {
        return hardnessSpec;
    }

    public void setHardnessSpec(String hardnessSpec) {
        this.hardnessSpec = hardnessSpec;
    }

    public String getHardnessActualLower() {
        return hardnessActualLower;
    }

    public void setHardnessActualLower(String hardnessActualLower) {
        this.hardnessActualLower = hardnessActualLower;
    }

    public String getHardnessActualHigher() {
        return hardnessActualHigher;
    }

    public void setHardnessActualHigher(String hardnessActualHigher) {
        this.hardnessActualHigher = hardnessActualHigher;
    }

    public String getMaterialSpec() {
        return materialSpec;
    }

    public void setMaterialSpec(String materialSpec) {
        this.materialSpec = materialSpec;
    }

    public Date getProcessDate() {
        return processDate;
    }

    public void setProcessDate(Date processDate) {
        this.processDate = processDate;
    }

    public Plant getPlant() {
        return plant;
    }

    public void setPlant(Plant plant) {
        this.plant = plant;
    }

    public List<AtsContentSheet> getAtsContentSheet() {
        return atsContentSheet;
    }

    public void setAtsContentSheet(List<AtsContentSheet> atsContentSheet) {
        this.atsContentSheet = atsContentSheet;
    }

    public String getCocNo() {
        return cocNo;
    }

    public void setCocNo(String cocNo) {
        this.cocNo = cocNo;
    }

    public Date getCocDate() {
        return cocDate;
    }

    public void setCocDate(Date cocDate) {
        this.cocDate = cocDate;
    }

    public String getCocHeatNo() {
        return cocHeatNo;
    }

    public void setCocHeatNo(String cocHeatNo) {
        this.cocHeatNo = cocHeatNo;
    }

    public String getHeatTreatmentSpec() {
        return heatTreatmentSpec;
    }

    public void setHeatTreatmentSpec(String heatTreatmentSpec) {
        this.heatTreatmentSpec = heatTreatmentSpec;
    }

    public Date getAtsDate() {
        return atsDate;
    }

    public void setAtsDate(Date atsDate) {
        this.atsDate = atsDate;
    }

    public Integer getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(Integer approvedBy) {
        this.approvedBy = approvedBy;
    }

    public Integer getPreparedBy() {
        return preparedBy;
    }

    public void setPreparedBy(Integer preparedBy) {
        this.preparedBy = preparedBy;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Ats that = (Ats) o;

        if (id != that.id) return false;
        if (poId != that.poId) return false;
        if (partId != that.partId) return false;
        if (invoiceId != that.invoiceId) return false;
        if (poLineId != that.poLineId) return false;
        if (atsQty != that.atsQty) return false;
        if (heatCode != null ? !heatCode.equals(that.heatCode) : that.heatCode != null) return false;
        if (cocNo != null ? !cocNo.equals(that.cocNo) : that.cocNo != null) return false;
        if (hardnessSpec != null ? !hardnessSpec.equals(that.hardnessSpec) : that.hardnessSpec != null) return false;
        if (hardnessActualLower != null ? !hardnessActualLower.equals(that.hardnessActualLower) : that.hardnessActualLower != null) return false;
        if (hardnessActualHigher != null ? !hardnessActualHigher.equals(that.hardnessActualHigher) : that.hardnessActualHigher != null) return false;
        if (materialSpec != null ? !materialSpec.equals(that.materialSpec) : that.materialSpec != null) return false;
        if (processDate != null ? !processDate.equals(that.processDate) : that.processDate != null) return false;
        if (cocDate != null ? !cocDate.equals(that.cocDate) : that.cocDate != null) return false;
        if (cocHeatNo != null ? !cocHeatNo.equals(that.cocHeatNo) : that.cocHeatNo != null) return false;
        if (heatTreatmentSpec != null ? !heatTreatmentSpec.equals(that.heatTreatmentSpec) : that.heatTreatmentSpec != null) return false;
        if (atsDate != null ? !atsDate.equals(that.atsDate) : that.atsDate != null) return false;
        if (approvedBy != null ? !approvedBy.equals(that.approvedBy) : that.approvedBy != null) return false;
        if (preparedBy != null ? !preparedBy.equals(that.preparedBy) : that.preparedBy != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (poId != null ? poId.hashCode() : 0);
        result = 31 * result + (partId != null ? partId.hashCode() : 0);
        result = 31 * result + (invoiceId != null ? invoiceId.hashCode() : 0);
        result = 31 * result + (poLineId != null ? poLineId.hashCode() : 0);
        result = 31 * result + (atsQty != null ? atsQty.hashCode() : 0);
        result = 31 * result + (heatCode != null ? heatCode.hashCode() : 0);
        result = 31 * result + (cocNo != null ? cocNo.hashCode() : 0);
        result = 31 * result + (hardnessSpec != null ? hardnessSpec.hashCode() : 0);
        result = 31 * result + (hardnessActualLower != null ? hardnessActualLower.hashCode() : 0);
        result = 31 * result + (hardnessActualHigher != null ? hardnessActualHigher.hashCode() : 0);
        result = 31 * result + (materialSpec != null ? materialSpec.hashCode() : 0);
        result = 31 * result + (processDate != null ? processDate.hashCode() : 0);
        result = 31 * result + (cocDate != null ? cocDate.hashCode() : 0);
        result = 31 * result + (cocHeatNo != null ? cocHeatNo.hashCode() : 0);
        result = 31 * result + (heatTreatmentSpec != null ? heatTreatmentSpec.hashCode() : 0);
        result = 31 * result + (atsDate != null ? atsDate.hashCode() : 0);
        result = 31 * result + (approvedBy != null ? approvedBy.hashCode() : 0);
        result = 31 * result + (preparedBy != null ? preparedBy.hashCode() : 0);
        return result;
    }
}
