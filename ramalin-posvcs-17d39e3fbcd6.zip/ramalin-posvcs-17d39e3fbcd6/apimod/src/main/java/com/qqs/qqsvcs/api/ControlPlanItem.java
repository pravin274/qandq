package com.qqs.qqsvcs.api;

import java.util.Objects;

public class ControlPlanItem {
    private int id;
    private Integer processId;
    private String printNumber; //printItemNumber in bluePrint
    private String description;
    private String severity;
    private String specType;
    private String specValue;
    private String specLowVariance;
    private String specHighVariance;
    private String specification;
    private String calibrationInterval;
    private String calibrationMethod;
    private Integer itemOrder;
    private Integer sampleSize;
    private Integer sampleFrequency;
    private Integer controlMethod;
    private String responsibilityId;
    private String upperControlLimit;
    private String lowerControlLimit;
    private Boolean specValidation;
    private String actualValue;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getProcessId() {
        return processId;
    }

    public void setProcessId(Integer processId) {
        this.processId = processId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getItemOrder() {
        return itemOrder;
    }

    public void setItemOrder(Integer itemOrder) {
        this.itemOrder = itemOrder;
    }

    public Integer getControlMethod() {
        return controlMethod;
    }

    public void setControlMethod(Integer controlMethod) {
        this.controlMethod = controlMethod;
    }

    public String getPrintNumber() {
        return printNumber;
    }

    public void setPrintNumber(String printNumber) {
        this.printNumber = printNumber;
    }

    public String getSeverity() {
        return severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public String getSpecType() {
        return specType;
    }

    public void setSpecType(String specType) {
        this.specType = specType;
    }

    public String getSpecValue() {
        return specValue;
    }

    public void setSpecValue(String specValue) {
        this.specValue = specValue;
    }

    public String getSpecLowVariance() {
        return specLowVariance;
    }

    public void setSpecLowVariance(String specLowVariance) {
        this.specLowVariance = specLowVariance;
    }

    public String getSpecHighVariance() {
        return specHighVariance;
    }

    public void setSpecHighVariance(String specHighVariance) {
        this.specHighVariance = specHighVariance;
    }

    public String getSpecification() {
        return specification;
    }

    public void setSpecification(String specification) {
        this.specification = specification;
    }

    public String getCalibrationInterval() {
        return calibrationInterval;
    }

    public void setCalibrationInterval(String calibrationInterval) {
        this.calibrationInterval = calibrationInterval;
    }

    public String getCalibrationMethod() {
        return calibrationMethod;
    }

    public void setCalibrationMethod(String calibrationMethod) {
        this.calibrationMethod = calibrationMethod;
    }

    public Integer getSampleSize() {
        return sampleSize;
    }

    public void setSampleSize(Integer sampleSize) {
        this.sampleSize = sampleSize;
    }

    public Integer getSampleFrequency() {
        return sampleFrequency;
    }

    public void setSampleFrequency(Integer sampleFrequency) {
        this.sampleFrequency = sampleFrequency;
    }

    public String getResponsibilityId() {
        return responsibilityId;
    }

    public void setResponsibilityId(String responsibilityId) {
        this.responsibilityId = responsibilityId;
    }

    public String getUpperControlLimit() {
        return upperControlLimit;
    }

    public void setUpperControlLimit(String upperControlLimit) {
        this.upperControlLimit = upperControlLimit;
    }

    public String getLowerControlLimit() {
        return lowerControlLimit;
    }

    public void setLowerControlLimit(String lowerControlLimit) {
        this.lowerControlLimit = lowerControlLimit;
    }

    public Boolean getSpecValidation() {
        return specValidation;
    }

    public void setSpecValidation(Boolean specValidation) {
        this.specValidation = specValidation;
    }

    public String getActualValue() {
        return actualValue;
    }

    public void setActualValue(String actualValue) {
        this.actualValue = actualValue;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ControlPlanItem)) return false;
        ControlPlanItem that = (ControlPlanItem) o;
        return getId() == that.getId() &&
                getProcessId().equals(that.getProcessId()) &&
                getPrintNumber().equals(that.getPrintNumber()) &&
                getDescription().equals(that.getDescription()) &&
                getSeverity().equals(that.getSeverity()) &&
                getSpecType().equals(that.getSpecType()) &&
                getSpecValue().equals(that.getSpecValue()) &&
                getSpecLowVariance().equals(that.getSpecLowVariance()) &&
                getSpecHighVariance().equals(that.getSpecHighVariance()) &&
                getSpecification().equals(that.getSpecification()) &&
                getCalibrationInterval().equals(that.getCalibrationInterval()) &&
                getCalibrationMethod().equals(that.getCalibrationMethod()) &&
                getItemOrder().equals(that.getItemOrder()) &&
                getSampleSize().equals(that.getSampleSize()) &&
                getSampleFrequency().equals(that.getSampleFrequency()) &&
                getControlMethod().equals(that.getControlMethod()) &&
                getResponsibilityId().equals(that.getResponsibilityId()) &&
                getUpperControlLimit().equals(that.getUpperControlLimit()) &&
                getLowerControlLimit().equals(that.getLowerControlLimit()) &&
                getSpecValidation().equals(that.getSpecValidation()) &&
                getActualValue().equals(that.getActualValue());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getProcessId(), getPrintNumber(), getDescription(), getSeverity(), getSpecType(), getSpecValue(), getSpecLowVariance(), getSpecHighVariance(), getSpecification(), getCalibrationInterval(), getCalibrationMethod(), getItemOrder(), getSampleSize(), getSampleFrequency(), getControlMethod(), getResponsibilityId(), getUpperControlLimit(), getLowerControlLimit(), getSpecValidation(), getActualValue());
    }

    @Override
    public String toString() {
        return "ControlPlanItem{" +
                "id=" + id +
                ", processId=" + processId +
                ", printNumber='" + printNumber + '\'' +
                ", description='" + description + '\'' +
                ", severity='" + severity + '\'' +
                ", specType='" + specType + '\'' +
                ", specValue='" + specValue + '\'' +
                ", specLowVariance='" + specLowVariance + '\'' +
                ", specHighVariance='" + specHighVariance + '\'' +
                ", specification='" + specification + '\'' +
                ", calibrationInterval='" + calibrationInterval + '\'' +
                ", calibrationMethod='" + calibrationMethod + '\'' +
                ", itemOrder=" + itemOrder +
                ", sampleSize=" + sampleSize +
                ", sampleFrequency=" + sampleFrequency +
                ", controlMethod=" + controlMethod +
                ", responsibilityId='" + responsibilityId + '\'' +
                ", upperControlLimit='" + upperControlLimit + '\'' +
                ", lowerControlLimit='" + lowerControlLimit + '\'' +
                ", specValidation=" + specValidation +
                ", actualValue='" + actualValue + '\'' +
                '}';
    }
}
