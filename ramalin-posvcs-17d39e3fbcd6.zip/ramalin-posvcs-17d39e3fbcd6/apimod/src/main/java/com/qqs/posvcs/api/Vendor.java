package com.qqs.posvcs.api;

import com.qqs.posvcs.api.common.People;

import java.util.List;

public class Vendor {
    private int id;
    private String vendorName;
    private String panNo;
    private String gstinNo;
    private String ieCode;
    private List<People> people;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public String getPanNo() { return panNo; }

    public void setPanNo(String panNo) { this.panNo = panNo; }

    public String getGstinNo() { return gstinNo; }

    public void setGstinNo(String gstinNo) { this.gstinNo = gstinNo; }

    public String getIeCode() { return ieCode; }

    public void setIeCode(String ieCode) { this.ieCode = ieCode; }

    public List<People> getPeople() {
        return people;
    }

    public void setPeople(List<People> people) {
        this.people = people;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Vendor vendor = (Vendor) o;

        if (id != vendor.id) return false;
        if (vendorName != null ? !vendorName.equals(vendor.vendorName) : vendor.vendorName != null) return false;
        if (panNo != null ? !panNo.equals(vendor.panNo) : vendor.panNo != null) return false;
        if (gstinNo != null ? !gstinNo.equals(vendor.gstinNo) : vendor.gstinNo != null) return false;
        if (ieCode != null ? !ieCode.equals(vendor.ieCode) : vendor.ieCode != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (vendorName != null ? vendorName.hashCode() : 0);
        result = 31 * result + (panNo != null ? panNo.hashCode() : 0);
        result = 31 * result + (gstinNo != null ? gstinNo.hashCode() : 0);
        result = 31 * result + (ieCode != null ? ieCode.hashCode() : 0);
        return result;
    }
}
