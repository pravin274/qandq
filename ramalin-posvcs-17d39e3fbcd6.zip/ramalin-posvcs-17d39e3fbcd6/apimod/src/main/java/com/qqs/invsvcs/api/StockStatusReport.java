package com.qqs.invsvcs.api;

import java.util.List;
import java.util.Objects;
import java.util.Set;

public class StockStatusReport {

    private Set<String> reportColumnsList;
    private List<StockStatusDetails> stockStatusDetails;

    public Set<String> getReportColumnsList() {
        return reportColumnsList;
    }

    public void setReportColumnsList(Set<String> reportColumnsList) {
        this.reportColumnsList = reportColumnsList;
    }

    public List<StockStatusDetails> getStockStatusDetails() {
        return stockStatusDetails;
    }

    public void setStockStatusDetails(List<StockStatusDetails> stockStatusDetails) {
        this.stockStatusDetails = stockStatusDetails;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof StockStatusReport)) return false;
        StockStatusReport that = (StockStatusReport) o;
        return Objects.equals(getReportColumnsList(), that.getReportColumnsList()) &&
                Objects.equals(getStockStatusDetails(), that.getStockStatusDetails()) ;
    }

    @Override
    public int hashCode() {
        return Objects.hash(getReportColumnsList(), getStockStatusDetails());
    }
}
