package com.qqs.qqsvcs.api;

import java.util.List;

public class ControlTaskData {
    private Integer runningNumber;
    private List<ControlPlanItem>  controlPlanItems;

    public Integer getRunningNumber() { return runningNumber; }

    public void setRunningNumber(Integer runningNumber) { this.runningNumber = runningNumber; }

    public List<ControlPlanItem> getControlPlanItems() { return controlPlanItems; }

    public void setControlPlanItems(List<ControlPlanItem> controlPlanItems) {
        this.controlPlanItems = controlPlanItems;
    }
}
