package com.qqs.invsvcs.api;

import java.util.Objects;

public class InwardLineItem {
    private int id;
    private Integer inwardId;
    private Integer poLineItemId;
    private Double quantity;
    private Double receivedQuantity;
    private String status;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getInwardId() {
        return inwardId;
    }

    public void setInwardId(Integer inwardId) {
        this.inwardId = inwardId;
    }

    public Integer getPoLineItemId() {
        return poLineItemId;
    }

    public void setPoLineItemId(Integer poLineItemId) {
        this.poLineItemId = poLineItemId;
    }

    public Double getQuantity() {
        return quantity;
    }

    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    public Double getReceivedQuantity() { return receivedQuantity; }

    public void setReceivedQuantity(Double receivedQuantity) { this.receivedQuantity = receivedQuantity; }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof InwardLineItem)) return false;
        InwardLineItem inward = (InwardLineItem) o;
        return id == inward.id &&
                Objects.equals(poLineItemId, inward.poLineItemId) &&
                Objects.equals(inwardId, inward.inwardId) &&
                Objects.equals(status, inward.status) &&
                Objects.equals(quantity, inward.quantity) &&
                Objects.equals(receivedQuantity, inward.receivedQuantity);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, status, inwardId, poLineItemId, quantity, receivedQuantity);
    }
}
