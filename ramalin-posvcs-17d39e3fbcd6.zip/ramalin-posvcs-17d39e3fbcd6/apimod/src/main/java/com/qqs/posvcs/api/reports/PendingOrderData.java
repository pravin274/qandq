package com.qqs.posvcs.api.reports;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PendingOrderData {
    private int id;
    private int serialNo;
    private String poNumber;
    private String poRevision;
    private String poStatus;
    private String partType;
    private String poItem;
    private String poDate;
    private String partNumber;
    private String partName;
    private String partRevNo;
    private String deliveryDate;
    private int poQty;
    private double deliveredQty;
    private double pendingQty;
    private String companyName;
    private String plantName;
    private int daysLeft;

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public String getPoNumber() {
        return poNumber;
    }

    public void setPoNumber(String poNumber) {
        this.poNumber = poNumber;
    }

    public String getPoRevision() { return poRevision; }

    public void setPoRevision(String poRevision) { this.poRevision = poRevision; }

    public String getPoStatus() { return poStatus; }

    public void setPoStatus(String poStatus) { this.poStatus = poStatus; }

    public String getPartType() { return partType; }

    public void setPartType(String partType) { this.partType = partType; }

    public String getPoItem() { return poItem; }

    public void setPoItem(String poItem) { this.poItem = poItem; }

    public String getPartName() {
        return partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }

    public String getPoDate() { return poDate; }

    public void setPoDate(String poDate) { this.poDate = poDate; }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }
    public String getPartRevNo() {
        return partRevNo;
    }

    public void setPartRevNo(String partRevNo) {
        this.partRevNo = partRevNo;
    }

    public String getDeliveryDate() { return deliveryDate; }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
        if(deliveryDate == null) {
            this.daysLeft = 0;
        } else {
            try {
                Date deliveryDateObj = new SimpleDateFormat("yyyy-MM-dd").parse(deliveryDate);
                Date currDate = new Date();
                long startTime = deliveryDateObj.getTime();
                long endTime = currDate.getTime();
                long diffTime = startTime - endTime;
                Long diffDays = (diffTime / (1000 * 60 * 60 * 24));
                this.daysLeft = diffDays.intValue();
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
    }
    public int getPoQty() {
        return poQty;
    }

    public void setPoQty(int poQty) {
        this.poQty = poQty;
    }

    public double getDeliveredQty() {
        return deliveredQty;
    }

    public void setDeliveredQty(double deliveredQty) {
        this.deliveredQty = deliveredQty;
        this.pendingQty = this.poQty - deliveredQty;
        if(this.pendingQty == 0) {
            this.setDaysLeft(0);
        }
    }

    public double getPendingQty() {
        return pendingQty;
    }

    public void setPendingQty(double pendingQty) {
        this.pendingQty = pendingQty;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getPlantName() {
        return plantName;
    }

    public void setPlantName(String plantName) {
        this.plantName = plantName;
    }

    public int getDaysLeft() {
        return daysLeft;
    }

    public void setDaysLeft(int daysLeft) {
        this.daysLeft = daysLeft;
    }

    public int getSerialNo() { return serialNo; }

    public void setSerialNo(int serialNo) { this.serialNo = serialNo; }
}
