package com.qqs.qqsvcs.api;

public class ToolChange {
    private int id;
    private int toolLayoutDetailId;
    private String toolChangeAt;
    private int controlTaskId;
    private String reason;
    private String remarks;

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public int getToolLayoutDetailId() { return toolLayoutDetailId; }

    public void setToolLayoutDetailId(int toolLayoutDetailId) { this.toolLayoutDetailId = toolLayoutDetailId; }

    public int getControlTaskId() { return controlTaskId; }

    public void setControlTaskId(int controlTaskId) { this.controlTaskId = controlTaskId; }

    public String getToolChangeAt() {
        return toolChangeAt;
    }

    public void setToolChangeAt(String toolChangeAt) {
        this.toolChangeAt = toolChangeAt;
    }

    public String getReason() { return reason; }

    public void setReason(String reason) { this.reason = reason; }

    public String getRemarks() { return remarks; }

    public void setRemarks(String remarks) { this.remarks = remarks; }

    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        if (!super.equals(object)) return false;

        ToolChange that = (ToolChange) object;

        if (id != that.id) return false;
        if (toolLayoutDetailId != that.toolLayoutDetailId) return false;
        if (controlTaskId != that.controlTaskId) return false;
        if (reason != null ? !reason.equals(that.reason) : that.reason != null) return false;
        if (remarks != null ? !remarks.equals(that.remarks) : that.remarks != null) return false;

        return true;
    }

    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + id;
        result = 31 * result + toolLayoutDetailId;
        result = 31 * result + controlTaskId;
        result = 31 * result + (reason != null ? reason.hashCode() : 0);
        result = 31 * result + (remarks != null ? remarks.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Tool{");
        sb.append("id=").append(id);
        sb.append(", toolLayoutDetailId=").append(toolLayoutDetailId);
        sb.append(", controlTaskId='").append(controlTaskId).append('\'');
        sb.append(", reason='").append(reason).append('\'');
        sb.append(", remarks='").append(remarks).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
