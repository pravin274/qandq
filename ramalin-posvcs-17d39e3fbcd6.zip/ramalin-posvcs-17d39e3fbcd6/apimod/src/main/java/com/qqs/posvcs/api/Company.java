package com.qqs.posvcs.api;

import java.util.Collection;

public class    Company {
    private int id;
    private Integer parentId;
    private String name;
    private String type;
    private String description;
    private String taxId;
    private Integer hierarchy;
    private Collection<Plant> plants;
    private Collection<Address> addresses;
    private Collection<Email> emails;
    private Collection<Phone> phones;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTaxId() {
        return taxId;
    }

    public void setTaxId(String taxId) {
        this.taxId = taxId;
    }

    public Integer getHierarchy() {
        return hierarchy;
    }

    public void setHierarchy(Integer hierarchy) {
        this.hierarchy = hierarchy;
    }

    public Collection<Plant> getPlants() {
        return plants;
    }

    public void setPlants(Collection<Plant> plants) {
        this.plants = plants;
    }

    public Collection<Address> getAddresses() {
        return addresses;
    }

    public void setAddresses(Collection<Address> addresses) {
        this.addresses = addresses;
    }

    public Collection<Email> getEmails() {
        return emails;
    }

    public void setEmails(Collection<Email> emails) {
        this.emails = emails;
    }

    public Collection<Phone> getPhones() {
        return phones;
    }

    public void setPhones(Collection<Phone> phones) {
        this.phones = phones;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Company{");
        sb.append("id=").append(id);
        sb.append(", parentId=").append(parentId);
        sb.append(", name='").append(name).append('\'');
        sb.append(", type='").append(type).append('\'');
        sb.append(", desc='").append(description).append('\'');
        sb.append(", taxId='").append(taxId).append('\'');
        sb.append(", hierarchy=").append(hierarchy);
        sb.append(", plants=").append(plants);
        sb.append(", addresses=").append(addresses);
        sb.append(", emails=").append(emails);
        sb.append(", phones=").append(phones);
        sb.append('}');
        return sb.toString();
    }
}
