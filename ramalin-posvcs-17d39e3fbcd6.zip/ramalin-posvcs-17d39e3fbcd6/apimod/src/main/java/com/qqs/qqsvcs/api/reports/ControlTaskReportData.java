package com.qqs.qqsvcs.api.reports;

import java.util.Objects;

public class ControlTaskReportData {
    String date;
    String shift;
    String partSerialNo;
    String description;
    String printNumber;
    String partStatus;
    String specValue;
    String specLowVariance;
    String specHighVariance;
    String calibrationMethod;
    String actualValue;
    String machineName;
    String operatorName;
    String taskType;
    String sampleFrequency;
    String sampleSize;

   

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

    public String getShift() {
        return shift;
    }

    public void setShift(String shift) {
        this.shift = shift;
    }

    public String getPartSerialNo() {
        return partSerialNo;
    }

    public void setPartSerialNo(String partSerialNo) {
        this.partSerialNo = partSerialNo;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPrintNumber() {
        return printNumber;
    }

    public void setPrintNumber(String printNumber) {
        this.printNumber = printNumber;
    }

    public String getPartStatus() {
        return partStatus;
    }

    public void setPartStatus(String partStatus) {
        this.partStatus = partStatus;
    }

    public String getSpecValue() {
        return specValue;
    }

    public void setSpecValue(String specValue) {
        this.specValue = specValue;
    }

    public String getSpecLowVariance() {
        return specLowVariance;
    }

    public void setSpecLowVariance(String specLowVariance) {
        this.specLowVariance = specLowVariance;
    }

    public String getSpecHighVariance() {
        return specHighVariance;
    }

    public void setSpecHighVariance(String specHighVariance) {
        this.specHighVariance = specHighVariance;
    }

    public String getCalibrationMethod() {
        return calibrationMethod;
    }

    public void setCalibrationMethod(String calibrationMethod) {
        this.calibrationMethod = calibrationMethod;
    }

    public String getActualValue() {
        return actualValue;
    }

    public void setActualValue(String actualValue) {
        this.actualValue = actualValue;
    }

    public String getMachineName() {
        return machineName;
    }

    public void setMachineName(String machineName) {
        this.machineName = machineName;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public String getTaskType() { return taskType; }

    public void setTaskType(String taskType) { this.taskType = taskType; }

    public String getSampleFrequency() {
        return sampleFrequency;
    }

    public void setSampleFrequency(String sampleFrequency) {
        this.sampleFrequency = sampleFrequency;
    }

    public String getSampleSize() {
        return sampleSize;
    }

    public void setSampleSize(String sampleSize) {
        this.sampleSize = sampleSize;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ControlTaskReportData controlTaskReportData = (ControlTaskReportData) o;
        
        if (!Objects.equals(date, controlTaskReportData.date)) return false;
        if (!Objects.equals(shift, controlTaskReportData.shift)) return false;
        if (!Objects.equals(partSerialNo, controlTaskReportData.partSerialNo)) return false;
        if (!Objects.equals(description, controlTaskReportData.description)) return false;
        if (!Objects.equals(printNumber, controlTaskReportData.printNumber)) return false;
        if (!Objects.equals(partStatus, controlTaskReportData.partStatus)) return false;
        if (!Objects.equals(specValue, controlTaskReportData.specValue)) return false;
        if (!Objects.equals(specLowVariance, controlTaskReportData.specLowVariance)) return false;
        if (!Objects.equals(specHighVariance, controlTaskReportData.specHighVariance)) return false;
        if (!Objects.equals(calibrationMethod, controlTaskReportData.calibrationMethod)) return false;
        if (!Objects.equals(actualValue, controlTaskReportData.actualValue)) return false;
        if (!Objects.equals(machineName, controlTaskReportData.machineName)) return false;
        if (!Objects.equals(operatorName, controlTaskReportData.operatorName)) return false;
        if (!Objects.equals(taskType, controlTaskReportData.taskType)) return false;
        if (!Objects.equals(sampleFrequency, controlTaskReportData.sampleFrequency)) return false;
        if (!Objects.equals(sampleSize, controlTaskReportData.sampleSize)) return false;


        return true;
    }

    @Override
    public int hashCode() {
        int result = (partSerialNo != null ? partSerialNo.hashCode() : 0);
        result = 31 * result + (date != null ? date.hashCode() : 0);
        result = 31 * result + (shift != null ? shift.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (printNumber != null ? printNumber.hashCode() : 0);
        result = 31 * result + (partStatus != null ? partStatus.hashCode() : 0);
        result = 31 * result + (specValue != null ? specValue.hashCode() : 0);
        result = 31 * result + (specLowVariance != null ? specLowVariance.hashCode() : 0);
        result = 31 * result + (specHighVariance != null ? specHighVariance.hashCode() : 0);
        result = 31 * result + (calibrationMethod != null ? calibrationMethod.hashCode() : 0);
        result = 31 * result + (actualValue != null ? actualValue.hashCode() : 0);
        result = 31 * result + (machineName != null ? machineName.hashCode() : 0);
        result = 31 * result + (operatorName != null ? operatorName.hashCode() : 0);
        result = 31 * result + (taskType != null ? taskType.hashCode() : 0);
        result = 31 * result + (sampleFrequency != null ? sampleFrequency.hashCode() : 0);
        result = 31 * result + (sampleSize != null ? sampleSize.hashCode() : 0);


        return result;
    }
}
