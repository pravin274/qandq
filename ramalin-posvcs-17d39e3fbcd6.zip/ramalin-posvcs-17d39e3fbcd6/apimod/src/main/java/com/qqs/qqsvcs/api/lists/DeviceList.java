package com.qqs.qqsvcs.api.lists;

import java.util.Arrays;
import java.util.List;

public enum DeviceList implements ListItem {
    TURN("Turning Center", ""),
    VMC("VMC", "");

    private String description;
    private String otherInfo;

    DeviceList(String description, String otherInfo) {
        this.description = description;
        this.otherInfo = otherInfo;
    }

    public String getDescription() {
        return description;
    }

    public String getOtherInfo() {
        return otherInfo;
    }

    public List<ListItem> getValues() {
        List<ListItem> result = Arrays.asList(values());
        return result;
    }

    public String getName() {
        return name();
    }
}
