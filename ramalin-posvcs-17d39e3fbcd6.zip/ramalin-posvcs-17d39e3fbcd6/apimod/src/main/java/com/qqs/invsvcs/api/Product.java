package com.qqs.invsvcs.api;

import java.util.List;
import java.util.Objects;

public class Product {
    private int id;
    private String name;
    private Integer categoryId;
    private InvProductDetails invProductDetails;
    private List<SupplierXProduct> supplierXProduct;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public InvProductDetails getInvProductDetails() {
        return invProductDetails;
    }

    public void setInvProductDetails(InvProductDetails invProductDetails) {
        this.invProductDetails = invProductDetails;
    }

    public List<SupplierXProduct> getSupplierXProduct() {
        return supplierXProduct;
    }

    public void setSupplierXProduct(List<SupplierXProduct> supplierXProduct) {
        this.supplierXProduct = supplierXProduct;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Product product = (Product) o;

        if (id != product.id) return false;
        if (categoryId != product.categoryId) return false;
        if (!Objects.equals(name, product.name)) return false;
        if (!Objects.equals(invProductDetails, product.invProductDetails)) return false;
        if (!Objects.equals(supplierXProduct, product.supplierXProduct)) return false;


        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = categoryId;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (invProductDetails != null ? invProductDetails.hashCode() : 0);
        result = 31 * result + (supplierXProduct != null ? supplierXProduct.hashCode() : 0);

        return result;
    }


}
