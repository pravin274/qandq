package com.qqs.posvcs.api.billing;

public class InvoiceLineItem {
    private int id;
    private Integer invoiceId;
    private Integer poLineId;
    private Double invoiceQty;
    private String toolPaymentDescription;
    private Double shippedQty;
    private String currentStatus;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Integer invoiceId) {
        this.invoiceId = invoiceId;
    }

    public Integer getPoLineId() {
        return poLineId;
    }

    public void setPoLineId(Integer poLineId) {
        this.poLineId = poLineId;
    }

    public Double getInvoiceQty() {
        return invoiceQty;
    }

    public void setInvoiceQty(Double invoiceQty) {
        this.invoiceQty = invoiceQty;
    }

    public String getToolPaymentDescription() {
        return toolPaymentDescription;
    }

    public void setToolPaymentDescription(String toolPaymentDescription) {
        this.toolPaymentDescription = toolPaymentDescription;
    }

    public Double getShippedQty() { return shippedQty; }

    public void setShippedQty(Double shippedQty) { this.shippedQty = shippedQty; }


    public String getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }



    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        InvoiceLineItem InvoiceLineItem = (InvoiceLineItem) o;

        if (id != InvoiceLineItem.id) return false;
        if (invoiceId != InvoiceLineItem.invoiceId) return false;
        if (poLineId != null ? !poLineId.equals(InvoiceLineItem.poLineId) : InvoiceLineItem.poLineId != null) return false;
        if (invoiceQty != null ? !invoiceQty.equals(InvoiceLineItem.invoiceQty) : InvoiceLineItem.invoiceQty != null) return false;
        if (shippedQty != InvoiceLineItem.shippedQty) return false;
        if (currentStatus != null ? !currentStatus.equals(InvoiceLineItem.currentStatus) : InvoiceLineItem.currentStatus != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (invoiceId != null ? invoiceId.hashCode() : 0);
        result = 31 * result + poLineId;
        result = 31 * result + (invoiceQty != null ? invoiceQty.hashCode() : 0);
        result = 31 * result + (shippedQty != null ? shippedQty.hashCode() : 0);
        result = 31 * result + (currentStatus != null ? currentStatus.hashCode() : 0);

        return result;
    }
}


