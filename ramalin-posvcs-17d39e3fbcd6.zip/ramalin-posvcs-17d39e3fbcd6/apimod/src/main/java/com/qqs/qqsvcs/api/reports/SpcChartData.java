package com.qqs.qqsvcs.api.reports;

import com.qqs.qqsvcs.api.ControlPlanItem;

import java.util.Objects;

public class SpcChartData {
    private Integer customerId;
    private Integer partId;

    private ChartData chartData;
    private ControlPlanItem controlPlanItem;

    public ChartData getChartData() { return chartData; }

    public void setChartData(ChartData chartData) { this.chartData = chartData; }

    public ControlPlanItem getControlPlanItem() { return controlPlanItem; }

    public void setControlPlanItem(ControlPlanItem controlPlanItem) { this.controlPlanItem = controlPlanItem; }

    public Integer getCustomerId() { return customerId; }

    public void setCustomerId(Integer customerId) { this.customerId = customerId; }

    public Integer getPartId() { return partId; }

    public void setPartId(Integer partId) { this.partId = partId; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SpcChartData chartData = (SpcChartData) o;

        if (!Objects.equals(chartData, chartData.chartData)) return false;
        if (!Objects.equals(controlPlanItem, chartData.controlPlanItem)) return false;
        if (!Objects.equals(customerId, chartData.customerId)) return false;
        if (!Objects.equals(partId, chartData.partId)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (chartData != null ? chartData.hashCode() : 0);
        result = 31 * result + (controlPlanItem != null ? controlPlanItem.hashCode() : 0);
        result = 31 * result + (customerId != null ? customerId.hashCode() : 0);
        result = 31 * result + (partId != null ? partId.hashCode() : 0);

        return result;
    }
}

