package com.qqs.invsvcs.api;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Objects;
import java.util.Set;

public class Inward {
    private int id;
    private Integer poId;
    private Date inwardDate;
    private String dcNumber;
    private Integer receivedBy;
    private String remarks;
    private Set<InwardLineItem> inwardLineItem;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getPoId() {
        return poId;
    }

    public void setPoId(Integer poId) {
        this.poId = poId;
    }

    public Date getInwardDate() {
        return inwardDate;
    }

    public void setInwardDate(Date inwardDate) {
        this.inwardDate = inwardDate;
    }

    public String getDcNumber() {
        return dcNumber;
    }

    public void setDcNumber(String dcNumber) {
        this.dcNumber = dcNumber;
    }

    public Integer getReceivedBy() {
        return receivedBy;
    }

    public void setReceivedBy(Integer receivedBy) {
        this.receivedBy = receivedBy;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Set<InwardLineItem> getInwardLineItem() {
        return inwardLineItem;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Inward)) return false;
        Inward inward = (Inward) o;
        return getId() == inward.getId() &&
                Objects.equals(getPoId(), inward.getPoId()) &&
                Objects.equals(getInwardDate(), inward.getInwardDate()) &&
                Objects.equals(getDcNumber(), inward.getDcNumber()) &&
                Objects.equals(getReceivedBy(), inward.getReceivedBy()) &&
                Objects.equals(getRemarks(), inward.getRemarks()) &&
                Objects.equals(getInwardLineItem(), inward.getInwardLineItem());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getPoId(), getInwardDate(), getDcNumber(), getReceivedBy(), getRemarks(), getInwardLineItem());
    }

    public void setInwardLineItem(Set<InwardLineItem> inwardLineItem) {
        this.inwardLineItem = inwardLineItem;
    }

}
