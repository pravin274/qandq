package com.qqs.posvcs.api.parts;


import java.sql.Timestamp;

public class PartCommodity {
    private int id;
    private int partId;
    private String commodityCode;
    private String countryCode;
    private Timestamp effectiveDt;
    private Timestamp expiryDt;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPartId() {
        return partId;
    }

    public void setPartId(int partId) {
        this.partId = partId;
    }

    public String getCommodityCode() {
        return commodityCode;
    }

    public void setCommodityCode(String commodityCode) {
        this.commodityCode = commodityCode;
    }

    public String getCountryCode() { return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public Timestamp getEffectiveDt() {
        return effectiveDt;
    }

    public void setEffectiveDt(Timestamp effectiveDt) {
        this.effectiveDt = effectiveDt;
    }

    public Timestamp getExpiryDt() {
        return expiryDt;
    }

    public void setExpiryDt(Timestamp expiryDt) {
        this.expiryDt = expiryDt;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("PartCommodity{");
        sb.append("id=").append(id);
        sb.append(", partId=").append(partId);
        sb.append(", commodityCode='").append(commodityCode).append('\'');
        sb.append(", countryCode=").append(countryCode);
        sb.append(", effectiveDt=").append(effectiveDt);
        sb.append(", expiryDt=").append(expiryDt);
        sb.append('}');
        return sb.toString();
    }
}
