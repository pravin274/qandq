package com.qqs.posvcs.api;

import java.sql.Timestamp;

public class CurrencyExchangeRate {
    private int id;
    private String currency;
    private Double value;
    private Timestamp effectiveDt;
    private Timestamp expiryDt;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    public Timestamp getEffectiveDt() {
        return effectiveDt;
    }

    public void setEffectiveDt(Timestamp effectiveDt) {
        this.effectiveDt = effectiveDt;
    }

    public Timestamp getExpiryDt() {
        return expiryDt;
    }

    public void setExpiryDt(Timestamp expiryDt) {
        this.expiryDt = expiryDt;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("CurrencyExchangeRate{");
        sb.append("id=").append(id);
        sb.append(", currency='").append(currency).append('\'');
        sb.append(", value=").append(value);
        sb.append(", effectiveDt=").append(effectiveDt);
        sb.append(", expiryDt=").append(expiryDt);
        sb.append('}');
        return sb.toString();
    }



}
