package com.qqs.posvcs.api;

import com.qqs.posvcs.api.parts.Part;
import java.sql.Timestamp;

public class PoLineItem {
    private int id;
    private int poId;
    private int partId;
    private int poLineToolId;
    private String partType;
    private String item;
    private String material;
    private String revision;
    private String description;
    private Integer quantity;
    private String unit;
    private String currency;
    private Double partPrice;
    private Integer partPriceId;
    private Timestamp deliveryDate;
    private Integer commodityCodeId;
    private Double shippedQty;
    private Part part;
    private PoLineTool poLineTool;
    private Boolean isDeleted;
    private String currentStatus;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPoId() {
        return poId;
    }

    public void setPoId(int poId) {
        this.poId = poId;
    }

    public int getPartId() {
        return partId;
    }

    public void setPartId(int partId) {
        this.partId = partId;
    }

    public int getPoLineToolId() { return poLineToolId; }

    public void setPoLineToolId(int poLineToolId) { this.poLineToolId = poLineToolId; }

    public String getPartType() { return partType; }

    public void setPartType(String partType) { this.partType = partType; }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getRevision() {
        return revision;
    }

    public void setRevision(String revision) {
        this.revision = revision;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Double getPartPrice() {
        return partPrice;
    }

    public void setPartPrice(Double partPrice) {
        this.partPrice = partPrice;
    }

    public Integer getPartPriceId() {
        return partPriceId;
    }

    public void setPartPriceId(Integer partPriceId) {
        this.partPriceId = partPriceId;
    }

    public Timestamp getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(Timestamp deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public Integer getCommodityCodeId() { return commodityCodeId; }

    public void setCommodityCodeId(Integer commodityCodeId) {
        if (commodityCodeId != null) {
            this.commodityCodeId = commodityCodeId;
        }
    }

    public Double getShippedQty() { return shippedQty; }

    public void setShippedQty(Double shippedQty) { this.shippedQty = shippedQty; }

    public Part getPart() {
        return part;
    }

    public void setPart(Part part) {
        this.part = part;
    }

    public PoLineTool getPoLineTool() { return poLineTool; }

    public void setPoLineTool(PoLineTool poLineTool) { this.poLineTool = poLineTool; }


    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    public String getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }


    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("PoLineItem{");
        sb.append("id=").append(id);
        sb.append(", poId=").append(poId);
        sb.append(", partId=").append(poId);
        sb.append(", item='").append(item).append('\'');
        sb.append(", material='").append(material).append('\'');
        sb.append(", revision='").append(revision).append('\'');
        sb.append(", description='").append(description).append('\'');
        sb.append(", quantity=").append(quantity);
        sb.append(", unit='").append(unit).append('\'');
        sb.append(", currency='").append(currency).append('\'');
        sb.append(", partPrice='").append(partPrice).append('\'');
        sb.append(", partPriceId=").append(partPriceId);
        sb.append(", deliveryDate=").append(deliveryDate);
        sb.append(", commodityCodeId=").append(commodityCodeId);
        sb.append(", shippedQty=").append(shippedQty);
        sb.append(", isDeleted=").append(isDeleted);
        sb.append(", currentStatus=").append(currentStatus);

        sb.append('}');
        return sb.toString();
    }
}
