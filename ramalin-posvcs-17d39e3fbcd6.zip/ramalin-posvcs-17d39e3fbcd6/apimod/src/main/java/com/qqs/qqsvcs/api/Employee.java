package com.qqs.qqsvcs.api;

import java.util.Date;
import java.util.List;
import java.util.Objects;

public class Employee {
    private int id;
    private String empId;
    private Integer userId;
    private String firstName;
    private String lastName;
    private String email;
    private String designation;
    private String department;
    private Double experienceInYr;
    private Date dateOfJoining;
    private String contactNumber;
    private String education;
    private Date dateOfBirth;
    private String aadharNumber;
    private String maritalStatus;
    private String nativePlace;
    private Boolean active;
    private List<Salary> salaryList;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public Integer getUserId() { return userId; }

    public void setUserId(Integer userId) { this.userId = userId; }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public Double getExperienceInYr() {
        return experienceInYr;
    }

    public void setExperienceInYr(Double experienceInYr) {
        this.experienceInYr = experienceInYr;
    }

    public Date getDateOfJoining() {
        return dateOfJoining;
    }

    public void setDateOfJoining(Date dateOfJoining) {
        this.dateOfJoining = dateOfJoining;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getAadharNumber() {
        return aadharNumber;
    }

    public void setAadharNumber(String aadharNumber) {
        this.aadharNumber = aadharNumber;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public String getNativePlace() {
        return nativePlace;
    }

    public void setNativePlace(String nativePlace) {
        this.nativePlace = nativePlace;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public List<Salary> getSalaryList() {
        return salaryList;
    }

    public void setSalaryList(List<Salary> salaryList) {
        this.salaryList = salaryList;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Employee)) return false;
        Employee employee = (Employee) o;
        return getId() == employee.getId() &&
                Objects.equals(getEmpId(), employee.getEmpId()) &&
                Objects.equals(getUserId(), employee.getUserId()) &&
                Objects.equals(getFirstName(), employee.getFirstName()) &&
                Objects.equals(getLastName(), employee.getLastName()) &&
                Objects.equals(getEmail(), employee.getEmail()) &&
                Objects.equals(getDesignation(), employee.getDesignation()) &&
                Objects.equals(getDepartment(), employee.getDepartment()) &&
                Objects.equals(getExperienceInYr(), employee.getExperienceInYr()) &&
                Objects.equals(getDateOfJoining(), employee.getDateOfJoining()) &&
                Objects.equals(getContactNumber(), employee.getContactNumber()) &&
                Objects.equals(getEducation(), employee.getEducation()) &&
                Objects.equals(getDateOfBirth(), employee.getDateOfBirth()) &&
                Objects.equals(getAadharNumber(), employee.getAadharNumber()) &&
                Objects.equals(getMaritalStatus(), employee.getMaritalStatus()) &&
                Objects.equals(getNativePlace(), employee.getNativePlace()) &&
                Objects.equals(getActive(), employee.getActive()) &&
                Objects.equals(getSalaryList(), employee.getSalaryList());

    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getEmpId(), getUserId(), getFirstName(), getLastName(), getEmail(), getDesignation(), getDepartment(), getExperienceInYr(),
                getDateOfJoining(), getContactNumber(), getEducation(), getDateOfBirth(), getAadharNumber(), getMaritalStatus(), getNativePlace(), getActive(),
                getSalaryList());
    }
}

