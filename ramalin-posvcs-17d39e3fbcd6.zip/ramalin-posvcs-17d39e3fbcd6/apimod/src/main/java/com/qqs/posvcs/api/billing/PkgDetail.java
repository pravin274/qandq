package com.qqs.posvcs.api.billing;

import com.qqs.posvcs.api.parts.Part;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class PkgDetail {
    private int id;
    private Integer pkgId;
    private Integer pkgNo;
    private Integer invoiceLineItemId;
    private BigDecimal weightPrPiece;
    private Integer qty;
    private Part part;
    private Boolean isDeleted;




    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getPkgId() {
        return pkgId;
    }

    public void setPkgId(Integer pkgId) {
        this.pkgId = pkgId;
    }

    public Integer getInvoiceLineItemId() {
        return invoiceLineItemId;
    }

    public void setInvoiceLineItemId(Integer invoiceLineItemId) {
        this.invoiceLineItemId = invoiceLineItemId;
    }

    public BigDecimal getWeightPrPiece() {
        return weightPrPiece;
    }

    public void setWeightPrPiece(BigDecimal weightPrPiece) {
        this.weightPrPiece = weightPrPiece;
    }


    public Integer getQty() {
        return qty;
    }

    public void setQty(Integer qty) {
        this.qty = qty;
    }

    public Part getPart() { return part; }

    public void setPart(Part part) { this.part = part; }

    public Integer getPkgNo() { return pkgNo; }

    public void setPkgNo(Integer pkgNo) { this.pkgNo = pkgNo; }

    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        if(isDeleted == null) {
            this.isDeleted = false;
        } else {
            this.isDeleted = isDeleted;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PkgDetail that = (PkgDetail) o;

        if (id != that.id) return false;
        if (pkgId != null ? !pkgId.equals(that.pkgId) : that.pkgId != null) return false;
        if (invoiceLineItemId != null ? !invoiceLineItemId.equals(that.invoiceLineItemId) : that.invoiceLineItemId != null) return false;
        if (weightPrPiece != null ? !weightPrPiece.equals(that.weightPrPiece) : that.weightPrPiece != null) return false;
        if (qty != null ? !qty.equals(that.qty) : that.qty != null) return false;
        if (part != null ? !part.equals(that.part) : that.part != null) return false;
        if (pkgNo != null ? !pkgNo.equals(that.pkgNo) : that.pkgNo != null) return false;
        if (isDeleted != null ? !isDeleted.equals(that.isDeleted) : that.isDeleted != null) return false;


        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (pkgId != null ? pkgId.hashCode() : 0);
        result = 31 * result + (invoiceLineItemId != null ? invoiceLineItemId.hashCode() : 0);
        result = 31 * result + (qty != null ? qty.hashCode() : 0);
        result = 31 * result + (weightPrPiece != null ? weightPrPiece.hashCode() : 0);
        result = 31 * result + (part != null ? part.hashCode() : 0);
        result = 31 * result + (pkgNo != null ? pkgNo.hashCode() : 0);
        result = 31 * result + (isDeleted != null ? isDeleted.hashCode() : 0);

        return result;
    }
}
