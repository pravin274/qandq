package com.qqs.qqsvcs.api;

import java.util.Date;
import java.util.Objects;

public class IdleTime {
    private int id;
    private Date fromTime;
    private Date toTime;
    private Integer machineId;
    private Integer idleTimeInMins;
    private String status;
    private String reason;
    private Machine machine;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getFromTime() {
        return fromTime;
    }

    public void setFromTime(Date fromTime) {
        this.fromTime = fromTime;
    }

    public Date getToTime() {
        return toTime;
    }

    public void setToTime(Date toTime) {
        this.toTime = toTime;
    }

    public Integer getMachineId() {
        return machineId;
    }

    public void setMachineId(Integer machineId) {
        this.machineId = machineId;
    }

    public Integer getIdleTimeInMins() {
        return idleTimeInMins;
    }

    public void setIdleTimeInMins(Integer idleTimeInMins) {
        this.idleTimeInMins = idleTimeInMins;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Machine getMachine() { return machine; }

    public void setMachine(Machine machine) { this.machine = machine; }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof IdleTime)) return false;
        IdleTime idleTime = (IdleTime) o;
        return getId() == idleTime.getId() &&
                getFromTime().equals(idleTime.getFromTime()) &&
                getToTime().equals(idleTime.getToTime()) &&
                getMachineId().equals(idleTime.getMachineId()) &&
                getIdleTimeInMins().equals(idleTime.getIdleTimeInMins()) &&
                getStatus().equals(idleTime.getStatus()) &&
                getReason().equals(idleTime.getReason()) &&
                getMachine().equals(idleTime.getMachine());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getFromTime(), getToTime(), getMachineId(), getIdleTimeInMins(), getStatus(), getReason(), getMachine());
    }

    @Override
    public String toString() {
        return "IdleTime{" +
                "id=" + id +
                ", fromTime=" + fromTime +
                ", toTime=" + toTime +
                ", machineId=" + machineId +
                ", idleTimeInMins=" + idleTimeInMins +
                ", status='" + status + '\'' +
                ", reason='" + reason + '\'' +
                ", machine=" + machine +
                '}';
    }
}
