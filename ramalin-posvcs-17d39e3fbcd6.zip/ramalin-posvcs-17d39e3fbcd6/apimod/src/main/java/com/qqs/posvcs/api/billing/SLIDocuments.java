package com.qqs.posvcs.api.billing;


public class SLIDocuments {
    private int id;
    private int invoiceId;
    private String document;
    private String value;
    private Boolean isDeleted;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(int invoiceId) {
        this.invoiceId = invoiceId;
    }

    public String getDocument() {
        return document;
    }

    public void setDocument(String document) {
        this.document = document;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public Boolean getIsDeleted() {
        if (isDeleted == null) return false;
        return isDeleted;
    }

    public void setIsDeleted(Boolean deleted) { isDeleted = deleted; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SLIDocuments that = (SLIDocuments) o;

        if (id != that.id) return false;
        if (invoiceId != that.invoiceId) return false;
        if (invoiceId != that.invoiceId) return false;
        if (document != null ? !document.equals(that.document) : that.document != null) return false;
        if (value != null ? !value.equals(that.value) : that.value != null) return false;

        return true;
    }

    @Override
    public int hashCode() {

        int result = id;
        result = 31 * result + invoiceId;
        result = 31 * result + (document != null ? document.hashCode() : 0);
        result = 31 * result + (value != null ? value.hashCode() : 0);
        return result;
    }
}



