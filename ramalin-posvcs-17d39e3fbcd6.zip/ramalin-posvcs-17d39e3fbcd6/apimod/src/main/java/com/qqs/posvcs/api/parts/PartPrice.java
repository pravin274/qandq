package com.qqs.posvcs.api.parts;
import java.sql.Timestamp;

public class PartPrice {
    private int id;
    private int partId;
    private String currency;
    private Double value;
    private String priceDesc;
    private String partCategory;
    private String defaultInd;
    private Timestamp effectiveDt;
    private Timestamp expiryDt;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPartId() {
        return partId;
    }

    public void setPartId(int partId) {
        this.partId = partId;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    public String getPriceDesc() {
        return priceDesc;
    }

    public void setPriceDesc(String priceDesc) {
        this.priceDesc = priceDesc;
    }

    public String getPartCategory() {
        return partCategory;
    }

    public void setPartCategory(String partCategory) {
        this.partCategory = partCategory;
    }

    public String getDefaultInd() {
        return defaultInd;
    }

    public void setDefaultInd(String defaultInd) {
        this.defaultInd = defaultInd;
    }

    public Timestamp getEffectiveDt() {
        return effectiveDt;
    }

    public void setEffectiveDt(Timestamp effectiveDt) {
        this.effectiveDt = effectiveDt;
    }

    public Timestamp getExpiryDt() {
        return expiryDt;
    }

    public void setExpiryDt(Timestamp expiryDt) {
        this.expiryDt = expiryDt;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("PartPrice{");
        sb.append("id=").append(id);
        sb.append(", partId=").append(partId);
        sb.append(", currency='").append(currency).append('\'');
        sb.append(", value=").append(value);
        sb.append(", priceDesc='").append(priceDesc).append('\'');
        sb.append(", defaultInd='").append(defaultInd).append('\'');
        sb.append(", effectiveDt=").append(effectiveDt);
        sb.append(", expiryDt=").append(expiryDt);
        sb.append('}');
        return sb.toString();
    }
}
