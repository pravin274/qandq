package com.qqs.posvcs.api.reports;

import java.util.List;
import java.util.Objects;

public class ChartDataSet {
    private String label;
    private List<String> data;
    private Boolean fill = false;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public List<String> getData() {
        return data;
    }

    public void setData(List<String> data) {
        this.data = data;
    }

    public Boolean getFill() {
        return fill;
    }

    public void setFill(Boolean fill) {
        this.fill = fill;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ChartDataSet chartDataSet = (ChartDataSet) o;
        if (!Objects.equals(label, chartDataSet.label)) return false;
        if (!Objects.equals(data, chartDataSet.data)) return false;
        if (!Objects.equals(fill, chartDataSet.fill)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (label != null ? label.hashCode() : 0);
        result = 31 * result + (data != null ? data.hashCode() : 0);
        result = 31 * result + (fill != null ? fill.hashCode() : 0);

        return result;
    }
}
