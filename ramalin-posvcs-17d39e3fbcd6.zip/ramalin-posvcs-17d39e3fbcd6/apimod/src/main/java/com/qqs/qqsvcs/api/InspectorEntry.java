package com.qqs.qqsvcs.api;

import java.util.Date;
import java.util.List;


public class InspectorEntry {
    private int id;
    private Integer inspectorId;
    private Date date;
    private Integer shiftId;

	private List<String> machineId;

 
    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Integer getInspectorId() {
		return inspectorId;
	}

	public void setInspectorId(Integer inspectorId) {
		this.inspectorId = inspectorId;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Integer getShiftId() {
		return shiftId;
	}

	public void setShiftId(Integer shiftId) {
		this.shiftId = shiftId;
	}   

	public List<String> getMachineId() { 
		return machineId; 
	}

    public void setMachineId(List<String> machineId) { 
		this.machineId = machineId;
	}

} 
