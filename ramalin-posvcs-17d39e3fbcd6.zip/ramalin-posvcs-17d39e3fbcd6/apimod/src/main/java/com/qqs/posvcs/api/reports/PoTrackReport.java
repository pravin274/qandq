package com.qqs.posvcs.api.reports;

import java.util.Map;
import java.util.Objects;

public class PoTrackReport {
    private Integer invoiceId;
    private String invoiceDate;
    private Double totalInvoiceValue;
    private String invoiceNumber;
    private String companyName;
    private String plantName;
    private Integer companyId;
    private Integer plantId;
    private String invoiceStatus;
    private String invoiceStatusCode;
    private String poNumber;
    private String itemNumber;
    private String partType;
    private String invoiceQuantity;
    private String poQuantity;
    private String poDate;
    private String partNumber;
    private String partRevisionNumber;
    private String description;
    private String hsCode;
    private String dueDate;
    private Double pOValue;
    private Double pOValueINR;
    private Double pendingValue;
    private Double pendingValueINR;
    private String poStatus;
    private String poRevision;
    private String pendingQty;
    private String pricePerPart;
    private Double totalInvoiceValueINR;
    private Map<String, Map<String, String>> invoiceStatusMap;


    public Integer getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Integer invoiceId) {
        this.invoiceId = invoiceId;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public Double getTotalInvoiceValue() {
        return totalInvoiceValue;
    }

    public void setTotalInvoiceValue(Double totalInvoiceValue) {
        this.totalInvoiceValue = totalInvoiceValue;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getPlantName() {
        return plantName;
    }

    public void setPlantName(String plantName) {
        this.plantName = plantName;
    }

    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    public Integer getPlantId() {
        return plantId;
    }

    public void setPlantId(Integer plantId) {
        this.plantId = plantId;
    }

    public String getInvoiceStatus() {
        return invoiceStatus;
    }

    public void setInvoiceStatus(String invoiceStatus) {
        this.invoiceStatus = invoiceStatus;
    }

    public String getInvoiceStatusCode() {
        return invoiceStatusCode;
    }

    public void setInvoiceStatusCode(String invoiceStatusCode) {
        this.invoiceStatusCode = invoiceStatusCode;
    }

    public String getPoNumber() {
        return poNumber;
    }

    public void setPoNumber(String poNumber) {
        this.poNumber = poNumber;
    }

    public String getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(String itemNumber) {
        this.itemNumber = itemNumber;
    }

    public String getPartType() {
        return partType;
    }

    public void setPartType(String partType) {
        this.partType = partType;
    }

    public String getInvoiceQuantity() {
        return invoiceQuantity;
    }

    public void setInvoiceQuantity(String invoiceQuantity) {
        this.invoiceQuantity = invoiceQuantity;
    }

    public String getPoQuantity() {
        return poQuantity;
    }

    public void setPoQuantity(String poQuantity) {
        this.poQuantity = poQuantity;
    }

    public String getPoDate() {
        return poDate;
    }

    public void setPoDate(String poDate) {
        this.poDate = poDate;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getPartRevisionNumber() {
        return partRevisionNumber;
    }

    public void setPartRevisionNumber(String partRevisionNumber) {
        this.partRevisionNumber = partRevisionNumber;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getHsCode() {
        return hsCode;
    }

    public void setHsCode(String hsCode) {
        this.hsCode = hsCode;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public Map<String, Map<String, String>> getInvoiceStatusMap() {
        return invoiceStatusMap;
    }

    public void setInvoiceStatusMap(Map<String, Map<String, String>> invoiceStatusMap) {
        this.invoiceStatusMap = invoiceStatusMap;
    }

    public String getPoStatus() {
        return poStatus;
    }

    public void setPoStatus(String poStatus) {
        this.poStatus = poStatus;
    }

    public String getPoRevision() {
        return poRevision;
    }

    public void setPoRevision(String poRevision) {
        this.poRevision = poRevision;
    }

    public String getPendingQty() {
        return pendingQty;
    }

    public void setPendingQty(String pendingQty) {
        this.pendingQty = pendingQty;
    }

    public Double getpOValue() {
        return pOValue;
    }

    public void setpOValue(Double pOValue) {
        this.pOValue = pOValue;
    }

    public Double getPendingValue() {
        return pendingValue;
    }

    public void setPendingValue(Double pendingValue) {
        this.pendingValue = pendingValue;
    }

    public String getPricePerPart() {
        return pricePerPart;
    }

    public void setPricePerPart(String pricePerPart) {
        this.pricePerPart = pricePerPart;
    }

    public Double getpOValueINR() {
        return pOValueINR;
    }

    public void setpOValueINR(Double pOValueINR) {
        this.pOValueINR = pOValueINR;
    }

    public Double getPendingValueINR() {
        return pendingValueINR;
    }

    public void setPendingValueINR(Double pendingValueINR) {
        this.pendingValueINR = pendingValueINR;
    }

    public Double getTotalInvoiceValueINR() {
        return totalInvoiceValueINR;
    }

    public void setTotalInvoiceValueINR(Double totalInvoiceValueINR) {
        this.totalInvoiceValueINR = totalInvoiceValueINR;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PoTrackReport)) return false;
        PoTrackReport that = (PoTrackReport) o;
        return Objects.equals(getInvoiceId(), that.getInvoiceId()) &&
                Objects.equals(getInvoiceDate(), that.getInvoiceDate()) &&
                Objects.equals(getTotalInvoiceValue(), that.getTotalInvoiceValue()) &&
                Objects.equals(getInvoiceNumber(), that.getInvoiceNumber()) &&
                Objects.equals(getCompanyName(), that.getCompanyName()) &&
                Objects.equals(getPlantName(), that.getPlantName()) &&
                Objects.equals(getCompanyId(), that.getCompanyId()) &&
                Objects.equals(getPlantId(), that.getPlantId()) &&
                Objects.equals(getInvoiceStatus(), that.getInvoiceStatus()) &&
                Objects.equals(getInvoiceStatusCode(), that.getInvoiceStatusCode()) &&
                Objects.equals(getPoNumber(), that.getPoNumber()) &&
                Objects.equals(getItemNumber(), that.getItemNumber()) &&
                Objects.equals(getPartType(), that.getPartType()) &&
                Objects.equals(getInvoiceQuantity(), that.getInvoiceQuantity()) &&
                Objects.equals(getPoQuantity(), that.getPoQuantity()) &&
                Objects.equals(getPoDate(), that.getPoDate()) &&
                Objects.equals(getPartNumber(), that.getPartNumber()) &&
                Objects.equals(getPartRevisionNumber(), that.getPartRevisionNumber()) &&
                Objects.equals(getDescription(), that.getDescription()) &&
                Objects.equals(getHsCode(), that.getHsCode()) &&
                Objects.equals(getDueDate(), that.getDueDate());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getInvoiceId(), getInvoiceDate(), getTotalInvoiceValue(), getInvoiceNumber(), getCompanyName(), getPlantName(), getCompanyId(), getPlantId(), getInvoiceStatus(), getInvoiceStatusCode(), getPoNumber(), getItemNumber(), getPartType(), getInvoiceQuantity(), getPoQuantity(), getPoDate(), getPartNumber(), getPartRevisionNumber(), getDescription(), getHsCode(), getDueDate());
    }
}
