package com.qqs.qqsvcs.api.reports;

import java.util.Objects;

public class IdleTimeReportData{

    String fromTime;
    String toTime;
    String machineName;
    String idleTimeInMins;
    String reason;
    String name;
    String shift;


    public String getFromTime() {
        return fromTime;
    }

    public void setFromTime(String fromTime) {
        this.fromTime = fromTime;
    }

    public String getToTime() {
        return toTime;
    }

    public void setToTime(String toTime) { this.toTime = toTime; }

    public String getIdleTimeInMins() { return idleTimeInMins; }

    public String getMachineName() { return machineName; }

    public void setMachineName(String machineName) { this.machineName = machineName; }

    public void setIdleTimeInMins(String idleTimeInMins) { this.idleTimeInMins = idleTimeInMins; }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShift() {
        return shift;
    }

    public void setShift(String shift) {
        this.shift = shift;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        IdleTimeReportData idleTimeReportData = (IdleTimeReportData) o;

        if (!Objects.equals(fromTime, idleTimeReportData.fromTime)) return false;
        if (!Objects.equals(toTime, idleTimeReportData.toTime)) return false;
        if (!Objects.equals(machineName, idleTimeReportData.machineName)) return false;
        if (!Objects.equals(idleTimeInMins, idleTimeReportData.idleTimeInMins)) return false;
        if (!Objects.equals(reason, idleTimeReportData.reason)) return false;
        if (!Objects.equals(name, idleTimeReportData.name)) return false;
        if (!Objects.equals(shift, idleTimeReportData.shift)) return false;


        return true;
    }

    @Override
    public int hashCode() {
        int result = (fromTime != null ? fromTime.hashCode() : 0);
        result = 31 * result + (toTime != null ? toTime.hashCode() : 0);
        result = 31 * result + (machineName != null ? machineName.hashCode() : 0);
        result = 31 * result + (idleTimeInMins != null ? idleTimeInMins.hashCode() : 0);
        result = 31 * result + (reason != null ? reason.hashCode() : 0);
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (shift != null ? shift.hashCode() : 0);


        return result;
    }


}
