package com.qqs.qqsvcs.api;

import com.qqs.invsvcs.api.InvProductDetails;

public class Tool {
    private int id;
    private String name;
    private String type;
    private String modelNo;
    private String make;
    private Integer noOfInsert;
    private InvProductDetails invProductDetails;

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public String getType() { return type; }

    public void setType(String type) { this.type = type; }

    public String getModelNo() { return modelNo; }

    public void setModelNo(String modelNo) { this.modelNo = modelNo; }

    public String getMake() { return make; }

    public void setMake(String make) { this.make = make; }

    public Integer getNoOfInsert() { return noOfInsert; }

    public void setNoOfInsert(Integer noOfInsert) { this.noOfInsert = noOfInsert; }

    public InvProductDetails getInvProductDetails() {
        return invProductDetails;
    }

    public void setInvProductDetails(InvProductDetails invProductDetails) {
        this.invProductDetails = invProductDetails;
    }

    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        if (!super.equals(object)) return false;

        Tool that = (Tool) object;

        if (id != that.id) return false;
        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        if (type != null ? !type.equals(that.type) : that.type != null) return false;
        if (modelNo != null ? !modelNo.equals(that.modelNo) : that.modelNo != null) return false;
        if (make != null ? !make.equals(that.make) : that.make != null) return false;
        if (noOfInsert != null ? !noOfInsert.equals(that.noOfInsert) : that.noOfInsert != null) return false;
        if (invProductDetails != null ? !invProductDetails.equals(that.invProductDetails) : that.invProductDetails != null) return false;

        return true;
    }

    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + id;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (type != null ? type.hashCode() : 0);
        result = 31 * result + (modelNo != null ? modelNo.hashCode() : 0);
        result = 31 * result + (make != null ? make.hashCode() : 0);
        result = 31 * result + (noOfInsert != null ? noOfInsert.hashCode() : 0);

        result = 31 * result + (invProductDetails != null ? invProductDetails.hashCode() : 0);
        return result;
    }
}
