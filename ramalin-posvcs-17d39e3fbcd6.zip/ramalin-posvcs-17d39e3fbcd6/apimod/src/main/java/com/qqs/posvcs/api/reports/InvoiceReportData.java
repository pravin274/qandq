package com.qqs.posvcs.api.reports;

import java.util.Map;

public class InvoiceReportData {
    private Integer invoiceId;
    private String invoiceDate;
    private Double totalInvoiceValue;
    private String invoiceNumber;
    private String companyName;
    private String plantName;
    private Integer companyId;
    private Integer plantId;
    private String invoiceStatus;
    private String invoiceStatusCode;


    private Map<String, Map<String, String>> invoiceStatusMap;

    public Integer getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Integer invoiceId) {
        this.invoiceId = invoiceId;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public Double getTotalInvoiceValue() {
        return totalInvoiceValue;
    }

    public void setTotalInvoiceValue(Double totalInvoiceValue) {
        this.totalInvoiceValue = totalInvoiceValue;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public Map<String, Map<String, String>> getInvoiceStatusMap() {
        return invoiceStatusMap;
    }

    public void setInvoiceStatusMap(Map<String, Map<String, String>> invoiceStatusMap) {
        this.invoiceStatusMap = invoiceStatusMap;
    }

    public String getInvoiceStatus() {
        return invoiceStatus;
    }

    public void setInvoiceStatus(String invoiceStatus) {
        this.invoiceStatus = invoiceStatus;
    }

    public String getCompanyName() { return companyName; }

    public void setCompanyName(String companyName) { this.companyName = companyName; }

    public String getPlantName() { return plantName; }

    public void setPlantName(String plantName) { this.plantName = plantName; }

    public Integer getCompanyId() { return companyId; }

    public void setCompanyId(Integer companyId) { this.companyId = companyId; }

    public Integer getPlantId() { return plantId; }

    public void setPlantId(Integer plantId) { this.plantId = plantId; }

    public String getInvoiceStatusCode() { return invoiceStatusCode; }

    public void setInvoiceStatusCode(String invoiceStatusCode) { this.invoiceStatusCode = invoiceStatusCode; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        InvoiceReportData invoiceReportData = (InvoiceReportData) o;

        if (invoiceId != invoiceReportData.invoiceId) return false;
        if (invoiceDate != null ? !invoiceDate.equals(invoiceReportData.invoiceDate) : invoiceReportData.invoiceDate != null) return false;
        if (invoiceNumber != null ? !invoiceNumber.equals(invoiceReportData.invoiceNumber) : invoiceReportData.invoiceNumber != null) return false;
        if (companyName != null ? !companyName.equals(invoiceReportData.companyName) : invoiceReportData.companyName != null) return false;
        if (plantName != null ? !plantName.equals(invoiceReportData.plantName) : invoiceReportData.plantName != null) return false;
        if (totalInvoiceValue != null ? !totalInvoiceValue.equals(invoiceReportData.totalInvoiceValue) : invoiceReportData.totalInvoiceValue != null) return false;
        if (invoiceStatusMap != null ? !invoiceStatusMap.equals(invoiceReportData.invoiceStatusMap) : invoiceReportData.invoiceStatusMap != null) return false;
        if (invoiceStatus != null ? !invoiceStatus.equals(invoiceReportData.invoiceStatus) : invoiceReportData.invoiceStatus != null) return false;
        if (invoiceStatusCode != null ? !invoiceStatusCode.equals(invoiceReportData.invoiceStatusCode) : invoiceReportData.invoiceStatusCode != null) return false;
        if (companyId != null ? !companyId.equals(invoiceReportData.companyId) : invoiceReportData.companyId != null) return false;
        if (plantId != null ? !plantId.equals(invoiceReportData.plantId) : invoiceReportData.plantId != null) return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = invoiceId;
        result = 31 * result + (totalInvoiceValue != null ? totalInvoiceValue.hashCode() : 0);
        result = 31 * result + (invoiceDate != null ? invoiceDate.hashCode() : 0);
        result = 31 * result + (invoiceNumber != null ? invoiceNumber.hashCode() : 0);
        result = 31 * result + (companyName != null ? companyName.hashCode() : 0);
        result = 31 * result + (plantName != null ? plantName.hashCode() : 0);
        result = 31 * result + (companyId != null ? companyId.hashCode() : 0);
        result = 31 * result + (plantId != null ? plantId.hashCode() : 0);
        result = 31 * result + (invoiceStatusMap != null ? invoiceStatusMap.hashCode() : 0);
        result = 31 * result + (invoiceStatus != null ? invoiceStatus.hashCode() : 0);
        result = 31 * result + (invoiceStatusCode != null ? invoiceStatusCode.hashCode() : 0);

        return result;
    }
}
