package com.qqs.posvcs.api.parts;


import java.sql.Timestamp;

public class PartImage {
    private int id;
    private int partId;
    private byte[] imageData;
    private String imageFileName;
    private String remarks;
    private String imageType;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPartId() {
        return partId;
    }

    public void setPartId(int partId) {
        this.partId = partId;
    }

    public byte[] getImageData() {
        return imageData;
    }

    public void setImageData(byte[] imageData) {
        this.imageData = imageData;
    }

    public String getImageType() {
        return imageType;
    }

    public void setImageType(String imageType) {
        this.imageType = imageType;
    }
    public String getImageFileName() {
        return imageFileName;
    }

    public void setImageFileName(String imageFileName) {
        this.imageFileName = imageFileName;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }


    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("PartImage{");
        sb.append("id=").append(id);
        sb.append(", partId=").append(partId);
        sb.append(", imageData=");
        if (imageData == null) sb.append("null");
        else {
            sb.append('[');
            for (int i = 0; i < imageData.length; ++i)
                sb.append(i == 0 ? "" : ", ").append(imageData[i]);
            sb.append(']');
        }
        sb.append('}');
        return sb.toString();
    }
}
