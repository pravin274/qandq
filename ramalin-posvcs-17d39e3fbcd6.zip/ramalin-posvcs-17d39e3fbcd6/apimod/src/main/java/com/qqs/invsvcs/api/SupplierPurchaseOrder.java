package com.qqs.invsvcs.api;

import java.sql.Timestamp;
import java.util.Objects;
import java.util.Set;

public class SupplierPurchaseOrder {
    private int id;
    private Integer supplierId;
    private String poNumber;
    private Timestamp poDate;
    private String poFileName;
    private String poStatus;
    private String quotationNumber;
    private Timestamp quotationDate;
    private Set<SupplierPoLineItem> supplierPoLineItem;
    private Supplier supplier;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(Integer supplierId) {
        this.supplierId = supplierId;
    }

    public String getPoNumber() {
        return poNumber;
    }

    public void setPoNumber(String poNumber) {
        this.poNumber = poNumber;
    }

    public Timestamp getPoDate() {
        return poDate;
    }

    public void setPoDate(Timestamp poDate) {
        this.poDate = poDate;
    }

    public String getPoFileName() {
        return poFileName;
    }

    public void setPoFileName(String poFileName) {
        this.poFileName = poFileName;
    }

    public String getPoStatus() {
        return poStatus;
    }

    public void setPoStatus(String poStatus) {
        this.poStatus = poStatus;
    }


    public String getQuotationNumber() {
        return quotationNumber;
    }

    public void setQuotationNumber(String quotationNumber) {
        this.quotationNumber = quotationNumber;
    }

    public Timestamp getQuotationDate() {
        return quotationDate;
    }

    public void setQuotationDate(Timestamp quotationDate) {
        this.quotationDate = quotationDate;
    }


    public Set<SupplierPoLineItem> getSupplierPoLineItem() {
        return supplierPoLineItem;
    }

    public void setSupplierPoLineItem(Set<SupplierPoLineItem> supplierPoLineItem) {
        this.supplierPoLineItem = supplierPoLineItem;
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SupplierPurchaseOrder)) return false;
        SupplierPurchaseOrder that = (SupplierPurchaseOrder) o;
        return getId() == that.getId() &&
                Objects.equals(getSupplierId(), that.getSupplierId()) &&
                Objects.equals(getPoNumber(), that.getPoNumber()) &&
                Objects.equals(getPoDate(), that.getPoDate()) &&
                Objects.equals(getPoFileName(), that.getPoFileName()) &&
                Objects.equals(getPoStatus(), that.getPoStatus()) &&
                Objects.equals(getQuotationNumber(), that.getQuotationNumber()) &&
                Objects.equals(getQuotationDate(), that.getQuotationDate()) &&
                Objects.equals(getSupplierPoLineItem(), that.getSupplierPoLineItem()) &&
                Objects.equals(getSupplier(), that.getSupplier());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getSupplierId(), getPoNumber(), getPoDate(), getPoFileName(), getPoStatus(), getQuotationNumber(),
                getQuotationDate(), getSupplierPoLineItem(), getSupplier());
    }
}
