package com.qqs.qqsvcs.api;

import java.util.Date;

public class Salary {
    private int id;
    private int employeeId;
    private String basics;
    private String da;
    private String hra;
    private Date fromDate;
    private Date toDate;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getBasics() {
        return basics;
    }

    public void setBasics(String basics) {
        this.basics = basics;
    }

    public String getDa() {
        return da;
    }

    public void setDa(String da) {
        this.da = da;
    }

    public String getHra() {
        return hra;
    }

    public void setHra(String hra) {
        this.hra = hra;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }


    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        if (!super.equals(object)) return false;

        Salary that = (Salary) object;

        if (id != that.id) return false;
        if (employeeId != that.employeeId) return false;
        if (basics != null ? !basics.equals(that.basics) : that.basics != null) return false;
        if (da != null ? !da.equals(that.da) : that.da != null) return false;
        if (hra != null ? !hra.equals(that.hra) : that.hra != null) return false;
        if (fromDate != null ? !fromDate.equals(that.fromDate) : that.fromDate != null) return false;
        if (toDate != null ? !toDate.equals(that.toDate) : that.toDate != null) return false;

        return true;
    }

    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + id;
        result = 31 * result + employeeId;
        result = 31 * result + (basics != null ? basics.hashCode() : 0);
        result = 31 * result + (da != null ? da.hashCode() : 0);
        result = 31 * result + (hra != null ? hra.hashCode() : 0);
        result = 31 * result + (fromDate != null ? fromDate.hashCode() : 0);
        result = 31 * result + (toDate != null ? toDate.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Salary{");
        sb.append("id=").append(id);
        sb.append("employeeId=").append(employeeId);
        sb.append(", basics=").append(basics);
        sb.append(", da='").append(da).append('\'');
        sb.append(", hra='").append(hra).append('\'');
        sb.append(", fromDate='").append(fromDate).append('\'');
        sb.append(", toDate='").append(toDate).append('\'');
        sb.append('}');
        return sb.toString();
    }


}
