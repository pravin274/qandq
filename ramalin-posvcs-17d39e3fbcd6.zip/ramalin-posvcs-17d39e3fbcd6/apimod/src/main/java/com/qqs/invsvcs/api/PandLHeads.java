package com.qqs.invsvcs.api;

import java.util.Objects;

public class PandLHeads {
    private int id;
    private String pandLCategory;
    private Integer parentHeadsId;
    private String heads;
    private String description;
    private Integer displaySeq;
    private String isUserGenerated;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPandLCategory() {
        return pandLCategory;
    }

    public void setPandLCategory(String pandLCategory) {
        this.pandLCategory = pandLCategory;
    }

    public String getHeads() {
        return heads;
    }

    public void setHeads(String heads) {
        this.heads = heads;
    }

    public Integer getParentHeadsId() {
        return parentHeadsId;
    }

    public void setParentHeadsId(Integer parentHeadsId) {
        this.parentHeadsId = parentHeadsId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getDisplaySeq() {
        return displaySeq;
    }

    public void setDisplaySeq(Integer displaySeq) {
        this.displaySeq = displaySeq;
    }

    public String getIsUserGenerated() {
        if (isUserGenerated == null) return "Y";
        return isUserGenerated;
    }

    public void setIsUserGenerated(String isUserGenerated) {
        if (isUserGenerated == null) {
            this.isUserGenerated = "Y";
        } else {
            this.isUserGenerated = isUserGenerated;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PandLHeads pandLHeads = (PandLHeads) o;

        if (id != pandLHeads.id) return false;
        if (!Objects.equals(pandLCategory, pandLHeads.pandLCategory)) return false;
        if (!Objects.equals(parentHeadsId, pandLHeads.parentHeadsId)) return false;
        if (!Objects.equals(heads, pandLHeads.heads)) return false;
        if (!Objects.equals(description, pandLHeads.description)) return false;
        if (!Objects.equals(displaySeq, pandLHeads.displaySeq)) return false;
        if (!Objects.equals(isUserGenerated, pandLHeads.isUserGenerated)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (pandLCategory != null ? pandLCategory.hashCode() : 0);
        result = 31 * result + (parentHeadsId != null ? parentHeadsId.hashCode() : 0);
        result = 31 * result + (heads != null ? heads.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (displaySeq != null ? displaySeq.hashCode() : 0);
        result = 31 * result + (isUserGenerated != null ? isUserGenerated.hashCode() : 0);
        return result;
    }



}
