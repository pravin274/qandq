package com.qqs.posvcs.api;

import java.util.Date;

public class PoLineItemxCurrentStatus {
    private int id;
    private int poLineItemId;
    private String currentStatus;
    private Date date;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPoLineItemId() {
        return poLineItemId;
    }

    public void setPoLineItemId(int poLineItemId) {
        this.poLineItemId = poLineItemId;
    }

    public String getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("PoLineItem{");
        sb.append("id=").append(id);
        sb.append(", poLineItemId=").append(poLineItemId);
        sb.append(", currentStatus=").append(currentStatus);
        sb.append(", date='").append(date).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
