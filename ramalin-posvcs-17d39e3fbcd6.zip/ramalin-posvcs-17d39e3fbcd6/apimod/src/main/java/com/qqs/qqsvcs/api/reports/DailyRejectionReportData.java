package com.qqs.qqsvcs.api.reports;

import java.util.Objects;

public class DailyRejectionReportData{
    
    String month;
    String date;
    String shift;
    String machineName;
    String empCode;
    String qaInspectorName;
	String productionEmpCode;
    String productionInchargeName;
	String operatorEmpCode;
    String operatorName;
    String experienceInYr;
    String partCode;
    String partNo;
    String partName;
    String partWeight;
    String totalWeight;
    String reasonForRejection;
    String rejectionSingleWorld;
    String rootCause;
    String rootCauseDetails;
    String systemCode;
    String systemDetails;
    String reason;
    String correctiveAction;
    String targetDate;
    String responsibility;
    String status;
    String closedDate;
    String remarks;
  
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getShift() {
		return shift;
	}
	public void setShift(String shift) {
		this.shift = shift;
	}
	public String getMachineName() {
		return machineName;
	}
	public void setMachineName(String machineName) {
		this.machineName = machineName;
	}
	public String getEmpCode() {
		return empCode;
	}
	public void setEmpCode(String empCode) {
		this.empCode = empCode;
	}
	public String getQaInspectorName() {
		return qaInspectorName;
	}
	public void setQaInspectorName(String qaInspectorName) {
		this.qaInspectorName = qaInspectorName;
	}
	public String getProductionEmpCode() {
		return productionEmpCode;
	}
	public void setProductionEmpCode(String productionEmpCode) {
		this.productionEmpCode = productionEmpCode;
	}
	public String getProductionInchargeName() {
		return productionInchargeName;
	}
	public void setProductionInchargeName(String productionInchargeName) {
		this.productionInchargeName = productionInchargeName;
	}
	public String getOperatorEmpCode() {
		return operatorEmpCode;
	}
	public void setOperatorEmpCode(String operatorEmpCode) {
		this.operatorEmpCode = operatorEmpCode;
	}
	public String getOperatorName() {
		return operatorName;
	}
	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}
	public String getExperienceInYr() {
		return experienceInYr;
	}
	public void setExperienceInYr(String experienceInYr) {
		this.experienceInYr = experienceInYr;
	}
	public String getPartCode() {
		return partCode;
	}
	public void setPartCode(String partCode) {
		this.partCode = partCode;
	}
	public String getPartNo() {
		return partNo;
	}
	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}
	public String getPartName() {
		return partName;
	}
	public void setPartName(String partName) {
		this.partName = partName;
	}
	public String getPartWeight() {
		return partWeight;
	}
	public void setPartWeight(String partWeight) {
		this.partWeight = partWeight;
	}
	public String getTotalWeight() {
		return totalWeight;
	}
	public void setTotalWeight(String totalWeight) {
		this.totalWeight = totalWeight;
	}
	public String getReasonForRejection() {
		return reasonForRejection;
	}
	public void setReasonForRejection(String reasonForRejection) {
		this.reasonForRejection = reasonForRejection;
	}
	public String getRejectionSingleWorld() {
		return rejectionSingleWorld;
	}
	public void setRejectionSingleWorld(String rejectionSingleWorld) {
		this.rejectionSingleWorld = rejectionSingleWorld;
	}
	public String getRootCause() {
		return rootCause;
	}
	public void setRootCause(String rootCause) {
		this.rootCause = rootCause;
	}
	public String getRootCauseDetails() {
		return rootCauseDetails;
	}
	public void setRootCauseDetails(String rootCauseDetails) {
		this.rootCauseDetails = rootCauseDetails;
	}
	public String getSystemCode() {
		return systemCode;
	}
	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}
	public String getSystemDetails() {
		return systemDetails;
	}
	public void setSystemDetails(String systemDetails) {
		this.systemDetails = systemDetails;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getCorrectiveAction() {
		return correctiveAction;
	}
	public void setCorrectiveAction(String correctiveAction) {
		this.correctiveAction = correctiveAction;
	}
	public String getTargetDate() {
		return targetDate;
	}
	public void setTargetDate(String targetDate) {
		this.targetDate = targetDate;
	}
	public String getResponsibility() {
		return responsibility;
	}
	public void setResponsibility(String responsibility) {
		this.responsibility = responsibility;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getClosedDate() {
		return closedDate;
	}
	public void setClosedDate(String closedDate) {
		this.closedDate = closedDate;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

     @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DailyRejectionReportData dailyRejectionReportData = (DailyRejectionReportData) o;

        if (!Objects.equals(month, dailyRejectionReportData.month)) return false;
        if (!Objects.equals(date, dailyRejectionReportData.date)) return false;
        if (!Objects.equals(shift, dailyRejectionReportData.shift)) return false;        
        if (!Objects.equals(machineName, dailyRejectionReportData.machineName)) return false;
        if (!Objects.equals(empCode, dailyRejectionReportData.empCode)) return false;
        if (!Objects.equals(qaInspectorName, dailyRejectionReportData.qaInspectorName)) return false;
		if (!Objects.equals(productionEmpCode, dailyRejectionReportData.productionEmpCode)) return false;
        if (!Objects.equals(productionInchargeName, dailyRejectionReportData.productionInchargeName)) return false;
		if (!Objects.equals(operatorEmpCode, dailyRejectionReportData.operatorEmpCode)) return false;
        if (!Objects.equals(operatorName, dailyRejectionReportData.operatorName)) return false;
        if (!Objects.equals(experienceInYr, dailyRejectionReportData.experienceInYr)) return false;  
        if (!Objects.equals(partCode, dailyRejectionReportData.partCode)) return false;
        if (!Objects.equals(partNo, dailyRejectionReportData.partNo)) return false;
        if (!Objects.equals(partName, dailyRejectionReportData.partName)) return false;
        if (!Objects.equals(partWeight, dailyRejectionReportData.partWeight)) return false;
        if (!Objects.equals(totalWeight, dailyRejectionReportData.totalWeight)) return false;
        if (!Objects.equals(reasonForRejection, dailyRejectionReportData.reasonForRejection)) return false;
        if (!Objects.equals(rejectionSingleWorld, dailyRejectionReportData.rejectionSingleWorld)) return false;
        if (!Objects.equals(rootCause, dailyRejectionReportData.rootCause)) return false;
        if (!Objects.equals(rootCauseDetails, dailyRejectionReportData.rootCauseDetails)) return false;
        if (!Objects.equals(systemCode, dailyRejectionReportData.systemCode)) return false;
        if (!Objects.equals(systemDetails, dailyRejectionReportData.systemDetails)) return false;
        if (!Objects.equals(reason, dailyRejectionReportData.reason)) return false;
        if (!Objects.equals(correctiveAction, dailyRejectionReportData.correctiveAction)) return false;
        if (!Objects.equals(targetDate, dailyRejectionReportData.targetDate)) return false;
        if (!Objects.equals(responsibility, dailyRejectionReportData.responsibility)) return false;
        if (!Objects.equals(status, dailyRejectionReportData.status)) return false;
        if (!Objects.equals(closedDate, dailyRejectionReportData.closedDate)) return false;
        if (!Objects.equals(remarks, dailyRejectionReportData.remarks)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (month != null ? month.hashCode() : 0);
        result = 31 * result + (date != null ? date.hashCode() : 0);
        result = 31 * result + (shift != null ? shift.hashCode() : 0);
        result = 31 * result + (machineName != null ? machineName.hashCode() : 0);
        result = 31 * result + (empCode != null ? empCode.hashCode() : 0);
        result = 31 * result + (qaInspectorName != null ? qaInspectorName.hashCode() : 0);
		result = 31 * result + (productionEmpCode != null ? productionEmpCode.hashCode() : 0);
        result = 31 * result + (productionInchargeName != null ? productionInchargeName.hashCode() : 0);
		result = 31 * result + (operatorEmpCode != null ? operatorEmpCode.hashCode() : 0);
        result = 31 * result + (operatorName != null ? operatorName.hashCode() : 0);
        result = 31 * result + (experienceInYr != null ? experienceInYr.hashCode() : 0);
        result = 31 * result + (partCode != null ? partCode.hashCode() : 0);
        result = 31 * result + (partNo != null ? partNo.hashCode() : 0);
        result = 31 * result + (partName != null ? partName.hashCode() : 0);
        result = 31 * result + (partWeight != null ? partWeight.hashCode() : 0);
        result = 31 * result + (totalWeight != null ? totalWeight.hashCode() : 0);
        result = 31 * result + (reasonForRejection != null ? reasonForRejection.hashCode() : 0);
        result = 31 * result + (rejectionSingleWorld != null ? rejectionSingleWorld.hashCode() : 0);
        result = 31 * result + (rootCause != null ? rootCause.hashCode() : 0);
        result = 31 * result + (rootCauseDetails != null ? rootCauseDetails.hashCode() : 0);
        result = 31 * result + (systemCode != null ? systemCode.hashCode() : 0);
        result = 31 * result + (systemDetails != null ? systemDetails.hashCode() : 0);
        result = 31 * result + (reason != null ? reason.hashCode() : 0);
        result = 31 * result + (correctiveAction != null ? correctiveAction.hashCode() : 0);
        result = 31 * result + (targetDate != null ? targetDate.hashCode() : 0);
        result = 31 * result + (responsibility != null ? responsibility.hashCode() : 0);
        result = 31 * result + (closedDate != null ? closedDate.hashCode() : 0);
        result = 31 * result + (remarks != null ? remarks.hashCode() : 0);


        return result;
    }

}
