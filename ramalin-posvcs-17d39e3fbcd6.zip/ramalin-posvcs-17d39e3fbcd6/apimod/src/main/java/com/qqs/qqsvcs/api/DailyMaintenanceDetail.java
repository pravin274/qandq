package com.qqs.qqsvcs.api;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Objects;

public class DailyMaintenanceDetail {
    private int id;
    private Integer dailyMaintenanceId;
    private Integer machineId;
    private Date date;
    private String statusValue;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getDailyMaintenanceId() {
        return dailyMaintenanceId;
    }

    public void setDailyMaintenanceId(Integer dailyMaintenanceId) {
        this.dailyMaintenanceId = dailyMaintenanceId;
    }

    public String getStatusValue() {
        return statusValue;
    }

    public void setStatusValue(String statusValue) {
        this.statusValue = statusValue;
    }


    public Integer getMachineId() {
        return machineId;
    }

    public void setMachineId(Integer machineId) {
        this.machineId = machineId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Timestamp date) {
        this.date = date;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof DailyMaintenanceDetail)) return false;
        DailyMaintenanceDetail that = (DailyMaintenanceDetail) o;
        return id == that.id &&
                dailyMaintenanceId.equals(that.dailyMaintenanceId) &&
                machineId.equals(that.machineId) &&
                date.equals(that.date) &&
                statusValue.equals(that.statusValue);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, dailyMaintenanceId, machineId, date, statusValue);
    }

    @Override
    public String toString() {
        return "DailyMaintenanceDetail{" +
                "id=" + id +
                ", dailyMaintenanceId=" + dailyMaintenanceId +
                ", machineId=" + machineId +
                ", date=" + date +
                ", statusValue='" + statusValue + '\'' +
                '}';
    }

}
