package com.qqs.posvcs.api.reports;

import java.util.List;
import java.util.Objects;
import java.util.Set;

public class ChartData {
    private Set<String> labels;
    private List<ChartDataSet> dataSets;

    public Set<String> getLabels() {
        return labels;
    }

    public void setLabels(Set<String> labels) {
        this.labels = labels;
    }

    public List<ChartDataSet> getDataSets() {
        return dataSets;
    }

    public void setDataSets(List<ChartDataSet> dataSets) {
        this.dataSets = dataSets;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ChartData chartData = (ChartData) o;

        if (!Objects.equals(labels, chartData.labels)) return false;
        if (!Objects.equals(dataSets, chartData.dataSets)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (labels != null ? labels.hashCode() : 0);
        result = 31 * result + (dataSets != null ? dataSets.hashCode() : 0);

        return result;
    }
}
