package com.qqs.posvcs;

import org.junit.Test;


public class TestPasswordSvcs {
    @Test
    public void generatePassword(){
        /*
        Md5PasswordEncoder md5 = new Md5PasswordEncoder();
        System.out.println(md5.encodePassword("sunday", "sorna2025velu"));

         */
    }
}
