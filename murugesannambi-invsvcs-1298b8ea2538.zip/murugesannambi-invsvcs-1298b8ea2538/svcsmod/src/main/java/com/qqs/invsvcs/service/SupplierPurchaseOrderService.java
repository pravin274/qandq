package com.qqs.invsvcs.service;

import com.qqs.invsvcs.api.SupplierPoLineItem;
import com.qqs.invsvcs.api.SupplierPurchaseOrder;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import com.qqs.invsvcs.utils.Constants;
import org.springframework.web.client.RestTemplate;


import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;
import java.io.ByteArrayOutputStream;
import java.util.*;

import static com.qqs.invsvcs.service.translate.APITranslator.*;


@Component
public class SupplierPurchaseOrderService {
    Logger logger = LoggerFactory.getLogger(SupplierPurchaseOrderService.class);

    @Resource
    DataService ds;

    @Resource
    SupplierPurchaseOrderDataService supplierPurchaseOrderDataService;

    @Resource
    SupplierPoLineItemService supplierPoLineItemService;

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    @Resource
    SupplierService supplierService;

    @Resource
    SupportService supportService;

    @Resource
    PoGenerateHelper poGenerateHelper;

    @Value("${app.posvcs.url}")
    private String posvcsURL;


    @Transactional
    public SupplierPurchaseOrder saveSupplierPurchaseOrder(SupplierPurchaseOrder supplierPurchaseOrderData) throws QQBusinessException {
        SupplierPurchaseOrder supplierPurchaseOrderToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();

        try {
            com.qqs.invsvcs.model.SupplierPurchaseOrder toSaveSupplierPurchaseOrder = supplierPurchaseOrderToDB.translate(supplierPurchaseOrderData, com.qqs.invsvcs.model.SupplierPurchaseOrder.class, true);
            if (toSaveSupplierPurchaseOrder.getId() > 0) {
                new DateUtils<com.qqs.invsvcs.model.SupplierPurchaseOrder>().setTimeStamp(toSaveSupplierPurchaseOrder, com.qqs.invsvcs.model.SupplierPurchaseOrder.class, true);
                toSaveSupplierPurchaseOrder.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.invsvcs.model.SupplierPurchaseOrder>().setTimeStamp(toSaveSupplierPurchaseOrder, com.qqs.invsvcs.model.SupplierPurchaseOrder.class, false);
                toSaveSupplierPurchaseOrder.setCreatedBy(loggedInUser);
            }
            com.qqs.invsvcs.model.SupplierPurchaseOrder supplierPurchaseOrder = supplierPurchaseOrderDataService.saveSupplierPurchaseOrder(toSaveSupplierPurchaseOrder);

            if (!supplierPurchaseOrderData.getSupplierPoLineItem().isEmpty()) {
                supplierPurchaseOrderData.getSupplierPoLineItem().forEach(supplierPoLineItem -> {
                    if (supplierPurchaseOrder.getPoStatus().equals("PLACED")) {
                        supplierPoLineItem.setItemStatus(Constants.PO_LINE_STATUS_PLACED);
                    } else {
                        supplierPoLineItem.setItemStatus(Constants.PO_LINE_STATUS_NEW);
                    }
                });
                supplierPoLineItemService.saveAllSupplierPoLineItem(supplierPurchaseOrderData.getSupplierPoLineItem(), supplierPurchaseOrder.getId());
            }
            supplierPurchaseOrderToApi = supplierPurchaseOrderToAPI.translate(supplierPurchaseOrder, SupplierPurchaseOrder.class, true);
        } catch (Exception e) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving SupplierPurchaseOrder");
        }
        return supplierPurchaseOrderToApi;
    }

    public SupplierPurchaseOrder getSupplierPurchaseOrderById(Integer id, HttpServletRequest request) throws QQBusinessException {
        SupplierPurchaseOrder supplierPurchaseOrderApi = null;
        try {
            Optional<com.qqs.invsvcs.model.SupplierPurchaseOrder> supplierPurchaseOrder = supplierPurchaseOrderDataService.getSupplierPurchaseOrderById(id);
            if (supplierPurchaseOrder.isPresent()) {
                supplierPurchaseOrderApi = supplierPurchaseOrderToAPI.translate(supplierPurchaseOrder.get(), SupplierPurchaseOrder.class, true);

                List<SupplierPoLineItem> supplierPoLineItems = supplierPoLineItemService.getSupplierPoLineItemByPOId(supplierPurchaseOrderApi.getId(), request);
                List<Integer> poLineItemIds = new ArrayList<>();
                supplierPoLineItems.forEach(item -> {
                    poLineItemIds.add(item.getId());
                });
                Map<Integer, Double> receivedQuantityMap = supplierPoLineItemService.getReceivedQuantity(poLineItemIds);
                supplierPoLineItems.forEach(item -> {
                    if (receivedQuantityMap.get(item.getId()) != null) {
                        item.setReceivedQuantity(receivedQuantityMap.get(item.getId()));
                    }
                });
                supplierPurchaseOrderApi.setSupplier(supplierService.getSupplierById(supplierPurchaseOrderApi.getSupplierId(), request));
                supplierPurchaseOrderApi.setSupplierPoLineItem(new HashSet<>(supplierPoLineItems));
            }
        } catch (Exception e) {
            throw new QQBusinessException("Error while fetching SupplierPurchaseOrder");
        }
        return supplierPurchaseOrderApi;
    }

    public List<SupplierPurchaseOrder> searchSupplierPurchaseOrder(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.invsvcs.model.SupplierPurchaseOrder>> supplierPurchaseOrderList = supplierPurchaseOrderDataService.searchSupplierPurchaseOrder(conditions);
        if (!supplierPurchaseOrderList.isPresent())
            throw new QQBusinessException("No SupplierPurchaseOrder details found for criteria SupplierPurchaseOrder search");
        List<SupplierPurchaseOrder> result = null;
        try {
            result = supplierPurchaseOrderToAPI.translate(supplierPurchaseOrderList.get(), SupplierPurchaseOrder.class, false);
        } catch (Exception e) {
            logger.error("Error getting SupplierPurchaseOrder", e);
        }

        return result;
    }

    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"supplierId", "poNumber", "poDate", "poDateTo", "poStatus"}));
        Map<String, String> operators = new HashMap<>(2);
        operators.put("poDate", ">");
        if (params.get("poDateTo") != null && params.get("poDate") != null) {
            params.put("poDate", params.get("poDate") + "||" + params.get("poDateTo"));
            params.remove("poDateTo");
            operators.put("poDate", "^");
        } else if (params.get("poDateTo") != null) {
            operators.put("poDate", "<");
            params.put("poDate", params.get("poDateTo"));
            params.remove("poDateTo");
        }
//        operators.put("poDateTo", "<");
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, operators, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }

    public String generatePONumber(HttpServletRequest request) {
        String poNumber = "";
        DateTime currentDate = new DateTime();
        Integer currMonth = currentDate.getMonthOfYear();
        Integer currFY = currentDate.getYear();
        if (currMonth > 3) currFY = currFY + 1;

        Optional<String> maxPO = supplierPurchaseOrderDataService.getMaxPONumber();
        if (maxPO.isPresent()) {
            String maxPODb = maxPO.get();
            Integer splitIndex = maxPODb.indexOf("-");
            Integer poSeriesYear = 2000 + Integer.parseInt(maxPODb.substring(splitIndex - 2, splitIndex));
            Integer newPO = Integer.parseInt(maxPODb.substring(splitIndex + 1));
            if (poSeriesYear.equals(currFY)) {
                poNumber = maxPODb.substring(0, splitIndex + 1) + "" + (newPO + 1);
            } else {
                poNumber = maxPODb.substring(0, splitIndex - 2) + "" + (currFY - 2000) + "-1";
            }
        } else {
            // TODO PO Series to be fetched from Codes table
            Map<String, Map<String, LinkedHashMap<String, String>>> codesMap = supportService.getCodes(request);
            poNumber =  codesMap.get(Constants.PO_NUMBER_SERIES).get("PONOS").get("description") + (currFY - 2000) + "-1";
        }
        return poNumber;
    }



    public void generatePo(Integer poId, ByteArrayOutputStream stream, HttpServletRequest request) throws QQBusinessException {
        poGenerateHelper.generatePo(getSupplierPurchaseOrderById(poId, request), stream, request);
    }

    public String getPOSeries(HttpServletRequest request) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders requestHeaders = new HttpHeaders();
        String baseUrl = "";

        baseUrl = posvcsURL;

        requestHeaders.add("Authorization", request.getHeader("Authorization"));
        requestHeaders.add("Content-Type", "application/json; charset=UTF-8");

        HttpEntity requestEntity = new HttpEntity(null, requestHeaders);
        ResponseEntity response = restTemplate.exchange(baseUrl + Constants.CODES_URL,
                HttpMethod.GET, requestEntity, Object.class);
        Map<String, Map<String, LinkedHashMap<String, String>>> codesMap =
                (Map<String, Map<String, LinkedHashMap<String, String>>>) response.getBody();
        return codesMap.get(Constants.PO_NUMBER_SERIES).get("PONOS").get("description");
    }

}
