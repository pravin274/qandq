package com.qqs.invsvcs.rest;

import com.qqs.invsvcs.api.SupplierPurchaseOrder;
import com.qqs.invsvcs.service.SupplierPurchaseOrderService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/supplierpurchase")
public class SupplierPurchaseOrderController {
    @Resource
    SupplierPurchaseOrderService supplierPurchaseOrderService;

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_WRITE', 'ROLE_PRODUCT_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/save", produces = "application/json")
    public ResponseEntity<SupplierPurchaseOrder> saveSupplierPurchaseOrder(@RequestBody SupplierPurchaseOrder form) throws QQBusinessException {
        SupplierPurchaseOrder saved = supplierPurchaseOrderService.saveSupplierPurchaseOrder(form);
        ResponseEntity<SupplierPurchaseOrder> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_PRODUCT_READ', 'ROLE_PRODUCT_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/byId", produces = "application/json")
    public ResponseEntity<SupplierPurchaseOrder> getSupplierPurchaseOrderById(@RequestParam Integer id,
                                                                              HttpServletRequest request) throws QQBusinessException {
        SupplierPurchaseOrder pro = supplierPurchaseOrderService.getSupplierPurchaseOrderById(id, request);
        ResponseEntity<SupplierPurchaseOrder> result = new ResponseEntity(pro, HttpStatus.OK);
        return result;
    }


    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_PRODUCT_READ')")
    @RequestMapping(method = RequestMethod.GET, value = "/form/search", produces = "application/json")
    public ResponseEntity<List<SupplierPurchaseOrder>> searchSupplierPurchaseOrder(@RequestParam Map<String, String> searchParam,
                                                                                   @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                                                   HttpServletRequest request) throws QQBusinessException {
        List<SupplierPurchaseOrder> formList = supplierPurchaseOrderService.searchSupplierPurchaseOrder(searchParam, exactMatch.orElse(false));
        ResponseEntity<List<SupplierPurchaseOrder>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_PRODUCT_READ', 'ROLE_PRODUCT_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/getNextPONumber", produces = "application/json")
    public ResponseEntity<String> getNextPONumber(HttpServletRequest request) throws QQBusinessException {
        String poNumber = supplierPurchaseOrderService.generatePONumber(request);
        ResponseEntity<String> result = new ResponseEntity(poNumber, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_INVOICE_WRITE', 'ROLE_INVOICE_READ')")
    @RequestMapping(method = RequestMethod.GET, value =  "/generatePo", produces="application/pdf")
    public ResponseEntity<org.springframework.core.io.Resource> generatePO(@RequestParam Integer poId, HttpServletRequest request,
                                                                           HttpServletResponse response) throws QQBusinessException {

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        supplierPurchaseOrderService.generatePo(poId, stream, request);
        org.springframework.core.io.Resource file = new ByteArrayResource(stream.toByteArray());
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.put(HttpHeaders.CONTENT_DISPOSITION, Collections.singletonList("attachment; filename=filledapp.pdf"));
        httpHeaders.put(HttpHeaders.CONTENT_TYPE, Collections.singletonList("application/pdf"));
        ResponseEntity<org.springframework.core.io.Resource> result = ResponseEntity
                .ok()
                .headers(httpHeaders)
                .body(file);
        return result;
    }
}
