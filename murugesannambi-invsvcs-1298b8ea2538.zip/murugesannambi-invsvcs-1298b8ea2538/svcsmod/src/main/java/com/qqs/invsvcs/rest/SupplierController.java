package com.qqs.invsvcs.rest;


import com.qqs.invsvcs.api.Supplier;
import com.qqs.invsvcs.api.SupplierXProduct;
import com.qqs.invsvcs.service.SupplierService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/supplier")
public class SupplierController {
    @Resource
    SupplierService supplierService;

    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    @RequestMapping(method = RequestMethod.POST, value = "/save", produces = "application/json")
    public ResponseEntity<Supplier> saveSupplier(@RequestBody Supplier form) throws QQBusinessException {
        Supplier saved = supplierService.saveSupplier(form);
        ResponseEntity<Supplier> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/byId", produces = "application/json")
    public ResponseEntity<Supplier> getSupplierById(@RequestParam Integer id,
                                                                  HttpServletRequest request) throws QQBusinessException {
        Supplier supplier = supplierService.getSupplierById(id, request);
        ResponseEntity<Supplier> result = new ResponseEntity(supplier, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/form/search", produces = "application/json")
    public ResponseEntity<List<Supplier>> searchSupplier(@RequestParam Map<String, String> searchParam,
                                                                       @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                                       HttpServletRequest request) throws QQBusinessException {
        List<Supplier> formList = supplierService.searchSupplier(searchParam, exactMatch.orElse(false));
        ResponseEntity<List<Supplier>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    @RequestMapping(method = RequestMethod.POST, value = "/save/supplierxproduct", produces = "application/json")
    public ResponseEntity<SupplierXProduct> saveSupplierXProduct(@RequestBody SupplierXProduct form) throws QQBusinessException {
        SupplierXProduct saved = supplierService.saveSupplierXProduct(form);
        ResponseEntity<SupplierXProduct> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/supplierxproductbyTypeAndId", produces = "application/json")
    public ResponseEntity<List<SupplierXProduct>> getSupplierXProductByProductIdAndType(@RequestParam Integer productId, String productType,
                                                    HttpServletRequest request) throws QQBusinessException {
        List<SupplierXProduct> supplierXProduct = supplierService.getSupplierXProductByProductIdAndType(productId, productType, request);
        ResponseEntity<List<SupplierXProduct>> result = new ResponseEntity(supplierXProduct, HttpStatus.OK);
        return result;
    }

}
