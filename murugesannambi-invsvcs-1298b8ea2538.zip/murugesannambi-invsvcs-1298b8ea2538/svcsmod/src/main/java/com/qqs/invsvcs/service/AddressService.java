package com.qqs.invsvcs.service;

import com.qqs.posvcs.api.Address;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;


import static com.qqs.invsvcs.service.translate.APITranslator.*;

@Component
public class AddressService {
    Logger logger = LoggerFactory.getLogger(AddressService.class);

    @Resource
    AddressDataService addressds;

    @Resource
    DataService ds;

    public Address saveAddress(Address addressData) throws QQBusinessException {
        Address addressToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        try {
            com.qqs.invsvcs.model.Address toSaveAddresse =  addressToDB.translate(addressData, com.qqs.invsvcs.model.Address.class, true);
            if(toSaveAddresse.getId() > 0) {
                new DateUtils<com.qqs.invsvcs.model.Address>().setTimeStamp(toSaveAddresse, com.qqs.invsvcs.model.Address.class, true);
                toSaveAddresse.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.invsvcs.model.Address>().setTimeStamp(toSaveAddresse, com.qqs.invsvcs.model.Address.class, false);
                toSaveAddresse.setCreatedBy(loggedInUser);
            }
            com.qqs.invsvcs.model.Address address = addressds.saveAddress(toSaveAddresse);

            addressToApi = addressToAPI.translate(address , Address.class, true);

        } catch (Exception e ) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving Address details");
        }
        return addressToApi;

    }
    public Address getAddressById(Integer addressId) throws QQBusinessException {
        try {
            Optional<com.qqs.invsvcs.model.Address> address = addressds.getAddressById(addressId);
            if (!address.isPresent()) {
                throw new QQBusinessException("No address found");
            }
            Address addressAPI = addressToAPI.translate(address.get(), Address.class, false);
            return addressAPI;
        } catch (Exception e) {
            logger.error("Address fetch error", e);
        }
        throw new QQBusinessException("Address could not be retrieved");
    }

    public Collection<Address> getAddressBySupplier(Integer supplierId) throws QQBusinessException {
        return getAddressByParentType("S", supplierId);
    }


    public Collection<Address> getAddressByParentType(String parentType, Integer parentId) throws QQBusinessException {
        Optional<List<com.qqs.invsvcs.model.Address>> addresses = addressds.findAddressesForParentType(parentType, parentId);
        if (addresses.isPresent()) {
            try {
                return addressToAPI.translate(addresses.get(), Address.class, false);
            } catch (Exception e) {
                logger.error("Translation error in  Address", e);
            }
        }
        return null;
    }

    public List<String> addressFormatter(Address address,  Map<String, Map<String, LinkedHashMap<String, String>>>  codesMap) throws  QQBusinessException {
        List<String> formattedAddress = new ArrayList<>();
        String companyName   = "";
        String LineTwo   = "";
//        String streetName = "";
        String State  = "";
        String Country  = "";
        if ("GER".equals(address.getCountry())) {
            companyName   = address.getLineTwo();
            LineTwo   = address.getLineThree();
//            streetName = address.getStreetName() ;
            State  = address.getPostalCd() + ' ' +  address.getCity();
            Country  = codesMap.get("COUNTRY").get(address.getCountry()).get("description");
        } else {
            companyName   = address.getLineTwo();
            LineTwo   = address.getLineThree();
//            streetName = address.getStreetNo() + ' ' + address.getStreetName() ;
            State  = address.getCity() + ' ' +  codesMap.get("PROVINCE").get(address.getProvince()).get("description")+ ' ' +   address.getPostalCd();
            Country  = codesMap.get("COUNTRY").get(address.getCountry()).get("description");
        }
        formattedAddress.add(companyName);
        if( !"".equals(LineTwo)) {
            formattedAddress.add(LineTwo);
        }
//        formattedAddress.add(streetName);
        formattedAddress.add(State);
        formattedAddress.add(Country);
        return formattedAddress;
    }


}
