package com.qqs.invsvcs.service;

import com.qqs.invsvcs.api.InventoryStockDetailReport;
import com.qqs.invsvcs.api.StockStatusReport;
import com.qqs.invsvcs.model.StockStatusDetails;
import com.qqs.qqsoft.QQBusinessException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.qqs.invsvcs.service.translate.APITranslator.*;

@Component
public class InventoryReportService {
    Logger logger = LoggerFactory.getLogger(InvProductDetailsService.class);

    @Resource
    DataService ds;

    @Resource
    InvReportDataService invReportDataService;

    public List<InventoryStockDetailReport> getInventoryStockDetailReport(String frmDate, String tDate) throws QQBusinessException {
        List<InventoryStockDetailReport> inventoryStockDetailReportToApi = new ArrayList<>();

        try {

            Map<String, String> reportDateMap = formatReportDates(frmDate, tDate);

            String oneDateBeforeFromDate = reportDateMap.get("oneDateBeforeFromDate");
            String fromDate = reportDateMap.get("fromDate");
            String toDate = reportDateMap.get("toDate");
            String assumedStartDate = "1997-05-07"; // assumed or dummy start date My DB

            List<InventoryStockDetailReport> inventoryStockDetailReportFromQry = inventoryStockDetailReportToAPI.translate(invReportDataService.getInventoryStockDetailReport(fromDate, toDate), InventoryStockDetailReport.class, true);

            Map<String, Integer> openingBalance = getOpeningBalDetails(assumedStartDate, oneDateBeforeFromDate);

            inventoryStockDetailReportFromQry.forEach(stockDetail -> {
                InventoryStockDetailReport inventoryStockDetailReport = new InventoryStockDetailReport();
                inventoryStockDetailReport.setInwardQty(stockDetail.getInwardQty());
                inventoryStockDetailReport.setTotalConsumption(stockDetail.getTotalConsumption());
                inventoryStockDetailReport.setProductId((stockDetail.getProductId()));
                inventoryStockDetailReport.setProductName(stockDetail.getProductName());
                inventoryStockDetailReport.setProductType(StringUtils.capitalize(stockDetail.getProductType()));
                inventoryStockDetailReport.setOpeningStock(openingBalance.get(stockDetail.getProductType() + '-' + stockDetail.getProductId()));
                inventoryStockDetailReport.setClosingStock((stockDetail.getInwardQty() + stockDetail.getOpeningStock()) - stockDetail.getTotalConsumption());
                inventoryStockDetailReportToApi.add(inventoryStockDetailReport);
            });
        } catch (Exception e) {
            throw new QQBusinessException("Error fetching Inventory Stock Detail Report data" + e);
        }
        return inventoryStockDetailReportToApi;
    }

    private String parseDateString(String dateVal, String format, String timeZone, String outPutFormat) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        String formattedDateVal = "";
        if (timeZone != null && !("".equals(timeZone))) {
            sdf.setTimeZone(TimeZone.getTimeZone(timeZone));
        }
        Date formattedDate = null;

        try {
            if (dateVal != null) {
                formattedDate = sdf.parse(dateVal);
                sdf = new SimpleDateFormat(outPutFormat);
                formattedDateVal = sdf.format(formattedDate);
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return formattedDateVal;
    }

    public StockStatusReport getStockStageWiseData(String frmDate, String tDate) throws QQBusinessException {
        StockStatusReport stockStatusReport = new StockStatusReport();
        List<com.qqs.invsvcs.api.StockStatusDetails> stockStatusDetailsList = new ArrayList<>();

        try {
            Map<String, String> reportDateMap = formatReportDates(frmDate, tDate);

            String fromDate = reportDateMap.get("fromDate");
            String toDate = reportDateMap.get("toDate");
            String assumedStartDate = "1997-05-07"; // assumed or dummy start date My DB

            Map<String, com.qqs.invsvcs.api.StockStatusDetails> stockDetailsMap = new HashMap<>();
            List<InventoryStockDetailReport> openingStockReportForGivenDate = inventoryStockDetailReportToAPI.translate(
                    invReportDataService.getInventoryStockDetailReport(assumedStartDate, toDate), InventoryStockDetailReport.class, true);

            openingStockReportForGivenDate.forEach(item -> {
                com.qqs.invsvcs.api.StockStatusDetails stockStatusDetails = new com.qqs.invsvcs.api.StockStatusDetails();
                stockStatusDetails.setProductId(item.getProductId());
                stockStatusDetails.setProductType(StringUtils.capitalize(item.getProductType()));
                stockStatusDetails.setProductName(item.getProductName());
                stockStatusDetails.setAvailableStock((item.getOpeningStock() + item.getInwardQty()) - item.getTotalConsumption());
                stockDetailsMap.put(item.getProductType() + "-" + item.getProductId(), stockStatusDetails);
            });

            List<StockStatusDetails> stockStatusDetailsDB = invReportDataService.getStockStatusDetail(fromDate, toDate);
            Map<String, Map<String, Integer>> stockStageMap = new HashMap<>();
            Set<String> reportColumns = new LinkedHashSet<>();
            stockStatusDetailsDB.forEach(item -> {
                String key = item.getProductType() + "-" + item.getProductId();
                com.qqs.invsvcs.api.StockStatusDetails stockStatusDetails = new com.qqs.invsvcs.api.StockStatusDetails();
                if (stockDetailsMap.get(key) != null)
                    stockStatusDetails = stockDetailsMap.get(key);
                stockStatusDetails.setProductId(item.getProductId());
                stockStatusDetails.setProductType(StringUtils.capitalize(item.getProductType()));
                stockStatusDetails.setProductName(item.getProductName());

                stockDetailsMap.put(key, stockStatusDetails);

                Map<String, Integer> stageQtyMap = new HashMap<>();
                if (stockStageMap.get(key) != null)
                    stageQtyMap = stockStageMap.get(key);

                stageQtyMap.put("Opr" + item.getProcessOrder(), item.getStockQty());
                stockStageMap.put(key, stageQtyMap);
                reportColumns.add("Opr - " + item.getProcessOrder());
            });
            stockDetailsMap.entrySet().forEach(item -> {
                if (stockStageMap.get(item.getKey()) != null) {
                    item.getValue().setProcessStageStock(stockStageMap.get(item.getKey()));
                }
                stockStatusDetailsList.add(item.getValue());
            });
            fillMissingData(stockStatusDetailsList, reportColumns);
            stockStatusReport.setStockStatusDetails(stockStatusDetailsList);

            stockStatusReport.setReportColumnsList(reportColumns);
        } catch (Exception e) {
            throw new QQBusinessException("Error fetching Stock details");
        }
        return stockStatusReport;
    }

    private void fillMissingData(List<com.qqs.invsvcs.api.StockStatusDetails> stockStatusReports, Set<String> reportCols) {
        stockStatusReports.forEach(item -> {
            if (item.getProcessStageStock() == null) item.setProcessStageStock(new HashMap<>());
            reportCols.forEach(colItem -> {
                if(item.getProcessStageStock().get(colItem.replace(" - ", "")) == null) {
                    item.getProcessStageStock().put(colItem.replace(" - ", ""), 0);
                }
            });
        });
    }

    private Map<String, Integer> getOpeningBalDetails(String fromDate, String toDate) throws QQBusinessException {
        Map<String, Integer> openingBalance = new HashMap<>();
        try {
            List<InventoryStockDetailReport> openingStockReportForGivenDate = inventoryStockDetailReportToAPI.translate(
                    invReportDataService.getInventoryStockDetailReport(fromDate, toDate), InventoryStockDetailReport.class, true);

            openingStockReportForGivenDate.forEach(dataFromPreval -> {
                String productKey = dataFromPreval.getProductType() + '-' + dataFromPreval.getProductId();
                Integer openingBal = (dataFromPreval.getOpeningStock() + dataFromPreval.getInwardQty()) - dataFromPreval.getTotalConsumption();
                openingBalance.put(productKey, openingBal);
            });
        } catch (Exception e) {
            throw new QQBusinessException("Error fetching Stock details");
        }
        return openingBalance;
    }

    private Map<String, String> formatReportDates(String reportFromDate, String reportToDate) throws QQBusinessException {
        Map<String, String> reportDates = new HashMap<>();
        try {
            String fromDateFormat;
            String toDateFormat;
            if (reportFromDate.length() > 10) {
                fromDateFormat = "E MMM dd yyyy hh:mm:ss";
            } else {
                fromDateFormat = "yyyy-MM-dd";
            }
            if (reportToDate.length() > 10) {
                toDateFormat = "E MMM dd yyyy hh:mm:ss";
            } else {
                toDateFormat = "yyyy-MM-dd";
            }
            // To calculate on date before the from date
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date myDate = dateFormat.parse(reportFromDate);
            Date oneDayBefore = new Date(myDate.getTime() - 2);
            String result = dateFormat.format(oneDayBefore);

            String oneDateBeforeFromDate = parseDateString(result, fromDateFormat, "GMT", "yyyy-MM-dd");
            String fromDate = parseDateString(reportFromDate, fromDateFormat, "GMT", "yyyy-MM-dd");
            String toDate = parseDateString(reportToDate, toDateFormat, "GMT", "yyyy-MM-dd");

            reportDates.put("fromDate", fromDate);
            reportDates.put("toDate", toDate);
            reportDates.put("oneDateBeforeFromDate", oneDateBeforeFromDate);

        } catch (Exception e) {
            throw new QQBusinessException("Error fetching Stock details");
        }
        return reportDates;
    }
}
