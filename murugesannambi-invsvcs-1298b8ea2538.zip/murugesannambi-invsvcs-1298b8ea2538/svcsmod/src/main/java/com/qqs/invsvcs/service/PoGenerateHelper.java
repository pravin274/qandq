package com.qqs.invsvcs.service;

import com.qqs.invsvcs.api.InvProductDetails;
import com.qqs.invsvcs.api.SupplierPoLineItem;
import com.qqs.invsvcs.api.SupplierPurchaseOrder;
import com.qqs.invsvcs.utils.Constants;
import com.qqs.posvcs.api.Address;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.mail.MailService;
import com.qqs.qqsoft.pdf.PDFCreateService;
import com.qqs.qqsoft.utils.CurrencyUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.qqs.invsvcs.utils.Constants.PDF_PO_QQ;

@Component
public class PoGenerateHelper {

    @Resource
    DataService ds;

//    @Resource
//    private ApplicationCodeMap systemCodeMap;

    @Resource
    private AddressService addressService;

    @Resource
    private InvProductDetailsService invProductDetailService;

    @Resource
    private SupportService supportService;


    public void generatePo(SupplierPurchaseOrder purchaseOrder, ByteArrayOutputStream stream,  HttpServletRequest request) throws QQBusinessException {
        Map<String, String> invoicePdfValueMap = new HashMap<>();
        Map<String, Map<String, LinkedHashMap<String, String>>> codesMap = supportService.getCodes(request);

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
        sdf.setTimeZone(TimeZone.getTimeZone(codesMap.get("APP_TIME_ZONE").get("TZ").get("description")));
        String poDate = sdf.format(purchaseOrder.getPoDate());

        String  quotationDate = sdf.format(purchaseOrder.getQuotationDate());



        invoicePdfValueMap.put("poNumber", purchaseOrder.getPoNumber());
        invoicePdfValueMap.put("poDate", poDate);
        invoicePdfValueMap.put("deliveryDate", "NA");
        invoicePdfValueMap.put("quotationNumber", purchaseOrder.getQuotationNumber());
        invoicePdfValueMap.put("quotationDate", quotationDate);
        invoicePdfValueMap.put("supplierGst", purchaseOrder.getSupplier().getGstNo());
        invoicePdfValueMap.put("vendorCode", purchaseOrder.getSupplier().getVendorCode());
        if (purchaseOrder.getSupplier().getNote() != null) {
            invoicePdfValueMap.put("note", purchaseOrder.getSupplier().getNote());
        }
        if (purchaseOrder.getSupplier().getSplInstruction() != null) {
            invoicePdfValueMap.put("splInstruction", purchaseOrder.getSupplier().getSplInstruction());
        }
        if (purchaseOrder.getSupplier().getPaymentTerm() != null) {
            invoicePdfValueMap.put("paymentTerms", purchaseOrder.getSupplier().getPaymentTerm());
        }

        Integer lineItemCount = 1;
        Double totalQty = 0.0;
        Double totalUnitPrice = 0.0;
        Double totalValue = 0.0;
        Double totalTaxAmount = 0.0;
        for (SupplierPoLineItem lineItem : purchaseOrder.getSupplierPoLineItem()) {
            InvProductDetails invProductDetailList = new InvProductDetails();
            invProductDetailList =  invProductDetailService.getByProductIdProductType(lineItem.getSupplierXProduct().getProductId(),
                    lineItem.getSupplierXProduct().getProductType());

            invoicePdfValueMap.put("slNo" + lineItemCount, lineItemCount.toString());
            invoicePdfValueMap.put("product" + lineItemCount, lineItem.getSupplierXProduct().getProductName());

            invoicePdfValueMap.put("qty" + lineItemCount, lineItem.getQuantity().toString());
//            invoicePdfValueMap.put("uom" + lineItemCount, lineItem.getQuantity().toString());

            Double qty = lineItem.getQuantity();
            Double unitPrice = Double.valueOf(lineItem.getCost());
            Double total = qty * unitPrice;
            totalQty += qty;
            totalValue += total;
            invoicePdfValueMap.put("price" + lineItemCount, String.format("%.2f", unitPrice));
            invoicePdfValueMap.put("amount" + lineItemCount, String.format("%.2f", total));

            String taxPercent = "";
            String taxHead = "GST";
            String taxAmountHead = "GST Amount";
            Double taxAmount = 0.00;
            if (invProductDetailList.getCgst() != null && (!"".equals(invProductDetailList.getCgst()))) {
                taxPercent = invProductDetailList.getCgst() + "% + " + invProductDetailList.getSgst() + "%";
                taxHead = "CGST% + SGST%";
                taxAmountHead = "CGST + SGST Amount";
                taxAmount = (((total * Double.valueOf(invProductDetailList.getCgst()))) / 100) +
                        (((unitPrice * Double.valueOf(invProductDetailList.getSgst()))) / 100);
            } else if (invProductDetailList.getIgst() != null) {
                taxPercent = invProductDetailList.getIgst() + "%";
                taxHead = "IGST%";
                taxAmountHead = "IGST Amount";
                taxAmount = (total * Double.valueOf(invProductDetailList.getIgst())) / 100;
            }
            totalTaxAmount += taxAmount;
            invoicePdfValueMap.put("taxpercent" + lineItemCount, taxPercent);
            invoicePdfValueMap.put("taxAmount" + lineItemCount, taxAmount.toString());

            invoicePdfValueMap.put("taxHead" , taxHead);
            invoicePdfValueMap.put("taxAmountHead" , taxAmountHead);
            lineItemCount++;
        }

        Address deliveryAddress = purchaseOrder.getSupplier().getAddresses().get(0);
        List<String> deliveryAddressList = (List) addressService.addressFormatter(deliveryAddress, codesMap);

        int addressLineCount = 1;
        for (String del : deliveryAddressList) {
            invoicePdfValueMap.put("deliveryAddress" + addressLineCount, del);
            addressLineCount++;
        }

        invoicePdfValueMap.put("totalValue", String.format("%.2f", totalValue));
        invoicePdfValueMap.put("totalTaxAmount", String.format("%.2f", totalTaxAmount));
        invoicePdfValueMap.put("netTotal", String.format("%.2f", totalTaxAmount + totalValue));
        Double grandTotal = totalTaxAmount + totalValue;

        invoicePdfValueMap.put("totalQty", totalQty.toString());
        invoicePdfValueMap.put("valueInWords", CurrencyUtils.convertToWordCurrency(grandTotal, "INR").toString() + " only)");


        PDFCreateService service = new PDFCreateService();

        try {
            String templateName = PDF_PO_QQ;
            service.getPdfContent(invoicePdfValueMap, stream, templateName);
//            MailService.sendPOByEmail(stream);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
