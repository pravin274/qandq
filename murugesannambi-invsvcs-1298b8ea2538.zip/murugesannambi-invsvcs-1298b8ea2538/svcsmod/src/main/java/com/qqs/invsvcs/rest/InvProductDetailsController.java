package com.qqs.invsvcs.rest;

import com.qqs.invsvcs.api.InvProductDetails;
import com.qqs.invsvcs.service.InvProductDetailsService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/invPD")
public class InvProductDetailsController {
    @Resource
    InvProductDetailsService invPDService;

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_WRITE', 'ROLE_PRODUCT_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/save", produces = "application/json")
    public ResponseEntity<InvProductDetails> saveInvProductDetails(@RequestBody InvProductDetails form) throws QQBusinessException {
        InvProductDetails saved = invPDService.saveInvProductDetails(form);
        ResponseEntity<InvProductDetails> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_PRODUCT_READ', 'ROLE_PRODUCT_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/byId", produces = "application/json")
    public ResponseEntity<InvProductDetails> getInvProductDetailsById(@RequestParam Integer id,
                                                  HttpServletRequest request) throws QQBusinessException {
        InvProductDetails invPD = invPDService.getInvProductDetailsById(id);
        ResponseEntity<InvProductDetails> result = new ResponseEntity(invPD, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_PRODUCT_READ', 'ROLE_PRODUCT_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/byProductIdType", produces = "application/json")
    public ResponseEntity<InvProductDetails> getProductByProductIdType(@RequestParam Integer productId, String productType,
                                                  HttpServletRequest request) throws QQBusinessException {
        InvProductDetails invPD = invPDService.getByProductIdProductType(productId, productType);
        ResponseEntity<InvProductDetails> result = new ResponseEntity(invPD, HttpStatus.OK);
        return result;
    }

}

