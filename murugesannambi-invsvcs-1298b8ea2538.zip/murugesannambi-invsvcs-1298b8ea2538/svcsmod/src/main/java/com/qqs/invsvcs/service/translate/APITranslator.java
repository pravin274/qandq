package com.qqs.invsvcs.service.translate;

import com.qqs.invsvcs.model.*;
import com.qqs.qqsoft.utils.ApiUtils;
import com.qqs.qqsoft.utils.SearchCriteria;


public class APITranslator {
    public static ApiUtils<ProductCategory, com.qqs.invsvcs.api.ProductCategory> productCategoryToAPI = new ApiUtils<>();
    public static ApiUtils<Product, com.qqs.invsvcs.api.Product> productToAPI = new ApiUtils<>();
    public static ApiUtils<InvProductDetails, com.qqs.invsvcs.api.InvProductDetails> invProductDetailsToAPI = new ApiUtils<>();
    public static ApiUtils<Inward, com.qqs.invsvcs.api.Inward> inwardToAPI = new ApiUtils<>();
    public static ApiUtils<InwardLineItem, com.qqs.invsvcs.api.InwardLineItem> inwardLineItemToAPI = new ApiUtils<>();
    public static ApiUtils<ProductBrand, com.qqs.invsvcs.api.ProductBrand> productBrandToAPI = new ApiUtils<>();
    public static ApiUtils<UserEntity, com.qqs.invsvcs.api.User> userToAPI = new ApiUtils<>();
    public static ApiUtils<User, com.qqs.invsvcs.api.User> userIToAPI = new ApiUtils<>();
    public static ApiUtils<SearchCriteria, com.qqs.invsvcs.service.SearchCriteria> searchCriteriaToJPA = new ApiUtils<>();
    public static ApiUtils<Supplier, com.qqs.invsvcs.api.Supplier> supplierToAPI = new ApiUtils<>();
    public static ApiUtils<SupplierXProduct, com.qqs.invsvcs.api.SupplierXProduct> supplierXProductToAPI = new ApiUtils<>();
    public static ApiUtils<Consumption, com.qqs.invsvcs.api.Consumption> consumptionToAPI = new ApiUtils<>();
    public static ApiUtils<SupplierPoLineItem, com.qqs.invsvcs.api.SupplierPoLineItem> supplierPoLineItemToAPI = new ApiUtils<>();
    public static ApiUtils<SupplierPurchaseOrder, com.qqs.invsvcs.api.SupplierPurchaseOrder> supplierPurchaseOrderToAPI = new ApiUtils<>();
    public static ApiUtils<Address, com.qqs.posvcs.api.Address> addressToAPI = new ApiUtils<>();
    public static ApiUtils<InvRequirements, com.qqs.invsvcs.api.InvRequirements> invRequirementsToAPI = new ApiUtils<>();
    public static ApiUtils<PandLHeads, com.qqs.invsvcs.api.PandLHeads> pandLHeadsToAPI = new ApiUtils<>();
    public static ApiUtils<InventoryStockDetailReport, com.qqs.invsvcs.api.InventoryStockDetailReport> inventoryStockDetailReportToAPI = new ApiUtils<>();
    public static ApiUtils<PandL, com.qqs.invsvcs.api.PandL> pandLToAPI = new ApiUtils<>();
    public static ApiUtils<PandLReportData, com.qqs.invsvcs.api.PandLReportData> pandLReportDataToAPI = new ApiUtils<>();
    public static ApiUtils<People, com.qqs.posvcs.api.common.People> peopleToAPI = new ApiUtils<>();
    public static ApiUtils<Phone, com.qqs.posvcs.api.Phone> phoneToAPI = new ApiUtils<>();
    public static ApiUtils<Email, com.qqs.posvcs.api.Email> emailToAPI = new ApiUtils<>();

    public static ApiUtils<com.qqs.invsvcs.api.ProductCategory , ProductCategory> productCategoryToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.invsvcs.api.Product , Product> productToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.invsvcs.api.InvProductDetails , InvProductDetails> invProductDetailsToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.invsvcs.api.Inward, Inward> inwardToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.invsvcs.api.InwardLineItem, InwardLineItem> inwardLineItemToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.invsvcs.api.ProductBrand , ProductBrand> productBrandToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.invsvcs.api.User, UserEntity> userToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.invsvcs.api.Supplier , Supplier> supplierToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.invsvcs.api.SupplierXProduct , SupplierXProduct> supplierXProductToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.invsvcs.api.Consumption , Consumption> consumptionToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.invsvcs.api.SupplierPoLineItem , SupplierPoLineItem> supplierPoLineItemToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.invsvcs.api.SupplierPurchaseOrder , SupplierPurchaseOrder> supplierPurchaseOrderToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.Address, Address> addressToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.invsvcs.api.InvRequirements, InvRequirements> invRequirementsToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.invsvcs.api.PandLHeads , PandLHeads> pandLHeadsToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.invsvcs.api.InventoryStockDetailReport, InventoryStockDetailReport> inventoryStockDetailReportToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.invsvcs.api.PandL , PandL> pandLToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.common.People, People> peopleToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.Email, Email> emailToDB = new ApiUtils<>();
    public static ApiUtils<com.qqs.posvcs.api.Phone, Phone> phoneToDB = new ApiUtils<>();







}
