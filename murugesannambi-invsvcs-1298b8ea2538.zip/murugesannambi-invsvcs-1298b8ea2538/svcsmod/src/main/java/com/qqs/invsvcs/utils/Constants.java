package com.qqs.invsvcs.utils;


import com.google.common.collect.ImmutableMap;
import org.springframework.beans.factory.annotation.Value;

import java.util.*;

public final class Constants {

    @Value("${app.posvcs.url}")
    private static String posvcsURL;

    @Value("${app.qnqsvcs.url}")
    private static String qnqsvcsURL;

    private Constants() {
        // restrict instantiation
    }
    public static final String PO_STATUS_NEW = "NEW";

    public static final String PO_LINE_STATUS_NEW = "NEW";
    public static final String PO_LINE_STATUS_PARTIAL_RECEIVED = "PARTIAL RECEIVED";
    public static final String PO_LINE_STATUS_RECEIVED = "RECEIVED";
    public static final String PO_LINE_STATUS_PLACED = "PLACED";

    public static final Map<String, String> CATEGORY_URL_MAP = ImmutableMap.of("part", "part/all",
            "tool", "tools/all", "inserts", "insert/all", "holder", "holder/all");

    public static final String CODES_URL = "support/picklist";
    public static final String PO_NUMBER_SERIES = "PO_NUMBER_SERIES";

    public static final Map<String, String> PRODUCT_TYPE_MAP = ImmutableMap.of("part", "part", "tool", "tool",
            "inserts", "inserts", "holder", "holder", "product", "product");

    public static final String PART_REQ_URL = "/part/partReq?reqFromDate=";
    public static final String INSERTYS_REQ_URL = "/insert/insertsReq?reqFromDate=";

    public static final String PANDL_REPORT_TOTAL = "pandlTotal";
    public static final String PANDL_REPORT_SUB_TOTAL = "Sub Total";
    public static final String OPENING_STOCK = "Opening Stock";
    public static final String CLOSING_STOCK = "Closing Stock";
    public static final String NET_STOCK = "Net Stock Incr/Dec";
    public static final String PURCHASE_RAW_MATERIAL = "Purchases Raw material";
    public static final String PURCHASE_RETURN = "Purchase Return";
    public static final String NET_PURCHASE = "Net Purchase";
    public static final String INCOME = "INC";
    public static final String EXPENDITURE = "EXP";




    public static final List<String> PANDL_CALC_CAT = new ArrayList<>(Arrays.asList("CON", "PBI", "CPR",
            "PBPIS", "PL", "CS", "CPRP", "PLP"));

    public static final String BOLD = "font-weight-bold";

    public static final String SUCCESS = "table-success";
    public static final String PDF_PO_QQ = "QQPoFormat.pdf";


    public static final Map<String, List<String>> PANDL_CALC_MAP_LIST = new HashMap<>();
    static {
        PANDL_CALC_MAP_LIST.put("CON", (new ArrayList<>(Arrays.asList("INC", "EXP", "INC"))));
        PANDL_CALC_MAP_LIST.put("PBI", (new ArrayList<>(Arrays.asList("CON", "OEX", "INC"))));
        PANDL_CALC_MAP_LIST.put("CPR", (new ArrayList<>(Arrays.asList("PBI", "INT", "INC"))));
        PANDL_CALC_MAP_LIST.put("PBPIS", (new ArrayList<>(Arrays.asList("CPR", "DPR", "INC"))));
        PANDL_CALC_MAP_LIST.put("PL", (new ArrayList<>(Arrays.asList("PBPIS", "ODC", "INC"))));
        PANDL_CALC_MAP_LIST.put("CS", (new ArrayList<>(Arrays.asList("PL", "RPY", "INC"))));

        PANDL_CALC_MAP_LIST.put("CPRP", (new ArrayList<>(Arrays.asList("CPR", "XX", "INC"))));
        PANDL_CALC_MAP_LIST.put("PLP", (new ArrayList<>(Arrays.asList("PL", "XX", "INC"))));

    }

}
