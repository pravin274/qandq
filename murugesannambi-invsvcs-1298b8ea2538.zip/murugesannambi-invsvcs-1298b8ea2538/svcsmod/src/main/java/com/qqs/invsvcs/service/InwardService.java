package com.qqs.invsvcs.service;

import com.qqs.invsvcs.api.Inward;
import com.qqs.invsvcs.model.*;
import com.qqs.invsvcs.utils.Constants;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static com.qqs.invsvcs.service.translate.APITranslator.*;

@Component
public class InwardService {
    Logger logger = LoggerFactory.getLogger(InwardService.class);

    @Resource
    DataService ds;

    @Resource
    InwardDataService inwardDataService;

    @Resource
    SupplierPoLineItemDataService spPoLineItemDataService;

    @Resource
    SupplierPoLineItemService supplierPoLineItemService;

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    @Resource
    SupplierPurchaseOrderDataService purchaseOrderDataService;

    @Resource
    ProductDataService productDataService;

    @Resource
    InvProductDetailsDataService invPDDataService;

    public Inward saveInward(Inward inwardData) throws QQBusinessException {
        Inward inwardToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        Double prevQuantity = 0.0;
        try {
            com.qqs.invsvcs.model.Inward toSaveInward = inwardToDB.translate(inwardData, com.qqs.invsvcs.model.Inward.class, true);
            if (toSaveInward.getId() > 0) {
                new DateUtils<com.qqs.invsvcs.model.Inward>().setTimeStamp(toSaveInward, com.qqs.invsvcs.model.Inward.class, true);
                toSaveInward.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.invsvcs.model.Inward>().setTimeStamp(toSaveInward, com.qqs.invsvcs.model.Inward.class, false);
                toSaveInward.setCreatedBy(loggedInUser);
            }
            com.qqs.invsvcs.model.Inward inward = inwardDataService.saveInward(toSaveInward);

            inwardToApi = inwardToAPI.translate(inward, Inward.class, true);

            inwardToApi.setInwardLineItem(saveAllInwardLineItem(inwardData, inward.getId()));

        } catch (Exception e) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving Inward");
        }

        return inwardToApi;

    }

    public Inward getInwardById(Integer id) throws QQBusinessException {
        Inward inwardApi = null;
        try {
            Optional<com.qqs.invsvcs.model.Inward> inward = inwardDataService.getInwardById(id);
            if (inward.isPresent()) {
                inwardApi = inwardToAPI.translate(inward.get(), Inward.class, true);
            }
            Iterable<InwardLineItem> inwardLineItems = inwardDataService.getAllInwardLineItemByInwardId(inwardApi.getId());
            List<com.qqs.invsvcs.api.InwardLineItem> inwardLineItemsApi = inwardLineItemToAPI.translate(inwardLineItems,
                    com.qqs.invsvcs.api.InwardLineItem.class, true);

            List<Integer> poLineItemIds = new ArrayList<>();
            inwardLineItemsApi.forEach(item -> {
                poLineItemIds.add(item.getPoLineItemId());
            });

            Map<Integer, Double> receivedQuantityMap = supplierPoLineItemService.getReceivedQuantity(poLineItemIds, id);
            inwardLineItemsApi.forEach(item -> {
                if(receivedQuantityMap.get(item.getPoLineItemId()) != null) {
                    item.setReceivedQuantity(receivedQuantityMap.get(item.getPoLineItemId()));
                }
            });

            inwardApi.setInwardLineItem(inwardLineItemsApi.stream().collect(Collectors.toSet()));

        } catch (Exception e) {
            throw new QQBusinessException("Error while fetching Inward");
        }
        return inwardApi;
    }

    public List<Inward> searchInward(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.invsvcs.model.Inward>> inwardList = inwardDataService.searchInward(conditions);
        if (!inwardList.isPresent())
            throw new QQBusinessException("No Inward details found for criteria Inward search");
        List<Inward> result = null;
        try {
            result = inwardToAPI.translate(inwardList.get(), Inward.class, false);
        } catch (Exception e) {
            logger.error("Error getting Inward", e);
        }
        return result;
    }

    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"poId"}));
        Map<String, String> operators = new HashMap<>(2);
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, operators, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }

    public Set<com.qqs.invsvcs.api.InwardLineItem> saveAllInwardLineItem(Inward inwardData, Integer inwardId)
            throws QQBusinessException {
        Set<com.qqs.invsvcs.api.InwardLineItem> inwardLIToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        List<InwardLineItem> toSaveInwardLineItem = new ArrayList<>();
        Map<Integer, Double> prevQuantityMap = new HashMap<>();
        List<Integer> poLineItemIdList = new ArrayList<>();
        Map<Integer, Double> spPoLineQuantityMap = new HashMap<>();

        try {

            Iterable<InwardLineItem> exInwardLineItem = inwardDataService.getAllInwardLineItemByInwardId(inwardId);
            exInwardLineItem.forEach(item -> {
                prevQuantityMap.put(item.getId(), item.getQuantity());
            });

            inwardData.getInwardLineItem().forEach(item -> {
                try {
                    InwardLineItem inwardLineItemDb = inwardLineItemToDB.translate(item, InwardLineItem.class, true);
                    inwardLineItemDb.setInwardId(inwardId);
                    if (inwardLineItemDb.getId() > 0) {
                        new DateUtils<com.qqs.invsvcs.model.InwardLineItem>().setTimeStamp(inwardLineItemDb, InwardLineItem.class, true);
                        inwardLineItemDb.setModifiedBy(loggedInUser);
                    } else {
                        new DateUtils<com.qqs.invsvcs.model.InwardLineItem>().setTimeStamp(inwardLineItemDb, InwardLineItem.class, false);
                        inwardLineItemDb.setCreatedBy(loggedInUser);
                    }
                    toSaveInwardLineItem.add(inwardLineItemDb);
                    poLineItemIdList.add(inwardLineItemDb.getPoLineItemId());
                    spPoLineQuantityMap.put(item.getPoLineItemId(), item.getQuantity());
                } catch (Exception e) {
                    logger.error(e.toString());
                }
            });

            Iterable<com.qqs.invsvcs.model.InwardLineItem> inwardLineItems = inwardDataService.saveAllInwardLineItem(toSaveInwardLineItem);

            inwardLineItems.forEach(item -> {
                // updating availableStock quantity in product master
                if (prevQuantityMap.get(item.getId()) == null || !(item.getQuantity().equals(prevQuantityMap.get(item.getId())))) {
                    Double prevQuantity = 0.0;
                    if (prevQuantityMap.get(item.getId()) != null)
                        prevQuantity = prevQuantityMap.get(item.getId());

                    Double newQuantity = item.getQuantity() - prevQuantity;

                    Optional<InvProductDetails> invProductDetails = invPDDataService.getInvPDByInwardLineItemId(item.getPoLineItemId());
                    if (invProductDetails.isPresent()) {
                        InvProductDetails toSave = invProductDetails.get();

                        BigDecimal bd = new BigDecimal(toSave.getAvailableStock() + newQuantity).setScale(2, RoundingMode.HALF_UP);
                        double availStock = bd.doubleValue();

                        toSave.setAvailableStock(availStock);
                        invPDDataService.saveInvProductDetails(toSave);
                    }
                }
            });
            updatePoLineStatus(poLineItemIdList);

            inwardLIToApi = inwardLineItemToAPI.translate(inwardLineItems,
                    com.qqs.invsvcs.api.InwardLineItem.class, true).stream().collect(Collectors.toSet());

        } catch (Exception e) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving InwardLineItem");
        }

        return inwardLIToApi;
    }

    private void updatePoLineStatus(List<Integer> poLineItemIdList) {
        //Updating itemstatus in polineitem
        Integer poId = 0;
        Iterable<SupplierPoLineItem> spPoLineItems = spPoLineItemDataService.getAllSupplierPoLineItemByPoId(poLineItemIdList);

        Map<Integer, Double> receivedQuantityMap = supplierPoLineItemService.getReceivedQuantity(poLineItemIdList);

        spPoLineItems.forEach(item -> {
            Double poQuantity = item.getQuantity();
            Double receivedQty = 0.0;
            String poLineStatus = Constants.PO_LINE_STATUS_PARTIAL_RECEIVED;
            if(receivedQuantityMap.get(item.getId()) != null)
                receivedQty = receivedQuantityMap.get(item.getId());

            if(receivedQty.compareTo(poQuantity) >= 0)
                poLineStatus = Constants.PO_LINE_STATUS_RECEIVED;

            item.setItemStatus(poLineStatus);
        });
        spPoLineItemDataService.saveAllSupplierPoLineItem(StreamSupport.stream(spPoLineItems.spliterator(), false).
                collect(Collectors.toList()));

        //Updating POStatus
        String poStatus = Constants.PO_LINE_STATUS_PARTIAL_RECEIVED;
        poId = spPoLineItems.iterator().next().getPoId();
        Optional<List<SupplierPoLineItem>> spPoLineItemList = spPoLineItemDataService.getAllSupplierPoLineItemByPoId(poId);
        if(spPoLineItemList.isPresent()) {
            if (spPoLineItemList.get().stream().allMatch(item -> Constants.PO_LINE_STATUS_RECEIVED.equals(item.getItemStatus())))
                poStatus = Constants.PO_LINE_STATUS_RECEIVED;
        }
        Optional<SupplierPurchaseOrder> spPo = purchaseOrderDataService.getSupplierPurchaseOrderById(poId);
        if(spPo.isPresent()) {
            spPo.get().setPoStatus(poStatus);
            purchaseOrderDataService.saveSupplierPurchaseOrder(spPo.get());
        }
    }
}
