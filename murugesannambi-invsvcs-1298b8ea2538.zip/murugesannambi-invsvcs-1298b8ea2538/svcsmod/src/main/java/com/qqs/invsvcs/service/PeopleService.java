package com.qqs.invsvcs.service;

import com.qqs.posvcs.api.Address;
import com.qqs.posvcs.api.Email;
import com.qqs.posvcs.api.Phone;
import com.qqs.posvcs.api.common.People;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;

import static com.qqs.posvcs.api.translation.ParentEntityType.*;
import static com.qqs.invsvcs.service.translate.APITranslator.*;



@Component
public class PeopleService {
    Logger logger = LoggerFactory.getLogger(PeopleService.class);

    @Resource
    DataService ds;

    public People savePeople(People plantData) throws QQBusinessException {
        People peopleToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        try {
            com.qqs.invsvcs.model.People toSavepeople = peopleToDB.translate(plantData, com.qqs.invsvcs.model.People.class, true);
            if(toSavepeople.getId() > 0) {
                new DateUtils<com.qqs.invsvcs.model.People>().setTimeStamp(toSavepeople, com.qqs.invsvcs.model.People.class, true);
                toSavepeople.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.invsvcs.model.People>().setTimeStamp(toSavepeople, com.qqs.invsvcs.model.People.class, false);
                toSavepeople.setCreatedBy(loggedInUser);
            }
            com.qqs.invsvcs.model.People people = ds.getPeopleDS().savePeople(toSavepeople);

            Email email = new Email();
            if (!"".equals(plantData.getEmailId())) {
                email.setId(plantData.getEmailId());
            }
            email.setParentId(people.getId());
            email.setEmailId(plantData.getEmail());
            email.setParentEntity("H");
            email.setType("C");

            com.qqs.invsvcs.model.Email toSaveEmail = emailToDB.translate(email, com.qqs.invsvcs.model.Email.class, false);
            if(toSaveEmail.getId() > 0) {
                new DateUtils<com.qqs.invsvcs.model.Email>().setTimeStamp(toSaveEmail, com.qqs.invsvcs.model.Email.class, true);
                toSaveEmail.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.invsvcs.model.Email>().setTimeStamp(toSaveEmail, com.qqs.invsvcs.model.Email.class, false);
                toSaveEmail.setCreatedBy(loggedInUser);
            }
            com.qqs.invsvcs.model.Email emailData = ds.getEmailDS().saveEmail(toSaveEmail);

            Phone phone = new Phone();
            if (!"".equals(plantData.getPhoneId())) {
                phone.setId(plantData.getPhoneId());
            }
            phone.setParentId(people.getId());
            phone.setPhoneNo(plantData.getPhone());
            phone.setParentEntity("H");
            phone.setType("C");

            com.qqs.invsvcs.model.Phone toSavePhone = phoneToDB.translate(phone, com.qqs.invsvcs.model.Phone.class, false);
            if(toSavePhone.getId() > 0) {
                new DateUtils<com.qqs.invsvcs.model.Phone>().setTimeStamp(toSavePhone, com.qqs.invsvcs.model.Phone.class, true);
                toSavePhone.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.invsvcs.model.Phone>().setTimeStamp(toSavePhone, com.qqs.invsvcs.model.Phone.class, false);
                toSavePhone.setCreatedBy(loggedInUser);
            }
            com.qqs.invsvcs.model.Phone phoneData = ds.getPhoneDS().savePhone(toSavePhone);

            peopleToApi = peopleToAPI.translate(people, People.class, true);

            Optional<List<com.qqs.invsvcs.model.Phone>> phones =
                    ds.getPhoneDS().findPhoneByParentType(PEOPLE.getDbCode(), people.getId());
            if (phones.isPresent()) {
                List<Phone> phoneAPI = phoneToAPI.translate(phones.get(), Phone.class, false);
                peopleToApi.setPhones(new HashSet<>(phoneAPI));
            }
            Optional<List<com.qqs.invsvcs.model.Email>> emails =
                    ds.getEmailDS().findEmailByParentType(PEOPLE.getDbCode(), people.getId());
            if (emails.isPresent()) {
                List<Email> emailAPI = emailToAPI.translate(emails.get(), Email.class, false);
                peopleToApi.setEmails(new HashSet<>(emailAPI));
            }

        } catch (Exception e) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving People");
        }
        return peopleToApi;

    }

    public People getPeopleById(Integer peopleId) throws QQBusinessException {
        try {
            Optional<com.qqs.invsvcs.model.People> people = ds.getPeopleDS().findPeopleById(peopleId);
            if (!people.isPresent()) {
                throw new QQBusinessException("No people found");
            }
            People peopleAPI = peopleToAPI.translate(people.get(), People.class, false);
            Optional<List<com.qqs.invsvcs.model.Address>> addresses = ds.getAddressDS().findAddressesByPeople(peopleId);
            if (addresses.isPresent()) {
                List<com.qqs.posvcs.api.Address> addressAPI = addressToAPI.translate(addresses.get(), Address.class, false);
                peopleAPI.setAddresses(new HashSet<>(addressAPI));
            }
            Optional<List<com.qqs.invsvcs.model.Phone>> phones =
                    ds.getPhoneDS().findPhoneByParentType(PEOPLE.getDbCode(), peopleId);
            if (phones.isPresent()) {
                List<Phone> phoneAPI = phoneToAPI.translate(phones.get(), Phone.class, false);
                peopleAPI.setPhones(new HashSet<>(phoneAPI));
            }
            Optional<List<com.qqs.invsvcs.model.Email>> emails =
                    ds.getEmailDS().findEmailByParentType(PEOPLE.getDbCode(), peopleId);
            if (emails.isPresent()) {
                List<Email> emailAPI = emailToAPI.translate(emails.get(), Email.class, false);
                peopleAPI.setEmails(new HashSet<>(emailAPI));
            }
            return peopleAPI;
        } catch (Exception e) {
            logger.error("People fetch error", e);
        }
        throw new QQBusinessException("People could not be retrieved");
    }

    public Collection<People> getPeopleByCompany(Integer companyId) throws QQBusinessException {
        return getPeopleByParentType(COMPANY.getDbCode(), companyId);
    }

    public Collection<People> getPeopleByPlant(Integer companyId) throws QQBusinessException {
        return getPeopleByParentType(PLANT.getDbCode(), companyId);
    }

    public Collection<People> getPeopleByParentType(String parentType, Integer parentId) throws QQBusinessException {
        Optional<List<com.qqs.invsvcs.model.People>> people = ds.getPeopleDS().findPeopleForParentType(parentType, parentId);
        if (!people.isPresent()) {
//            throw new QQBusinessException("No people found");
            return null;
        }
        try {
            return peopleToAPI.translate(people.get(), People.class, false);
        } catch (Exception e) {
            logger.error("Translation error people", e);
        }
        return null;
    }

}
