package com.qqs.invsvcs.service;

import com.qqs.invsvcs.api.InvProductDetails;
import com.qqs.invsvcs.api.Product;
import com.qqs.invsvcs.utils.Constants;
import com.qqs.invsvcs.api.SupplierXProduct;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

import static com.qqs.invsvcs.service.translate.APITranslator.*;

@Component
public class ProductService {
    Logger logger = LoggerFactory.getLogger(ProductService.class);

    @Resource
    DataService ds;

    @Resource
    ProductDataService productDataService;

    @Resource
    InvProductDetailsService invPDService;

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    @Resource
    InvProductDetailsService invProductDetailsService;

    @Value("${app.posvcs.url}")
    private String posvcsURL;

    @Resource
    SupplierXProductDataService supplierXProductDataService;

    @Resource
    SupplierService supplierService;

    @Value("${app.qnqsvcs.url}")
    private  String qnqsvcsURL;

    public Product saveProduct(Product productData) throws QQBusinessException {
        Product productToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();

        try {
            com.qqs.invsvcs.model.Product toSaveProduct = productToDB.translate(productData, com.qqs.invsvcs.model.Product.class, true);
            if (toSaveProduct.getId() > 0) {
                new DateUtils<com.qqs.invsvcs.model.Product>().setTimeStamp(toSaveProduct, com.qqs.invsvcs.model.Product.class, true);
                toSaveProduct.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.invsvcs.model.Product>().setTimeStamp(toSaveProduct, com.qqs.invsvcs.model.Product.class, false);
                toSaveProduct.setCreatedBy(loggedInUser);
            }
            com.qqs.invsvcs.model.Product product = productDataService.saveProduct(toSaveProduct);
            productToApi = productToAPI.translate(product, Product.class, true);

            //Saving invProductDetails
            com.qqs.invsvcs.api.InvProductDetails invProductDetails = productData.getInvProductDetails();
            invProductDetails.setProductId(productToApi.getId());
            invProductDetails.setProductType(Constants.PRODUCT_TYPE_MAP.get("product"));
            invProductDetails = invPDService.saveInvProductDetails(invProductDetails);

            productToApi.setInvProductDetails(invProductDetails);

        } catch (Exception e) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving Product");
        }
        return productToApi;

    }

    public Product getProductById(Integer id) throws QQBusinessException {
        Product productApi = null;
        List<SupplierXProduct> supplierXProductListApi = new ArrayList<SupplierXProduct>() ;
        InvProductDetails invProductDetails = new InvProductDetails();

        try {
            Optional<com.qqs.invsvcs.model.Product> product = productDataService.getProductById(id);
            if (product.isPresent()) {
                productApi =  productToAPI.translate(product.get(), Product.class, true);
                Optional<List<com.qqs.invsvcs.model.SupplierXProduct>> supplierXProductList =
                        supplierXProductDataService.getAllSupplierXProductByProductIdAndType(productApi.getId(), Constants.PRODUCT_TYPE_MAP.get("product"));
                if (supplierXProductList.isPresent()) {
                    supplierXProductListApi = supplierXProductToAPI.translate(supplierXProductList.get(), SupplierXProduct.class, true);
                    productApi.setSupplierXProduct(supplierXProductListApi);
                }
                invProductDetails = invPDService.getByProductIdProductType(id, Constants.PRODUCT_TYPE_MAP.get("product"));
                if (invProductDetails != null) {
                    productApi.setInvProductDetails(invProductDetails);
                }
            }
        } catch (Exception e) {
            throw new QQBusinessException("Error while fetching Product");
        }
        return productApi;
    }


    public Map<String, String> getProductByProductType(String productType, HttpServletRequest request) throws QQBusinessException {
        Map<String, String> productMap = new HashMap<>();
        try {
            if (Constants.CATEGORY_URL_MAP.get(productType) != null) {
                return getProductFromService(productType, request);
            } else {
                Iterable<com.qqs.invsvcs.model.Product> product = productDataService.getAllProduct();
                product.forEach(item -> {
                    productMap.put(String.valueOf(item.getId()), item.getName());
                });
            }

        } catch (Exception e) {
            throw new QQBusinessException("Error while fetching Product");
        }
        return productMap;
    }


    public List<Product> searchProduct(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.invsvcs.model.Product>> productList = productDataService.searchProduct(conditions);
        if (!productList.isPresent())
            throw new QQBusinessException("No Product details found for criteria product search");
        List<Product> result = null;
        try {
            result = productToAPI.translate(productList.get(), Product.class, false);
            List<String> productIdAndType = new ArrayList<>();
            result.forEach(item -> {
                productIdAndType.add(Constants.PRODUCT_TYPE_MAP.get("product") + "-" + item.getId());
            });
            List<InvProductDetails> invProductDetails = invProductDetailsService.getByProductIdProductType(productIdAndType);
            Map<Integer, InvProductDetails> invProductDetailsMap = new HashMap<>();
            invProductDetails.forEach(item -> {
                invProductDetailsMap.put(item.getProductId(), item);
            });
            result.forEach(item -> {
                if(invProductDetailsMap.get(item.getId()) != null) {
                    item.setInvProductDetails(invProductDetailsMap.get(item.getId()));
                }
            });

        } catch (Exception e) {
            logger.error("Error getting Product", e);
        }
        return result;
    }

    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"name", "productType", "categoryId"}));
        Map<String, String> operators = new HashMap<>(2);
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, operators, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }


    public Map<String, String> getProductFromService(String productType, HttpServletRequest request) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders requestHeaders = new HttpHeaders();
        String baseUrl = "";

        if("part".equalsIgnoreCase(productType)) {
            baseUrl = posvcsURL;
        } else {
            baseUrl = qnqsvcsURL;
        }
        requestHeaders.add("Authorization", request.getHeader("Authorization"));
        requestHeaders.add("Content-Type", "application/json; charset=UTF-8");

        HttpEntity requestEntity = new HttpEntity(null, requestHeaders);
        ResponseEntity response = restTemplate.exchange(baseUrl + Constants.CATEGORY_URL_MAP.get(productType),
                HttpMethod.GET, requestEntity, Object.class);
        Map<String, String> productMap1 = (Map<String, String>) response.getBody();
//                    String result = restTemplate.getForObject(categoryURLMap.get(categoryName), String.class);
        logger.info(productMap1.toString());
        return productMap1;
    }
}
