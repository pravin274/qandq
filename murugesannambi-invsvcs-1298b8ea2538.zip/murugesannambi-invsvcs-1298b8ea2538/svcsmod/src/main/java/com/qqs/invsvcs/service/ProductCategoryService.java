package com.qqs.invsvcs.service;

import com.qqs.invsvcs.api.ProductCategory;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;
import static com.qqs.invsvcs.service.translate.APITranslator.*;

@Component
public class ProductCategoryService {

    Logger logger = LoggerFactory.getLogger(ProductCategoryService.class);

    @Resource
    DataService ds;

    @Resource
    ProductCategoryDataService productCategoryDataService;

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    public ProductCategory saveProductCategory(ProductCategory productCategoryData) throws QQBusinessException {
        ProductCategory productCategoryToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();

        try {
            com.qqs.invsvcs.model.ProductCategory toSaveProductCategory =  productCategoryToDB.translate(productCategoryData, com.qqs.invsvcs.model.ProductCategory.class, true);
            if(toSaveProductCategory.getId() > 0) {
                new DateUtils<com.qqs.invsvcs.model.ProductCategory>().setTimeStamp(toSaveProductCategory, com.qqs.invsvcs.model.ProductCategory.class, true);
                toSaveProductCategory.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.invsvcs.model.ProductCategory>().setTimeStamp(toSaveProductCategory, com.qqs.invsvcs.model.ProductCategory.class, false);
                toSaveProductCategory.setCreatedBy(loggedInUser);
            }
            com.qqs.invsvcs.model.ProductCategory productCategory = productCategoryDataService.saveProductCategory(toSaveProductCategory);

            productCategoryToApi = productCategoryToAPI.translate(productCategory , ProductCategory.class, true);

        } catch (Exception e ) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving ProductCategory");
        }

        return productCategoryToApi;

    }

    public ProductCategory getProductCategoryById(Integer id) throws QQBusinessException {
        ProductCategory productCategoryApi = null;
        try {
            Optional<com.qqs.invsvcs.model.ProductCategory> productCategory = productCategoryDataService.getProductCategoryById(id);
            if (productCategory.isPresent()) {
                productCategoryApi =  productCategoryToAPI.translate(productCategory.get(), ProductCategory.class, true);
            }
        } catch (Exception e) {
            throw new QQBusinessException("Error while fetching ProductCategory");
        }
        return productCategoryApi;
    }

    public List<ProductCategory> searchProductCategory(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.invsvcs.model.ProductCategory>> productCategoryList = productCategoryDataService.searchProductCategory(conditions);
        if (!productCategoryList.isPresent())
            throw new QQBusinessException("No ProductCategory details found for criteria productCategory search");
        List<ProductCategory> result = null;
        try {
            result = productCategoryToAPI.translate(productCategoryList.get(), ProductCategory.class, false);
        } catch (Exception e) {
            logger.error("Error getting ProductCategory", e);
        }

        return result;
    }

    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"name", "description"}));
        Map<String, String> operators = new HashMap<>(2);
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, operators, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }
}




