package com.qqs.invsvcs.service;

import com.qqs.invsvcs.api.Consumption;
import com.qqs.invsvcs.api.SupplierPoLineItem;
import com.qqs.invsvcs.api.SupplierPurchaseOrder;
import com.qqs.invsvcs.model.*;
import com.qqs.invsvcs.utils.Constants;
import com.qqs.posvcs.api.PurchOrder;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import com.qqs.qqsoft.mail.MailService;


import javax.annotation.RegEx;
import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;

import static com.qqs.invsvcs.service.translate.APITranslator.*;

@Component
public class ConsumptionService {
    Logger logger = LoggerFactory.getLogger(ConsumptionService.class);

    @Resource
    DataService ds;

    @Resource
    ConsumptionDataService consumptionDataService;

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    @Resource
    InvProductDetailsDataService invPDDataService;

    @Resource
    InvRequirementsDataService invReqDataService;

    @Resource
    SupplierPurchaseOrderService spoService;

    @Resource
    SupplierDataService supplierDataService;

    public Consumption saveConsumption(Consumption consumptionData) throws QQBusinessException {
        Consumption consumptionToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        Double prevQuantity = 0.0;
        try {
            com.qqs.invsvcs.model.Consumption toSaveConsumption = consumptionToDB.translate(consumptionData, com.qqs.invsvcs.model.Consumption.class, true);
            if (toSaveConsumption.getId() > 0) {
                new DateUtils<com.qqs.invsvcs.model.Consumption>().setTimeStamp(toSaveConsumption, com.qqs.invsvcs.model.Consumption.class, true);
                toSaveConsumption.setModifiedBy(loggedInUser);

                Optional<com.qqs.invsvcs.model.Consumption> existingConsumption = consumptionDataService.getConsumptionById(consumptionData.getId());
                if (existingConsumption.isPresent()) {
                    prevQuantity = existingConsumption.get().getQuantity();
                }
            } else {
                new DateUtils<com.qqs.invsvcs.model.Consumption>().setTimeStamp(toSaveConsumption, com.qqs.invsvcs.model.Consumption.class, false);
                toSaveConsumption.setCreatedBy(loggedInUser);
            }
            com.qqs.invsvcs.model.Consumption consumption = consumptionDataService.saveConsumption(toSaveConsumption);

            consumptionToApi = consumptionToAPI.translate(consumption, Consumption.class, true);

            Optional<InvProductDetails> invProductDetails = invPDDataService.getInvPDByProductIdAndProductType
                    (consumptionToApi.getProductId(), consumptionToApi.getProductType());

            if (invProductDetails.isPresent()) {
                InvProductDetails invPD = invProductDetails.get();

                // updating availableStock quantity in product master
                if (!prevQuantity.equals(consumptionToApi.getQuantity())) {
                    Double newQuantity = consumptionToApi.getQuantity() - prevQuantity;

                    BigDecimal bd = new BigDecimal(invPD.getAvailableStock() - newQuantity).setScale(2, RoundingMode.HALF_UP);
                    double availStock = bd.doubleValue();

                    invPD.setAvailableStock(availStock);
                    invPD = invPDDataService.saveInvProductDetails(invPD);
                }

                // Checking MSL and place order accordingly
                if (invPD.getAvailableStock() < (invPD.getMsl() + invPD.getSafetyStock())) {
                    raisePo(invPD);
                }
            }
            // updating Unusedquantity in invRequirements table.
            if (!prevQuantity.equals(consumptionToApi.getQuantity())) {

                Optional<InvRequirements> invRequirements = invReqDataService.getCurrInvReqByProductIdAndType
                        (consumptionToApi.getProductId(), consumptionToApi.getProductType());

                if (invRequirements.isPresent()) {
                    InvRequirements invReq = invRequirements.get();
                    Double newQuantity = consumptionToApi.getQuantity() - prevQuantity;
                    invReq.setUnUsedQuantity(invReq.getUnUsedQuantity() - newQuantity);
                    invReqDataService.saveInvRequirements(invReq);
                }
            }

        } catch (Exception e) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving Consumption");
        }

        return consumptionToApi;

    }

    public Consumption getConsumptionById(Integer id) throws QQBusinessException {
        Consumption consumptionApi = null;
        try {
            Optional<com.qqs.invsvcs.model.Consumption> consumption = consumptionDataService.getConsumptionById(id);
            if (consumption.isPresent()) {
                consumptionApi = consumptionToAPI.translate(consumption.get(), Consumption.class, true);

                Optional<Product> productDb = ds.getProductDS().getProductById(consumptionApi.getProductId());
                if (productDb.isPresent()) {
                    consumptionApi.setProduct(productToAPI.translate(productDb.get(), com.qqs.invsvcs.api.Product.class, true));
                }

                Optional<ProductBrand> productBrandDb = ds.getBrandDS().getProductBrandById(consumptionApi.getBrandId());
                if (productDb.isPresent()) {
                    consumptionApi.setBrand(productBrandToAPI.translate(productBrandDb.get(), com.qqs.invsvcs.api.ProductBrand.class, true));
                }
            }

        } catch (Exception e) {
            throw new QQBusinessException("Error while fetching Consumption");
        }
        return consumptionApi;
    }

    public List<Consumption> searchConsumption(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.invsvcs.model.Consumption>> consumptionList = consumptionDataService.searchConsumption(conditions);
        if (!consumptionList.isPresent())
            throw new QQBusinessException("No Consumption details found for criteria Consumption search");
        List<Consumption> result = null;
        try {
            result = consumptionToAPI.translate(consumptionList.get(), Consumption.class, false);
        } catch (Exception e) {
            logger.error("Error getting Consumption", e);
        }

        return result;
    }

    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"consumptionDate", "consumptionDateTo", "productId", "brandId", "quantity", "consumedBy", "productType"}));
        Map<String, String> operators = new HashMap<>(2);
        operators.put("consumptionDate", ">");
        if (params.get("consumptionDateTo") != null && params.get("consumptionDate") != null) {
            params.put("consumptionDate", params.get("consumptionDate") + "||" + params.get("consumptionDateTo"));
            params.remove("consumptionDateTo");
            operators.put("consumptionDate", "^");
        } else if (params.get("consumptionDateTo") != null) {
            operators.put("consumptionDate", "<");
            params.put("consumptionDate", params.get("consumptionDateTo"));
            params.remove("consumptionDateTo");
        }
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, operators, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }

    private void raisePo(InvProductDetails invProductDetails) throws QQBusinessException {
        Boolean raisePoFlag = true;
        Double poQuantity = (invProductDetails.getMsl() - invProductDetails.getAvailableStock());

        Optional<Object> openPo = ds.getSpoDataService().getOpenPurchaseOrder
                (invProductDetails.getProductId(), invProductDetails.getProductType());
        if (openPo.isPresent()) {
            Double openPoQuantity = ((Double) openPo.get()).doubleValue();
            if (openPoQuantity > 0 && openPoQuantity >= poQuantity)
                raisePoFlag = false;
        }

        if (raisePoFlag) {
            Optional<List<SupplierXProduct>> sxpList =
                    ds.getSxpDataService().getAllSupplierXProductByProductIdAndType(invProductDetails.getProductId(), invProductDetails.getProductType());

            if (sxpList.isPresent()) {
                findOrderQuantity(sxpList.get(), poQuantity);
            }
        }
    }

    private void findOrderQuantity(List<SupplierXProduct> sxpList, Double reqOrderQuantity) throws QQBusinessException {
        Double totalRaisedQty = 0.0;
        Double pendingQty = reqOrderQuantity;
        Double supQty = 0.0;
        List<SupplierXProduct> prefList = sxpList.stream()
                .filter(item -> "Y".equalsIgnoreCase(item.getIspreferred())).collect(Collectors.toList());

        if (prefList.size() == 0) prefList = sxpList;
        prefList.sort(Comparator.nullsFirst(Comparator.comparing(SupplierXProduct::getPrefpercent)).reversed());

        for (SupplierXProduct sxp : prefList) {
            if (sxp.getMbq().compareTo(pendingQty) >= 0) { //Minimum batch quantity is greater than req/pending qty
                totalRaisedQty += sxp.getMbq();
                pendingQty -= sxp.getMbq();
                supQty = sxp.getMbq();
            } else {
                Double calQty = pendingQty;
                if (sxp.getPrefpercent() != null) {
                    calQty = ((reqOrderQuantity * sxp.getPrefpercent()) / 100);
                    if (calQty.compareTo(pendingQty) >= 0) calQty = pendingQty;
                }
                supQty = ((int) Math.ceil(calQty / sxp.getMbq())) * sxp.getMbq();
                totalRaisedQty += supQty;
                pendingQty -= supQty;
            }
            createPo(sxp, supQty);
            if (totalRaisedQty.compareTo(reqOrderQuantity) >= 0) break;
        }
    }

    private void createPo(SupplierXProduct sxp, Double quantity) throws QQBusinessException {
        Integer supplierId = sxp.getSupplierId();
        Double cost = (sxp.getCost() * quantity);
        Integer supplierXProductId = sxp.getId();

        SupplierPurchaseOrder supplierPurchaseOrder = new SupplierPurchaseOrder();
        supplierPurchaseOrder.setPoDate(new Timestamp(System.currentTimeMillis()));
        supplierPurchaseOrder.setPoStatus(Constants.PO_STATUS_NEW);
        supplierPurchaseOrder.setSupplierId(supplierId);

        SupplierPoLineItem supplierPoLineItem = new SupplierPoLineItem();
        supplierPoLineItem.setCost(0.0);
        supplierPoLineItem.setQuantity(quantity);
        supplierPoLineItem.setCost(cost);
        supplierPoLineItem.setSupplierXProductId(supplierXProductId);

        Set<SupplierPoLineItem> splSet = new HashSet();
        splSet.add(supplierPoLineItem);

        supplierPurchaseOrder.setSupplierPoLineItem(splSet);

        SupplierPurchaseOrder po = spoService.saveSupplierPurchaseOrder(supplierPurchaseOrder);
        Optional<Supplier> supplierFromDb = supplierDataService.getSupplierById(sxp.getSupplierId());
        if (supplierFromDb != null) {
            try {
                supplierPurchaseOrder.setSupplier(supplierToAPI.translate(supplierFromDb.get(), com.qqs.invsvcs.api.Supplier.class, true));
            } catch (InstantiationException e) {
                logger.error("Error in Set Supplier  in createPo ", e);
            } catch (IllegalAccessException e) {
                logger.error("Error in Set Supplier  in createPo", e);
            }
        }
//        MailService.poForApproval(supplierPurchaseOrder);
    }
}
