package com.qqs.invsvcs.service;
import com.qqs.qqsoft.utils.SecurityUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
public class DataService {
    @Resource
    private ProductCategoryDataService productCategoryDS;

    @Resource
    private ProductDataService productDataService;

    @Resource
    private ProductBrandDataService brandDataService;

    @Resource
    private SupplierPurchaseOrderDataService spoDataService;

    @Resource
    private SupplierXProductDataService sxpDataService;

    @Resource
    private PhoneDataService phoneDS;

    @Resource
    private EmailDataService emailDS;

    @Resource
    private PeopleDataService peopleDS;

    @Resource
    private AddressDataService addressDS;


    @Resource
    SecurityUtils security;

    public ProductCategoryDataService getProductCategoryDS() {
        return productCategoryDS;
    }

    public ProductDataService getProductDS() {
        return productDataService;
    }

    public ProductBrandDataService getBrandDS() {
        return brandDataService;
    }

    public SupplierPurchaseOrderDataService getSpoDataService() {
        return spoDataService;
    }

    public SupplierXProductDataService getSxpDataService() {
        return sxpDataService;
    }

    public SecurityUtils getSecurity() {
        return security;
    }

    public PhoneDataService getPhoneDS() {
        return phoneDS;
    }

    public EmailDataService getEmailDS() {
        return emailDS;
    }

    public PeopleDataService getPeopleDS() {
        return peopleDS;
    }

    public AddressDataService getAddressDS() {
        return addressDS;
    }

}
