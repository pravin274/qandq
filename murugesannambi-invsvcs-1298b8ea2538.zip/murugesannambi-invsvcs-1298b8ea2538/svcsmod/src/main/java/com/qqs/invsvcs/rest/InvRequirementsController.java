package com.qqs.invsvcs.rest;

import com.qqs.invsvcs.api.InvRequirements;
import com.qqs.invsvcs.api.InventoryStockDetailReport;
import com.qqs.invsvcs.api.StockStatusReport;
import com.qqs.invsvcs.service.InvRequirementsService;
import com.qqs.invsvcs.service.InventoryReportService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/invreq")
public class InvRequirementsController {
    @Resource
    InvRequirementsService invRequirementsService;

    @Resource
    InventoryReportService invReportService;

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_PRODUCT_READ', 'ROLE_PRODUCT_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/searchbydate", produces = "application/json")
    public ResponseEntity<List<InvRequirements>> getInvReqByReqFrom(@RequestParam String reqFrom, Boolean regen,
                                                                    HttpServletRequest request) throws QQBusinessException {
        List<InvRequirements> invRequirements = invRequirementsService.getInvReqByReqFrom(reqFrom, regen, request);
        ResponseEntity<List<InvRequirements>> result = new ResponseEntity(invRequirements, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_PRODUCT_READ', 'ROLE_PRODUCT_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/inventorystock", produces = "application/json")
    public ResponseEntity<List<InventoryStockDetailReport>> getInventoryStockDetailReport(@RequestParam String fromDate, String  toDate,
                                                                    HttpServletRequest request) throws QQBusinessException {
        List<InventoryStockDetailReport> invRequirements = invReportService.getInventoryStockDetailReport(fromDate, toDate);
        ResponseEntity<List<InventoryStockDetailReport>> result = new ResponseEntity(invRequirements, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_PRODUCT_READ', 'ROLE_PRODUCT_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/stockStageWise", produces = "application/json")
    public ResponseEntity<StockStatusReport> getStockStatusReport(@RequestParam String fromDate, String  toDate,
                                                                                          HttpServletRequest request) throws QQBusinessException {
        StockStatusReport stockStatusReport = invReportService.getStockStageWiseData(fromDate, toDate);
        ResponseEntity<StockStatusReport> result = new ResponseEntity(stockStatusReport, HttpStatus.OK);
        return result;
    }
}

