package com.qqs.invsvcs.rest;

import com.qqs.invsvcs.api.ProductBrand;
import com.qqs.invsvcs.service.ProductBrandService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/productBrand")
public class ProductBrandController {
    @Resource
    ProductBrandService productBrandService;

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_WRITE', 'ROLE_PRODUCTBRAND_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/save", produces = "application/json")
    public ResponseEntity<ProductBrand> saveProductBrand(@RequestBody ProductBrand form) throws QQBusinessException {
        ProductBrand saved = productBrandService.saveProductBrand(form);
        ResponseEntity<ProductBrand> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_PRODUCTBRAND_READ', 'ROLE_PRODUCTBRAND_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/byId", produces = "application/json")
    public ResponseEntity<ProductBrand> getProductBrandById(@RequestParam Integer id,
                                                            HttpServletRequest request) throws QQBusinessException {
        ProductBrand emp = productBrandService.getProductBrandById(id);
        ResponseEntity<ProductBrand> result = new ResponseEntity(emp, HttpStatus.OK);
        return result;
    }


    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_PRODUCTBRAND_READ')")
    @RequestMapping(method = RequestMethod.GET, value = "/form/search", produces = "application/json")
    public ResponseEntity<List<ProductBrand>> searchProductBrand(@RequestParam Map<String, String> searchParam,
                                                                 @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                                 HttpServletRequest request) throws QQBusinessException {
        List<ProductBrand> formList = productBrandService.searchProductBrand(searchParam, exactMatch.orElse(false));
        ResponseEntity<List<ProductBrand>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }
}
