package com.qqs.invsvcs.service;

import com.qqs.invsvcs.api.InvProductDetails;
import com.qqs.invsvcs.api.InvRequirements;
import com.qqs.invsvcs.utils.Constants;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.config.WebServiceConfiguration;
import com.qqs.qqsoft.utils.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.qqs.invsvcs.service.translate.APITranslator.*;

@Component
public class InvRequirementsService {
    Logger logger = LoggerFactory.getLogger(InvProductDetailsService.class);

    @Resource
    InvRequirementsDataService invRequirementsDataService;

    @Value("${app.qnqsvcs.url}")
    private String qnqsvcsURL;

    @Resource
    WebServiceConfiguration webServiceConfiguration;

    @Resource
    DataService ds;

    @Resource
    ProductService productService;

    @Resource
    InvProductDetailsService invPDService;

    public List<InvRequirements> getInvReqByReqFrom(String reqFrom, Boolean regen,
                                                    HttpServletRequest request) throws QQBusinessException {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            Date parsedDate = dateFormat.parse(reqFrom);
            Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());

            if (regen) {
                //recalculate Inventory requirements based on schedule.
                Integer loggedInUser = ds.getSecurity().getLoggedInUser();

                List<InvRequirements> invRequirementsList = fetchInsertsReq(reqFrom, request);

                try {
                    List<com.qqs.invsvcs.model.InvRequirements> toSave = invRequirementsToDB.translate
                            (invRequirementsList, com.qqs.invsvcs.model.InvRequirements.class, false);

                    Iterable<com.qqs.invsvcs.model.InvRequirements> invReqDB =
                            invRequirementsDataService.getAllInvRequirementsByReqDate(timestamp);

                    Map<String, com.qqs.invsvcs.model.InvRequirements> invReqMap = new HashMap<>();
                    invReqDB.forEach(item -> {
                        invReqMap.put(item.getProductType() + "-" + item.getProductId(), item);
                    });

                    toSave.forEach(item -> {

                        if (invReqMap.get(item.getProductType() + "-" + item.getProductId()) != null) {
                            com.qqs.invsvcs.model.InvRequirements invRequirements = invReqMap.get(item.getProductType() + "-" + item.getProductId());
                            item.setId(invRequirements.getId());
                            item.setUnUsedQuantity(item.getReqQuantity() - (invRequirements.getReqQuantity() - invRequirements.getUnUsedQuantity()));
                            item.setCreatedBy(invRequirements.getCreatedBy());
                            item.setCreatedDt(invRequirements.getCreatedDt());
                        }

                        try {
                            item.setReqFrom(timestamp);
                            item.setReqTo(timestamp);
                            if (item.getId() > 0) {
                                new DateUtils<com.qqs.invsvcs.model.InvRequirements>().setTimeStamp(item, com.qqs.invsvcs.model.InvRequirements.class, true);
                                item.setModifiedBy(loggedInUser);
                            } else {
                                item.setUnUsedQuantity(item.getReqQuantity());
                                new DateUtils<com.qqs.invsvcs.model.InvRequirements>().setTimeStamp(item, com.qqs.invsvcs.model.InvRequirements.class, false);
                                item.setCreatedBy(loggedInUser);
                            }
                        } catch (Exception e) {
                            logger.error("Error while fetching Inventory Requirements");
                        }
                    });

                    invRequirementsDataService.deleteInvRequirements(invReqDB);

                    return fillDetails(invRequirementsDataService.saveInvRequirements(toSave), request);

                } catch (Exception e) {
                    logger.error("Error while fetching Inventory Requirements");
                    throw new QQBusinessException("Error while fetching Inventory Requirements");
                }

            }
            return getInvReqByReqFrom(timestamp, request);
        } catch (Exception e) {
            logger.error("Error while fetching Inventory Requirements");
            throw new QQBusinessException("Error while fetching Inventory Requirements");
        }
    }

    public List<InvRequirements> getInvReqByReqFrom(Timestamp reqFrom, HttpServletRequest request) throws QQBusinessException {
        List<InvRequirements> invRequirementsList = new ArrayList<>();
        try {
            Iterable<com.qqs.invsvcs.model.InvRequirements> invReqDB =
                    invRequirementsDataService.getAllInvRequirementsByReqDate(reqFrom);

            return fillDetails(invReqDB, request);

        } catch (Exception e) {
            logger.error("Error while fetching Inventory Requirments");
            throw new QQBusinessException("Error while fetching Inventory Requirments");
        }
    }

    public List<InvRequirements> fillDetails(Iterable<com.qqs.invsvcs.model.InvRequirements> invReqDB, HttpServletRequest request) throws QQBusinessException {
        List<InvRequirements> invRequirementsList = null;
        if (invReqDB.iterator().hasNext()) {
            Map<String, String> partsMap = productService.getProductByProductType(Constants.PRODUCT_TYPE_MAP.get("part"), request);
            Map<String, String> insertsMap = productService.getProductByProductType(Constants.PRODUCT_TYPE_MAP.get("inserts"), request);
            List<String> productIdAndType = new ArrayList<>();

            try {
                invRequirementsList = invRequirementsToAPI.translate(invReqDB, InvRequirements.class, true);

                invRequirementsList.forEach(item -> {
                    if (Constants.PRODUCT_TYPE_MAP.get("part").equalsIgnoreCase(item.getProductType())) {
                        item.setProductName(partsMap.get(item.getProductId().toString()));
                    } else if (Constants.PRODUCT_TYPE_MAP.get("inserts").equalsIgnoreCase(item.getProductType())) {
                        item.setProductName(insertsMap.get(item.getProductId().toString()));
                    }
                    item.setProductTypeDesc(StringUtils.capitalize(item.getProductType()));
                    productIdAndType.add(item.getProductType() + '-' + item.getProductId());
                });
                Map<String, Double> avlQtyMap = new HashMap<>();
                Map<String, Double> unUsedQtyMap = new HashMap<>();

                List<InvProductDetails> invProductDetails = invPDService.getByProductIdProductType(productIdAndType);
                invProductDetails.forEach(item -> {
                    avlQtyMap.put(item.getProductType() + '-' + item.getProductId(), item.getAvailableStock());
                });

                List<InvRequirements> invRequirements =  getByProductIdProductType(productIdAndType, invRequirementsList.get(0).getReqFrom());
                invRequirements.forEach(item -> {
                    unUsedQtyMap.put(item.getProductType() + '-' + item.getProductId(), item.getUnUsedQuantity());
                });

                invRequirementsList.forEach(item -> {
                    if(avlQtyMap.get(item.getProductType() + '-' + item.getProductId()) != null) {
                        item.setAvlQuantity(avlQtyMap.get(item.getProductType() + '-' + item.getProductId()));
                    } else {
                        item.setAvlQuantity(0.0);
                    }

                    if(unUsedQtyMap.get(item.getProductType() + '-' + item.getProductId()) != null) {
                        item.setReservedQuantity(unUsedQtyMap.get(item.getProductType() + '-' + item.getProductId()));
                    } else {
                        item.setReservedQuantity(0.0);
                    }

                    item.setNetReqQuantity(item.getReqQuantity() - (item.getAvlQuantity() - item.getReservedQuantity()));

                });


                } catch (Exception e) {
                logger.error("Error while fetching Inventory Requirments");
                throw new QQBusinessException("Error while fetching Inventory Requirments");
            }
        }
        return invRequirementsList;
    }

    private List<InvRequirements> fetchInsertsReq(String reqFrom, HttpServletRequest request) {
        RestTemplate restTemplate = webServiceConfiguration.restTemplate(webServiceConfiguration.getHttpClient());
        StringBuffer baseUrl = new StringBuffer();

        HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.add("Authorization", request.getHeader("Authorization"));
        requestHeaders.add("Content-Type", "application/json; charset=UTF-8");

        baseUrl.append(qnqsvcsURL).append(Constants.INSERTYS_REQ_URL).append(reqFrom);

        HttpEntity requestEntity = new HttpEntity(null, requestHeaders);
        ResponseEntity response = restTemplate.exchange(baseUrl.toString(),
                HttpMethod.GET, requestEntity, new ParameterizedTypeReference<List<InvRequirements>>(){});
        List<InvRequirements> invRequirementsList = (List<InvRequirements>) response.getBody();

        return invRequirementsList;
    }

    public List<InvRequirements> getByProductIdProductType(List<String> productTypeAndIdConcat, Timestamp reqFromDate) throws QQBusinessException {
        List<InvRequirements> invRequirementsList = new ArrayList<>();
        try {
            Iterable<com.qqs.invsvcs.model.InvRequirements> invReqDb =
                    invRequirementsDataService.getInvReqByProductIdAndType(productTypeAndIdConcat, reqFromDate);
            invRequirementsList = invRequirementsToAPI.translate(invReqDb, InvRequirements.class, true);

        } catch (Exception e) {
            throw new QQBusinessException("Error while fetching Inventory Requirements");
        }
        return invRequirementsList;
    }

}
