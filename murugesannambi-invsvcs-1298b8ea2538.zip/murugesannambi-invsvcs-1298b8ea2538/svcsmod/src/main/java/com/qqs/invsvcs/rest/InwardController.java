package com.qqs.invsvcs.rest;

import com.qqs.invsvcs.api.Inward;
import com.qqs.invsvcs.service.InwardService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/inward")
public class InwardController {
    @Resource
    InwardService inwardService;

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_WRITE', 'ROLE_INWARD_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/save", produces = "application/json")
    public ResponseEntity<Inward> saveInward(@RequestBody Inward form) throws QQBusinessException {
        Inward saved = inwardService.saveInward(form);
        ResponseEntity<Inward> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_INWARD_READ', 'ROLE_INWARD_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/byId", produces = "application/json")
    public ResponseEntity<Inward> getInwardById(@RequestParam Integer id,
                                                  HttpServletRequest request) throws QQBusinessException {
        Inward inward = inwardService.getInwardById(id);
        ResponseEntity<Inward> result = new ResponseEntity(inward, HttpStatus.OK);
        return result;
    }


    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_INWARD_READ')")
    @RequestMapping(method = RequestMethod.GET, value = "/form/search", produces = "application/json")
    public ResponseEntity<List<Inward>> searchInward(@RequestParam Map<String, String> searchParam,
                                                       @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                       HttpServletRequest request) throws QQBusinessException {
        List<Inward> formList = inwardService.searchInward(searchParam, exactMatch.orElse(false));
        ResponseEntity<List<Inward>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }
}
