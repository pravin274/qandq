package com.qqs.invsvcs.rest;

import com.qqs.invsvcs.api.PandL;
import com.qqs.invsvcs.api.PandLReport;
import com.qqs.invsvcs.service.PandLService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/pandl")
public class PandLController {
    @Resource
    PandLService pandLService;

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_WRITE', 'ROLE_PANDL_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/save", produces = "application/json")
    public ResponseEntity<PandL> savePandL(@RequestBody PandL form) throws QQBusinessException {
        PandL saved = pandLService.savePandL(form);
        ResponseEntity<PandL> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_PANDL_READ', 'ROLE_PANDL_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/byId", produces = "application/json")
    public ResponseEntity<PandL> getPandLById(@RequestParam Integer id,
                                                        HttpServletRequest request) throws QQBusinessException {
        PandL pandL = pandLService.getPandLById(id);
        ResponseEntity<PandL> result = new ResponseEntity(pandL, HttpStatus.OK);
        return result;
    }


    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_PANDL_READ')")
    @RequestMapping(method = RequestMethod.GET, value = "/form/search", produces = "application/json")
    public ResponseEntity<List<PandL>> searchPandL(@RequestParam Map<String, String> searchParam,
                                                             @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                             HttpServletRequest request) throws QQBusinessException {
        List<PandL> formList = pandLService.searchPandL(searchParam, exactMatch.orElse(false));
        ResponseEntity<List<PandL>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }


    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_PANDL_READ', 'ROLE_PANDL_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/pandlReport", produces = "application/json")
    public ResponseEntity<PandLReport> getPAndLReport(@RequestParam String fromDate, String  toDate,
                                                                  HttpServletRequest request) throws QQBusinessException {
        PandLReport pandLReport = pandLService.getPandLReport(fromDate, toDate);
        ResponseEntity<PandLReport> result = new ResponseEntity(pandLReport, HttpStatus.OK);
        return result;
    }
}
