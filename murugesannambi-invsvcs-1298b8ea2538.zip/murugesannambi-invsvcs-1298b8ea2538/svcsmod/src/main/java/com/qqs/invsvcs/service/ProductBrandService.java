package com.qqs.invsvcs.service;

import com.qqs.invsvcs.api.ProductBrand;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;

import static com.qqs.invsvcs.service.translate.APITranslator.*;

@Component
public class ProductBrandService {
    Logger logger = LoggerFactory.getLogger(ProductBrandService.class);

    @Resource
    DataService ds;

    @Resource
    ProductBrandDataService productBrandDataService;

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    public ProductBrand saveProductBrand(ProductBrand productBrandData) throws QQBusinessException {
        ProductBrand productBrandToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();

        try {
            com.qqs.invsvcs.model.ProductBrand toSaveProductBrand =  productBrandToDB.translate(productBrandData, com.qqs.invsvcs.model.ProductBrand.class, true);
            if(toSaveProductBrand.getId() > 0) {
                new DateUtils<com.qqs.invsvcs.model.ProductBrand>().setTimeStamp(toSaveProductBrand, com.qqs.invsvcs.model.ProductBrand.class, true);
                toSaveProductBrand.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.invsvcs.model.ProductBrand>().setTimeStamp(toSaveProductBrand, com.qqs.invsvcs.model.ProductBrand.class, false);
                toSaveProductBrand.setCreatedBy(loggedInUser);
            }
            com.qqs.invsvcs.model.ProductBrand productBrand = productBrandDataService.saveProductBrand(toSaveProductBrand);

            productBrandToApi = productBrandToAPI.translate(productBrand, ProductBrand.class, true);

        } catch (Exception e ) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving ProductBrand");
        }

        return productBrandToApi;

    }

    public ProductBrand getProductBrandById(Integer id) throws QQBusinessException {
        ProductBrand productBrandApi = null;
        try {
            Optional<com.qqs.invsvcs.model.ProductBrand> productBrand = productBrandDataService.getProductBrandById(id);
            if (productBrand.isPresent()) {
                productBrandApi =  productBrandToAPI.translate(productBrand.get(), ProductBrand.class, true);
            }
        } catch (Exception e) {
            throw new QQBusinessException("Error while fetching ProductBrand");
        }
        return productBrandApi;
    }

    public List<ProductBrand> searchProductBrand(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.invsvcs.model.ProductBrand>> productBrandList = productBrandDataService.searchProductBrand(conditions);
        if (!productBrandList.isPresent())
            throw new QQBusinessException("No Product Brand details found for criteria product brand search");
        List<ProductBrand> result = null;
        try {
            result = productBrandToAPI.translate(productBrandList.get(), ProductBrand.class, false);
        } catch (Exception e) {
            logger.error("Error getting Product Brand", e);
        }

        return result;
    }

    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"name"}));
        Map<String, String> operators = new HashMap<>(2);
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, operators, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }
}
