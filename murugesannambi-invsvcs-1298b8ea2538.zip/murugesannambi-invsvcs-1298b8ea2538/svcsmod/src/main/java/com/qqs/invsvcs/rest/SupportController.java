package com.qqs.invsvcs.rest;

import com.qqs.invsvcs.service.PeopleService;
import com.qqs.posvcs.api.Address;
import com.qqs.invsvcs.service.AddressService;
import com.qqs.posvcs.api.common.People;
import com.qqs.posvcs.api.translation.ParentEntityType;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Collection;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/support")
public class SupportController {
    @Resource
    AddressService addressService;

    @Resource
    private PeopleService peopleService;



    // ADDRESS
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/address", produces = "application/json")
    public ResponseEntity<Collection<Address>> getAddressByParent(HttpServletRequest request,
                                                                  @RequestParam Integer parentId, @RequestParam String parentType) throws QQBusinessException {

        Collection<Address> address = addressService.getAddressByParentType(parentType, parentId);
        ResponseEntity<Collection<Address>> result = new ResponseEntity(address, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/address/save", produces = "application/json")
    public ResponseEntity<Address> saveAddress(@RequestBody com.qqs.posvcs.api.Address form) throws QQBusinessException {
        com.qqs.posvcs.api.Address saved = addressService.saveAddress(form);
        ResponseEntity<Address> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    // PEOPLE
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/people", produces = "application/json")
    public ResponseEntity<Collection<People>> getPeopleByParentType(HttpServletRequest request,
                                                                    @RequestParam Integer parentId, @RequestParam String parentType) throws QQBusinessException {
        Collection<People> people = peopleService.getPeopleByParentType(parentType, parentId);
        ResponseEntity<Collection<People>> result = new ResponseEntity(people, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/people/byId", produces = "application/json")
    public ResponseEntity<Collection<People>> getPeopleById(HttpServletRequest request,
                                                            @RequestParam Integer id) throws QQBusinessException {
        People people = peopleService.getPeopleById(id);
        ResponseEntity<Collection<People>> result = new ResponseEntity(people, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/people/byCompany", produces = "application/json")
    public ResponseEntity<Collection<People>> getPeopleByCompany(HttpServletRequest request, @RequestParam Integer companyId) throws QQBusinessException {
        Collection<People> people = peopleService.getPeopleByCompany(companyId);
        ResponseEntity<Collection<People>> result = new ResponseEntity(people, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/people/byPlant", produces = "application/json")
    public ResponseEntity<Collection<People>> getPeopleByPlant(HttpServletRequest request, @RequestParam Integer plantId) throws QQBusinessException {
        Collection<People> people = peopleService.getPeopleByParentType(ParentEntityType.PLANT.getDbCode(), plantId);
        ResponseEntity<Collection<People>> result = new ResponseEntity(people, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/people/save", produces = "application/json")
    public ResponseEntity<People> savePeople(@RequestBody com.qqs.posvcs.api.common.People form) throws QQBusinessException {
        com.qqs.posvcs.api.common.People saved = peopleService.savePeople(form);
        ResponseEntity<People> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }
}
