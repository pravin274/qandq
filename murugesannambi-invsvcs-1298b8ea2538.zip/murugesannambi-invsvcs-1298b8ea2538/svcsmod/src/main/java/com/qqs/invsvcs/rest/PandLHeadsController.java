package com.qqs.invsvcs.rest;

import com.qqs.invsvcs.api.PandLHeads;
import com.qqs.invsvcs.service.PandLHeadsService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/pandlheads")
public class PandLHeadsController {
    @Resource
    PandLHeadsService pandLHeadsService;

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_WRITE', 'ROLE_PANDLHEADS_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/save", produces = "application/json")
    public ResponseEntity<PandLHeads> savePandLHeads(@RequestBody PandLHeads form) throws QQBusinessException {
        PandLHeads saved = pandLHeadsService.savePandLHeads(form);
        ResponseEntity<PandLHeads> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_PANDLHEADS_READ', 'ROLE_PANDLHEADS_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/byId", produces = "application/json")
    public ResponseEntity<PandLHeads> getPandLHeadsById(@RequestParam Integer id,
                                                HttpServletRequest request) throws QQBusinessException {
        PandLHeads pandLHeads = pandLHeadsService.getPandLHeadsById(id);
        ResponseEntity<PandLHeads> result = new ResponseEntity(pandLHeads, HttpStatus.OK);
        return result;
    }


    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_PANDLHEADS_READ')")
    @RequestMapping(method = RequestMethod.GET, value = "/form/search", produces = "application/json")
    public ResponseEntity<List<PandLHeads>> searchPandLHeads(@RequestParam Map<String, String> searchParam,
                                                     @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                     HttpServletRequest request) throws QQBusinessException {
        List<PandLHeads> formList = pandLHeadsService.searchPandLHeads(searchParam, exactMatch.orElse(false));
        ResponseEntity<List<PandLHeads>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }
}
