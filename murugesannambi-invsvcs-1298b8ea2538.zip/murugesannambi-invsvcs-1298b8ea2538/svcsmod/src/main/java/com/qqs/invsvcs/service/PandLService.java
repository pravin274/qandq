package com.qqs.invsvcs.service;

import com.qqs.invsvcs.api.PandL;
import com.qqs.invsvcs.api.PandLReport;
import com.qqs.invsvcs.api.PandLReportData;
import com.qqs.invsvcs.utils.Constants;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.DateFormatUtils;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;

import static com.qqs.invsvcs.service.translate.APITranslator.*;

@Component
public class PandLService {

    Logger logger = LoggerFactory.getLogger(PandLService.class);

    @Resource
    DataService ds;

    @Resource
    PandLDataService pandLDataService;

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    Map<String, Double> incomeSubTotalMap = new HashMap<>();


    public PandL savePandL(PandL pandLData) throws QQBusinessException {
        PandL pandLToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();

        try {
            com.qqs.invsvcs.model.PandL toSavePandL = pandLToDB.translate(pandLData, com.qqs.invsvcs.model.PandL.class, true);
            if (toSavePandL.getId() > 0) {
                new DateUtils<com.qqs.invsvcs.model.PandL>().setTimeStamp(toSavePandL, com.qqs.invsvcs.model.PandL.class, true);
                toSavePandL.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.invsvcs.model.PandL>().setTimeStamp(toSavePandL, com.qqs.invsvcs.model.PandL.class, false);
                toSavePandL.setCreatedBy(loggedInUser);
            }
            com.qqs.invsvcs.model.PandL pandL = pandLDataService.savePandL(toSavePandL);

            pandLToApi = pandLToAPI.translate(pandL, PandL.class, true);

        } catch (Exception e) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving PandL");
        }

        return pandLToApi;

    }

    public PandL getPandLById(Integer id) throws QQBusinessException {
        PandL pandLApi = null;
        try {

            Optional<com.qqs.invsvcs.model.PandL> pandL = pandLDataService.getPandLById(id);
            if (pandL.isPresent()) {
                pandLApi = pandLToAPI.translate(pandL.get(), PandL.class, true);
            }
        } catch (Exception e) {
            throw new QQBusinessException("Error while fetching PandL");
        }
        return pandLApi;
    }

    public List<PandL> searchPandL(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.invsvcs.model.PandL>> pandLList = pandLDataService.searchPandL(conditions);
        if (!pandLList.isPresent())
            throw new QQBusinessException("No PandL details found for criteria PandL search");
        List<PandL> result = null;
        try {
            result = pandLToAPI.translate(pandLList.get(), PandL.class, false);
        } catch (Exception e) {
            logger.error("Error getting PandL", e);
        }

        return result;
    }

    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"headsId", "amount", "remarks", "fromDate", "toDate",}));
        Map<String, String> operators = new HashMap<>(2);
        params.remove("exactMatch");
        operators.put("fromDate", ">");
        operators.put("toDate", "<");

        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, operators, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }

    public PandLReport getPandLReport(String fromDate, String toDate) throws QQBusinessException {
        PandLReport pandLReport = new PandLReport();
        List<PandLReportData> derivedPandLDataList = new ArrayList<>();

        Map<String, Map<String, Double>> headwiseDataMap = new HashMap<>();
        Map<String, Map<String, Double>> totalHeadsCatMap = new HashMap<>();
        Map<String, Map<String, Double>> stockValueDataMap = new HashMap<>();
        Map<String, Map<String, Double>> expNetValueDataMap = new HashMap<>();


        Map<String, Double> stockValueMap = new HashMap<>();

        Map<String, Double> expenditureNetPurchaseValueMap = new HashMap<>();


        List<String> monthsBtw = new ArrayList<>();
        monthsBtw.add(Constants.PANDL_REPORT_TOTAL);
        monthsBtw.addAll(DateFormatUtils.getMonthsBetween(fromDate, toDate));

        List<com.qqs.invsvcs.model.PandLReportData> pandLReportDataDB = pandLDataService.getPandLReport(fromDate, toDate);
        if (pandLReportDataDB != null && pandLReportDataDB.size() > 0) {
            try {
                pandLReportDataDB.forEach(item -> {
                    if (item.getCatOrder() != null) {
                        Map<String, Double> stockInnerDataMap = new HashMap<>();
                        Map<String, Double> expNetValueInnerDataMap = new HashMap<>();

                        Map<String, Double> monthPandLDataMap = new HashMap<>();
                        if (headwiseDataMap.get(item.getHeads()) != null) {
                            monthPandLDataMap = headwiseDataMap.get(item.getHeads());
                        }else {
                            monthPandLDataMap.put(item.getTransMonthYear(), item.getTotalAmt());
                        }

                        Double totalVal = 0.0;
                        if (monthPandLDataMap.get(Constants.PANDL_REPORT_TOTAL) != null) {
                            totalVal = monthPandLDataMap.get(Constants.PANDL_REPORT_TOTAL);
                        }else {
                            monthPandLDataMap.put(Constants.PANDL_REPORT_TOTAL, totalVal + item.getTotalAmt());
                        }

                        if(item.getHeadsCat().equals(Constants.INCOME)) {
                            if (item.getHeads().equals(Constants.OPENING_STOCK)) {
                                stockValueMap.put(item.getHeads(), item.getTotalAmt());
                            }
                            if (item.getHeads().equals(Constants.CLOSING_STOCK)) {
                                stockValueMap.put(item.getHeads(), item.getTotalAmt());
                            }

                            if (stockValueMap.size() > 1) {
                                stockValueMap.put(Constants.NET_STOCK, stockValueMap.get(Constants.CLOSING_STOCK) - stockValueMap.get(Constants.OPENING_STOCK));
                            }

                            stockInnerDataMap.put(item.getTransMonthYear(), stockValueMap.get(Constants.NET_STOCK));
                            stockInnerDataMap.put(Constants.PANDL_REPORT_TOTAL, stockValueMap.get(Constants.NET_STOCK));
                            stockValueDataMap.put(Constants.NET_STOCK, stockInnerDataMap);

                        }

                        if(item.getHeadsCat().equals(Constants.EXPENDITURE)) {
                            if (item.getHeads().equals(Constants.PURCHASE_RAW_MATERIAL)) {
                                expenditureNetPurchaseValueMap.put(item.getHeads(), item.getTotalAmt());
                            }
                            if (item.getHeads().equals(Constants.PURCHASE_RETURN)) {
                                expenditureNetPurchaseValueMap.put(item.getHeads(), item.getTotalAmt());
                            }

                            if(expenditureNetPurchaseValueMap.size() > 1) {
                                expenditureNetPurchaseValueMap.put(Constants.NET_PURCHASE, expenditureNetPurchaseValueMap.get(Constants.PURCHASE_RAW_MATERIAL)
                                        - expenditureNetPurchaseValueMap.get(Constants.PURCHASE_RETURN));
                            }
                            expNetValueInnerDataMap.put(item.getTransMonthYear(), expenditureNetPurchaseValueMap.get(Constants.NET_PURCHASE));
                            expNetValueInnerDataMap.put(Constants.PANDL_REPORT_TOTAL, expenditureNetPurchaseValueMap.get(Constants.NET_PURCHASE));
                            expNetValueDataMap.put(Constants.NET_PURCHASE, expNetValueInnerDataMap);
                        }

                        headwiseDataMap.put(item.getHeads(), monthPandLDataMap);


                    } else {
                        Map<String, Double> monthTotalMap = new HashMap<>();
                        if (totalHeadsCatMap.get(item.getHeadsCat()) != null){
                            monthTotalMap = totalHeadsCatMap.get(item.getHeadsCat());
                        }else {
                            if(item.getHeadsCat().equals(Constants.INCOME)) {
                                monthTotalMap.put(item.getTransMonthYear(), item.getTotalAmt() - stockValueMap.get(Constants.OPENING_STOCK) -
                                        stockValueMap.get(Constants.CLOSING_STOCK) + stockValueMap.get(Constants.NET_STOCK));
                            } else if(item.getHeadsCat().equals(Constants.EXPENDITURE)) {
                                monthTotalMap.put(item.getTransMonthYear(), item.getTotalAmt() - expenditureNetPurchaseValueMap.get(Constants.PURCHASE_RAW_MATERIAL) -
                                        expenditureNetPurchaseValueMap.get(Constants.PURCHASE_RETURN) + expenditureNetPurchaseValueMap.get(Constants.NET_PURCHASE));
                            } else {
                                monthTotalMap.put(item.getTransMonthYear(), item.getTotalAmt());
                            }
                        }

                        Double totalVal = 0.0;
                        if (monthTotalMap.get(Constants.PANDL_REPORT_TOTAL) != null) {
                            totalVal = monthTotalMap.get(Constants.PANDL_REPORT_TOTAL) - stockValueMap.get(Constants.NET_STOCK);
                        }else {
                            if(item.getHeadsCat().equals(Constants.INCOME)) {
                                monthTotalMap.put(Constants.PANDL_REPORT_TOTAL, totalVal + item.getTotalAmt() - stockValueMap.get(Constants.OPENING_STOCK) -
                                        stockValueMap.get(Constants.CLOSING_STOCK) + stockValueMap.get(Constants.NET_STOCK));
                            } else if(item.getHeadsCat().equals(Constants.EXPENDITURE)) {
                                monthTotalMap.put(Constants.PANDL_REPORT_TOTAL, totalVal + item.getTotalAmt() - expenditureNetPurchaseValueMap.get(Constants.PURCHASE_RAW_MATERIAL) -
                                        expenditureNetPurchaseValueMap.get(Constants.PURCHASE_RETURN) + expenditureNetPurchaseValueMap.get(Constants.NET_PURCHASE));
                            } else {
                                monthTotalMap.put(Constants.PANDL_REPORT_TOTAL, totalVal + item.getTotalAmt());
                            }
                        }

                        totalHeadsCatMap.put(item.getHeadsCat(), monthTotalMap);

                    }
                });

                List<com.qqs.invsvcs.model.PandLReportData> pandLHeadsDataDB = pandLDataService.getPandLHeadsData();
                List<PandLReportData> pandLReportDataList = pandLReportDataToAPI.translate(pandLHeadsDataDB, PandLReportData.class, true);

                String prevHeadsCat = "";
                Integer netStockCount = 0;
                Integer netPurchaseValueCount = 0;
                int headsCatRecCnt = 0;
                for (PandLReportData item : pandLReportDataList) {
                    if (headwiseDataMap.get(item.getHeads()) != null) {
                            item.setMonthPandLData(headwiseDataMap.get(item.getHeads()));
                    } else {
                        item.setMonthPandLData(stockValueDataMap.get(Constants.NET_STOCK));
                        item.setMonthPandLData(new HashMap<>());
                    }
                    item.setMonthPercentData(new HashMap<>());

//                    if(!(item.getHeads().equals(Constants.OPENING_STOCK) || item.getHeads().equals(Constants.CLOSING_STOCK) ||
//                            item.getHeads().equals(Constants.PURCHASE_RAW_MATERIAL) || item.getHeads().equals(Constants.PURCHASE_RETURN))) {
                        fillMissingVal(item.getHeadsCat(), item.getHeads(), item.getMonthPandLData(), monthsBtw, item.getMonthPercentData(), totalHeadsCatMap.get(item.getHeadsCat()));
//                    }
                    if (!("".equals(prevHeadsCat) || prevHeadsCat.equals(item.getHeadsCat()))) {
                        if (headsCatRecCnt > 1) {
                            if(stockValueDataMap != null && netStockCount == 0){
                                derivedPandLDataList.add(getNetValue(totalHeadsCatMap, prevHeadsCat, stockValueDataMap.get(Constants.NET_STOCK), monthsBtw));
                                netStockCount++;
                            }
                            if(prevHeadsCat.equals(Constants.EXPENDITURE) ) {
                                if (expNetValueDataMap != null && netPurchaseValueCount == 0) {
                                    derivedPandLDataList.add(getNetValue(totalHeadsCatMap, prevHeadsCat, expNetValueDataMap.get(Constants.NET_PURCHASE), monthsBtw));
                                    netPurchaseValueCount++;
                                }
                            }
                            derivedPandLDataList.add(createSummary(prevHeadsCat, totalHeadsCatMap.get(prevHeadsCat), monthsBtw));
                        }
                        headsCatRecCnt = 0;
                    } else {
                        if (!("".equals(prevHeadsCat))) item.setHeadsCatDesc(" ");
                    }
                    if (Constants.PANDL_CALC_CAT.contains(item.getHeadsCat())) {
                        headsCatRecCnt = 0;
                        fillCalcFieldVals(item, totalHeadsCatMap);
                    }

                    derivedPandLDataList.add(item);
                    prevHeadsCat = item.getHeadsCat();
                    headsCatRecCnt++;
                }

                if ((!("".equals(prevHeadsCat))) && headsCatRecCnt > 1) {
                    if(stockValueDataMap != null && netStockCount == 0){
                        derivedPandLDataList.add(getNetValue(totalHeadsCatMap, prevHeadsCat, stockValueDataMap.get(Constants.NET_STOCK), monthsBtw));
                        netStockCount++;
                    }
                    if(expNetValueDataMap != null && netPurchaseValueCount == 0) {
                        derivedPandLDataList.add(getNetValue(totalHeadsCatMap, prevHeadsCat, expNetValueDataMap.get(Constants.NET_PURCHASE), monthsBtw));
                        netPurchaseValueCount++;
                    }
                    derivedPandLDataList.add(createSummary(prevHeadsCat, totalHeadsCatMap.get(prevHeadsCat), monthsBtw));
                }


            } catch (Exception e) {
                logger.error("Error while fetching P & L Report data");
                throw new QQBusinessException("Error while fetching P & L Report data");
            }
        }
        pandLReport.setPandLReportData(derivedPandLDataList);
        pandLReport.setMonthList(monthsBtw);
        return pandLReport;
    }

    private void fillCalcFieldVals(PandLReportData pandLReportData, Map<String, Map<String, Double>> totalHeadMap) {
        pandLReportData.setRowDisplayFormat(Constants.BOLD + " " + Constants.SUCCESS);
        List<String> calList = Constants.PANDL_CALC_MAP_LIST.get(pandLReportData.getHeadsCat());
        getCalcValues(pandLReportData, totalHeadMap, calList.get(0), calList.get(1), calList.get(2));
    }

    private void getCalcValues(PandLReportData pandLReportData, Map<String, Map<String, Double>> totalHeadMap,
                               String mapKey1, String mapKey2, String totalPerKey) {
        Map<String, Double> totalMap1 = totalHeadMap.get(mapKey1);
        Map<String, Double> totalMap2 = totalHeadMap.get(mapKey2);
        Map<String, Double> totalPerMap = totalHeadMap.get(totalPerKey);

        Map<String, Double> currentHeadMap = new HashMap<>();

        pandLReportData.getMonthPandLData().forEach((k, v) -> {

            Double totVal1 = 0.0;
            Double totVal2 = 0.0;
            Double percentVal = 1.0;


            if (totalMap1 != null && totalMap1.get(k) != null) {
                totVal1 = totalMap1.get(k);
            }
            if (totalMap2 != null && totalMap2.get(k) != null) {
                totVal2 = totalMap2.get(k);

            }
            if (totalPerMap != null && totalPerMap.get(k) != null) {
                percentVal = totalPerMap.get(k);
            }
            Double grossVal = totVal1 - totVal2;
            Integer grossValPer = (int) Math.ceil(((grossVal / percentVal) * 100));

            pandLReportData.getMonthPandLData().put(k, grossVal);
            pandLReportData.getMonthPercentData().put(k, grossValPer);
            currentHeadMap.put(k, grossVal);
        });
        //Setting the current calculated values in map for further calculations
        if(totalHeadMap.get(pandLReportData.getHeadsCat()) == null)
            totalHeadMap.put(pandLReportData.getHeadsCat(), currentHeadMap);

    }

    private void fillMissingVal(String headsCat, String heads, Map<String, Double> headsMap, List<String> periodList,
                                Map<String, Integer> headsPercentMap, Map<String, Double> totalHeadsMap) {

        if (headsCat.equals(Constants.INCOME) && heads.equals(Constants.PANDL_REPORT_SUB_TOTAL)) {
            incomeSubTotalMap = totalHeadsMap;
        }

        Map<String, Double> finalIncomeSubTotalMap = incomeSubTotalMap;


        periodList.forEach(item -> {
            if (headsMap.get(item) == null) {
                headsMap.put(item, 0.0);
            }
        });


        if(heads.equals(Constants.OPENING_STOCK) || heads.equals(Constants.CLOSING_STOCK)) {
            periodList.forEach(item -> {
                headsPercentMap.put(item, null);
            });
        } else {
            if (headsPercentMap != null) {
                periodList.forEach(item -> {
                    if (headsMap.get(item) == null || headsMap.get(item).compareTo(0.0) == 0
                            || totalHeadsMap == null || totalHeadsMap.get(item) == null) {
                        headsPercentMap.put(item, 0);
                    } else {
                        if (finalIncomeSubTotalMap.size() == 0) {
                            headsPercentMap.put(item, (int) Math.ceil(((headsMap.get(item) / totalHeadsMap.get(item)) * 100)));
                        } else {
                            headsPercentMap.put(item, (int) Math.ceil(((headsMap.get(item) / finalIncomeSubTotalMap.get(item)) * 100)));
                        }
                    }
                });
            }
        }
    }

    private PandLReportData createSummary(String headsCat, Map<String, Double> totalHeadsCatMap, List<String> monthsBtw) {
        PandLReportData pandLReportData = new PandLReportData();
        pandLReportData.setHeadsCat(" ");
        pandLReportData.setHeadsCatDesc(" ");
        pandLReportData.setHeadsDesc(Constants.PANDL_REPORT_SUB_TOTAL);
        pandLReportData.setHeads(Constants.PANDL_REPORT_SUB_TOTAL);
        pandLReportData.setRowDisplayFormat(Constants.BOLD);
        if (totalHeadsCatMap != null) {
            pandLReportData.setMonthPandLData(totalHeadsCatMap);
        } else {
            pandLReportData.setMonthPandLData(new HashMap<>());
        }
        pandLReportData.setMonthPercentData(new HashMap<>());


        fillMissingVal(headsCat, pandLReportData.getHeads(), pandLReportData.getMonthPandLData(), monthsBtw, pandLReportData.getMonthPercentData(), totalHeadsCatMap);
        return pandLReportData;
    }

    private PandLReportData getNetValue(Map<String, Map<String, Double>> totalHeadsCatMap, String headsCat, Map<String, Double> stockValueDataMap, List<String> monthsBtw) {
        PandLReportData pandLReportData = new PandLReportData();
        pandLReportData.setHeadsCat(" ");
        pandLReportData.setHeadsCatDesc(" ");
        if(headsCat.equals(Constants.EXPENDITURE)){
            pandLReportData.setHeadsDesc(Constants.NET_PURCHASE);
            pandLReportData.setHeads(Constants.NET_PURCHASE);
        }
        if(headsCat.equals(Constants.INCOME)) {
            pandLReportData.setHeadsDesc(Constants.NET_STOCK);
            pandLReportData.setHeads(Constants.NET_STOCK);

        }
        pandLReportData.setRowDisplayFormat(" ");
        if (stockValueDataMap != null) {
            pandLReportData.setMonthPandLData(stockValueDataMap);
        } else {
            pandLReportData.setMonthPandLData(new HashMap<>());
        }
        pandLReportData.setMonthPercentData(new HashMap<>());

        fillMissingNetValue(totalHeadsCatMap, pandLReportData.getHeads(), pandLReportData.getMonthPandLData(), monthsBtw, pandLReportData.getMonthPercentData(), stockValueDataMap);
        return pandLReportData;
    }

    private void fillMissingNetValue(Map<String, Map<String, Double>> totalHeadsCatMap, String heads, Map<String, Double> headsMap, List<String> periodList,
                                Map<String, Integer> headsPercentMap, Map<String, Double> totalHeadsMap) {
        periodList.forEach(item -> {
            if (headsMap.get(item) == null) {
                headsMap.put(item, 0.0);
            }
        });

        totalHeadsCatMap.forEach((k,v) -> {
            if(k.equals(Constants.INCOME) || k.equals(Constants.EXPENDITURE)) {
                periodList.forEach(item -> {
                    if(v.get(item) == null || v.get(item).compareTo(0.0) == 0) {
                        headsPercentMap.put(item, 0);
                    } else {
                        headsPercentMap.put(item, (int) Math.ceil((headsMap.get(item) / v.get(item)) * 100));

                    }
                });
                }
            });
    }
}
