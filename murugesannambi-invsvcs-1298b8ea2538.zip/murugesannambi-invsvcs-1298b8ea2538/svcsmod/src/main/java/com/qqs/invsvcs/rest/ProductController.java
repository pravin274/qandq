package com.qqs.invsvcs.rest;

import com.qqs.invsvcs.service.ProductService;
import com.qqs.invsvcs.api.Product;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/product")
public class ProductController {
    @Resource
    ProductService productService;

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_WRITE', 'ROLE_PRODUCT_WRITE')")
    @RequestMapping(method = RequestMethod.POST, value = "/save", produces = "application/json")
    public ResponseEntity<Product> saveProduct(@RequestBody Product form) throws QQBusinessException {
        Product saved = productService.saveProduct(form);
        ResponseEntity<Product> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_PRODUCT_READ', 'ROLE_PRODUCT_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/byId", produces = "application/json")
    public ResponseEntity<Product> getProductById(@RequestParam Integer id,
                                                  HttpServletRequest request) throws QQBusinessException {
        Product pro = productService.getProductById(id);
        ResponseEntity<Product> result = new ResponseEntity(pro, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_PRODUCT_READ', 'ROLE_PRODUCT_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/byProductType", produces = "application/json")
    public ResponseEntity<Map<String, String>> getProductByProductType(@RequestParam String productType,
                                                  HttpServletRequest request) throws QQBusinessException {
        Map<String, String> pro = productService.getProductByProductType(productType, request);
        ResponseEntity<Map<String, String>> result = new ResponseEntity(pro, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ', 'ROLE_PRODUCT_READ')")
    @RequestMapping(method = RequestMethod.GET, value = "/form/search", produces = "application/json")
    public ResponseEntity<List<Product>> searchProduct(@RequestParam Map<String, String> searchParam,
                                                       @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                       HttpServletRequest request) throws QQBusinessException {
        List<Product> formList = productService.searchProduct(searchParam, exactMatch.orElse(false));
        ResponseEntity<List<Product>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }


}

