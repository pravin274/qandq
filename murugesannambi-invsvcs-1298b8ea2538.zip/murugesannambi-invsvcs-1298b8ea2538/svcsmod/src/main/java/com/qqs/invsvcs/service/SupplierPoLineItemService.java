package com.qqs.invsvcs.service;

import com.qqs.invsvcs.api.SupplierPoLineItem;
import com.qqs.invsvcs.api.SupplierXProduct;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.math.BigInteger;
import java.util.*;

import static com.qqs.invsvcs.service.translate.APITranslator.*;

@Component
public class SupplierPoLineItemService {
    Logger logger = LoggerFactory.getLogger(SupplierPoLineItemService.class);

    @Resource
    DataService ds;

    @Resource
    SupplierPoLineItemDataService supplierPoLineItemDataService;

    @Resource
    SupplierXProductDataService supplierXProductDataService;

    @Resource
    SupplierService supplierService;

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    public SupplierPoLineItem saveSupplierPoLineItem(SupplierPoLineItem supplierPoLineItemData) throws QQBusinessException {
        SupplierPoLineItem supplierPoLineItemToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();

        try {
            com.qqs.invsvcs.model.SupplierPoLineItem toSaveSupplierPoLineItem = supplierPoLineItemToDB.translate(supplierPoLineItemData, com.qqs.invsvcs.model.SupplierPoLineItem.class, true);
            if (toSaveSupplierPoLineItem.getId() > 0) {
                new DateUtils<com.qqs.invsvcs.model.SupplierPoLineItem>().setTimeStamp(toSaveSupplierPoLineItem, com.qqs.invsvcs.model.SupplierPoLineItem.class, true);
                toSaveSupplierPoLineItem.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.invsvcs.model.SupplierPoLineItem>().setTimeStamp(toSaveSupplierPoLineItem, com.qqs.invsvcs.model.SupplierPoLineItem.class, false);
                toSaveSupplierPoLineItem.setCreatedBy(loggedInUser);
            }
            com.qqs.invsvcs.model.SupplierPoLineItem supplierPoLineItem = supplierPoLineItemDataService.saveSupplierPoLineItem(toSaveSupplierPoLineItem);

            supplierPoLineItemToApi = supplierPoLineItemToAPI.translate(supplierPoLineItem, SupplierPoLineItem.class, true);

        } catch (Exception e) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving SupplierPoLineItem");
        }
        return supplierPoLineItemToApi;
    }

    public List<SupplierPoLineItem> saveAllSupplierPoLineItem(Set<SupplierPoLineItem> supplierPoLineItemData, Integer poId) throws QQBusinessException {
        List<SupplierPoLineItem> supplierPoLineItemToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        List<com.qqs.invsvcs.model.SupplierPoLineItem> toSaveSupplierPoLineItemToDb = new ArrayList<>();
        try {
            for (com.qqs.invsvcs.api.SupplierPoLineItem poLineItem : supplierPoLineItemData) {
                poLineItem.setPoId(poId);
                com.qqs.invsvcs.model.SupplierPoLineItem toSaveSupplierPoLineItem = supplierPoLineItemToDB.translate(poLineItem, com.qqs.invsvcs.model.SupplierPoLineItem.class, true);
                if (toSaveSupplierPoLineItem.getId() > 0) {
                    new DateUtils<com.qqs.invsvcs.model.SupplierPoLineItem>().setTimeStamp(toSaveSupplierPoLineItem, com.qqs.invsvcs.model.SupplierPoLineItem.class, true);
                    toSaveSupplierPoLineItem.setModifiedBy(loggedInUser);
                } else {
                    new DateUtils<com.qqs.invsvcs.model.SupplierPoLineItem>().setTimeStamp(toSaveSupplierPoLineItem, com.qqs.invsvcs.model.SupplierPoLineItem.class, false);
                    toSaveSupplierPoLineItem.setCreatedBy(loggedInUser);
                }
                toSaveSupplierPoLineItemToDb.add(toSaveSupplierPoLineItem);
            }
            Iterable<com.qqs.invsvcs.model.SupplierPoLineItem> supplierPoLineItem = supplierPoLineItemDataService.saveAllSupplierPoLineItem(toSaveSupplierPoLineItemToDb);

            supplierPoLineItemToApi = supplierPoLineItemToAPI.translate(supplierPoLineItem, SupplierPoLineItem.class, true);

        } catch (Exception e) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving All SupplierPoLineItem");
        }
        return supplierPoLineItemToApi;
    }

    public SupplierPoLineItem getSupplierPoLineItemById(Integer id) throws QQBusinessException {
        SupplierPoLineItem supplierPoLineItemApi = null;
        try {
            Optional<com.qqs.invsvcs.model.SupplierPoLineItem> supplierPoLineItem = supplierPoLineItemDataService.getSupplierPoLineItemById(id);
            if (supplierPoLineItem.isPresent()) {
                supplierPoLineItemApi = supplierPoLineItemToAPI.translate(supplierPoLineItem.get(), SupplierPoLineItem.class, true);
            }
        } catch (Exception e) {
            throw new QQBusinessException("Error while fetching SupplierPoLineItem");
        }
        return supplierPoLineItemApi;
    }

    public List<SupplierPoLineItem> getSupplierPoLineItemByPOId(Integer poId, HttpServletRequest request) throws QQBusinessException {
        List<SupplierPoLineItem> supplierPoLineItemApi = null;
        try {
            Optional<List<com.qqs.invsvcs.model.SupplierPoLineItem>> supplierPoLineItem = supplierPoLineItemDataService.getAllSupplierPoLineItemByPoId(poId);
            if (supplierPoLineItem.isPresent()) {
                supplierPoLineItemApi = supplierPoLineItemToAPI.translate(supplierPoLineItem.get(), SupplierPoLineItem.class, true);
                supplierPoLineItemApi.forEach(supplierPoLineItem1 -> {
                    try {
                        supplierPoLineItem1.setSupplierXProduct(supplierService.getSupplierXProductById(supplierPoLineItem1.getSupplierXProductId(), request));
                    } catch (QQBusinessException e) {
                        logger.info("supplierPoLineItem add supplierxproduct object" + e);
                    }
                });
            }
        } catch (Exception e) {
            throw new QQBusinessException("Error while fetching SupplierPoLineItem");
        }
        return supplierPoLineItemApi;
    }

    public List<SupplierPoLineItem> searchSupplierPoLineItem(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.invsvcs.model.SupplierPoLineItem>> supplierPoLineItemList = supplierPoLineItemDataService.searchSupplierPoLineItem(conditions);
        if (!supplierPoLineItemList.isPresent())
            throw new QQBusinessException("No SupplierPoLineItem details found for criteria SupplierPoLineItem search");
        List<SupplierPoLineItem> result = null;
        try {
            result = supplierPoLineItemToAPI.translate(supplierPoLineItemList.get(), SupplierPoLineItem.class, false);
        } catch (Exception e) {
            logger.error("Error getting SupplierPoLineItem", e);
        }

        return result;
    }

    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"id", "poId", "supplierXProductId", "quantity", "cost"}));
        Map<String, String> operators = new HashMap<>(2);
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, operators, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }

    public Map<Integer, Double> getReceivedQuantity(Iterable<Integer> poLineItemIds, Integer inwardId) {
        return generateQuantityMap(supplierPoLineItemDataService.getReceivedQtyByPOLineItems(poLineItemIds, inwardId));
    }

    public Map<Integer, Double> getReceivedQuantity(Iterable<Integer> poLineItemIds) {
        return generateQuantityMap(supplierPoLineItemDataService.getReceivedQtyByPOLineItems(poLineItemIds));
    }

    private Map<Integer, Double> generateQuantityMap(Optional<List<Object[]>> receivedQtyList) {
        Map<Integer, Double> receivedQuantityMap = new HashMap<>();
        if(receivedQtyList.isPresent()) {
            receivedQtyList.get().forEach(item -> {
                receivedQuantityMap.put(((BigInteger)item[0]).intValue(), ((Double) item[1]));
            });
        }
        return receivedQuantityMap;
    }
}
