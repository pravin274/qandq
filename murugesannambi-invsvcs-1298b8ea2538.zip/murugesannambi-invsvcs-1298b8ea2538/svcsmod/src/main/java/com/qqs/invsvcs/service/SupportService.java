package com.qqs.invsvcs.service;

import com.qqs.invsvcs.utils.Constants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import java.util.LinkedHashMap;
import java.util.Map;


@Component
public class SupportService {

    @Value("${app.posvcs.url}")
    private String posvcsURL;

    public Map<String, Map<String, LinkedHashMap<String, String>>> getCodes(HttpServletRequest request) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders requestHeaders = new HttpHeaders();
        String baseUrl = "";

        requestHeaders.add("Cookie", request.getHeader("po-auth-token"));
        baseUrl = posvcsURL;

        requestHeaders.add("Authorization", request.getHeader("Authorization"));
        requestHeaders.add("Content-Type", "application/json; charset=UTF-8");

        HttpEntity requestEntity = new HttpEntity(null, requestHeaders);
        ResponseEntity response = restTemplate.exchange(baseUrl + Constants.CODES_URL,
                HttpMethod.GET, requestEntity, Object.class);
        Map<String, Map<String, LinkedHashMap<String, String>>> codesMap =
                (Map<String, Map<String, LinkedHashMap<String, String>>>) response.getBody();
        return codesMap;
    }
}
