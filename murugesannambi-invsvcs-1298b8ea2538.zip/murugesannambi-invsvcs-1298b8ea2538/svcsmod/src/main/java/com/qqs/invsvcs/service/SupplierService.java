package com.qqs.invsvcs.service;

import com.qqs.invsvcs.api.Product;
import com.qqs.invsvcs.api.ProductBrand;
import com.qqs.invsvcs.api.Supplier;
import com.qqs.invsvcs.api.SupplierXProduct;
import com.qqs.posvcs.api.Address;
import com.qqs.posvcs.api.translation.ParentEntityType;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

import static com.qqs.invsvcs.service.translate.APITranslator.*;
import static com.qqs.posvcs.api.translation.ParentEntityType.PEOPLE;


@Component
public class SupplierService {

    Logger logger = LoggerFactory.getLogger(SupplierService.class);

    @Resource
    DataService ds;

    @Resource
    SupplierDataService supplierDataService;

    @Resource
    SupplierXProductDataService supplierXProductDataService;

    @Resource
     ProductDataService productDataService;
    @Resource
    ProductBrandDataService productBrandDataService;

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    @Resource
    ProductService productService;

    @Resource
    PeopleService peopleService;

    @Resource
    DataService dataService;

    @Resource
    AddressDataService addressDataService;

    public Supplier saveSupplier(Supplier supplierData) throws QQBusinessException {
        Supplier supplierToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        try {
            com.qqs.invsvcs.model.Supplier toSaveSupplier = supplierToDB.translate(supplierData, com.qqs.invsvcs.model.Supplier.class, true);
            if (toSaveSupplier.getId() > 0) {
                new DateUtils<com.qqs.invsvcs.model.Supplier>().setTimeStamp(toSaveSupplier, com.qqs.invsvcs.model.Supplier.class, true);
                toSaveSupplier.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.invsvcs.model.Supplier>().setTimeStamp(toSaveSupplier, com.qqs.invsvcs.model.Supplier.class, false);
                toSaveSupplier.setCreatedBy(loggedInUser);
            }
            com.qqs.invsvcs.model.Supplier supplier = supplierDataService.saveSupplier(toSaveSupplier);
            supplierToApi = supplierToAPI.translate(supplier, Supplier.class, true);
        } catch (Exception e) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving Supplier");
        }
        return supplierToApi;
    }

    public Supplier getSupplierById(Integer id, HttpServletRequest request) throws QQBusinessException {
        Supplier supplierApi = null;
        List<SupplierXProduct> supplierXProductListToApi = null;
        Set<String> prodTySet = new LinkedHashSet<>();
        Set<Integer> brandIdList = new LinkedHashSet<>();

        Map<String, Map<String, String>> productTyeMap = new HashMap< String, Map<String, String>>();

        try {
            Optional<com.qqs.invsvcs.model.Supplier> supplier = supplierDataService.getSupplierById(id);
            if (supplier.isPresent()) {
                supplierApi = supplierToAPI.translate(supplier.get(), Supplier.class, true);
                Optional<List<com.qqs.invsvcs.model.SupplierXProduct>> supplierXProductList = supplierXProductDataService.getAllSupplierXProductBySupplierId(supplierApi.getId());
                if (supplierXProductList.isPresent()) {
                    Iterable<ProductBrand> productBrandList = new ArrayList<>();
                    supplierXProductListToApi = supplierXProductToAPI.translate(supplierXProductList.get(), SupplierXProduct.class, true);
                    supplierXProductListToApi.forEach( sup -> {
                        brandIdList.add(sup.getBrandId());
                        prodTySet.add(sup.getProductType());
                    });
                    productBrandList = productBrandToAPI.translate(productBrandDataService.getAllProductBrandById(brandIdList), ProductBrand.class, true);
                    prodTySet.forEach( sets -> {
                        try {
                            productTyeMap.put(sets, productService.getProductByProductType(sets, request));
                        } catch (QQBusinessException e) {
                            logger.error("Error Get Product By Product  Type", e);
                        }
                    });
                    Iterable<ProductBrand> finalProductBrandList = productBrandList;
                    supplierXProductListToApi.forEach(supList -> {
                        if (supList.getProductType().equals("product")) {
                            try {
                                supList.setProduct(productToAPI.translate(productDataService.getProductById(supList.getProductId()).get(), Product.class, true) );
                            } catch (InstantiationException e) {
                                logger.error("Error Get Product By Product  ID", e);
                            } catch (IllegalAccessException e) {
                                logger.error("Error Get Product By Product  ID", e);
                            }

                        }
                        supList.setProductName(productTyeMap.get(supList.getProductType()).get(String.valueOf(supList.getProductId())));
                        finalProductBrandList.forEach(brand -> {
                            if (brand.getId() == supList.getBrandId()) {
                                supList.setBrand(brand);
                            }
                        });
                    });
                    supplierApi.setSupplierXProduct(supplierXProductListToApi);
                }
                try {
                    Collection<com.qqs.posvcs.api.common.People> peopleList = peopleService.getPeopleByParentType("S", supplierApi.getId());
                    List<Integer> peopleIds = new ArrayList<>();
                    if (peopleList != null) {
                        peopleList.forEach( people -> {
                            peopleIds.add(people.getId());
                        });
                    }

                    Optional<List<com.qqs.invsvcs.model.Phone>> phoneList =  dataService.getPhoneDS().findAllByParentIdInAndParentEntity(peopleIds, "H");
                    Optional<List<com.qqs.invsvcs.model.Email>> emailList = dataService.getEmailDS().findAllByParentIdInAndParentEntity(peopleIds, "H");
                    Optional<List<com.qqs.invsvcs.model.Address>>  addressesList = addressDataService.findAddressesBySupplier(supplierApi.getId());

                    if (addressesList.isPresent()) {
                        supplierApi.setAddresses(addressToAPI.translate(addressesList.get(), Address.class, true));
                    }
                    Map<Integer, Set<com.qqs.posvcs.api.Phone>> phoneMap = new HashMap<>();
                    Map<Integer, Set<com.qqs.posvcs.api.Email>> emailMap = new HashMap<>();
                    if (phoneList.isPresent()) {
                        List<com.qqs.posvcs.api.Phone> phonesToApi = phoneToAPI.translate(phoneList.get(), com.qqs.posvcs.api.Phone.class , true );
                        phonesToApi.forEach( phone ->  {
                            if (phoneMap.get(phone.getParentId()) == null) {
                                phoneMap.put(phone.getParentId(), new HashSet<>());
                            }
                            phoneMap.get(phone.getParentId()).add(phone);
                        });
                        peopleList.forEach( people -> {
                            if (phoneMap.get(people.getId()) != null) {
                                people.setPhones(phoneMap.get(people.getId()));
                            }
                        });
                    }
                    if (emailList.isPresent()) {
                        List<com.qqs.posvcs.api.Email> emailsToApi = emailToAPI.translate(emailList.get(), com.qqs.posvcs.api.Email.class , true );
                        emailsToApi.forEach( email ->  {
                            if (emailMap.get(email.getParentId()) == null) {
                                emailMap.put(email.getParentId(), new HashSet<>());
                            }
                            emailMap.get(email.getParentId()).add(email);
                        });
                        peopleList.forEach( people -> {
                            if (emailMap.get(people.getId()) != null) {
                                people.setEmails(emailMap.get(people.getId()));
                            }
                        });
                    }
                    if (peopleList != null) {
                        supplierApi.setPeople(new ArrayList(peopleList));
                    }
                } catch (Exception e) {
                    logger.error("translation exception - People");
                }
            }
        } catch (Exception e) {
            throw new QQBusinessException("Error while fetching Supplier");
        }
        return supplierApi;
    }

    public SupplierXProduct getSupplierXProductById(Integer id, HttpServletRequest request ) throws QQBusinessException {
        SupplierXProduct supplierXProductListApi = null;
        Map<String, Map<String, String>> productTypeMap = new HashMap< String, Map<String, String>>();

        try {
            Optional<com.qqs.invsvcs.model.SupplierXProduct> supplierXProduct = supplierXProductDataService.getSupplierXProductById(id);
            if (supplierXProduct.isPresent()) {
                supplierXProductListApi = supplierXProductToAPI.translate(supplierXProduct.get(), SupplierXProduct.class, false);
                productTypeMap.put(supplierXProductListApi.getProductType(), productService.getProductByProductType(supplierXProductListApi.getProductType(), request));
                supplierXProductListApi.setProductName(productTypeMap.get(supplierXProductListApi.getProductType()).get(String.valueOf(supplierXProductListApi.getProductId())));
                supplierXProductListApi.setBrand(
                        productBrandToAPI.translate((productBrandDataService.getProductBrandById(supplierXProductListApi.getBrandId())).get(), ProductBrand.class, true));
            }
        } catch (Exception e) {
            throw new QQBusinessException("Error while fetching Supplier X Product");
        }
        return supplierXProductListApi;
    }

    public List<SupplierXProduct> getSupplierXProductByProductIdAndType(Integer productId, String productType, HttpServletRequest request ) throws QQBusinessException {
        List<SupplierXProduct> supplierXProductListApi = null;
        Set<String> productTypeSet = new LinkedHashSet<>();
        Map<String, Map<String, String>> productTypeMap = new HashMap< String, Map<String, String>>();
        try {
            Optional<List<com.qqs.invsvcs.model.SupplierXProduct>> supplierXProduct = supplierXProductDataService.getAllSupplierXProductByProductIdAndType(productId, productType);

            if (supplierXProduct.isPresent()) {
                supplierXProductListApi = supplierXProductToAPI.translate(supplierXProduct.get(), SupplierXProduct.class, false);
                supplierXProductListApi.forEach( sup -> {
                    productTypeSet.add(sup.getProductType());
                });
                productTypeSet.forEach( sets -> {
                    try {
                        productTypeMap.put(sets, productService.getProductByProductType(sets, request));
                    } catch (QQBusinessException e) {
                        logger.error("Error Get Product By Product  Type", e);
                    }
                });
                supplierXProductListApi.forEach( supList -> {
                    supList.setProductName(productTypeMap.get(supList.getProductType()).get(String.valueOf(supList.getProductId())));
                });
            }
        } catch (Exception e) {
            throw new QQBusinessException("Error while fetching Supplier");
        }
        return supplierXProductListApi;
    }


    public List<Supplier> searchSupplier(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.invsvcs.model.Supplier>> supplierList = supplierDataService.searchSupplier(conditions);
        if (!supplierList.isPresent())
            throw new QQBusinessException("No Supplier details found for criteria supplier search");
        List<Supplier> result = null;
        try {
            result = supplierToAPI.translate(supplierList.get(), Supplier.class, false);
        } catch (Exception e) {
            logger.error("Error getting Supplier", e);
        }

        return result;
    }

    public SupplierXProduct saveSupplierXProduct(SupplierXProduct supplierData) throws QQBusinessException {
        SupplierXProduct supplierToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();
        try {
            com.qqs.invsvcs.model.SupplierXProduct toSaveSupplier = supplierXProductToDB.translate(supplierData, com.qqs.invsvcs.model.SupplierXProduct.class, true);
            if (toSaveSupplier.getId() > 0) {
                new DateUtils<com.qqs.invsvcs.model.SupplierXProduct>().setTimeStamp(toSaveSupplier, com.qqs.invsvcs.model.SupplierXProduct.class, true);
                toSaveSupplier.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.invsvcs.model.SupplierXProduct>().setTimeStamp(toSaveSupplier, com.qqs.invsvcs.model.SupplierXProduct.class, false);
                toSaveSupplier.setCreatedBy(loggedInUser);
            }
            com.qqs.invsvcs.model.SupplierXProduct supplier = supplierXProductDataService.saveSupplierXProduct(toSaveSupplier);
            supplierToApi = supplierXProductToAPI.translate(supplier, SupplierXProduct.class, true);
        } catch (Exception e) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving Supplier");
        }
        return supplierToApi;
    }

    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"name", "status"}));
        Map<String, String> operators = new HashMap<>(2);
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, operators, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }
}
