package com.qqs.invsvcs.service;

import com.qqs.invsvcs.api.InvProductDetails;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;

import static com.qqs.invsvcs.service.translate.APITranslator.*;

@Component
public class InvProductDetailsService {
    Logger logger = LoggerFactory.getLogger(InvProductDetailsService.class);

    @Resource
    DataService ds;

    @Resource
    InvProductDetailsDataService invPDDataService;

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    public InvProductDetails saveInvProductDetails(InvProductDetails invProductDetails) throws QQBusinessException {
        InvProductDetails invPDApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();

        try {
            com.qqs.invsvcs.model.InvProductDetails toSaveInvPD = invProductDetailsToDB.translate(invProductDetails,
                    com.qqs.invsvcs.model.InvProductDetails.class, true);
            if (toSaveInvPD.getId() > 0) {
                new DateUtils<com.qqs.invsvcs.model.InvProductDetails>().setTimeStamp(toSaveInvPD, com.qqs.invsvcs.model.InvProductDetails.class, true);
                toSaveInvPD.setModifiedBy(loggedInUser);
            } else {
                toSaveInvPD.setAvailableStock(0.00);
                toSaveInvPD.setOpeningStock(0.00);
                new DateUtils<com.qqs.invsvcs.model.InvProductDetails>().setTimeStamp(toSaveInvPD, com.qqs.invsvcs.model.InvProductDetails.class, false);
                toSaveInvPD.setCreatedBy(loggedInUser);
            }
            com.qqs.invsvcs.model.InvProductDetails invProductDetailsDb = invPDDataService.saveInvProductDetails(toSaveInvPD);
            invPDApi = invProductDetailsToAPI.translate(invProductDetailsDb, InvProductDetails.class, true);

        } catch (Exception e) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving");
        }
        return invPDApi;

    }

    public InvProductDetails getInvProductDetailsById(Integer id) throws QQBusinessException {
        InvProductDetails invProductDetails = new InvProductDetails();
        try {
            Optional<com.qqs.invsvcs.model.InvProductDetails> invProductDetailsDb = invPDDataService.getInvProductDetailsById(id);
            if (invProductDetailsDb.isPresent()) {
                invProductDetails = invProductDetailsToAPI.translate(invProductDetailsDb.get(), InvProductDetails.class, true);
            }
        } catch (Exception e) {
            throw new QQBusinessException("Error while fetching InvProductDetails");
        }
        return invProductDetails;
    }

    public InvProductDetails getByProductIdProductType(Integer productId, String productType) throws QQBusinessException {
        InvProductDetails invProductDetails = new InvProductDetails();
        try {
            Optional<com.qqs.invsvcs.model.InvProductDetails> invProductDetailsDb =
                    invPDDataService.getInvPDByProductIdAndProductType(productId, productType);
            if (invProductDetailsDb.isPresent()) {
                invProductDetails = invProductDetailsToAPI.translate(invProductDetailsDb.get(), InvProductDetails.class, true);
            }

        } catch (Exception e) {
            throw new QQBusinessException("Error while fetching InvProductDetails");
        }
        return invProductDetails;
    }


    public List<InvProductDetails> getByProductIdProductType(List<String> productTypeAndIdConcat) throws QQBusinessException {
        List<InvProductDetails> invProductDetails = new ArrayList<>();
        try {
            Iterable<com.qqs.invsvcs.model.InvProductDetails> invProductDetailsDb =
                    invPDDataService.getInvPDByProductIdAndProductType(productTypeAndIdConcat);
            invProductDetails = invProductDetailsToAPI.translate(invProductDetailsDb, InvProductDetails.class, true);

        } catch (Exception e) {
            throw new QQBusinessException("Error while fetching InvProductDetails");
        }
        return invProductDetails;
    }

}
