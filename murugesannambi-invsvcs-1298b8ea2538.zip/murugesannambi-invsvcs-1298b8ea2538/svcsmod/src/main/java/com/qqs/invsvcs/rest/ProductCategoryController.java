package com.qqs.invsvcs.rest;
import com.qqs.invsvcs.api.ProductCategory;
import com.qqs.invsvcs.service.ProductCategoryService;
import com.qqs.qqsoft.QQBusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/pc")
public class ProductCategoryController {

    @Resource
    ProductCategoryService productCategoryService;

    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    @RequestMapping(method = RequestMethod.POST, value = "/save", produces = "application/json")
    public ResponseEntity<ProductCategory> saveProductCategory(@RequestBody ProductCategory form) throws QQBusinessException {
        ProductCategory saved = productCategoryService.saveProductCategory(form);
        ResponseEntity<ProductCategory> result = new ResponseEntity(saved, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ')")
    @RequestMapping(method = RequestMethod.GET, value = "/search/byId", produces = "application/json")
    public ResponseEntity<ProductCategory> getProductCategoryById(@RequestParam Integer id,
                                                         HttpServletRequest request) throws QQBusinessException {
        ProductCategory productCategory = productCategoryService.getProductCategoryById(id);
        ResponseEntity<ProductCategory> result = new ResponseEntity(productCategory, HttpStatus.OK);
        return result;
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_ALL_READ','ROLE_MASTER_READ','ROLE_MASTER_WRITE')")
    @RequestMapping(method = RequestMethod.GET, value = "/form/search", produces = "application/json")
    public ResponseEntity<List<ProductCategory>> searchProductCategory(@RequestParam Map<String, String> searchParam,
                                                              @RequestParam(required = false) Optional<Boolean> exactMatch,
                                                              HttpServletRequest request) throws QQBusinessException {
        List<ProductCategory> formList = productCategoryService.searchProductCategory(searchParam, exactMatch.orElse(false));
        ResponseEntity<List<ProductCategory>> result = new ResponseEntity(formList, HttpStatus.OK);
        return result;
    }
}
