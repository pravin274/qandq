package com.qqs.invsvcs.service;

import com.qqs.invsvcs.api.PandLHeads;
import com.qqs.qqsoft.QQBusinessException;
import com.qqs.qqsoft.utils.DateUtils;
import com.qqs.qqsoft.utils.SearchCriteriaUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;

import static com.qqs.invsvcs.service.translate.APITranslator.*;

@Component
public class PandLHeadsService {

    Logger logger = LoggerFactory.getLogger(PandLHeadsService.class);

    @Resource
    DataService ds;

    @Resource
    PandLHeadsDataService pandLHeadsDataService;

    @Resource
    SearchCriteriaUtils searchCriteriaUtils;

    public PandLHeads savePandLHeads(PandLHeads pandLHeadsData) throws QQBusinessException {
        PandLHeads pandLHeadsToApi = null;
        Integer loggedInUser = ds.getSecurity().getLoggedInUser();

        try {
            com.qqs.invsvcs.model.PandLHeads toSavePandLHeads =  pandLHeadsToDB.translate(pandLHeadsData, com.qqs.invsvcs.model.PandLHeads.class, true);
            if(toSavePandLHeads.getId() > 0) {
                new DateUtils<com.qqs.invsvcs.model.PandLHeads>().setTimeStamp(toSavePandLHeads, com.qqs.invsvcs.model.PandLHeads.class, true);
                toSavePandLHeads.setModifiedBy(loggedInUser);
            } else {
                new DateUtils<com.qqs.invsvcs.model.PandLHeads>().setTimeStamp(toSavePandLHeads, com.qqs.invsvcs.model.PandLHeads.class, false);
                toSavePandLHeads.setCreatedBy(loggedInUser);
            }
            com.qqs.invsvcs.model.PandLHeads pandLHeads = pandLHeadsDataService.savePandLHeads(toSavePandLHeads);

            pandLHeadsToApi = pandLHeadsToAPI.translate(pandLHeads, PandLHeads.class, true);

        } catch (Exception e ) {
            System.out.println(e);
            throw new QQBusinessException("Error while saving PandLHeads");
        }

        return pandLHeadsToApi;

    }

    public PandLHeads getPandLHeadsById(Integer id) throws QQBusinessException {
        PandLHeads pandLHeadsdApi = null;
        try {
            Optional<com.qqs.invsvcs.model.PandLHeads> pandLHeads = pandLHeadsDataService.getPandLHeadsById(id);
            if (pandLHeads.isPresent()) {
                pandLHeadsdApi =  pandLHeadsToAPI.translate(pandLHeads.get(), PandLHeads.class, true);
            }
        } catch (Exception e) {
            throw new QQBusinessException("Error while fetching PandLHeads");
        }
        return pandLHeadsdApi;
    }

    public List<PandLHeads> searchPandLHeads(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        List<SearchCriteria> conditions = createSearchCriteria(params, exactMatch);
        Optional<List<com.qqs.invsvcs.model.PandLHeads>> pandLHeadsList = pandLHeadsDataService.searchPandLHeads(conditions);
        if (!pandLHeadsList.isPresent())
            throw new QQBusinessException("No PandLHeads details found for criteria PandLHeads search");
        List<PandLHeads> result = null;
        try {
            result = pandLHeadsToAPI.translate(pandLHeadsList.get(), PandLHeads.class, false);
        } catch (Exception e) {
            logger.error("Error getting PandLHeads", e);
        }

        return result;
    }

    private List<SearchCriteria> createSearchCriteria(Map<String, String> params, Boolean exactMatch) throws QQBusinessException {
        Set validColumns = new HashSet(Arrays.asList(new String[]{"pandLCategory", "heads", "description"}));
        Map<String, String> operators = new HashMap<>(2);
        params.remove("exactMatch");
        List<SearchCriteria> conditions = new ArrayList<>();
        try {
            conditions = searchCriteriaToJPA.translate(
                    searchCriteriaUtils.createSearchCriteria(params, exactMatch, operators, validColumns),
                    SearchCriteria.class, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conditions;
    }
}
