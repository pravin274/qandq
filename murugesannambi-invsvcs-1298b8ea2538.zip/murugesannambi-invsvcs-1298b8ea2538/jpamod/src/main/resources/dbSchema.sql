create schema `invmgmnt`;

CREATE TABLE `invmgmnt`.`product` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(300) NOT NULL,
  `categoryId` INT(20) NULL,
  `MSL` INT(20) NULL,
  `preferredSupplier` INT(20) NULL,
  `preferredBrand` INT(20) NULL,
  `openingStock` INT(20) NULL,
  `availableStock` INT(20) NULL,
 `createdBy` int(20) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedBy` int(20) DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`));

  CREATE TABLE `invmgmnt`.`productcategory` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(300) NOT NULL,
  `description` VARCHAR(500) NULL,
 `createdBy` int(20) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedBy` int(20) DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `invmgmnt`.`supplier` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(300) NOT NULL,
  `status` CHAR(1) NULL,
 `createdBy` int(20) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedBy` int(20) DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `invmgmnt`.`productbrand` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(300) NOT NULL,
 `createdBy` int(20) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedBy` int(20) DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `invmgmnt`.`supllierxproduct` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `productId` INT(20) NOT NULL,
  `supplierId` INT(20) NOT NULL,
  `brandId` INT(20) NOT NULL,
  `cost` DOUBLE NOT NULL,
  `mbq` INT(20) NULL,
  `leadTimeInDays` INT(20) NULL,
  `effectiveFrom` DATETIME NOT NULL,
  `effectiveTo` DATETIME NULL,
 `createdBy` int(20) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedBy` int(20) DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `invmgmnt`.`purchase` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `supplierXProductId` INT(20) NOT NULL,
  `quantity` INT(20) NOT NULL,
  `totalCost` DOUBLE NOT NULL,
  `discountVal` DOUBLE NULL,
   `createdBy` int(20) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedBy` int(20) DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `invmgmnt`.`consumption` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `consumptionDate` DATETIME NOT NULL,
  `productId` INT(20) NOT NULL,
  `brandId` INT(20) NOT NULL,
  `quantity` INT(20) NOT NULL,
  `consumedBy` INT(20) NOT NULL,
  `partId` INT(20) NOT NULL,
   `createdBy` int(20) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedBy` int(20) DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`));

CREATE  OR REPLACE VIEW `invmgmnt`.`user` AS select * FROM `qandq`.`user`;

CREATE TABLE `invmgmnt`.`purchorder` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `supplierId` BIGINT(20) NOT NULL,
  `poNumber` VARCHAR(100) NULL,
  `poDate` DATETIME NULL,
  `poFileName` VARCHAR(200) NULL,
  `poStatus` VARCHAR(10) NULL,
  `createdBy` BIGINT(20) NULL,
  `createdDt` DATETIME NULL,
  `modifiedBy` BIGINT(20) NULL,
  `modifiedDt` DATETIME NULL,
  PRIMARY KEY (`id`));

  CREATE TABLE `invmgmnt`.`polineitem` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `poId` BIGINT(20) NOT NULL,
  `supplierXProductId` BIGINT(20) NOT NULL,
  `quantity` INT(10),
  `cost` DOUBLE  ,
  `createdBy` BIGINT(20) NULL,
  `createdDt` DATETIME NULL,
  `modifiedBy` BIGINT(20) NULL,
  `modifiedDt` DATETIME NULL,
  PRIMARY KEY (`id`));
