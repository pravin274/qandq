ALTER TABLE `invmgmnt`.`purchase`
ADD COLUMN `purchaseDate` DATETIME NULL DEFAULT NULL AFTER `discountVal`;

ALTER TABLE `invmgmnt`.`purchase`
ADD COLUMN `poNumber` VARCHAR(100) NULL DEFAULT NULL AFTER `purchaseDate`,
ADD COLUMN `dcNumber` VARCHAR(100) NULL DEFAULT NULL AFTER `purchaseDate`;

ALTER TABLE `invmgmnt`.`supplier`
CHANGE COLUMN `status` `status` TINYINT(1) NULL DEFAULT NULL ;


ALTER TABLE `invmgmnt`.`product`
CHANGE COLUMN `preferredSupplier` `preferredSupplierId` INT(20) NULL DEFAULT NULL ,
CHANGE COLUMN `preferredBrand` `preferredBrandId` INT(20) NULL DEFAULT NULL ;


ALTER TABLE `invmgmnt`.`supllierxproduct`
RENAME TO  `invmgmnt`.`supplierxproduct` ;


ALTER TABLE `invmgmnt`.`productbrand`
ADD COLUMN `description` VARCHAR(400) NULL DEFAULT NULL AFTER `name`;

ALTER TABLE `invmgmnt`.`purchase`
ADD COLUMN `uom` VARCHAR(45) NULL AFTER `quantity`,
CHANGE COLUMN `quantity` `quantity` DOUBLE NOT NULL ;

ALTER TABLE `invmgmnt`.`product`
CHANGE COLUMN `openingStock` `openingStock` DOUBLE NULL DEFAULT NULL ,
CHANGE COLUMN `availableStock` `availableStock` DOUBLE NULL DEFAULT NULL ;

ALTER TABLE `invmgmnt`.`consumption`
CHANGE COLUMN `quantity` `quantity` DOUBLE NOT NULL ;

ALTER TABLE `invmgmnt`.`purchorder`
CHANGE COLUMN `supplierId` `supplierId` BIGINT(20) NULL ;

ALTER TABLE `invmgmnt`.`supplierxproduct`
CHANGE COLUMN `mbq` `mbq` DOUBLE NULL DEFAULT NULL ;

ALTER TABLE `invmgmnt`.`purchase`
DROP COLUMN `poNumber`,
DROP COLUMN `discountVal`,
DROP COLUMN `totalCost`,
DROP COLUMN `uom`,
DROP COLUMN `quantity`,
DROP COLUMN `supplierXProductId`,
ADD COLUMN `receivedBy` BIGINT(20) NULL AFTER `dcNumber`,
ADD COLUMN `remarks` VARCHAR(300) NULL AFTER `receivedBy`, RENAME TO  `invmgmnt`.`inward` ;

CREATE TABLE `invmgmnt`.`inwardlineitem` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `inwardId` BIGINT(20) NOT NULL,
  `poLineItemId` BIGINT(20) NULL,
  `quantity` DOUBLE NULL,
  `status` VARCHAR(10) NULL,
  `createdBy` BIGINT(20) NULL,
  `createdDt` DATETIME NULL,
  `modifiedBy` BIGINT(20) NULL,
  `modifiedDt` DATETIME NULL,
  PRIMARY KEY (`id`));

ALTER TABLE `invmgmnt`.`inward`
CHANGE COLUMN `purchaseDate` `inwardDate` DATETIME NULL DEFAULT NULL ;


ALTER TABLE `invmgmnt`.`polineitem`
ADD COLUMN `item` VARCHAR(100) NULL DEFAULT NULL AFTER `poId`,
ADD COLUMN `itemStatus` VARCHAR(50) NULL DEFAULT NULL AFTER `item`;

ALTER TABLE `invmgmnt`.`purchorder`
CHANGE COLUMN `poStatus` `poStatus` VARCHAR(100) NULL DEFAULT NULL ;


ALTER TABLE `invmgmnt`.`inward`
ADD COLUMN `poId` INT(20) NOT NULL AFTER `id`;

ALTER TABLE `invmgmnt`.`supplierxproduct`
ADD COLUMN `ispreferred` VARCHAR(1) NULL DEFAULT NULL AFTER `brandId`,
ADD COLUMN `prefpercent` INT(10) NULL DEFAULT NULL AFTER `ispreferred`,
ADD COLUMN `productType` VARCHAR(45) NULL DEFAULT NULL AFTER `prefpercent`;

ALTER TABLE `invmgmnt`.`consumption`
ADD COLUMN `productType` VARCHAR(50) NULL DEFAULT NULL AFTER `productId`,
ADD COLUMN `categoryId` INT(10) NULL DEFAULT NULL AFTER `productType`;


ALTER TABLE `invmgmnt`.`supplierxproduct`
ADD UNIQUE INDEX `SpBrUnique` (`productId` ASC, `supplierId` ASC, `brandId` ASC) VISIBLE;
;


ALTER TABLE `invmgmnt`.`product`
DROP COLUMN `preferredBrandId`,
DROP COLUMN `preferredSupplierId`;

CREATE TABLE `invmgmnt`.`invproductdetails` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `productId` BIGINT(20) NOT NULL,
  `productType` VARCHAR(45) NOT NULL,
  `msl` DOUBLE NULL,
  `openingStock` DOUBLE NULL DEFAULT 0,
  `availableStock` DOUBLE NULL DEFAULT 0,
  `safetyStock` DOUBLE NULL DEFAULT 0,
  `safetyStockUnit` VARCHAR(45) NULL,
  `jobType` VARCHAR(100) NULL,
   `createdBy` int(20) DEFAULT NULL,
    `createdDt` datetime DEFAULT NULL,
    `modifiedBy` int(20) DEFAULT NULL,
    `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`));


CREATE TABLE `invmgmnt`.`address` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(20) NOT NULL,
  `parentEntity` varchar(20) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `streetNo` varchar(50) DEFAULT NULL,
  `streetName` varchar(100) DEFAULT NULL,
  `lineTwo` varchar(100) DEFAULT NULL,
  `lineThree` varchar(100) DEFAULT NULL,
  `lineFour` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `country` varchar(3) DEFAULT NULL,
  `postalCd` varchar(20) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
     `createdBy` int(20) DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
      `modifiedBy` int(20) DEFAULT NULL,

  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;


ALTER TABLE `invmgmnt`.`supplierxproduct`
DROP INDEX `SpBrUnique` ,
ADD UNIQUE INDEX `SpBrUnique` (`productId` ASC, `supplierId` ASC, `brandId` ASC, `productType` ASC) VISIBLE;
;

CREATE TABLE `invmgmnt`.`invrequirements` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `productId` BIGINT(20) NOT NULL,
  `productType` VARCHAR(45) NOT NULL,
  `reqFrom` DATETIME NOT NULL,
  `reqTo` DATETIME NOT NULL,
  `reqQuantity` DOUBLE NOT NULL,
  `unUsedQuantity` DOUBLE NOT NULL,
  `createdBy` BIGINT(20) NULL,
  `createdDt` DATETIME NULL,
  `modifiedBy` BIGINT(20) NULL,
  `modifiedDt` DATETIME NULL,
  PRIMARY KEY (`id`));

ALTER TABLE `invmgmnt`.`product`
DROP COLUMN `MSL`,
DROP COLUMN `openingStock`,
DROP COLUMN `availableStock`;

CREATE TABLE `invmgmnt`.`pandlheads` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `pandLCategory` VARCHAR(45) NOT NULL,
  `heads` VARCHAR(100) NOT NULL,
  `description` VARCHAR(400) NOT NULL,
  `createdBy` BIGINT(20) NULL,
  `createdDt` DATETIME NULL,
  `modifiedBy` BIGINT(20) NULL,
  `modifiedDt` DATETIME NULL,
  PRIMARY KEY (`id`));

ALTER TABLE `invmgmnt`.`invproductdetails` ADD INDEX idx_product_id_type((concat_ws('-', productType, productId)));
ALTER TABLE `invmgmnt`.`invrequirements` ADD INDEX idx_product_id_type((concat_ws('-', productType, productId)));


CREATE TABLE `invmgmnt`.`pandl` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `heads` BIGINT(20) NOT NULL,
   `amount` VARCHAR(50) NOT NULL,
  `fromDate` DATETIME NOT NULL,
  `toDate` DATETIME NOT NULL,
  `remarks` VARCHAR(450) NOT NULL,
  `createdBy` BIGINT(20) NULL,
  `createdDt` DATETIME NULL,
  `modifiedBy` BIGINT(20) NULL,
  `modifiedDt` DATETIME NULL,
  PRIMARY KEY (`id`));


 ALTER TABLE `invmgmnt`.`pandl`
CHANGE COLUMN `fromDate` `fromDate` varchar(20) NULL DEFAULT NULL ,
CHANGE COLUMN `toDate` `toDate` varchar(20) NULL DEFAULT NULL;



ALTER TABLE `invmgmnt`.`inward`
ADD INDEX `idx_inwarddate` (`inwardDate` ASC) VISIBLE;
;

ALTER TABLE `invmgmnt`.`inwardlineitem`
ADD INDEX `idx_inwardid` (`inwardId` ASC) VISIBLE;
;


ALTER TABLE `invmgmnt`.`consumption`
ADD INDEX `idx_consumptiondate` (`consumptionDate` ASC) VISIBLE;
;

ALTER TABLE `invmgmnt`.`consumption`
ADD INDEX `idx_product` (`productId` ASC, `productType` ASC) VISIBLE;
;



ALTER TABLE `invmgmnt`.`invproductdetails`
ADD INDEX `idx_product` (`productId` ASC, `productType` ASC) VISIBLE;
;

ALTER TABLE `invmgmnt`.`pandl`
CHANGE COLUMN `heads` `headsId` BIGINT(20) NOT NULL ;

ALTER TABLE `invmgmnt`.`pandl`
CHANGE COLUMN `fromDate` `fromDate` DATE NULL DEFAULT NULL ,
CHANGE COLUMN `toDate` `toDate` DATE NULL DEFAULT NULL ;

ALTER TABLE `invmgmnt`.`pandlheads`
ADD COLUMN `parentHeadsId` bigint(20) NULL DEFAULT NULL AFTER `pandLCategory`;
ADD COLUMN `displaySeq` INT NULL AFTER `description`;

ALTER TABLE `invmgmnt`.`consumption`
CHANGE COLUMN `consumptionDate` `consumptionDate` DATE NULL DEFAULT NULL;

ALTER TABLE `invmgmnt`.`inward`
CHANGE COLUMN `inwardDate` `inwardDate` DATE NULL DEFAULT NULL;

ALTER TABLE `invmgmnt`.`pandlheads`
ADD COLUMN `isUserGenerated` CHAR(1) NULL DEFAULT 'Y' AFTER `displaySeq`;

---- Query implemented in th Q & Q AWS

ALTER TABLE `invmgmnt`.`supplier`
ADD COLUMN `gstNo` VARCHAR(100) NULL DEFAULT NULL AFTER `status`;

DROP TABLE IF EXISTS `invmgmnt`.`people`;

CREATE TABLE `invmgmnt`.`people` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `externalId` varchar(100) DEFAULT NULL,
  `parentType` varchar(5) DEFAULT NULL,
  `parentId` int(20) DEFAULT NULL,
  `category` varchar(5) DEFAULT NULL,
  `firstName` varchar(30) DEFAULT NULL,
  `lastName` varchar(30) DEFAULT NULL,
  `middleInitial` varchar(10) DEFAULT NULL,
  `otherInfo` varchar(300) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `invmgmnt`.`phone`;

CREATE TABLE `invmgmnt`.`phone` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(20) DEFAULT NULL,
  `parentEntity` varchar(20) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `phoneNo` varchar(50) DEFAULT NULL,
  `extension` varchar(50) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `invmgmnt`.`email`;

CREATE TABLE `invmgmnt`.`email` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(20) DEFAULT NULL,
  `parentEntity` varchar(20) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `emailId` varchar(100) DEFAULT NULL,
  `createdDt` datetime DEFAULT NULL,
  `modifiedDt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

ALTER TABLE `invmgmnt`.`people`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `otherInfo`,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL;

ALTER TABLE `invmgmnt`.`phone`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `extension`,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL after `createdDt`;

ALTER TABLE `invmgmnt`.`email`
ADD COLUMN  `createdBy` int(20) DEFAULT NULL after `emailId`,
ADD COLUMN   `modifiedBy` int(20) DEFAULT NULL after `createdDt`;
----- -- -
ALTER TABLE `invmgmnt`.`invproductdetails`
ADD COLUMN `cgst` VARCHAR(100) NULL DEFAULT NULL AFTER `jobType`,
ADD COLUMN `sgst` VARCHAR(100) NULL DEFAULT NULL AFTER `cgst`,
ADD COLUMN `igst` VARCHAR(100) NULL DEFAULT NULL AFTER `sgst`;

ALTER TABLE `invmgmnt`.`consumption`
CHANGE COLUMN `partId` `partId` INT(20) NULL ;

ALTER TABLE `invmgmnt`.`supplier`
ADD COLUMN `paymentTerm` VARCHAR(100) NULL DEFAULT NULL AFTER `gstNo`,
ADD COLUMN `splInstruction` VARCHAR(400) NULL DEFAULT NULL AFTER `paymentTerm`,
ADD COLUMN `note` VARCHAR(400) NULL DEFAULT NULL AFTER `splInstruction`,
ADD COLUMN `vendorCode` VARCHAR(100) NULL DEFAULT NULL AFTER `note`;

ALTER TABLE `invmgmnt`.`purchorder`
ADD COLUMN `quotationNumber` VARCHAR(100) NULL DEFAULT NULL AFTER `poStatus`,
ADD COLUMN `quotationDate` DATETIME NULL DEFAULT NULL AFTER `quotationNumber`;


ALTER TABLE `invmgmnt`.`invproductdetails`
ADD COLUMN `dailyRequirementQty` VARCHAR(100) NULL DEFAULT NULL AFTER `igst`;


---- Query implemented in th Q & Q AWS

ALTER TABLE `invmgmnt`.`polineitem`
CHANGE COLUMN `quantity` `quantity` DOUBLE NULL DEFAULT NULL ;

---- Query implemented in th Q & Q AWS

 ALTER TABLE `invmgmnt`.`pandl`
CHANGE COLUMN `remarks` `remarks` VARCHAR(450) NULL;


 ALTER TABLE `invmgmnt`.`pandlheads`
CHANGE COLUMN `description` `description` VARCHAR(450) NULL;
---- Query implemented in th Q & Q AWS   AND FT AWS on 09-03-2020

ALTER TABLE `invmgmnt`.`address`
ADD COLUMN `lineOne` VARCHAR(500) NULL AFTER `type`;

-- set sql_safe_updates = 0;
UPDATE `invmgmnt`.`address` SET `lineOne` = concat(`streetNo`, ' ', `streetName`);

ALTER TABLE `invmgmnt`.`address`
DROP COLUMN `streetNo`,
DROP COLUMN `streetName`;
---- Query implemented in th Q & Q AWS on 18th aprl 2020
-- Query implemented in th FT AWS
