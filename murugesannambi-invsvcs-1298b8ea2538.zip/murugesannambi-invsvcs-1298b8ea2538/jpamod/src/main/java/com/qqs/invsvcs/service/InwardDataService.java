package com.qqs.invsvcs.service;

import com.qqs.invsvcs.model.Inward;
import com.qqs.invsvcs.model.InwardLineItem;
import com.qqs.invsvcs.repository.InwardLineItemRepository;
import com.qqs.invsvcs.repository.InwardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import java.util.List;
import java.util.Optional;

@Component
public class InwardDataService {
    @Autowired
    private InwardRepository repository;

    @Autowired
    private InwardLineItemRepository inwardLineItemRepository;

    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<Inward> utils = new DataServiceUtils<>();


    public Optional<Inward> getInwardById(Integer id) {
        return repository.findById(id);
    }

    public Optional<List<Inward>> searchInward(List<SearchCriteria> params) {
        List<Inward> result = utils.createPredicate(entityManager, params, Inward.class);
        Optional<List<Inward>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public Iterable<Inward> getAllInward() {
        Iterable<Inward> result = repository.findAll();
        return result;
    }

    @Transactional
    public Inward saveInward(Inward item) {
        return repository.save(item);
    }

    public Optional<InwardLineItem> getInwardLineItemById(Integer id) {
        return inwardLineItemRepository.findById(id);
    }

    public Iterable<InwardLineItem> getAllInwardLineItemByInwardId(Integer inwardId) {
        Iterable<InwardLineItem> result = inwardLineItemRepository.findAllByInwardId(inwardId);
        return result;
    }

    @Transactional
    public InwardLineItem saveInwardLineItem(InwardLineItem item) {
        return inwardLineItemRepository.save(item);
    }

    @Transactional
    public Iterable<InwardLineItem> saveAllInwardLineItem(List<InwardLineItem> item) {
        return inwardLineItemRepository.saveAll(item);
    }
}
