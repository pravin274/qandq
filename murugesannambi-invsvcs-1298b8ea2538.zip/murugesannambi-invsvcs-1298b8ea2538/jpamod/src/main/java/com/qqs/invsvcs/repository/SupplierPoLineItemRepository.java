package com.qqs.invsvcs.repository;

import com.qqs.invsvcs.model.SupplierPoLineItem;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface SupplierPoLineItemRepository  extends CrudRepository<SupplierPoLineItem, Integer> {
    Optional<List<SupplierPoLineItem>> findByPoId(Integer poId);

    @Query(value = "SELECT ili.poLineItemId as poLineItemId, sum(quantity) as receivedQty " +
            " FROM `invmgmnt`.`inwardlineitem` ili " +
            " WHERE ili.poLineItemId in (?1)  AND ili.inwardId != ?2 " +
            " GROUP BY 1 ", nativeQuery = true)
    Optional<List<Object[]>> findReceivedQtyByPoLineItems(Iterable<Integer> poLineItemIds, Integer inwardId);

    @Query(value = "SELECT ili.poLineItemId as poLineItemId, sum(quantity) as receivedQty " +
            " FROM `invmgmnt`.`inwardlineitem` ili " +
            " WHERE ili.poLineItemId in (?1) " +
            " GROUP BY 1 ", nativeQuery = true)
    Optional<List<Object[]>> findReceivedQtyByPoLineItems(Iterable<Integer> poLineItemIds);

    @Query(value = "SELECT sum(quantity) as receivedQty FROM `invmgmnt`.`inwardlineitem` ili " +
            " WHERE ili.poLineItemId = ?1 GROUP BY 1 ", nativeQuery = true)
    Optional<Object> findReceivedQtyByPoLineItems(Integer poLineItemId);
}
