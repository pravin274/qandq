package com.qqs.invsvcs.service;

import com.qqs.invsvcs.model.PandL;
import com.qqs.invsvcs.model.PandLReportData;
import com.qqs.invsvcs.repository.PandLRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component

public class PandLDataService {
    @Autowired
    private PandLRepository repository;

    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<PandL> utils = new DataServiceUtils<>();


    public Optional<PandL> getPandLById(Integer id) {
        return repository.findById(id);
    }

    public Optional<List<PandL>> searchPandL(List<SearchCriteria> params) {
        List<PandL> result = utils.createPredicate(entityManager, params, PandL.class);
        Optional<List<PandL>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public Iterable<PandL> getAllPandL() {
        Iterable<PandL> result = repository.findAll();
        return result;
    }

    public List<PandLReportData> getPandLReport (String fromDate, String  toDate) {
        return repository.getPandLReport(fromDate, toDate);
    }

    public List<PandLReportData> getPandLHeadsData () {
        return repository.getPandLHeadsData ();
    }

    @Transactional
    public PandL savePandL(PandL item) {
        return repository.save(item);
    }
}
