package com.qqs.invsvcs.repository;

import com.qqs.invsvcs.model.Address;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface AddressRepository extends CrudRepository<Address, Integer> {

    //Parent entity types are available at ParentEntityType enum

    @Query(value = "select * from address where parentEntity = ?1 AND parentId = ?2", nativeQuery = true)
    Optional<List<Address>> findAddressesByParent(String parentType, Integer parentId);

    @Query(value = "select * from address where parentEntity = 'S' AND parentId = ?1", nativeQuery = true)
    Optional<List<Address>> findAddressesBySupplier(Integer supplierId);

    @Query(value = "select * from address where parentEntity = 'H' AND parentId = ?1", nativeQuery = true)
    Optional<List<Address>> findAddressesByPeople(Integer peopleId);


}
