package com.qqs.invsvcs.model;

import javax.persistence.*;
import javax.persistence.criteria.CriteriaBuilder;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "invproductdetails", schema = "invmgmnt", catalog = "")
public class InvProductDetails {
    private int id;
    private Integer productId;
    private String productType;
    private Double msl;
    private Double openingStock;
    private Double availableStock;
    private Double safetyStock;
    private String safetyStockUnit;
    private String jobType;
    private String cgst;
    private String sgst;
    private String igst;
    private String dailyRequirementQty;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "productId")
    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    @Column(name = "productType")
    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    @Column(name = "msl")
    public Double getMsl() {
        return msl;
    }

    public void setMsl(Double msl) {
        this.msl = msl;
    }

    @Column(name = "openingStock")
    public Double getOpeningStock() {
        return openingStock;
    }

    public void setOpeningStock(Double openingStock) {
        this.openingStock = openingStock;
    }

    @Column(name = "availableStock")
    public Double getAvailableStock() {
        return availableStock;
    }

    public void setAvailableStock(Double availableStock) {
        this.availableStock = availableStock;
    }

    @Column(name = "safetyStock")
    public Double getSafetyStock() {
        return safetyStock;
    }

    public void setSafetyStock(Double safetyStock) {
        this.safetyStock = safetyStock;
    }

    @Column(name = "safetyStockUnit")
    public String getSafetyStockUnit() {
        return safetyStockUnit;
    }

    public void setSafetyStockUnit(String safetyStockUnit) {
        this.safetyStockUnit = safetyStockUnit;
    }

    @Column(name = "jobType")
    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    @Column(name = "cgst")
    public String getCgst() {
        return cgst;
    }

    public void setCgst(String cgst) {
        this.cgst = cgst;
    }

    @Column(name = "sgst")
    public String getSgst() {
        return sgst;
    }

    public void setSgst(String sgst) {
        this.sgst = sgst;
    }

    @Column(name = "igst")
    public String getIgst() { return igst; }

    public void setIgst(String igst) {
        this.igst = igst;
    }

    @Column(name = "dailyRequirementQty")
    public String getDailyRequirementQty() {
        return dailyRequirementQty;
    }

    public void setDailyRequirementQty(String dailyRequirementQty) {
        this.dailyRequirementQty = dailyRequirementQty;
    }

    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InvProductDetails product = (InvProductDetails) o;
        return id == product.id &&
                productId == product.productId &&
                productType.equals(product.productType) &&
                msl.equals(product.msl) &&
                openingStock.equals(product.openingStock) &&
                availableStock.equals(product.availableStock) &&
                safetyStock.equals(product.safetyStock) &&
                safetyStockUnit.equals(product.safetyStockUnit) &&
                jobType.equals(product.jobType) &&
                cgst.equals(product.cgst) &&
                sgst.equals(product.sgst) &&
                igst.equals(product.igst) &&
                dailyRequirementQty.equals(product.dailyRequirementQty) &&
                createdBy.equals(product.createdBy) &&
                createdDt.equals(product.createdDt) &&
                modifiedBy.equals(product.modifiedBy) &&
                modifiedDt.equals(product.modifiedDt);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, productId, productType, msl, openingStock, availableStock,
                safetyStock, safetyStockUnit, jobType, cgst, sgst, igst, dailyRequirementQty, createdBy, createdDt, modifiedBy, modifiedDt);
    }
}
