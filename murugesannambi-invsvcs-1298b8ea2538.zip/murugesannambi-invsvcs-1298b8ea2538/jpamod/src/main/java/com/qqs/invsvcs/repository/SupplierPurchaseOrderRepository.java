package com.qqs.invsvcs.repository;

import com.qqs.invsvcs.model.SupplierPurchaseOrder;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface SupplierPurchaseOrderRepository extends CrudRepository<SupplierPurchaseOrder, Integer> {
    @Query(value = "SELECT ifnull(sum(pol.quantity),0) AS quantity " +
            " FROM `invmgmnt`.`polineitem` pol,  `invmgmnt`.`purchorder` po, `invmgmnt`.`supplierxproduct` sxp  " +
            " where pol.poId = po.id AND pol.supplierXProductId = sxp.id " +
            " AND po.poStatus IN  ('NEW') AND pol.itemStatus != 'RECEIVED' AND sxp.productId = ?1 AND sxp.productType = ?2", nativeQuery = true)
    Optional<Object> getOpenPurchaseOrder(Integer productId, String productType);

    @Query(value = "SELECT Max(poNumber) AS maxPO FROM `invmgmnt`.`purchorder` po ", nativeQuery = true)
    Optional<String> getMaxPONumber();


}
