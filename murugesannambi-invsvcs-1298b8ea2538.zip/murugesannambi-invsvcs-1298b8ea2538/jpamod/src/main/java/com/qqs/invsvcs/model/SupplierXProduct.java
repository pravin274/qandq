package com.qqs.invsvcs.model;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "supplierxproduct", schema = "invmgmnt", catalog = "")
public class SupplierXProduct {
    private int id;
    private Integer productId;
    private Integer supplierId;
    private Integer brandId;
    private Double cost;
    private Double mbq;
    private Integer leadTimeInDays;
    private Timestamp effectiveFrom;
    private Timestamp effectiveTo;
    private String ispreferred;
    private String productType;
    private Integer prefpercent;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "productId")
    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    @Column(name = "supplierId")
    public Integer getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(Integer supplierId) {
        this.supplierId = supplierId;
    }

    @Column(name = "brandId")
    public Integer getBrandId() {
        return brandId;
    }

    public void setBrandId(Integer brandId) {
        this.brandId = brandId;
    }

    @Column(name = "cost")
    public Double getCost() {
        return cost;
    }

    public void setCost(Double cost) {
        this.cost = cost;
    }

    @Column(name = "mbq")
    public Double getMbq() {
        return mbq;
    }

    public void setMbq(Double mbq) {
        this.mbq = mbq;
    }

    @Column(name = "leadTimeInDays")
    public Integer getLeadTimeInDays() {
        return leadTimeInDays;
    }

    public void setLeadTimeInDays(Integer leadTimeInDays) {
        this.leadTimeInDays = leadTimeInDays;
    }

    @Column(name = "effectiveFrom")
    public Timestamp getEffectiveFrom() {
        return effectiveFrom;
    }

    public void setEffectiveFrom(Timestamp effectiveFrom) {
        this.effectiveFrom = effectiveFrom;
    }

    @Column(name = "effectiveTo")
    public Timestamp getEffectiveTo() {
        return effectiveTo;
    }

    public void setEffectiveTo(Timestamp effectiveTo) {
        this.effectiveTo = effectiveTo;
    }

    @Column(name = "ispreferred")
    public String getIspreferred() {
        return ispreferred;
    }

    public void setIspreferred(String ispreferred) {
        this.ispreferred = ispreferred;
    }

    @Column(name = "productType")
    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    @Column(name = "prefpercent")
    public Integer getPrefpercent() {
        return prefpercent;
    }

    public void setPrefpercent(Integer prefpercent) {
        this.prefpercent = prefpercent;
    }

    @Column(name = "createdBy")
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "createdDt")
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }



    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SupplierXProduct)) return false;
        SupplierXProduct that = (SupplierXProduct) o;
        return getId() == that.getId() &&
                getProductId().equals(that.getProductId()) &&
                getSupplierId().equals(that.getSupplierId()) &&
                getBrandId().equals(that.getBrandId()) &&
                getCost().equals(that.getCost()) &&
                getMbq().equals(that.getMbq()) &&
                getLeadTimeInDays().equals(that.getLeadTimeInDays()) &&
                getEffectiveFrom().equals(that.getEffectiveFrom()) &&
                getEffectiveTo().equals(that.getEffectiveTo()) &&
                getCreatedBy().equals(that.getCreatedBy()) &&
                getCreatedDt().equals(that.getCreatedDt()) &&
                getModifiedBy().equals(that.getModifiedBy()) &&
                getModifiedDt().equals(that.getModifiedDt());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getProductId(), getSupplierId(), getBrandId(), getCost(), getMbq(), getLeadTimeInDays(), getEffectiveFrom(), getEffectiveTo(), getCreatedBy(), getCreatedDt(), getModifiedBy(), getModifiedDt());
    }
}
