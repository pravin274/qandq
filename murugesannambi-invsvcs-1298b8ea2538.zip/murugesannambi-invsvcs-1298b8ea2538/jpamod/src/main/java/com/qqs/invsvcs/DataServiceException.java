package com.qqs.invsvcs;

public class DataServiceException extends Exception {
    public DataServiceException(String msg) {
        super(msg);
    }
}
