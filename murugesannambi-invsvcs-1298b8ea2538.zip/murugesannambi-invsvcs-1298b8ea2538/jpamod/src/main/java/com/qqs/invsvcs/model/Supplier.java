package com.qqs.invsvcs.model;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;


@Entity
@Table(name = "supplier", schema = "invmgmnt", catalog = "")
public class Supplier {
    private int id;
    private String name;
    private Boolean status;
    private String gstNo;
    private String paymentTerm;
    private String splInstruction;
    private String note;
    private String vendorCode;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "name")
    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    @Column(name = "status")
    public Boolean getStatus() { return status; }

    public void setStatus(Boolean status) { this.status = status; }

    @Column(name = "gstNo")
    public String getGstNo() {
        return gstNo;
    }

    public void setGstNo(String gstNo) {
        this.gstNo = gstNo;
    }

    @Column(name = "paymentTerm")
    public String getPaymentTerm() {
        return paymentTerm;
    }

    public void setPaymentTerm(String paymentTerm) {
        this.paymentTerm = paymentTerm;
    }


    @Column(name = "splInstruction")
    public String getSplInstruction() {
        return splInstruction;
    }

    public void setSplInstruction(String splInstruction) {
        this.splInstruction = splInstruction;
    }

    @Column(name = "note")
    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }


    @Column(name = "vendorCode")
    public String getVendorCode() {
        return vendorCode;
    }

    public void setVendorCode(String vendorCode) {
        this.vendorCode = vendorCode;
    }


    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Supplier supplier = (Supplier) o;

        if (id != supplier.id) return false;
        if (!Objects.equals(name, supplier.name)) return false;
        if (!Objects.equals(status, supplier.status)) return false;
        if (!Objects.equals(gstNo, supplier.gstNo)) return false;
        if (!Objects.equals(paymentTerm, supplier.paymentTerm)) return false;
        if (!Objects.equals(splInstruction, supplier.splInstruction)) return false;
        if (!Objects.equals(note, supplier.note)) return false;
        if (!Objects.equals(vendorCode, supplier.vendorCode)) return false;
        if (!Objects.equals(createdBy, supplier.createdBy)) return false;
        if (!Objects.equals(createdDt, supplier.createdDt)) return false;
        if (!Objects.equals(modifiedBy, supplier.modifiedBy)) return false;
        if (!Objects.equals(modifiedDt, supplier.modifiedDt)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (gstNo != null ? gstNo.hashCode() : 0);
        result = 31 * result + (paymentTerm != null ? paymentTerm.hashCode() : 0);
        result = 31 * result + (splInstruction != null ? splInstruction.hashCode() : 0);
        result = 31 * result + (note != null ? note.hashCode() : 0);
        result = 31 * result + (vendorCode != null ? vendorCode.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDt != null ? createdDt.hashCode() : 0);
        result = 31 * result + (modifiedBy != null ? modifiedBy.hashCode() : 0);
        result = 31 * result + (modifiedDt != null ? modifiedDt.hashCode() : 0);
        return result;
    }
}
