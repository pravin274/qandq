package com.qqs.invsvcs.service;

import com.qqs.invsvcs.model.People;
import com.qqs.invsvcs.repository.PeopleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Component
public class PeopleDataService {
    @Autowired
    private PeopleRepository repository;

    public Optional<People> findPeopleById(Integer id) {
        return repository.findById(id);
    }

    public Optional<List<People>> findPeopleForCategory(String parentType, Integer parentId, String category) {
        return repository.findPeopleForCategory(parentType, parentId, category);
    }

    public Optional<List<People>> findPeopleForParentType(String parentType, Integer parentId) {
        return repository.findPeopleForParentType(parentType, parentId);
    }

    public Iterable<People> findAllPeopleById(List<Integer> ids) {
        return repository.findAllById(ids);
    }

    @Transactional
    public People savePeople(People item) {
        return repository.save(item);
    }
}
