package com.qqs.invsvcs.service;

import com.qqs.invsvcs.model.SupplierPurchaseOrder;
import com.qqs.invsvcs.repository.SupplierPoLineItemRepository;
import com.qqs.invsvcs.repository.SupplierPurchaseOrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Component
public class SupplierPurchaseOrderDataService {
    @Autowired
    private SupplierPurchaseOrderRepository repository;

    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<SupplierPurchaseOrder> utils = new DataServiceUtils<>();


    public Optional<SupplierPurchaseOrder> getSupplierPurchaseOrderById(Integer id) {
        return repository.findById(id);
    }

    public Optional<List<SupplierPurchaseOrder>> searchSupplierPurchaseOrder(List<SearchCriteria> params) {
        List<SupplierPurchaseOrder> result = utils.createPredicate(entityManager, params, SupplierPurchaseOrder.class);
        Optional<List<SupplierPurchaseOrder>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public Iterable<SupplierPurchaseOrder> getAllSupplierPurchaseOrder() {
        Iterable<SupplierPurchaseOrder> result = repository.findAll();
        return result;
    }

    public Optional<Object> getOpenPurchaseOrder(Integer productId, String productType) {
        return repository.getOpenPurchaseOrder(productId, productType);
    }

    public Optional<String> getMaxPONumber() {
        return repository.getMaxPONumber();
    }

    @Transactional
    public SupplierPurchaseOrder saveSupplierPurchaseOrder(SupplierPurchaseOrder item) {
        return repository.save(item);
    }
}
