package com.qqs.invsvcs.service;

import com.qqs.invsvcs.model.SupplierPoLineItem;
import com.qqs.invsvcs.repository.SupplierPoLineItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Component
public class SupplierPoLineItemDataService {
    @Autowired
    private SupplierPoLineItemRepository repository;

    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<SupplierPoLineItem> utils = new DataServiceUtils<>();


    public Optional<SupplierPoLineItem> getSupplierPoLineItemById(Integer id) {
        return repository.findById(id);
    }

    public Optional<List<SupplierPoLineItem>> searchSupplierPoLineItem(List<SearchCriteria> params) {
        List<SupplierPoLineItem> result = utils.createPredicate(entityManager, params, SupplierPoLineItem.class);
        Optional<List<SupplierPoLineItem>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public Iterable<SupplierPoLineItem> getAllSupplierPoLineItem() {
        Iterable<SupplierPoLineItem> result = repository.findAll();
        return result;
    }

    public Optional<List<SupplierPoLineItem>> getAllSupplierPoLineItemByPoId(Integer poId) {
        Optional<List<SupplierPoLineItem>> result = repository.findByPoId(poId);
        return result;
    }

    public Iterable<SupplierPoLineItem> getAllSupplierPoLineItemByPoId(List<Integer> poLineItemIds) {
        Iterable<SupplierPoLineItem> result = repository.findAllById(poLineItemIds);
        return result;
    }

    public Optional<List<Object[]>> getReceivedQtyByPOLineItems(Iterable<Integer> poLineItemIds, Integer inwardId) {
        return repository.findReceivedQtyByPoLineItems(poLineItemIds, inwardId);
    }

    public Optional<List<Object[]>> getReceivedQtyByPOLineItems(Iterable<Integer> poLineItemIds) {
        return repository.findReceivedQtyByPoLineItems(poLineItemIds);
    }

    @Transactional
    public SupplierPoLineItem saveSupplierPoLineItem(SupplierPoLineItem item) {
        return repository.save(item);
    }

    @Transactional
    public Iterable<SupplierPoLineItem> saveAllSupplierPoLineItem(List<SupplierPoLineItem> item) {
        return repository.saveAll(item);
    }
}
