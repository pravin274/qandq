package com.qqs.invsvcs.repository;

import com.qqs.invsvcs.model.InvProductDetails;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface InvProductDetailsRepository extends CrudRepository<InvProductDetails, Integer> {

    Optional<InvProductDetails> findByProductIdAndProductType(Integer productId, String productType);

    @Query(value = "SELECT ipd.* " +
            " FROM `invmgmnt`.`invproductdetails` ipd,  `invmgmnt`.`polineitem` pli, `invmgmnt`.`supplierxproduct` sxp  " +
            " WHERE sxp.productId = ipd.productId AND sxp.productType = ipd.productType AND sxp.id = pli.supplierXProductId AND pli.id = ?1", nativeQuery = true)
    Optional<InvProductDetails> findByInwardLineItemId(Integer inwardLineItemId);

    @Query(value = "SELECT ipd.* " +
            " FROM `invmgmnt`.`invproductdetails` ipd  " +
            " WHERE concat_ws('-', productType, productId) in (?1) ", nativeQuery = true)
    Iterable<InvProductDetails> findByProductIdAndProductType (List<String> productTypeAndIdConcat);

}

