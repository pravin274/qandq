package com.qqs.invsvcs.repository;

import com.qqs.invsvcs.model.Email;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface EmailRepository extends CrudRepository<Email, Integer> {

    //Parent entity types are available at ParentEntityType enum

    @Query(value = "select * from email where parentEntity = ?1 AND parentId = ?2", nativeQuery = true)
    Optional<List<Email>> findEmailByParent(String parentType, Integer parentId);

    @Query(value = "select * from email where parentEntity = 'C' AND parentId = ?1", nativeQuery = true)
    Optional<List<Email>> findEmailByCompany(Integer companyId);

    @Query(value = "select * from email where parentEntity = 'H' AND parentId = ?1", nativeQuery = true)
    Optional<List<Email>> findEmailByPeople(Integer peopleId);

    Optional<List<Email>> findAllByParentIdInAndParentEntity(List<Integer> parentIds, String parentEntity);
}
