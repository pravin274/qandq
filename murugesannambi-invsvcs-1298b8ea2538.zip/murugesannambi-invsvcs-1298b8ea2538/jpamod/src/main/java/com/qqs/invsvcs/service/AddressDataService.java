package com.qqs.invsvcs.service;

import com.qqs.invsvcs.model.Address;
import com.qqs.invsvcs.repository.AddressRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Component
public class AddressDataService {
    @Autowired
    private AddressRepository repository;

    public Optional<Address> getAddressById(Integer id) {
        return repository.findById(id);
    }

    public Iterable<Address> findAddressByIds(List<Integer> ids) {
        return repository.findAllById(ids);
    }

    public Optional<List<Address>> findAddressesBySupplier(Integer supplierId) {
        return repository.findAddressesBySupplier(supplierId);
    }

    public Optional<List<Address>> findAddressesByPeople(Integer peopleId) {
        return repository.findAddressesByPeople(peopleId);
    }

    public Optional<List<Address>> findAddressesForParentType(String parentType, Integer parentId) {
        return repository.findAddressesByParent(parentType, parentId);
    }

    @Transactional
    public Address saveAddress(Address item) {
        return repository.save(item);
    }

}
