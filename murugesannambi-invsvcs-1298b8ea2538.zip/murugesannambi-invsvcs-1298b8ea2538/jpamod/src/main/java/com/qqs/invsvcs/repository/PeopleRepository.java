package com.qqs.invsvcs.repository;

import com.qqs.invsvcs.model.People;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface PeopleRepository extends CrudRepository<People, Integer> {
    @Query(value = "select * FROM people WHERE parentType = ?1 AND parentId = ?2 AND category = ?3", nativeQuery = true)
    Optional<List<People>> findPeopleForCategory(String parentType, Integer parentId, String category);

    @Query(value = "select * FROM people WHERE parentType = ?1 AND parentId = ?2", nativeQuery = true)
    Optional<List<People>> findPeopleForParentType(String parentType, Integer parentId);
}
