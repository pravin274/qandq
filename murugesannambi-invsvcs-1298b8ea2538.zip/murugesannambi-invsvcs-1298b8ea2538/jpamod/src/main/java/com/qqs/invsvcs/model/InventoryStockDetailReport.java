package com.qqs.invsvcs.model;

public interface InventoryStockDetailReport {

    Integer getInwardQty();

    Integer getOpeningStock();

    Integer getTotalConsumption();

    String getProductType();

    Integer getProductId();

    String getProductName();


}
