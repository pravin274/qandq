package com.qqs.invsvcs.service;

import com.qqs.invsvcs.model.InvProductDetails;
import com.qqs.invsvcs.repository.InvProductDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import java.util.List;
import java.util.Optional;

@Component
public class InvProductDetailsDataService {

    @Autowired
    private InvProductDetailsRepository repository;

    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<InvProductDetails> utils = new DataServiceUtils<>();


    public Optional<InvProductDetails> getInvProductDetailsById(Integer id) {
        return repository.findById(id);
    }

    public Optional<InvProductDetails> getInvPDByProductIdAndProductType(Integer productId, String productType) {
        return repository.findByProductIdAndProductType(productId, productType);
    }

    public Iterable<InvProductDetails> getInvPDByProductIdAndProductType(List<String> productTypeAndIdConcat) {
        return repository.findByProductIdAndProductType(productTypeAndIdConcat);
    }

    public Optional<InvProductDetails> getInvPDByInwardLineItemId(Integer inwardLineItemId) {
        return repository.findByInwardLineItemId(inwardLineItemId);
    }

    @Transactional
    public InvProductDetails saveInvProductDetails(InvProductDetails item) {
        return repository.save(item);
    }
}
