package com.qqs.invsvcs.model;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "invrequirements", schema = "invmgmnt", catalog = "")
public class InvRequirements {
    private int id;
    private Integer productId;
    private String productType;
    private Timestamp reqFrom;
    private Timestamp reqTo;
    private Double reqQuantity;
    private Double unUsedQuantity;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "productId")
    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    @Column(name = "productType")
    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    @Column(name = "reqFrom")
    public Timestamp getReqFrom() {
        return reqFrom;
    }

    public void setReqFrom(Timestamp reqFrom) {
        this.reqFrom = reqFrom;
    }

    @Column(name = "reqTo")
    public Timestamp getReqTo() {
        return reqTo;
    }

    public void setReqTo(Timestamp reqTo) {
        this.reqTo = reqTo;
    }

    @Column(name = "reqQuantity")
    public Double getReqQuantity() {
        return reqQuantity;
    }

    public void setReqQuantity(Double reqQuantity) {
        this.reqQuantity = reqQuantity;
    }

    @Column(name = "unUsedQuantity")
    public Double getUnUsedQuantity() {
        return unUsedQuantity;
    }

    public void setUnUsedQuantity(Double unUsedQuantity) {
        this.unUsedQuantity = unUsedQuantity;
    }

    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InvRequirements product = (InvRequirements) o;
        return id == product.id &&
                productId == product.productId &&
                productType.equals(product.productType) &&
                reqFrom.equals(product.reqFrom) &&
                reqTo.equals(product.reqTo) &&
                reqQuantity.equals(product.reqQuantity) &&
                unUsedQuantity.equals(product.unUsedQuantity) &&
                createdBy.equals(product.createdBy) &&
                createdDt.equals(product.createdDt) &&
                modifiedBy.equals(product.modifiedBy) &&
                modifiedDt.equals(product.modifiedDt);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, productId, productType, reqFrom, reqTo, reqQuantity,
                unUsedQuantity, createdBy, createdDt, modifiedBy, modifiedDt);
    }
}
