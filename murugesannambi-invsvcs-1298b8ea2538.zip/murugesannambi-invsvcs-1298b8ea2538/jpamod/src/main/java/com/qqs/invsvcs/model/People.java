package com.qqs.invsvcs.model;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "people", schema = "invmgmnt", catalog = "")
public class People {
    private int id;
    private String externalId;
    private String parentType;
    private Integer parentId;
    private String category;
    private String firstName;
    private String lastName;
    private String middleInitial;
    private String otherInfo;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "externalId")
    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    @Basic
    @Column(name = "parentType")
    public String getParentType() {
        return parentType;
    }

    public void setParentType(String parentType) {
        this.parentType = parentType;
    }

    @Basic
    @Column(name = "parentId")
    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    @Basic
    @Column(name = "category")
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    @Basic
    @Column(name = "firstName")
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @Basic
    @Column(name = "lastName")
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Basic
    @Column(name = "middleInitial")
    public String getMiddleInitial() {
        return middleInitial;
    }

    public void setMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
    }

    @Basic
    @Column(name = "otherInfo")
    public String getOtherInfo() {
        return otherInfo;
    }

    public void setOtherInfo(String otherInfo) {
        this.otherInfo = otherInfo;
    }

    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        People people = (People) o;

        if (id != people.id) return false;
        if (externalId != null ? !externalId.equals(people.externalId) : people.externalId != null) return false;
        if (parentType != null ? !parentType.equals(people.parentType) : people.parentType != null) return false;
        if (parentId != null ? !parentId.equals(people.parentId) : people.parentId != null) return false;
        if (category != null ? !category.equals(people.category) : people.category != null) return false;
        if (firstName != null ? !firstName.equals(people.firstName) : people.firstName != null) return false;
        if (lastName != null ? !lastName.equals(people.lastName) : people.lastName != null) return false;
        if (middleInitial != null ? !middleInitial.equals(people.middleInitial) : people.middleInitial != null)
            return false;
        if (otherInfo != null ? !otherInfo.equals(people.otherInfo) : people.otherInfo != null) return false;
        if (createdBy != null ? !createdBy.equals(people.createdBy) : people.createdBy != null) return false;
        if (createdDt != null ? !createdDt.equals(people.createdDt) : people.createdDt != null) return false;
        if (modifiedBy != null ? !modifiedBy.equals(people.modifiedBy) : people.modifiedBy != null) return false;
        if (modifiedDt != null ? !modifiedDt.equals(people.modifiedDt) : people.modifiedDt != null) return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (externalId != null ? externalId.hashCode() : 0);
        result = 31 * result + (parentType != null ? parentType.hashCode() : 0);
        result = 31 * result + (parentId != null ? parentId.hashCode() : 0);
        result = 31 * result + (category != null ? category.hashCode() : 0);
        result = 31 * result + (firstName != null ? firstName.hashCode() : 0);
        result = 31 * result + (lastName != null ? lastName.hashCode() : 0);
        result = 31 * result + (middleInitial != null ? middleInitial.hashCode() : 0);
        result = 31 * result + (otherInfo != null ? otherInfo.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDt != null ? createdDt.hashCode() : 0);
        result = 31 * result + (modifiedBy != null ? modifiedBy.hashCode() : 0);
        result = 31 * result + (modifiedDt != null ? modifiedDt.hashCode() : 0);
        return result;
    }
}
