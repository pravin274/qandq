package com.qqs.invsvcs;

public class NotImplementedException extends Exception {
}
