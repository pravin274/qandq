package com.qqs.invsvcs.service;

import com.qqs.invsvcs.model.InvRequirements;
import com.qqs.invsvcs.repository.InvRequirementsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Component
public class InvRequirementsDataService {

    @Autowired
    private InvRequirementsRepository repository;

    private DataServiceUtils<InvRequirements> utils = new DataServiceUtils<>();


    public Optional<InvRequirements> getInvRequirementsById(Integer id) {
        return repository.findById(id);
    }

    public Iterable<InvRequirements> getAllInvRequirementsByReqDate(Timestamp reqDate) {
        Iterable<InvRequirements> result = repository.findAllByReqFrom(reqDate);
        return result;
    }

    public Iterable<InvRequirements> getInvReqByProductIdAndType(List<String> productTypeAndIdConcat, Timestamp reqFromDate) {
        return repository.findByProductIdAndProductType(productTypeAndIdConcat, reqFromDate);
    }

    public Optional<InvRequirements> getCurrInvReqByProductIdAndType(Integer productId, String productType) {
        return repository.findCurrByProductIdAndProductType(productId, productType);
    }

    @Transactional
    public InvRequirements saveInvRequirements(InvRequirements item) {
        return repository.save(item);
    }

    @Transactional
    public Iterable<InvRequirements> saveInvRequirements(List<InvRequirements> items) {
        return repository.saveAll(items);
    }

    @Transactional
    public void deleteInvRequirements(Iterable<InvRequirements> invRequirements) {
        repository.deleteAll(invRequirements);
    }


}
