package com.qqs.invsvcs.repository;

import com.qqs.invsvcs.model.Inward;
import org.springframework.data.repository.CrudRepository;

public interface InwardRepository extends CrudRepository<Inward, Integer> {
}
