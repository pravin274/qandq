package com.qqs.invsvcs.repository;

import com.qqs.invsvcs.model.Phone;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface PhoneRepository extends CrudRepository<Phone, Integer> {
    @Query(value = "select * from phone where parentEntity = ?1 AND parentId = ?2", nativeQuery = true)
    Optional<List<Phone>> findPhoneByParent(String parentType, Integer parentId);

    @Query(value = "select * from phone where parentEntity = 'C' AND parentId = ?1", nativeQuery = true)
    Optional<List<Phone>> findPhoneByCompany(Integer companyId);


    @Query(value = "select * from phone where parentEntity = 'C' AND parentId = ?1", nativeQuery = true)
    Optional<List<Phone>> findPhoneByPeople(Integer peopleId);

    Optional<List<Phone>> findAllByParentIdInAndParentEntity(List<Integer> parentIds, String parentEntity);
}
