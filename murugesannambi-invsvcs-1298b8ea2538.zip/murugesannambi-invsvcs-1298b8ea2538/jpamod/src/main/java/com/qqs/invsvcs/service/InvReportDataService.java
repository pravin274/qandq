package com.qqs.invsvcs.service;

import com.qqs.invsvcs.model.InventoryStockDetailReport;
import com.qqs.invsvcs.model.StockStatusDetails;
import com.qqs.invsvcs.repository.InvRequirementsRepository;
import com.qqs.invsvcs.repository.InventoryStockDetailReportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;


@Component
public class InvReportDataService {

    @Autowired
    private InventoryStockDetailReportRepository repository;

    private DataServiceUtils<InventoryStockDetailReport> utils = new DataServiceUtils<>();

    public List<InventoryStockDetailReport> getInventoryStockDetailReport(String fromDate, String toDate) {
        return repository.getInventoryStockDetailReport(fromDate, toDate);
    }

    public List<StockStatusDetails> getStockStatusDetail(String fromDate, String toDate) {
        return repository.getStockStatusDetail(fromDate, toDate);
    }

}
