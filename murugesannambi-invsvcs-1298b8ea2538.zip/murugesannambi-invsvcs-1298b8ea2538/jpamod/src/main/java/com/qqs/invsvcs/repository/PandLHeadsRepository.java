package com.qqs.invsvcs.repository;

import com.qqs.invsvcs.model.PandLHeads;
import org.springframework.data.repository.CrudRepository;

public interface PandLHeadsRepository extends CrudRepository<PandLHeads, Integer> {
}
