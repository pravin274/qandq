package com.qqs.invsvcs.model;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "inwardlineitem", schema = "invmgmnt", catalog = "")
public class InwardLineItem {
    private int id;
    private Integer inwardId;
    private Integer poLineItemId;
    private Double quantity;
    private String status;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "inwardId")
    public Integer getInwardId() { return inwardId; }

    public void setInwardId(Integer inwardId) {
        this.inwardId = inwardId;
    }

    @Column(name = "poLineItemId")
    public Integer getPoLineItemId() { return poLineItemId; }

    public void setPoLineItemId (Integer poLineItemId) {
        this.poLineItemId = poLineItemId;
    }

    @Column(name = "quantity")
    public Double getQuantity() { return quantity; }

    public void setQuantity (Double quantity) {
        this.quantity = quantity;
    }

    @Column(name = "status")
    public String getStatus() { return status; }

    public void setStatus(String status) {
        this.status = status;
    }

    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof InwardLineItem)) return false;
        InwardLineItem inward = (InwardLineItem) o;
        return id == inward.id &&
                Objects.equals(poLineItemId, inward.poLineItemId) &&
                Objects.equals(inwardId, inward.inwardId) &&
                Objects.equals(status, inward.status) &&
                Objects.equals(quantity, inward.quantity) &&
                Objects.equals(createdBy, inward.createdBy) &&
                Objects.equals(createdDt, inward.createdDt) &&
                Objects.equals(modifiedBy, inward.modifiedBy) &&
                Objects.equals(modifiedDt, inward.modifiedDt);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, status, inwardId, poLineItemId, quantity, createdBy, createdDt, modifiedBy, modifiedDt);
    }
}
