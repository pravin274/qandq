package com.qqs.invsvcs.model;


import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "inward", schema = "invmgmnt", catalog = "")
public class Inward {
    private int id;
    private Integer poId;
    private Date inwardDate;
    private String dcNumber;
    private Integer receivedBy;
    private String remarks;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "poId")
    public Integer getPoId() {
        return poId;
    }

    public void setPoId(Integer poId) {
        this.poId = poId;
    }

    @Column(name = "inwardDate")
    public Date getInwardDate() { return inwardDate; }

    public void setInwardDate(Date inwardDate) {
        this.inwardDate = inwardDate;
    }

    @Column(name = "receivedBy")
    public Integer getReceivedBy() { return receivedBy; }

    public void setReceivedBy(Integer receivedBy) {
        this.receivedBy = receivedBy;
    }

    @Column(name = "remarks")
    public String getRemarks() { return remarks; }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Column(name = "dcNumber")
    public String getDcNumber() { return dcNumber; }

    public void setDcNumber(String dcNumber) {
        this.dcNumber = dcNumber;
    }

    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Inward)) return false;
        Inward inward = (Inward) o;
        return getId() == inward.getId() &&
                Objects.equals(getPoId(), inward.getPoId()) &&
                Objects.equals(getInwardDate(), inward.getInwardDate()) &&
                Objects.equals(getDcNumber(), inward.getDcNumber()) &&
                Objects.equals(getReceivedBy(), inward.getReceivedBy()) &&
                Objects.equals(getRemarks(), inward.getRemarks()) &&
                Objects.equals(getCreatedBy(), inward.getCreatedBy()) &&
                Objects.equals(getCreatedDt(), inward.getCreatedDt()) &&
                Objects.equals(getModifiedBy(), inward.getModifiedBy()) &&
                Objects.equals(getModifiedDt(), inward.getModifiedDt());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getPoId(), getInwardDate(), getDcNumber(), getReceivedBy(), getRemarks(), getCreatedBy(), getCreatedDt(), getModifiedBy(), getModifiedDt());
    }
}
