package com.qqs.invsvcs.repository;

import com.qqs.invsvcs.model.InwardLineItem;
import org.springframework.data.repository.CrudRepository;

public interface InwardLineItemRepository extends CrudRepository<InwardLineItem, Integer> {
    Iterable<InwardLineItem> findAllByInwardId(Integer inwardId);
}
