package com.qqs.invsvcs.model;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "polineitem", schema = "invmgmnt", catalog = "")
public class SupplierPoLineItem {
    private int id;
    private Integer poId;
    private Integer supplierXProductId;
    private Double quantity;
    private Double cost;
    private String item;
    private String itemStatus;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "poId")
    public Integer getPoId() {
        return poId;
    }

    public void setPoId(Integer poId) {
        this.poId = poId;
    }

    @Column(name = "supplierXProductId")
    public Integer getSupplierXProductId() {
        return supplierXProductId;
    }

    public void setSupplierXProductId(Integer supplierXProductId) {
        this.supplierXProductId = supplierXProductId;
    }

    @Column(name = "quantity")
    public Double getQuantity() {
        return quantity;
    }

    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    @Column(name = "item")
    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    @Column(name = "itemStatus")
    public String getItemStatus() {
        return itemStatus;
    }

    public void setItemStatus(String itemStatus) {
        this.itemStatus = itemStatus;
    }

    @Column(name = "cost")
    public Double getCost() {
        return cost;
    }

    public void setCost(Double cost) {
        this.cost = cost;
    }

    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SupplierPoLineItem)) return false;
        SupplierPoLineItem that = (SupplierPoLineItem) o;
        return getId() == that.getId() &&
                Objects.equals(getPoId(), that.getPoId()) &&
                Objects.equals(getSupplierXProductId(), that.getSupplierXProductId()) &&
                Objects.equals(getQuantity(), that.getQuantity()) &&
                Objects.equals(getCost(), that.getCost()) &&
                Objects.equals(getCreatedBy(), that.getCreatedBy()) &&
                Objects.equals(getCreatedDt(), that.getCreatedDt()) &&
                Objects.equals(getModifiedBy(), that.getModifiedBy()) &&
                Objects.equals(getModifiedDt(), that.getModifiedDt());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getPoId(), getSupplierXProductId(), getQuantity(), getCost(), getCreatedBy(), getCreatedDt(), getModifiedBy(), getModifiedDt());
    }

}
