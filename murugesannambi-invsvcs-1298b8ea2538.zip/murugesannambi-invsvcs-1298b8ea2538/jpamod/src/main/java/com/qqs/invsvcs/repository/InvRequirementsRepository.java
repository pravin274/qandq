package com.qqs.invsvcs.repository;

import com.qqs.invsvcs.model.InvRequirements;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

public interface InvRequirementsRepository extends CrudRepository<InvRequirements, Integer> {
    Iterable<InvRequirements> findAllByReqFrom(Timestamp reqFrom);

    @Query(value = "SELECT ivr.* " +
            " FROM `invmgmnt`.`invrequirements` ivr  " +
            " WHERE concat_ws('-', productType, productId) in (?1) AND CURDATE() between reqFrom and reqTo AND reqTo < ?2", nativeQuery = true)
    Iterable<InvRequirements> findByProductIdAndProductType (List<String> productTypeAndIdConcat, Timestamp reqFromDate);

    @Query(value = "SELECT ivr.* " +
            " FROM `invmgmnt`.`invrequirements` ivr  " +
            " WHERE productType = ?2 AND productId = ?1 AND CURDATE() between reqFrom and reqTo ", nativeQuery = true)
    Optional<InvRequirements> findCurrByProductIdAndProductType (Integer productId, String productType);
}

