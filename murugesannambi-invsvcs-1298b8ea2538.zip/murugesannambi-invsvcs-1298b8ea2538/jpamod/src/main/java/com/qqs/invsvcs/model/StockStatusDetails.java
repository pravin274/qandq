package com.qqs.invsvcs.model;

public interface StockStatusDetails {

    Integer getProductId();
    String getProductType();
    String getProductName();
    Integer getProcessOrder();
    Integer getStockQty();

}
