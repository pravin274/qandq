package com.qqs.invsvcs.repository;

import com.qqs.invsvcs.model.Consumption;
import org.springframework.data.repository.CrudRepository;

public interface ConsumptionRepository extends CrudRepository<Consumption, Integer> {
}
