package com.qqs.invsvcs.repository;

import com.qqs.invsvcs.model.ProductCategory;
import org.springframework.data.repository.CrudRepository;

public interface ProductCategoryRepository extends CrudRepository<ProductCategory, Integer> {
    
}
