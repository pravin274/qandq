package com.qqs.invsvcs.model;


public interface User {
    int getId();
    String getFirstName();
    String getLastName();
    String getUserName();
}
