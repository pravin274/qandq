package com.qqs.invsvcs.repository;

import com.qqs.invsvcs.model.Supplier;
import org.springframework.data.repository.CrudRepository;

public interface SupplierRepository  extends CrudRepository<Supplier, Integer>{

}
