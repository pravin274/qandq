package com.qqs.invsvcs.model;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "purchorder", schema = "invmgmnt", catalog = "")
public class SupplierPurchaseOrder {
    private int id;
    private Integer supplierId;
    private String poNumber;
    private Timestamp poDate;
    private String poFileName;
    private String poStatus;
    private String quotationNumber;
    private Timestamp quotationDate;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "supplierId")
    public Integer getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(Integer supplierId) {
        this.supplierId = supplierId;
    }

    @Column(name = "poNumber")
    public String getPoNumber() {
        return poNumber;
    }

    public void setPoNumber(String poNumber) {
        this.poNumber = poNumber;
    }

    @Column(name = "poDate")
    public Timestamp getPoDate() {
        return poDate;
    }

    public void setPoDate(Timestamp poDate) {
        this.poDate = poDate;
    }

    @Column(name = "poFileName")
    public String getPoFileName() {
        return poFileName;
    }

    public void setPoFileName(String poFileName) {
        this.poFileName = poFileName;
    }

    @Column(name = "poStatus")
    public String getPoStatus() {
        return poStatus;
    }

    public void setPoStatus(String poStatus) {
        this.poStatus = poStatus;
    }

    @Column(name = "quotationNumber")
    public String getQuotationNumber() {
        return quotationNumber;
    }

    public void setQuotationNumber(String quotationNumber) {
        this.quotationNumber = quotationNumber;
    }

    @Column(name = "quotationDate")
    public Timestamp getQuotationDate() {
        return quotationDate;
    }

    public void setQuotationDate(Timestamp quotationDate) {
        this.quotationDate = quotationDate;
    }


    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SupplierPurchaseOrder)) return false;
        SupplierPurchaseOrder that = (SupplierPurchaseOrder) o;
        return getId() == that.getId() &&
                Objects.equals(getSupplierId(), that.getSupplierId()) &&
                Objects.equals(getPoNumber(), that.getPoNumber()) &&
                Objects.equals(getPoDate(), that.getPoDate()) &&
                Objects.equals(getPoFileName(), that.getPoFileName()) &&
                Objects.equals(getPoStatus(), that.getPoStatus()) &&
                Objects.equals(getQuotationNumber(), that.getQuotationNumber()) &&
                Objects.equals(getQuotationDate(), that.getQuotationDate()) &&
                Objects.equals(getCreatedBy(), that.getCreatedBy()) &&
                Objects.equals(getCreatedDt(), that.getCreatedDt()) &&
                Objects.equals(getModifiedBy(), that.getModifiedBy()) &&
                Objects.equals(getModifiedDt(), that.getModifiedDt());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getSupplierId(), getPoNumber(), getPoDate(), getPoFileName(), getPoStatus(),
                getQuotationNumber(), getQuotationDate(), getCreatedBy(), getCreatedDt(), getModifiedBy(), getModifiedDt());
    }
}
