package com.qqs.invsvcs.service;

import com.qqs.invsvcs.model.PandLHeads;
import com.qqs.invsvcs.repository.PandLHeadsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import java.util.List;
import java.util.Optional;

@Component
public class PandLHeadsDataService {
    @Autowired
    private PandLHeadsRepository repository;

    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<PandLHeads> utils = new DataServiceUtils<>();


    public Optional<PandLHeads> getPandLHeadsById(Integer id) {
        return repository.findById(id);
    }

    public Optional<List<PandLHeads>> searchPandLHeads(List<SearchCriteria> params) {
        List<PandLHeads> result = utils.createPredicate(entityManager, params, PandLHeads.class);
        Optional<List<PandLHeads>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public Iterable<PandLHeads> getAllPandLHeads() {
        Iterable<PandLHeads> result = repository.findAll();
        return result;
    }

    @Transactional
    public PandLHeads savePandLHeads(PandLHeads item) {
        return repository.save(item);
    }

}
