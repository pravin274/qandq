package com.qqs.invsvcs.repository;

import com.qqs.invsvcs.model.InventoryStockDetailReport;
import com.qqs.invsvcs.model.StockStatusDetails;
import com.qqs.invsvcs.model.SupplierPoLineItem;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface InventoryStockDetailReportRepository extends CrudRepository<SupplierPoLineItem, Integer> {

    @Query(value = " WITH inwardQty AS (  " +
            " SELECT sum(iwl.quantity) as inwardQty,  supxp.productType as productType, supxp.productId  as productId FROM invmgmnt.inwardlineitem as iwl " +
            " inner join  invmgmnt.polineitem as poline on poline.id = iwl.poLineItemId " +
            " inner join  invmgmnt.supplierxproduct as supxp on supxp.id = poline.supplierXProductId " +
            " INNER JOIN `qqordermgmnt`.`codes` cdd ON cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL' " +
            " inner join invmgmnt.inward as iw on iw.id = iwl.inwardId and  DATE(CONVERT_TZ(iw.inwardDate,'GMT', cdd.description)) BETWEEN ?1 and ?2 " +
            "  group by 2,3  " +
            "  ),  consumption as ( " +
            " SELECT sum(quantity) as totCon, con.productId as productId, con.productType  as productType FROM invmgmnt.consumption AS con " +
            " INNER JOIN `qqordermgmnt`.`codes` cdd ON cdd.category = 'APP_TIME_ZONE' AND cdd.code = 'TZ_MYSQL'" +
            " where " +
            " DATE(CONVERT_TZ(con.consumptionDate,'GMT', cdd.description)) BETWEEN ?1 and ?2  group by  2, 3 " +
            " )  SELECT ifnull(iwq.inwardQty, 0)  as inwardQty, invp.openingStock as openingStock, ifnull( cn.totCon , 0) as totalConsumption, invp.productType as productType , " +
            "  invp.productId as productId, " +
            "  case invp.productType " +
            "        when 'part' then concat(pt.number, '-', pt.partRevNo) " +
            "        when 'tool' then tl.name " +
            "        when 'inserts' then ins.name " +
            "        when 'holder' then hld.name " +
            "        else  prd.name " +
            "    end as productName " +
            "  from invmgmnt.invproductdetails as invp" +
            " left outer join  inwardQty as  iwq  on invp.productId = iwq.productId and invp.productType = iwq.productType " +
            " left outer join consumption as cn on invp.productId = cn.productId and invp.productType = cn.productType " +
            " left outer join invmgmnt.product as prd on prd.id = invp.productId  " +
            " left outer join qqordermgmnt.part as pt on pt.id = invp.productId  " +
            " left outer join qandq.inserts as ins on ins.id = invp.productId " +
            " left outer join qandq.tool as tl on tl.id = invp.productId " +
            " left outer join qandq.holder as hld on hld.id = invp.productId;", nativeQuery = true)
    List<InventoryStockDetailReport> getInventoryStockDetailReport(String fromDate, String toDate);

    @Query(value = " SELECT maxPr.partId as productId, 'part' as productType, concat_ws(' - ',  pt.number, pt.partRevNo) as productName,  " +
            " maxPr.processOrder, count(maxPr.heatNoSerialNo) as stockQty FROM (" +
            " SELECT cp.partId, ct.heatNoSerialNo,ct.partStatus, prs.processOrder, ROW_NUMBER() OVER w AS 'rank' " +
            " FROM `qandq`.`controltask` ct, `qandq`.`process` prs, `qandq`.`controlplan` cp " +
            " WHERE ct.controlProcessId = prs.id AND prs.controlPlanId = cp.id AND ct.processStatus = 'Completed' " +
            " AND ct.operateDt BETWEEN ?1 AND ?2 " +
            " WINDOW w AS (PARTITION BY ct.heatNoSerialNo ORDER BY prs.processOrder desc) " +
            " order by cp.partId, ct.heatNoSerialNo, prs.processOrder ) AS maxPr, `qqordermgmnt`.`part` pt " +
            " WHERE pt.id = maxPr.partId AND maxPr.partStatus = 'APV' and maxPr.rank = 1 " +
            " group by partId, processOrder; ", nativeQuery = true)
    List<StockStatusDetails> getStockStatusDetail(String fromDate, String toDate);
}
