package com.qqs.invsvcs.model;


import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "consumption", schema = "invmgmnt", catalog = "")
public class Consumption {
    private int id;
    private Date consumptionDate;
    private Integer productId;
    private Integer categoryId;
    private String productType;
    private Integer brandId;
    private Double quantity;
    private Integer consumedBy;
    private Integer partId;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "consumptionDate")
    public Date getConsumptionDate() {
        return consumptionDate;
    }

    public void setConsumptionDate(Date consumptionDate) {
        this.consumptionDate = consumptionDate;
    }

    @Column(name = "productId")
    public Integer getProductId() { return productId; }

    public void setProductId(Integer productId) { this.productId = productId; }

    @Column(name = "categoryId")
    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    @Column(name = "productType")
    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    @Column(name = "brandId")
    public Integer getBrandId() { return brandId; }

    public void setBrandId(Integer brandId) { this.brandId = brandId; }

    @Column(name = "quantity")
    public Double getQuantity() { return quantity; }

    public void setQuantity(Double quantity) { this.quantity = quantity; }

    @Column(name = "consumedBy")
    public Integer getConsumedBy() { return consumedBy; }

    public void setConsumedBy(Integer consumedBy) { this.consumedBy = consumedBy; }

    @Column(name = "partId")
    public Integer getPartId() { return partId; }

    public void setPartId(Integer partId) { this.partId = partId; }

    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Consumption consumption = (Consumption) o;

        if (id != consumption.id) return false;
        if (!Objects.equals(consumptionDate, consumption.consumptionDate)) return false;
        if (!Objects.equals(productId, consumption.productId)) return false;
        if (!Objects.equals(categoryId, consumption.categoryId)) return false;
        if (!Objects.equals(productType, consumption.productType)) return false;
        if (!Objects.equals(brandId, consumption.brandId)) return false;
        if (!Objects.equals(quantity, consumption.quantity)) return false;
        if (!Objects.equals(consumedBy, consumption.consumedBy)) return false;
        if (!Objects.equals(partId, consumption.partId)) return false;
        if (!Objects.equals(createdBy, consumption.createdBy)) return false;
        if (!Objects.equals(createdDt, consumption.createdDt)) return false;
        if (!Objects.equals(modifiedBy, consumption.modifiedBy)) return false;
        if (!Objects.equals(modifiedDt, consumption.modifiedDt)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (consumptionDate != null ? consumptionDate.hashCode() : 0);
        result = 31 * result + (productId != null ? productId.hashCode() : 0);
        result = 31 * result + (categoryId != null ? categoryId.hashCode() : 0);
        result = 31 * result + (productType != null ? productType.hashCode() : 0);
        result = 31 * result + (brandId != null ? brandId.hashCode() : 0);
        result = 31 * result + (quantity != null ? quantity.hashCode() : 0);
        result = 31 * result + (consumedBy != null ? consumedBy.hashCode() : 0);
        result = 31 * result + (partId != null ? partId.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDt != null ? createdDt.hashCode() : 0);
        result = 31 * result + (modifiedBy != null ? modifiedBy.hashCode() : 0);
        result = 31 * result + (modifiedDt != null ? modifiedDt.hashCode() : 0);
        return result;
    }
}


