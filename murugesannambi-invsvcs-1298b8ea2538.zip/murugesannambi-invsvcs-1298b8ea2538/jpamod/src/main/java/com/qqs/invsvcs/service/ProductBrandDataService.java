package com.qqs.invsvcs.service;

import com.qqs.invsvcs.model.ProductBrand;
import com.qqs.invsvcs.repository.ProductBrandRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Component
public class ProductBrandDataService {
    @Autowired
    private ProductBrandRepository repository;

    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<ProductBrand> utils = new DataServiceUtils<>();


    public Optional<ProductBrand> getProductBrandById(Integer id) {
        return repository.findById(id);
    }

    public Optional<List<ProductBrand>> searchProductBrand(List<SearchCriteria> params) {
        List<ProductBrand> result = utils.createPredicate(entityManager, params, ProductBrand.class);
        Optional<List<ProductBrand>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public Iterable<ProductBrand> getAllProductBrand() {
        Iterable<ProductBrand> result = repository.findAll();
        return result;
    }

    public Iterable<ProductBrand> getAllProductBrandById(Set<Integer> productBrandIds) {
        Iterable<ProductBrand> result = repository.findAllById(productBrandIds);
        return result;
    }

    @Transactional
    public ProductBrand saveProductBrand(ProductBrand item) {
        return repository.save(item);
    }
}
