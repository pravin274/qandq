package com.qqs.invsvcs.model;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "pandlheads", schema = "invmgmnt", catalog = "")
public class PandLHeads {
    private int id;
    private String pandLCategory;
    private Integer parentHeadsId;
    private Integer displaySeq;
    private String heads;
    private String description;
    private String isUserGenerated;
    private Integer createdBy;
    private Timestamp createdDt;
    private Integer modifiedBy;
    private Timestamp modifiedDt;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "pandLCategory")
    public String getPandLCategory() {
        return pandLCategory;
    }

    public void setPandLCategory(String pandLCategory) {
        this.pandLCategory = pandLCategory;
    }

    @Column(name = "heads")
    public String getHeads() {
        return heads;
    }

    public void setHeads(String heads) {
        this.heads = heads;
    }

    @Column(name = "description")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Column(name = "parentHeadsId")
    public Integer getParentHeadsId() {
        return parentHeadsId;
    }

    public void setParentHeadsId(Integer parentHeadsId) {
        this.parentHeadsId = parentHeadsId;
    }

    @Column(name = "displaySeq")
    public Integer getDisplaySeq() {
        return displaySeq;
    }

    public void setDisplaySeq(Integer displaySeq) {
        this.displaySeq = displaySeq;
    }

    @Column(name = "isUserGenerated", updatable = false)
    public String getIsUserGenerated() {
        return isUserGenerated;
    }

    public void setIsUserGenerated (String isUserGenerated) {
        this.isUserGenerated = isUserGenerated;
    }

    @Column(name = "createdBy", updatable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "createdDt", updatable = false)
    public Timestamp getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Timestamp createdDt) {
        this.createdDt = createdDt;
    }

    @Column(name = "modifiedBy")
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Column(name = "modifiedDt")
    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }



    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PandLHeads pandLHeads = (PandLHeads) o;

        if (id != pandLHeads.id) return false;
        if (!Objects.equals(pandLCategory, pandLHeads.pandLCategory)) return false;
        if (!Objects.equals(parentHeadsId, pandLHeads.parentHeadsId)) return false;
        if (!Objects.equals(heads, pandLHeads.heads)) return false;
        if (!Objects.equals(description, pandLHeads.description)) return false;
        if (!Objects.equals(isUserGenerated, pandLHeads.isUserGenerated)) return false;
        if (!Objects.equals(displaySeq, pandLHeads.displaySeq)) return false;
        if (!Objects.equals(createdBy, pandLHeads.createdBy)) return false;
        if (!Objects.equals(createdDt, pandLHeads.createdDt)) return false;
        if (!Objects.equals(modifiedBy, pandLHeads.modifiedBy)) return false;
        if (!Objects.equals(modifiedDt, pandLHeads.modifiedDt)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (pandLCategory != null ? pandLCategory.hashCode() : 0);
        result = 31 * result + (heads != null ? heads.hashCode() : 0);
        result = 31 * result + (parentHeadsId != null ? parentHeadsId.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (isUserGenerated != null ? isUserGenerated.hashCode() : 0);
        result = 31 * result + (displaySeq != null ? displaySeq.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDt != null ? createdDt.hashCode() : 0);
        result = 31 * result + (modifiedBy != null ? modifiedBy.hashCode() : 0);
        result = 31 * result + (modifiedDt != null ? modifiedDt.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "PandLHeads{" +
                "id=" + id +
                ", pandLCategory='" + pandLCategory + '\'' +
                ", parentHeadsId=" + parentHeadsId +
                ", displaySeq=" + displaySeq +
                ", heads='" + heads + '\'' +
                ", description='" + description + '\'' +
                ", isUserGenerated='" + isUserGenerated + '\'' +
                ", createdBy=" + createdBy +
                ", createdDt=" + createdDt +
                ", modifiedBy=" + modifiedBy +
                ", modifiedDt=" + modifiedDt +
                '}';
    }
}
