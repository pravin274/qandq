package com.qqs.invsvcs.service;

import com.qqs.invsvcs.model.Product;
import com.qqs.invsvcs.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import java.util.List;
import java.util.Optional;

@Component
public class ProductDataService {

    @Autowired
    private ProductRepository repository;

    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<Product> utils = new DataServiceUtils<>();


    public Optional<Product> getProductById(Integer id) {
        return repository.findById(id);
    }

    public Optional<List<Product>> getProductByCategoryId(Integer id) {
        return repository.findAllByCategoryId(id);
    }

    public Optional<List<Product>> searchProduct(List<SearchCriteria> params) {
        List<Product> result = utils.createPredicate(entityManager, params, Product.class);
        Optional<List<Product>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public Iterable<Product> getAllProduct() {
        Iterable<Product> result = repository.findAll();
        return result;
    }

    @Transactional
    public Product saveProduct(Product item) {
        return repository.save(item);
    }
}
