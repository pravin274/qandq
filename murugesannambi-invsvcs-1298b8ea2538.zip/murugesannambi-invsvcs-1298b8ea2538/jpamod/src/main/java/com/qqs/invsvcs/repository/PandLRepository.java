package com.qqs.invsvcs.repository;

import com.qqs.invsvcs.model.PandL;
import com.qqs.invsvcs.model.PandLReportData;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface PandLRepository extends CrudRepository<PandL, Integer> {

    @Query(value = " SELECT date_format(pdl.fromDate, '%Y-%m') as transMonthYear, cd.code as headsCat, " +
            " cd.description as headsCatDesc, cd.displaySeq as catOrder, pdlh.heads as heads, " +
            " pdlh.description as headsDesc,  pdlh.displaySeq as headsOrder, round(sum(pdl.amount),2) as totalAmt " +
            " FROM `invmgmnt`.`pandl`pdl, `invmgmnt`.`pandlheads`pdlht, `invmgmnt`.`pandlheads`pdlh, `qqordermgmnt`.`codes` cd " +
            " WHERE pdlht.id = pdl.headsId AND cd.code = pdlh.pandLCategory AND pdlh.id = pdlht.parentHeadsId " +
            " AND cd.category = 'P_AND_L' AND pdl.fromDate between ?1 and ?2 " +
            " GROUP BY 1,2,3,4,5,6,7 with Rollup " +
            " having ((pdlh.displaySeq is not null and pdlh.heads is not null and pdlh.description is not null " +
            " and cd.displaySeq is not null and cd.description is not null) or " +
            " (pdlh.displaySeq is null and pdlh.heads is null and pdlh.description is null " +
            " and cd.displaySeq is null and cd.description is null and cd.code is not null) ) ", nativeQuery = true)
    List<PandLReportData> getPandLReport(String fromDate, String toDate);


    @Query(value = " SELECT cd.code as headsCat, cd.description as headsCatDesc, cd.displaySeq as catOrder, " +
            " pdlh.heads as heads, pdlh.description as headsDesc,  pdlh.displaySeq as headsOrder " +
            " FROM `invmgmnt`.`pandlheads`pdlh, `qqordermgmnt`.`codes` cd " +
            " WHERE cd.code = pdlh.pandLCategory AND cd.category = 'P_AND_L' AND pdlh.parentHeadsId = 0 " +
            " ORDER BY cd.displaySeq, pdlh.displaySeq ", nativeQuery = true)
    List<PandLReportData> getPandLHeadsData ();

}
