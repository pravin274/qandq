package com.qqs.invsvcs.service;

import com.qqs.invsvcs.model.Consumption;
import com.qqs.invsvcs.repository.ConsumptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import java.util.List;
import java.util.Optional;

@Component
public class ConsumptionDataService {
    @Autowired
    private ConsumptionRepository repository;

    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<Consumption> utils = new DataServiceUtils<>();


    public Optional<Consumption> getConsumptionById(Integer id) {
        return repository.findById(id);
    }

    public Optional<List<Consumption>> searchConsumption(List<SearchCriteria> params) {
        List<Consumption> result = utils.createPredicate(entityManager, params, Consumption.class);
        Optional<List<Consumption>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public Iterable<Consumption> getAllConsumption() {
        Iterable<Consumption> result = repository.findAll();
        return result;
    }

    @Transactional
    public Consumption saveConsumption(Consumption item) {
        return repository.save(item);
    }
}
