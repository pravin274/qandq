package com.qqs.invsvcs.service;

import com.qqs.invsvcs.model.ProductCategory;
import com.qqs.invsvcs.repository.ProductCategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import java.util.List;
import java.util.Optional;

@Component
public class ProductCategoryDataService {
    @Autowired
    private ProductCategoryRepository repository;
    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<ProductCategory> utils = new DataServiceUtils<>();


    public Optional<ProductCategory> getProductCategoryById(Integer id) {
        return repository.findById(id);
    }

    public Optional<List<ProductCategory>> searchProductCategory(List<SearchCriteria> params) {
        List<ProductCategory> result = utils.createPredicate(entityManager, params, ProductCategory.class);
        Optional<List<ProductCategory>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public Iterable<ProductCategory> getAllProductCategory() {
        Iterable<ProductCategory> result = repository.findAll();
        return result;
    }

    @Transactional
    public ProductCategory saveProductCategory(ProductCategory item) {
        return repository.save(item);
    }
}
