package com.qqs.invsvcs.model;

public interface PandLReportData {

    String getHeadsCatDesc();
    String getHeadsCat();
    Integer getCatOrder();
    String getHeads();
    String getHeadsDesc();
    Integer getHeadsOrder();
    String getTransMonthYear();
    Double getTotalAmt();

}
