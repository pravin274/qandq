package com.qqs.invsvcs.repository;

import com.qqs.invsvcs.model.SupplierXProduct;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface SupplierXProductRepository  extends CrudRepository<SupplierXProduct, Integer> {

    Optional<List<SupplierXProduct>> findBySupplierId(Integer supplierId);

    Optional<List<SupplierXProduct>> findByProductIdAndProductType(Integer productId, String productType);

    Optional<List<SupplierXProduct>> findByProductIdAndSupplierId(Integer productId, Integer supplierId);

}
