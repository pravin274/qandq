package com.qqs.invsvcs.service;

import com.qqs.invsvcs.model.SupplierXProduct;
import com.qqs.invsvcs.repository.SupplierXProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import java.util.List;
import java.util.Optional;

@Component
public class SupplierXProductDataService {
    @Autowired
    private SupplierXProductRepository repository;

    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<SupplierXProduct> utils = new DataServiceUtils<>();


    public Optional<SupplierXProduct> getSupplierXProductById(Integer id) {
        return repository.findById(id);
    }

    public Optional<List<SupplierXProduct>> searchSupplierXProduct(List<SearchCriteria> params) {
        List<SupplierXProduct> result = utils.createPredicate(entityManager, params, SupplierXProduct.class);
        Optional<List<SupplierXProduct>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public Iterable<SupplierXProduct> getAllSupplierXProduct() {
        Iterable<SupplierXProduct> result = repository.findAll();
        return result;
    }

    public Optional<List<SupplierXProduct>> getAllSupplierXProductBySupplierId(Integer supplierId) {
        Optional<List<SupplierXProduct>> result = repository.findBySupplierId(supplierId);
        return result;
    }

    public Optional<List<SupplierXProduct>> getAllSupplierXProductByProductIdAndType(Integer productId, String productType) {
        Optional<List<SupplierXProduct>> result = repository.findByProductIdAndProductType(productId, productType);
        return result;
    }

    public Optional<List<SupplierXProduct>> getAllSXPByProductIdAndSupplierId(Integer productId, Integer supplierId) {
        Optional<List<SupplierXProduct>> result = repository.findByProductIdAndSupplierId(productId, supplierId);
        return result;
    }

    @Transactional
    public SupplierXProduct saveSupplierXProduct(SupplierXProduct item) {
        return repository.save(item);
    }
}
