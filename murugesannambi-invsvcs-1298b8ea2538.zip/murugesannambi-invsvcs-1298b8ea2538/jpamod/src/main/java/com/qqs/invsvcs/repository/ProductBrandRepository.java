package com.qqs.invsvcs.repository;

import com.qqs.invsvcs.model.ProductBrand;
import org.springframework.data.repository.CrudRepository;

public interface ProductBrandRepository extends CrudRepository<ProductBrand, Integer> {
}
