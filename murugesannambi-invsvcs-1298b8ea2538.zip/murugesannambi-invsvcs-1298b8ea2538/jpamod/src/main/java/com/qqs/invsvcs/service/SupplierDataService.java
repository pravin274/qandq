package com.qqs.invsvcs.service;

import com.qqs.invsvcs.model.Supplier;
import com.qqs.invsvcs.repository.SupplierRepository;
import com.qqs.invsvcs.repository.SupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Component
public class SupplierDataService {

    @Autowired
    private SupplierRepository repository;

    @Resource
    private EntityManager entityManager;

    private DataServiceUtils<Supplier> utils = new DataServiceUtils<>();


    public Optional<Supplier> getSupplierById(Integer id) {
        return repository.findById(id);
    }

    public Optional<List<Supplier>> searchSupplier(List<SearchCriteria> params) {
        List<Supplier> result = utils.createPredicate(entityManager, params, Supplier.class);
        Optional<List<Supplier>> resultSet = Optional.ofNullable(result);
        return resultSet;
    }

    public Iterable<Supplier> getAllSupplier() {
        Iterable<Supplier> result = repository.findAll();
        return result;
    }

    @Transactional
    public Supplier saveSupplier(Supplier item) {
        return repository.save(item);
    }
}
